import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useApp, Navi, PlayBtn, TT, ActionBar } from './ui.jsx';
import { say, sfx, srAvailable, listenHandle, recAvailable, startRecording, playRecording } from './audio.js';
import { matchSpeech, shuffle } from './engine.js';
import { voicePut, today } from './store.js';
import { tally } from './activities.jsx';


// Mic-first answer: he just says it. Kind matching; a miss is "Navi heard X. Once more?" (never a red X), choices appear
// after a miss (or with "Tap instead"); after 2 misses: "Sounds close! Listen and compare", then move on with no penalty.
export function VoiceAnswer({ lang, prompt, sayText, targets, opts, onDone, sess, startTap, autoNext = true, praise, label }) {
  const { S, set } = useApp();
  const canMic = srAvailable(lang);
  const [mode, setMode] = useState(canMic && !startTap ? 'mic' : 'tap');
  const [phase, setPhase] = useState('idle'); // idle | listening | right | close | reveal
  const [misses, setMisses] = useState(0);
  const [heard, setHeard] = useState('');
  const [gone, setGone] = useState([]);
  const [showChoices, setShowChoices] = useState(!canMic || !!startTap);
  const handle = useRef(null), recRef = useRef(null), blobRef = useRef(null), doneRef = useRef(false);
  const choices = useMemo(() => (opts ? shuffle(opts.map((o, i) => ({ ...o, i }))) : []), [opts]);
  const finish = (res) => { if (doneRef.current) return; doneRef.current = true; onDone(res); };
  const success = (viaMic) => {
    setPhase('right'); sfx('good');
    set((s) => { if (viaMic) { s[lang].speak.tries++; s[lang].speak.good++; } s.rupees += misses ? 1 : 2; });
    if (sess && viaMic) { sess.speak.tries++; sess.speak.good++; }
    if (sayText && !viaMic) say(lang, sayText);
    if (autoNext) setTimeout(() => finish({ ok: true, mic: viaMic, tries: misses }), 1100);
  };
  const start = async () => {
    if (phase === 'listening' || phase === 'right') return;
    setPhase('listening'); setHeard('');
    blobRef.current = null;
    if (recAvailable()) { try { recRef.current = await startRecording(); } catch (e) { recRef.current = null; } }
    const h = listenHandle(lang); handle.current = h;
    const r = await h.promise;
    handle.current = null;
    if (recRef.current) { try { blobRef.current = await recRef.current.stop(); } catch (e) {} recRef.current = null; }
    if (!srAvailable(lang) && !(r.alts && r.alts.length)) { setPhase('idle'); setMode('tap'); setShowChoices(true); return; }
    const m = matchSpeech(lang, r.alts || [], targets);
    if (m.ok) {
      setHeard(m.heard); success(true);
      // keep one clip of his voice per day for the weekly parent card
      if (blobRef.current && S.lastClipDay !== today()) { voicePut('clip:latest', { text: targets[0], lang, mime: blobRef.current.type, date: Date.now(), blob: blobRef.current }); set((s) => { s.lastClipDay = today(); }); }
      return;
    }
    const nm = misses + 1; setMisses(nm); setHeard(m.heard || '');
    set((s) => { s[lang].speak.tries++; }); if (sess) sess.speak.tries++;
    if (nm >= 2) { setPhase('close'); sfx('try'); compare(); return; }
    setPhase('idle'); setShowChoices(true); sfx('try');
  };
  const compare = async () => { if (sayText) await say(lang, sayText); if (blobRef.current) await playRecording(blobRef.current); };
  const stop = () => { if (handle.current) handle.current.stop(); };
  // hold Space to talk
  useEffect(() => {
    if (mode !== 'mic') return;
    const down = (e) => { if (e.code !== 'Space' || e.repeat || /input|textarea/i.test((e.target && e.target.tagName) || '')) return; e.preventDefault(); start(); };
    const up = (e) => { if (e.code !== 'Space') return; e.preventDefault(); stop(); };
    window.addEventListener('keydown', down); window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); };
  }, [mode, phase, misses]);
  useEffect(() => () => { stop(); }, []);
  const tap = (o) => {
    if (phase === 'right' || gone.includes(o.i)) return;
    if (o.ok) { success(false); return; }
    sfx('try'); const g = [...gone, o.i]; setGone(g);
    set((s) => tally(s, lang, 'listening', sess));
    if (g.length >= 2 || g.length >= choices.length - 1) { setPhase('reveal'); if (sayText) say(lang, sayText); }
  };
  const right = choices.find((c) => c.ok);
  return (
    <div className="card pop" data-testid="voice" data-say={globalThis.__LQ_TEST__ ? targets[0] : undefined}>
      {prompt}
      {mode === 'mic' && phase !== 'right' && phase !== 'close' && (
        <div className="center" style={{ margin: '14px 0 6px' }}>
          <button className={`btn mic ${phase === 'listening' ? 'good' : 'primary'}`} onClick={phase === 'listening' ? stop : start} data-testid="mic" aria-label="Say it">
            {phase === 'listening' ? '👂 Listening…' : `🎤 ${label || 'Say it'}`}
          </button>
          <div className="muted small" style={{ marginTop: 6 }}>or hold <kbd>Space</kbd> while you talk</div>
        </div>
      )}
      {heard && phase === 'idle' && <div className="fb info" style={{ marginTop: 8 }}>Navi heard “<span lang={lang} className={lang === 'fa' ? 'fa' : ''}>{heard}</span>”. Once more?</div>}
      {!heard && misses > 0 && phase === 'idle' && <div className="fb info" style={{ marginTop: 8 }}>Navi didn't catch that. Once more?</div>}
      {phase === 'close' && (
        <div className="fb info" style={{ marginTop: 10 }} data-testid="compare">
          <div><b>Sounds close!</b> Listen and compare.</div>
          <div className="row c" style={{ marginTop: 8 }}>
            {sayText && <button className="btn sm" onClick={() => say(lang, sayText)}>🔈 Navi</button>}
            {blobRef.current && <button className="btn sm" onClick={() => playRecording(blobRef.current)}>🎙️ You</button>}
          </div>
        </div>
      )}
      {phase === 'right' && <div className="fb good" style={{ marginTop: 10 }}>{praise || '✨'} {heard ? <span className="small">(Navi heard “<span lang={lang} className={lang === 'fa' ? 'fa' : ''}>{heard}</span>”)</span> : null}</div>}
      {showChoices && choices.length > 0 && phase !== 'close' && (
        <div className="choices" style={{ marginTop: 10, gridTemplateColumns: choices.some((c) => (c.x && (c.x.t || '').length > 14)) ? '1fr' : undefined }}>
          {choices.map((o) => (
            <button key={o.i} className={`choice ${phase === 'right' && o.ok ? 'right' : ''} ${gone.includes(o.i) ? 'gone' : ''} ${phase === 'reveal' && o.ok ? 'right' : ''}`} onClick={() => tap(o)} data-ok={o.ok ? '1' : '0'}>
              {o.pic ? <span className="pic emoji">{o.pic}</span> : null}
              {o.x ? <TT lang={lang} x={o.x} showW={false} /> : null}
              {o.sub ? <span className="sub">{o.sub}</span> : null}
            </button>
          ))}
        </div>
      )}
      {phase === 'reveal' && right && <div className="fb info" style={{ marginTop: 10 }}>It's <b><TT lang={lang} x={right.x} showW={false} /></b>. It will come back later!</div>}
      {mode === 'mic' && !showChoices && phase !== 'right' && phase !== 'close' && choices.length > 0 && (
        <div className="center"><button className="linkbtn" onClick={() => { setShowChoices(true); }} data-testid="tap-instead">Tap instead</button></div>
      )}
      <ActionBar>
        {phase === 'close' || phase === 'reveal' ? <button className="btn primary wide" onClick={() => finish({ ok: phase === 'close', mic: true, tries: misses, close: phase === 'close', revealed: phase === 'reveal' })} data-testid="next">Next</button>
          : phase === 'right' ? <button className="btn primary wide" onClick={() => finish({ ok: true, mic: mode === 'mic', tries: misses })} data-testid="next">Next</button>
          : <button className="btn ghost wide" disabled>{mode === 'mic' ? 'Say it or tap an answer' : 'Tap an answer'}</button>}
      </ActionBar>
    </div>
  );
}
