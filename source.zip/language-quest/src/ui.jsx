import React, { useState, useEffect, useRef, useContext, createContext } from 'react';
import { createPortal } from 'react-dom';
import { say, sfx } from './audio.js';
import { name, portrait, guideImg } from './skin.js';
import { learnedSet, canRead, vowelize } from './scriptdata.js';

export const AppCtx = createContext(null);
export const useApp = () => useContext(AppCtx);

const IC = {
  back: 'M15 5l-7 7 7 7', close: 'M6 6l12 12M18 6L6 18', gear: 'M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7zM19.4 13a7.6 7.6 0 0 0 0-2l2-1.6-2-3.4-2.4 1a7.4 7.4 0 0 0-1.7-1L15 3.5h-4l-.4 2.5a7.4 7.4 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.6a7.6 7.6 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7.4 7.4 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.4 7.4 0 0 0 1.7-1l2.4 1 2-3.4z',
  speaker: 'M4 9v6h4l5 4V5L8 9H4zM16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12', home: 'M4 11l8-7 8 7M6 10v10h12V10',
};
export function Icon({ n, size = 22 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={IC[n]} /></svg>;
}

export function NaviOrb({ size = 52 }) {
  return (
    <svg className="orbsvg" width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <radialGradient id="nv" cx=".5" cy=".5" r=".5"><stop offset="0" stopColor="#fff" /><stop offset=".35" stopColor="#bfe9ff" /><stop offset="1" stopColor="#3aa0e0" stopOpacity="0" /></radialGradient>
        <linearGradient id="wg" x1="0" x2="1"><stop offset="0" stopColor="#e8f8ff" stopOpacity=".9" /><stop offset="1" stopColor="#9fd8ff" stopOpacity=".3" /></linearGradient>
      </defs>
      <ellipse cx="18" cy="24" rx="14" ry="8" fill="url(#wg)" transform="rotate(-25 18 24)" />
      <ellipse cx="46" cy="24" rx="14" ry="8" fill="url(#wg)" transform="rotate(25 46 24)" />
      <ellipse cx="20" cy="40" rx="10" ry="6" fill="url(#wg)" transform="rotate(20 20 40)" opacity=".8" />
      <ellipse cx="44" cy="40" rx="10" ry="6" fill="url(#wg)" transform="rotate(-20 44 40)" opacity=".8" />
      <circle cx="32" cy="32" r="22" fill="url(#nv)" />
      <circle cx="32" cy="32" r="7" fill="#fff" />
    </svg>
  );
}

export function Rich({ text }) {
  if (typeof text !== 'string') return text;
  const parts = text.split(/([\u0600-\u06FF\u200c][\u0600-\u06FF\u200c\u064B-\u0652 ]*[\u0600-\u06FF\u064B-\u0652]|[\u0600-\u06FF])/);
  return parts.map((p, i) => (i % 2 ? <bdi key={i} className="fa" lang="fa" dir="rtl">{p}</bdi> : p));
}
const splitSentences = (t) => { const out = []; let cur = ''; for (let i = 0; i < t.length; i++) { cur += t[i]; if (/[.!?؟]/.test(t[i]) && (t[i + 1] === ' ' || i === t.length - 1) && !/\b(e\.g|Mr|Mrs)\.$/.test(cur)) { out.push(cur.trim()); cur = ''; } } if (cur.trim()) out.push(cur.trim()); return out; };
// ONE safe image helper for every picture in the app: never renders src="" or a missing src (which would load the page
// itself and show alt text); a missing or failing image becomes a styled fallback badge (no alt text, aria-label only).
export function SafeImg({ src, label = '', fallback = '✦', className = '', width, height, style }) {
  const [bad, setBad] = useState(null);
  const ok = typeof src === 'string' && /\S/.test(src) && bad !== src;
  if (!ok) {
    if (fallback === null) return null;
    return <span className={`imgfb ${className}`} data-imgfb="1" role={label ? 'img' : undefined} aria-label={label || undefined} aria-hidden={label ? undefined : 'true'} style={{ width, height, fontSize: width ? Math.max(12, Math.round(width * 0.6)) : undefined, ...(style || {}) }}>{fallback}</span>;
  }
  return <img src={src} alt="" aria-label={label || undefined} className={className || undefined} width={width} height={height} style={style} onError={() => setBad(src)} />;
}
function GuideOrb({ small }) {
  const src = guideImg();
  return <SafeImg className="orbsvg" src={src} width={small ? 44 : 56} height={small ? 44 : 56} fallback={<NaviOrb size={small ? 40 : 52} />} />;
}
// Navi says one sentence at a time; tap the bubble to skip ahead.
export function Navi({ children, small }) {
  const text = typeof children === 'string' ? children : null;
  const sents = text ? splitSentences(text) : null;
  const [k, setK] = useState(0);
  useEffect(() => { setK(0); }, [text]);
  useEffect(() => {
    if (!sents || k >= sents.length - 1) return;
    const t = setTimeout(() => setK((x) => Math.min(x + 1, sents.length - 1)), 1400 + sents[k].length * 55);
    return () => clearTimeout(t);
  }, [k, text]);
  const more = sents && k < sents.length - 1;
  return (
    <div className="navi" role="status" aria-live="polite">
      <div className="orb" title={name('navi')} aria-label={name('navi')}><GuideOrb small={small} /></div>
      <div className={`bubble ${more ? 'more' : ''}`} onClick={() => more && setK(k + 1)} data-testid="navi">{sents ? <Rich text={sents[Math.min(k, sents.length - 1)]} /> : children}{more ? <span className="nextdot" aria-hidden="true"> ›</span> : null}</div>
    </div>
  );
}

export function Portrait({ who, size = '', className = '', pose }) {
  const p = portrait(who, pose);
  const [bad, setBad] = useState(null);
  const ok = p.url && bad !== p.url;
  return (
    <div className={`portrait ${size} ${className}`} style={ok ? null : { background: `radial-gradient(circle at 40% 30%, ${p.color}, #0b1a16)` }} title={name(who)} role="img" aria-label={name(who)}>
      {ok ? <SafeImg src={p.url} fallback={<span className="emoji" aria-hidden="true">{p.emoji}</span>} /> : <span className="emoji" aria-hidden="true">{p.emoji}</span>}
    </div>
  );
}

export function PlayBtn({ lang, text, auto, sm, label }) {
  const [busy, setBusy] = useState(false);
  const [fail, setFail] = useState(false);
  const lastTap = useRef(0);
  const go = async () => { if (!text) return; const slow = Date.now() - lastTap.current < 3000; lastTap.current = Date.now(); setBusy(true); const ok = await say(lang, text, { slow }); setBusy(false); setFail(ok === false); };
  useEffect(() => { if (auto && text) { const t = setTimeout(go, 250); return () => clearTimeout(t); } }, [text]);
  return (
    <button className={`play ${sm ? 'sm' : ''}`} onClick={go} aria-label={label || 'Listen'} title={fail ? 'No audio on this device yet: a grown-up can record it in Family voices' : 'Listen'} style={fail ? { opacity: 0.55 } : null} data-noaudio={fail ? '1' : undefined}>
      <Icon n="speaker" size={sm ? 18 : 24} />
    </button>
  );
}

// Target-language text with transliteration (Farsi) and the written form when it differs.
export function useReading() {
  const ctx = useContext(AppCtx);
  const step = ctx && ctx.S ? ctx.S.fa.script.step || 0 : 0;
  const marks = ctx && ctx.S ? ctx.S.settings.marks || 'auto' : 'auto';
  return { set: learnedSet(step), step, marks };
}
export function TT({ lang, x, big, showTr = true, showW = true, cls = '', item }) {
  const R = useReading();
  if (!x) return null;
  if (lang === 'es') return <span className={`${big ? 'word' : ''} ${cls}`} lang="es">{x.t}</span>;
  // Script only for words made of letters he has learned; otherwise the spoken transliteration is the main text.
  if (!canRead(x.t, R.set)) {
    return (
      <span className={cls} style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
        <span className={`trmain ${big ? 'word' : ''}`}>{x.tr || x.t}</span>
        {showW && x.wt && x.wt !== x.tr ? <span className="written"><b>Written:</b> <span className="tr">{x.wt}</span></span> : null}
      </span>
    );
  }
  const marksOn = R.marks === 'on' || (R.marks === 'auto' && R.step < 13);
  const shown = marksOn ? vowelize(x.t, x.tr) || x.t : x.t;
  return (
    <span className={cls} style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
      <span className={`fa ${big ? 'word' : ''}`} lang="fa">{shown}</span>
      {showTr && x.tr ? <span className="tr">{x.tr}</span> : null}
      {showW && x.w && x.w !== x.t ? (
        <span className="written"><b>Written:</b> <span lang="fa" className="fa">{x.w}</span>{showTr && x.wt ? <> · <span className="tr">{x.wt}</span></> : null}</span>
      ) : null}
    </span>
  );
}

// Rendered into <body>: a card's backdrop-filter/transform would otherwise trap position:fixed.
export function ActionBar({ children }) {
  return createPortal(<div className="actionbar"><div className="inner">{children}</div></div>, document.body);
}

export function Modal({ children, onClose }) {
  useEffect(() => {
    const k = (e) => { if (e.key === 'Escape' && onClose) onClose(); };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, []);
  return <div className="modal" onClick={(e) => { if (e.target === e.currentTarget && onClose) onClose(); }}><div className="card pop">{children}</div></div>;
}

// Hint ladder: 1 = Navi's question and its clue, 2 = one wrong choice disappears, 3 = Navi plays the answer.
export function Hints({ question, clue, onRemove, onPlay }) {
  const [step, setStep] = useState(0);
  const [asking, setAsking] = useState(false);
  const labels = ['Hint', 'Hint 2: remove one', 'Hint 3: hear it'];
  return (
    <div style={{ display: 'grid', gap: 8 }}>
      {asking && step === 0 && (
        <div className="card soft"><Navi small>{question || 'What do you already know that could help?'}</Navi>
          <div className="row c" style={{ marginTop: 8 }}><button className="btn sm primary" onClick={() => { setAsking(false); setStep(1); }}>Show the clue</button></div></div>
      )}
      {step >= 1 && clue && <div className="fb info">💡 <Rich text={clue} /></div>}
      {step < 3 && !asking && (
        <div className="row"><button className="btn sm ghost" data-testid="hint" onClick={() => { sfx('tap'); if (step === 0) setAsking(true); else if (step === 1) { onRemove && onRemove(); setStep(2); } else { onPlay && onPlay(); setStep(3); } }}>💡 {labels[step]}</button></div>
      )}
    </div>
  );
}
export function HintLadder({ questions, hints, onUse }) {
  const [step, setStep] = useState(0); // hints revealed
  const [asking, setAsking] = useState(false);
  if (!hints || !hints.length) return null;
  const q = (questions && questions[step]) || 'What do you already know that could help?';
  return (
    <div className="grid" style={{ display: 'grid', gap: 8 }}>
      {step > 0 && <div className="fb info">💡 {hints.slice(0, step).map((h, i) => <div key={i}>{h}</div>)}</div>}
      {asking ? (
        <div className="card soft">
          <Navi small>{q}</Navi>
          <div className="row c" style={{ marginTop: 10 }}>
            <button className="btn sm" onClick={() => setAsking(false)}>I've got it!</button>
            <button className="btn sm primary" onClick={() => { setAsking(false); setStep(step + 1); onUse && onUse(step + 1); }}>Show hint {step + 1}</button>
          </div>
        </div>
      ) : step < Math.min(3, hints.length) ? (
        <div className="row"><button className="btn sm ghost" onClick={() => { sfx('tap'); setAsking(true); }}>💡 Hint ({step}/{Math.min(3, hints.length)})</button></div>
      ) : null}
    </div>
  );
}

// "Why?" before submit: tap a reason or type a few words.
export function Why({ reasons, value, onChange, prompt }) {
  const [typed, setTyped] = useState('');
  return (
    <div className="card soft">
      <div style={{ fontWeight: 800, marginBottom: 8 }}>🤔 {prompt || 'Why? Pick your reason first.'}</div>
      <div className="why">
        {reasons.map((r, i) => (
          <button key={i} className={value && value.i === i ? 'sel' : ''} onClick={() => onChange({ i, text: r })}>{r}</button>
        ))}
      </div>

    </div>
  );
}

const ACC = ['á', 'é', 'í', 'ó', 'ú', 'ñ', 'ü', '¿', '¡'];
export function AccentBar({ onInsert }) {
  return (
    <div className="accents" aria-label="Accent buttons">
      {ACC.map((c) => <button key={c} onMouseDown={(e) => e.preventDefault()} onClick={() => onInsert(c)}>{c}</button>)}
    </div>
  );
}
export function insertAt(ref, val, setVal, c) {
  const el = ref.current;
  if (!el) { setVal(val + c); return; }
  const s = el.selectionStart ?? val.length, e = el.selectionEnd ?? val.length;
  const nv = val.slice(0, s) + c + val.slice(e);
  setVal(nv);
  requestAnimationFrame(() => { el.focus(); el.setSelectionRange(s + c.length, s + c.length); });
}

const KROWS = [
  ['ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج', 'چ'],
  ['ش', 'س', 'ی', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ک', 'گ'],
  ['ظ', 'ط', 'ز', 'ر', 'ذ', 'د', 'پ', 'و', 'ژ', 'آ'],
];
export function PersianKeyboard({ onKey, highlight = [] }) {
  return (
    <div className="kbd" aria-label="Persian keyboard">
      {KROWS.map((r, i) => (
        <div className="krow" key={i}>
          {r.map((k) => <button key={k} className={highlight.includes(k) ? 'hi' : ''} onClick={() => { sfx('tap'); onKey(k); }}>{k}</button>)}
        </div>
      ))}
      <div className="krow">
        <button className="wide" onClick={() => onKey('BACK')} aria-label="Backspace">⌫</button>
        <button className="wide" onClick={() => onKey('\u200c')} title="Half-space (ZWNJ)">half-space</button>
        <button className="wide" onClick={() => onKey(' ')}>space</button>
        <button className="wide" onClick={() => onKey('؟')}>؟</button>
      </div>
    </div>
  );
}

export function Stars({ n, of = 3 }) {
  return <span className="stars" aria-label={`${n} of ${of} stars`}>{'★'.repeat(n)}<span style={{ opacity: 0.3 }}>{'★'.repeat(Math.max(0, of - n))}</span></span>;
}

export function Dots({ total, at }) {
  return <div className="dots" aria-label={`Step ${at + 1} of ${total}`}>{Array.from({ length: total }, (_, i) => <i key={i} className={i < at ? 'done' : i === at ? 'now' : ''} />)}</div>;
}

export function useKey(handler, deps = []) {
  useEffect(() => {
    const f = (e) => { if (e.target && /input|textarea/i.test(e.target.tagName)) return; handler(e); };
    window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f);
  }, deps);
}

export function Motes() {
  const r = useRef(Array.from({ length: 14 }, (_, i) => ({ l: (i * 37) % 100, t: 30 + ((i * 53) % 65), d: (i * 0.7) % 9 })));
  return <div className="motes">{r.current.map((m, i) => <i key={i} style={{ left: m.l + '%', top: m.t + '%', animationDelay: m.d + 's' }} />)}</div>;
}
