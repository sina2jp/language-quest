// Optional AI partner: Anthropic calls with the shared family key. The model is auto-detected: GET /v1/models and pick the
// newest available haiku (fast) model, when the key is saved and on first use; on a model-not-found error, re-detect once.
import { getAIKey } from './store.js';
const HDR = (key) => ({ 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' });
export async function detectModel(key = getAIKey()) {
  if (!key) throw new Error('No key saved');
  const r = await fetch('https://api.anthropic.com/v1/models?limit=100', { headers: HDR(key) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((j.error && j.error.message) || 'HTTP ' + r.status);
  const list = (j.data || []).slice().sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
  const pick = list.find((m) => /haiku/i.test(m.id || '')) || list.find((m) => /fast|flash|mini/i.test(m.id || '')) || list[0];
  if (!pick) throw new Error('No models available for this key');
  return pick.id;
}
const notFound = (r, j) => r.status === 404 || /not_found/.test((j && j.error && j.error.type) || '') || /model/i.test((j && j.error && j.error.message) || '') && r.status === 400;
export async function aiMessage({ body, model, onModel }) {
  const key = getAIKey(); if (!key) throw new Error('no key');
  let m = model;
  if (!m) { m = await detectModel(key); if (onModel) onModel(m); }
  for (let attempt = 0; attempt < 2; attempt++) {
    const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'content-type': 'application/json', ...HDR(key) }, body: JSON.stringify({ ...body, model: m }) });
    const j = await r.json().catch(() => ({}));
    if (r.ok) return j;
    if (attempt === 0 && notFound(r, j)) { m = await detectModel(key); if (onModel) onModel(m); continue; }
    throw new Error((j.error && j.error.message) || 'HTTP ' + r.status);
  }
  throw new Error('no answer');
}
