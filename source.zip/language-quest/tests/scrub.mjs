// Packaging scrub check: the dist, the preview and source.zip contain no internal hosts, tool names or paths.
// Run after node build.mjs: node tests/scrub.mjs [dist] [preview]
import fs from 'fs'; import path from 'path'; import { execSync } from 'child_process';
const b = fs.readFileSync(new URL('../build.mjs', import.meta.url), 'utf8');
const SCRUB = new RegExp(Buffer.from(b.match(/Buffer\.from\('([A-Za-z0-9+/=]+)', 'base64'\)\.toString\('utf8'\), 'i'\)/)[1], 'base64').toString('utf8'), 'i');
const planted = ['fwd' + 'proxy route', 'see internal' + 'meta.com', 'Meta' + 'mate said'];
let fail = planted.some((p) => !SCRUB.test(p)) ? 1 : 0; console.log((fail ? 'FAIL' : 'PASS') + ' scrub pattern catches planted examples');
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const TEXT = /\.(html|js|mjs|jsx|css|json|md|webmanifest|txt|py|sh|svg)$/i;
const hits = []; const scan = (root, label) => { for (const f of walk(root)) if (TEXT.test(f)) { const m = fs.readFileSync(f, 'utf8').replace(/[A-Za-z0-9+/=]{200,}/g, ' ').match(SCRUB); if (m) hits.push(`${label}/${path.relative(root, f)}: ${m[0]}`); } };
const DIST = path.resolve(process.argv[2] || 'dist'), PREV = path.resolve(process.argv[3] || '/tmp/lq/preview');
scan(DIST, 'dist'); scan(PREV, 'preview');
const z = '/tmp/lq_scrub_test'; fs.rmSync(z, { recursive: true, force: true }); fs.mkdirSync(z); execSync(`cd ${z} && unzip -q ${path.join(DIST, 'source.zip')}`); scan(z, 'source.zip'); fs.rmSync(z, { recursive: true, force: true });
console.log((hits.length ? 'FAIL' : 'PASS') + ` scrub: ${hits.length} hits in dist, preview and source.zip` + (hits.length ? ' — ' + hits.slice(0, 5).join(' | ') : ''));
process.exit(fail || hits.length ? 1 : 0);
