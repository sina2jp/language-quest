// Family Wallet bridge: family-wallet.js (shared, copied byte-identical; never edited) + this app's hooks.
// Courage shards for Language Quest; rupees are shared by all the family apps.
import './family-wallet.js';
import { on } from './hooks.js';
import { KITIDX } from './packs.js';
import { checkPin, pinIsSet } from './store.js';
import { effectiveSkin } from './sync.js';
export const FW = globalThis.FamilyWallet || null;
export const APP = 'language';
let lessonId = 'language';
export const setLesson = (id) => { lessonId = 'language:' + id; };
// kit picture for a catalog kit id (e.g. "saria_bust_curious", "kokiri_16x9", "medallion_fire"): the largest size we ship
export function imageFor(kitId) {
  const H = globalThis.HyruleKit; if (!H || !kitId) return null;
  let best = null, bestN = 0;
  for (const p of Object.keys((KITIDX && KITIDX.files) || {})) {
    const base = p.split('/').pop();
    if (base.startsWith(kitId + '_')) { const m = base.slice(kitId.length + 1).match(/^(\d+)\.(webp|png)$/); if (m && +m[1] > bestN) { best = p; bestN = +m[1]; } }
  }
  if (!best) return null;
  // only pictures from the loaded kit pack (blob/data URLs): before the pack is ready, show the item's emoji instead of
  // letting the browser request a kit path that does not exist as a file
  try { const u = H.url(best); return u && /^(blob:|data:)/.test(u) ? u : null; } catch (e) { return null; }
}
export const skinOf = (S) => (effectiveSkin(S) === 'fallback' ? 'grove' : 'hyrule');
// the old shop items, priced in shared rupees (bought in the Hyrule Market or in Talon's say-it-to-buy shop)
export function legacyItems(SHOP) {
  return (SHOP.items || []).map((it) => ({ id: 'language.' + it.id, app: APP, cat: 'legacy', slot: it.id.startsWith('tunic') ? 'language.tunic' : it.id.startsWith('navi') ? 'language.navi' : 'language.shield', price: it.price, emoji: it.icon || '🎁', image: it.image || null,
    name: { hyrule: it.en, grove: it.en, classic: it.en } }));
}
// PIN pad for the wallet (approving tickets): resolves true after the right PIN
export function pinCheck() {
  return new Promise((resolve) => {
    const wrap = document.createElement('div'); wrap.className = 'lq-pin-modal'; wrap.setAttribute('role', 'dialog'); wrap.setAttribute('aria-label', 'Grown-up PIN');
    wrap.innerHTML = '<div class="card center"><b>Grown-up: type your PIN</b><input class="field" type="password" inputmode="numeric" maxlength="4" data-testid="fw-pin" style="width:140px;text-align:center;margin:10px auto;display:block"><div class="fb info small" data-testid="fw-pin-err" style="display:none">That PIN isn’t right.</div><div class="row c"><button class="btn" data-x="cancel">Cancel</button><button class="btn primary" data-x="ok" data-testid="fw-pin-ok">Approve</button></div></div>';
    document.body.appendChild(wrap);
    const inp = wrap.querySelector('input'); const err = wrap.querySelector('[data-testid=fw-pin-err]');
    const done = (v) => { wrap.remove(); resolve(v); };
    const ok = async () => { if (!pinIsSet()) { err.textContent = 'A grown-up needs to set a PIN in the Parent corner first.'; err.style.display = ''; return; } if (await checkPin(inp.value)) done(true); else { err.style.display = ''; inp.value = ''; } };
    wrap.querySelector('[data-x=ok]').onclick = ok; wrap.querySelector('[data-x=cancel]').onclick = () => done(false);
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') ok(); }); setTimeout(() => inp.focus(), 30);
  });
}
// ---------- No farming (v7.3): tokens only for true learning ----------
// Shards are paid ONCE per thing learned (FW.earnOnce, on a pass only); rupees once per item per 30 days (FW.rupeesOnce).
// Repeats (graduated or review content, grown-up practice replays) pay nothing; their minutes still count as minutes.
let repeatNow = false, reviewNow = false;
// practice replays (graduated content a grown-up unlocked): no treasure at all, minutes count as repeat minutes
export const setRepeat = (v) => { repeatNow = !!v; };
// due reviews: the review pass pays once (payOnce), but its minutes are repeat minutes (no time shards)
export const setReview = (v) => { reviewNow = !!v; };
export const isRepeat = () => repeatNow || reviewNow;
const diag = (m) => { try { (globalThis.__lqDiagAdd || console.warn)('wallet: ' + m); } catch (e) {} };
// family-wallet 1.1 fallback (the 1.2 module has these calls built in)
const ONCE_LOCAL = 'langQuest.once';
function legacyOnce(onceId, shards, label) {
  const tag = 'once:' + APP + ':' + onceId;
  try { if ((FW.events({ app: APP, limit: 1000 }) || []).some((e) => e.tag === tag)) return { paid: 0, banked: 0, reason: 'repeat' }; } catch (e) {}
  const r = FW.earn(APP, 'progress', shards, label, { tag });
  return { paid: (r && r.granted) || 0, banked: 0, reason: r && r.why === 'guessing' ? 'guessing' : r && r.why === 'cap' ? 'cap' : null };
}
function legacyRupees(itemId) {
  let m = {}; try { m = JSON.parse(localStorage.getItem(ONCE_LOCAL) || '{}') || {}; } catch (e) {}
  const t = m[itemId]; if (t && Date.now() - t < 30 * 864e5) return 0;
  const b0 = FW.balance().rupees; FW.answer(APP, true, 'r1:' + itemId); const paid = Math.max(0, FW.balance().rupees - b0);
  if (paid) { m[itemId] = Date.now(); try { localStorage.setItem(ONCE_LOCAL, JSON.stringify(m)); } catch (e) {} }
  return paid;
}
// A pass earned during the module's rapid-guessing pause (or a wallet error) is not lost: it is kept here (this laptop
// only) and paid by retryPending() on the next calm screen or start. The onceId is not used up by 'guessing'.
const PENDING_KEY = 'langQuest.oncePending';
const readPending = () => { try { const a = JSON.parse(localStorage.getItem(PENDING_KEY) || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } };
const writePending = (a) => { try { if (a.length) localStorage.setItem(PENDING_KEY, JSON.stringify(a.slice(-50))); else localStorage.removeItem(PENDING_KEY); } catch (e) {} };
function earnRaw(onceId, shards, label) { return typeof FW.earnOnce === 'function' ? FW.earnOnce(APP, onceId, shards, label) : legacyOnce(onceId, shards, label); }
// the grown-up's Hub rule "Rewards only for new learning (no repeats)" (family-wallet 1.2 policy; on by default)
export function noRepeats() { try { return !(FW && typeof FW.policy === 'function' && FW.policy().noRepeats === false); } catch (e) { return true; } }
// pay shards once for a pass; returns { paid, banked, reason } ('repeat' | 'cap' | 'guessing' | 'practice' | null).
// Practice replays pay nothing while the no-repeats rule is on; with the rule off the module decides (repeats pay again).
export function payOnce(onceId, shards, label) {
  if (!FW) return { paid: 0, banked: 0, reason: 'off' };
  if (repeatNow && noRepeats()) return { paid: 0, banked: 0, reason: 'practice' };
  let r;
  try { r = earnRaw(onceId, shards, label) || { paid: 0, banked: 0, reason: null }; }
  catch (e) { diag(e && e.message); r = { paid: 0, banked: 0, reason: 'error' }; }
  if (r.reason === 'guessing' || r.reason === 'error') { const a = readPending().filter((x) => x.onceId !== onceId); a.push({ onceId, shards, label, at: Date.now() }); writePending(a); r = { ...r, pending: true }; }
  return r;
}
export function retryPending() {
  if (!FW) return 0; const a = readPending(); if (!a.length) return 0;
  let paid = 0; const keep = [];
  for (const x of a) {
    if (Date.now() - (x.at || 0) > 14 * 864e5) continue;
    let r = null; try { r = earnRaw(x.onceId, x.shards, x.label); } catch (e) { r = { reason: 'error' }; }
    if (r && (r.reason === 'guessing' || r.reason === 'error')) keep.push(x); else paid += (r && r.paid) || 0;
  }
  writePending(keep);
  return paid;
}
// first correct answer per item within 30 days; returns the rupees paid
// (family-wallet 1.2 counts a repeat for the Hub's summary and pays 0; the 1.1 fallback skips practice entirely)
export function payRupees(itemId, n, label) {
  if (!FW || !itemId) return 0;
  if (typeof FW.rupeesOnce !== 'function' && repeatNow) return 0;
  try { return (typeof FW.rupeesOnce === 'function' ? FW.rupeesOnce(APP, String(itemId), n, label) : legacyRupees(String(itemId))) || 0; }
  catch (e) { diag(e && e.message); return 0; }
}
// earning moments from the app's events (see hooks.js); a wallet problem can never break the app
let wired = false;
export function wireWallet() {
  if (!FW || wired) return; wired = true;
  try { if (typeof FW.releaseBanked === 'function') FW.releaseBanked(APP); } catch (e) {}
  try { retryPending(); } catch (e) {}
  on((type, d) => {
    try {
      if (type === 'answer') {
        if (d.correct) payRupees(d.itemId, 1, d.label ? 'Correct: ' + String(d.label).slice(0, 40) : 'Correct answer');
        else if (!repeatNow) FW.answer(APP, false, d.lessonId || lessonId); // feeds the module's rapid-guessing check; pays nothing
      } else if (type === 'secret') {
        // hidden finds (tap the moon…) are not learning: rupees only; hero challenges (learning milestones) pay a shard once
        if (d.kind === 'find') payRupees('secret:' + d.id, 10, 'Found a secret'); else payOnce('secret:' + d.id, 1, 'Hero challenge: ' + (d.name || d.id));
      }
      else if (type === 'mission:done') payRupees('mission:' + new Date().toISOString().slice(0, 10), 5, 'Home mission'); // self-reported: rupees only
      // lessons, quests, stories and bosses pay through payOnce() on a pass (firststeps.jsx, quest.jsx)
    } catch (e) { diag(e && e.message); }
  });
}
// one-time migration of this app's local rupees, waiting Skulltula tokens and old shop items
export function migrateOnce(S) {
  if (!FW) return;
  try { FW.migrateApp(APP, { rupees: Math.max(0, S.rupees || 0), tokens: Math.max(0, (S.treasure && S.treasure.tokens) || 0), owned: ((S.shop && S.shop.owned) || []).map((id) => 'language.' + id) }); } catch (e) {}
}
export const owns = (id) => { try { return !!(FW && FW.owns(id)); } catch (e) { return false; } };
export const PARTNERS = ['zelda', 'impa', 'ruto', 'darunia', 'malon', 'saria'];
export const partner = () => PARTNERS.find((p) => owns('partner.' + p)) || null;
