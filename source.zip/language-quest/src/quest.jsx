import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useApp, Navi, Portrait, PlayBtn, TT, ActionBar, Modal, Stars, Dots, Rich, Icon, SafeImg, hintsUsed, resetHints } from './ui.jsx';
import { SecretTap } from './treasure.jsx';
import { say, sfx, stopAudio } from './audio.js';
import { planQuest, introduce, grade, record, unitState, levelOf, shuffle, LEVELS } from './engine.js';
import { today } from './store.js';
import { LANG, T, getUnit, unitItems, allItems, triplets, getStory, storyTargets } from './content.js';
import { PLACES, name, cap, placeName, rewardName, rewardIcon, kitIcon, rewardImg, rewardNameK } from './skin.js';
import { LearnCard, Pick, SpellIt, SpeedRound, Triplets, GrammarStep, WriteStep, RolePlay, tally, showTr, praise, Pic, distractors, picKey } from './activities.jsx';
import { VoiceAnswer } from './voice.jsx';
import { ScriptLesson, LESSONS } from './script.jsx';
import { GREET, DAYS, TPR, LINES, COUNT, CHUNKS, makeChunk } from './routine.js';
import { UNIT_NOUNS, conceptOf } from './nouns.js';

const isTest = () => !!globalThis.__LQ_TEST__;
const opt = (lang, x, ok, extra) => ({ x: T(lang, x), ok, ...(extra || {}) });

// ---------- 1. Mentor greeting (same questions daily; answers grow over the weeks) ----------
export function Greeting({ lang, unit, onDone, sess }) {
  const { S, set } = useApp();
  const L = S[lang];
  const who = (PLACES[unit.n] || PLACES[1]).teacher;
  const weeks = Math.floor((today() - (L.firstDay || today())) / 7);
  const level = Math.min(2, weeks);
  const qs = useMemo(() => GREET[lang].filter((g) => (g.from || 0) <= weeks), [lang]);
  const m = L.mission;
  const [phase, setPhase] = useState(m && !m.done && m.day < today() ? 'mission' : 0);
  useEffect(() => { set((s) => { if (!s[lang].firstDay) s[lang].firstDay = today(); }); }, []);
  const g = phase === 'mission' ? null : qs[phase];
  useEffect(() => { if (phase !== 'mission' && !g) onDone({}); }, [phase]);
  if (phase === 'mission') {
    return (
      <div className="card pop center" data-testid="mission-check">
        <Portrait who={who} size="lg" />
        <Navi>{'Did you do your home mission?'}</Navi>
        <div className="ex" style={{ margin: '10px auto' }}>🏠 {m.en}{m.say ? <> — <TT lang={lang} x={T(lang, m.say)} showW={false} /></> : null}</div>
        <ActionBar>
          <button className="btn wide" onClick={() => { set((s) => { s[lang].mission.done = true; }); setPhase(0); }}>Not yet</button>
          <button className="btn primary wide" data-testid="mission-yes" onClick={() => { sfx('rupee'); set((s) => { s[lang].mission.done = true; s.rupees += 5; s[lang].missions = (s[lang].missions || 0) + 1; }); setPhase(0); }}>I did it! +5 💎</button>
        </ActionBar>
      </div>
    );
  }
  if (!g) return null;
  const q = T(lang, g.q);
  let opts, targets;
  if (g.day) {
    const d = new Date().getDay(); const days = DAYS[lang];
    const others = shuffle([0, 1, 2, 3, 4, 5, 6].filter((x) => x !== d)).slice(0, 2);
    opts = [opt(lang, days[d], true), ...others.map((o) => opt(lang, days[o], false))];
    targets = [T(lang, days[d]).t, T(lang, days[d]).w];
  } else {
    const chips = g.levels[level];
    opts = chips.map((c) => opt(lang, c, true));
    targets = chips.flatMap((c) => { const x = T(lang, c); return [x.t, x.w]; }).concat(g.levels[0].map((c) => T(lang, c).t));
  }
  return <VoiceAnswer key={phase} lang={lang} sess={sess} sayText={null} targets={targets} opts={opts} praise={praise(lang, true)}
    prompt={<><div className="row c"><Portrait who={who} size="sm" /><div><div className="muted small">{cap(name(who))} says</div>
      <div className="big row"><PlayBtn lang={lang} text={q.say} sm auto /><TT lang={lang} x={q} showTr={lang === 'fa'} /></div><div className="muted">{q.en}</div></div></div></>}
    onDone={() => (phase + 1 < qs.length ? setPhase(phase + 1) : onDone({}))} />;
}

// ---------- 2. Review: mic-first "say it" ----------
export function ReviewSay({ lang, item, pool, onDone, sess }) {
  const { set } = useApp();
  const opts = useMemo(() => [{ x: item, ok: true, pic: null }, ...distractors(item, pool, 2).map((d) => ({ x: d, ok: false }))], [item.id]);
  const bareT = lang === 'es' ? item.t.replace(/^(el|la|los|las) /i, '') : null;
  return <VoiceAnswer lang={lang} sess={sess} sayText={item.say} targets={[item.t, item.w, bareT].filter(Boolean)} opts={opts} praise={praise(lang, true)}
    prompt={<><Navi small>{`Say it in ${LANG[lang].name}!`}</Navi><div className="learn" style={{ margin: '10px 0' }}><div className="pic emoji"><Pic item={item} /></div><div className="big">{item.en}</div></div></>}
    onDone={(r) => { set((s) => { grade(s[lang], item.id, r.revealed ? 'wrong' : r.ok && !r.tries ? 'first' : 'retry'); record(s[lang], !!r.ok); }); if (sess) { sess.reviewed++; sess.total++; if (r.ok && !r.tries) sess.correct++; } onDone(r); }} />;
}

// ---------- 2b. Power phrase: a core chunk (quiero / mikhâm …) recycled with this unit's nouns ----------
export function unitNouns(lang, n, variety) {
  const all = allItems(lang, variety);
  return (UNIT_NOUNS[lang][n] || []).map((en) => { const c = conceptOf(en); const it = c && all.find((x) => x.kind === 'w' && x.b === c[lang]); return it ? { ...it, c } : null; }).filter(Boolean);
}
export function PowerPhrase({ lang, noun, nouns, k, onDone, sess }) {
  let x = null, others = [];
  try {
    x = makeChunk(lang, k, noun);
    others = shuffle(nouns.filter((o) => o.id !== noun.id)).slice(0, 2).map((o) => ({ x: makeChunk(lang, k, o), ok: false }));
  } catch (e) { x = null; }
  if (!x || !x.t) return <div className="card pop center" data-testid="chunk-skip"><Navi small>{'Power phrase coming soon!'}</Navi><ActionBar><button className="btn primary wide" onClick={() => onDone({})} data-testid="next">Next</button></ActionBar></div>;
  const tpl = CHUNKS[lang][k % CHUNKS[lang].length].en;
  return <VoiceAnswer lang={lang} sess={sess} sayText={x.say} targets={[x.t, x.w].filter(Boolean)} opts={[{ x, ok: true }, ...others]} praise={praise(lang, true)}
    prompt={<><div className="row" data-noun={noun.c ? noun.c.en : ''}><span className="chip">⚡ Power phrase</span><span className="muted">{tpl}</span></div><div className="learn" style={{ margin: '10px 0' }}><div className="pic emoji"><Pic item={noun} /></div><div className="row c"><PlayBtn lang={lang} text={x.say} sm /><span className="big">{x.en}</span></div></div></>}
    onDone={onDone} />;
}

// ---------- 3. Farsi new word, test-first ----------
export function NewWordFa({ item, pool, onDone, sess }) {
  const { set } = useApp();
  const [phase, setPhase] = useState('test');
  if (phase === 'test') return <Pick lang="fa" item={item} pool={pool} mode="listen" sess={sess} onDone={(r) => { set((s) => introduce(s.fa, item.id)); if (r.ok) { set((s) => { s.fa.srs[item.id].b = Math.max(2, s.fa.srs[item.id].b); s.fa.srs[item.id].d = today() + 2; s.fa.knew = (s.fa.knew || 0) + 1; }); setPhase('knew'); } else setPhase('learn'); }} />;
  if (phase === 'knew') {
    const opts = [{ x: item, ok: true }, ...distractors(item, pool, 2).map((d) => ({ x: d, ok: false }))];
    return <VoiceAnswer lang="fa" sess={sess} sayText={item.say} targets={[item.t, item.w]} opts={opts} praise={praise('fa', true)} startTap={false}
      prompt={<><div className="fb good">⭐ You already knew this one!</div><div className="learn" style={{ margin: '10px 0' }}><div className="pic emoji"><Pic item={item} /></div><div className="big">{item.en}</div><Navi small>Now say it out loud!</Navi></div></>}
      onDone={() => onDone({ ok: true })} />;
  }
  if (phase === 'learn') return <LearnCard lang="fa" item={item} onNext={() => setPhase('check')} />;
  return <Pick lang="fa" item={item} pool={pool} mode="picword" sess={sess} onDone={onDone} />;
}

// ---------- 4. Owl story (grows each day; introduces 2-3 words; 3 voice questions) ----------
export function OwlStory({ lang, unit, onDone, sess }) {
  const { S, set } = useApp();
  const story = getStory(lang, unit.n);
  const u = unitState(S[lang], unit.n);
  const k = Math.min(u.story || 0, (story ? story.parts.length : 1) - 1);
  const part = story && story.parts[k];
  const prev = story && k > 0 ? story.parts[k - 1] : null;
  const targetsItems = storyTargets(lang, unit.n, k, S.settings.variety);
  const [phase, setPhase] = useState(prev ? 'retell' : 'listen');
  const [qi, setQi] = useState(0);
  const lines = (part ? part.lines : []).map((l) => ({ ...T(lang, l), e: l.e }));
  const plines = (prev ? prev.lines : []).map((l) => ({ ...T(lang, l), e: l.e }));
  const playAll = async (ls) => { for (const l of ls) { await say(lang, l.say); await new Promise((r) => setTimeout(r, 250)); } };
  useEffect(() => { if (phase === 'retell') playAll(plines).then(() => setPhase((p) => (p === 'retell' ? 'listen' : p))); }, []);
  useEffect(() => { if (phase === 'listen') { const t = setTimeout(() => playAll(lines), 300); return () => clearTimeout(t); } }, [phase]);
  const finish = () => {
    set((s) => { for (const it of targetsItems) introduce(s[lang], it.id); const uu = unitState(s[lang], unit.n); uu.story = (uu.story || 0) + 1; uu.spk = (uu.spk || 0) + 1; if (story && k >= story.parts.length - 1) { s.treasure.flags.story = 1; } });
    if (sess) sess.newItems += targetsItems.length;
    onDone({ ids: targetsItems.map((x) => x.id) });
  };
  useEffect(() => { if (!part) onDone({}); }, []);
  const q0 = part && phase === 'q' ? part.qs[qi] : 1;
  useEffect(() => { if (part && phase === 'q' && !part.qs[qi]) finish(); }, [phase, qi]);
  if (!part || !q0) return null;
  const title = T(lang, story.title);
  const owl = <div className="row"><Portrait who="kaepora" size="sm" /><div className="grow"><div className="muted small">{cap(name('kaepora'))}'s story · day {k + 1}</div><h3 style={{ margin: 0 }}>{lang === 'fa' ? <TT lang="fa" x={title} showW={false} /> : title.t}</h3></div></div>;
  if (phase === 'retell' || phase === 'listen') {
    return (
      <div className="card pop" data-testid="story">
        {owl}
        {phase === 'retell' && <div className="ex" style={{ marginTop: 10, opacity: 0.85 }}><div className="muted small">Last time…</div>{plines.map((l, i) => <div key={i} className="row"><span className="emoji">{l.e}</span><TT lang={lang} x={l} showTr={lang === 'fa'} showW={false} /></div>)}</div>}
        {phase === 'listen' && <>
          <div className="storypic emoji">{lines.map((l) => l.e).join(' ')}</div>
          {lines.map((l, i) => <div key={i} className="ex row" style={{ marginTop: 8 }}><PlayBtn lang={lang} text={l.say} sm /><div><div className="big"><TT lang={lang} x={l} showTr={lang === 'fa'} /></div><div className="muted">{l.en}</div></div></div>)}
          <div className="row" style={{ justifyContent: 'flex-end' }}><SecretTap id="owl" label="a sparkle in the story" /></div>
          {targetsItems.length > 0 && <div className="row c" style={{ marginTop: 10, gap: 8 }}>{targetsItems.map((it) => <span key={it.id} className="chip newword"><Pic item={it} /> <TT lang={lang} x={it} showW={false} /> = {it.en}</span>)}</div>}
          <div className="center" style={{ marginTop: 10 }}><button className="linkbtn" onClick={() => playAll(lines)} data-testid="replay">🔁 Want to hear that again?</button></div>
        </>}
        <ActionBar><button className="btn primary wide" disabled={phase !== 'listen'} onClick={() => setPhase('q')} data-testid="next">{phase === 'retell' ? 'Remembering…' : 'Questions!'}</button></ActionBar>
      </div>
    );
  }
  const q = part.qs[qi];
  const qq = T(lang, q.q, null, q.en);
  const opts = (q.opts || []).map((o, i) => ({ x: T(lang, o), ok: i === q.a }));
  const ans = T(lang, q.opts[q.a]);
  return <VoiceAnswer key={qi} lang={lang} sess={sess} sayText={ans.say} targets={[ans.t, ans.w].filter(Boolean)} opts={opts} praise={praise(lang, true)}
    prompt={<>{owl}<div className="storypic small emoji">{lines.map((l) => l.e).join(' ')}</div><div className="ex row" style={{ marginTop: 8 }}><PlayBtn lang={lang} text={qq.say} sm auto /><div><div className="big"><TT lang={lang} x={qq} showTr={lang === 'fa'} /></div><div className="muted">{q.en || qq.en}</div></div></div>
      <div className="center"><button className="linkbtn" onClick={() => playAll(lines)}>🔁 Want to hear that again?</button></div></>}
    onDone={() => (qi + 1 < part.qs.length ? setQi(qi + 1) : finish())} />;
}

// ---------- 5. Kokiri sword training (60-second movement break, not scored) ----------
export function SwordTraining({ lang, onDone }) {
  const cmds = useMemo(() => shuffle(TPR[lang]).slice(0, 8), [lang]);
  const total = isTest() ? 3 : 60;
  const [t, setT] = useState(0);
  const [i, setI] = useState(-1);
  const per = total / cmds.length;
  useEffect(() => { if (t >= total) return; const h = setTimeout(() => setT(t + 1), 1000); return () => clearTimeout(h); }, [t]);
  useEffect(() => { const ni = Math.min(cmds.length - 1, Math.floor(t / per)); if (ni !== i && t < total) { setI(ni); const c = cmds[ni]; const x = lang === 'es' ? T('es', c[0]) : T('fa', c[0]); say(lang, x.say); } }, [t]);
  const c = cmds[Math.max(0, i)];
  const x = lang === 'es' ? { t: c[0], say: c[0], en: c[1] } : T('fa', c[0]);
  const emo = lang === 'es' ? c[2] : c[1];
  return (
    <div className="card pop center" data-testid="tpr">
      <h2>🗡️ Kokiri sword training</h2>
      <Navi small>{t >= total ? 'Great training, hero!' : 'Stand up! Do what you hear.'}</Navi>
      {t < total ? <>
        <div className="huge emoji" style={{ fontSize: '5rem', margin: '10px 0' }}>{emo}</div>
        <div className="big"><TT lang={lang} x={x} showTr={lang === 'fa'} showW={false} /></div>
        <div className="muted">{x.en}</div>
        <div className="bar" style={{ marginTop: 14 }}><i style={{ width: `${(t / total) * 100}%` }} /></div>
      </> : <div className="reward"><div className="item emoji">💪</div></div>}
      <ActionBar>
        {t >= total ? <button className="btn primary wide" onClick={() => onDone({})} data-testid="next">Back to the quest</button>
          : <button className="btn ghost wide" onClick={() => onDone({})} data-testid="skip-tpr">Skip</button>}
      </ActionBar>
    </div>
  );
}

// ---------- 6. Boss: heart bar = unit progress; mic-first; one template question and one spiral question ----------
function bossQuestions(lang, unit, S, variety) {
  const L = S[lang]; const out = [];
  const lines = (unit.boss && unit.boss.lines) || [];
  const u = unitState(L, unit.n);
  if (lines.length) { const l = lines[((u.bossSeen || 0) * 2) % lines.length]; out.push({ q: T(lang, l.q, variety, l.en), opts: l.opts.map((o, i) => ({ x: T(lang, o, variety), ok: i === l.a })), ans: T(lang, l.opts[l.a], variety) }); }
  // template from the unit's words he has met
  const met = unitItems(lang, unit.n, variety).filter((it) => it.kind === 'w' && L.srs[it.id] && it.e && !/^to /.test(it.en || ''));
  const pool = allItems(lang, variety).filter((it) => it.kind === 'w' && it.e && !/^to /.test(it.en || ''));
  const nouns = lang === 'es' ? met.filter((it) => /^(el|la|los|las) /.test(it.t)) : met;
  if (nouns.length) {
    const it = nouns[Math.floor(Math.random() * nouns.length)];
    if ((u.bossSeen || 0) % 2 === 0) {
      const ds = distractors(it, lang === 'es' ? pool.filter((x) => /^(el|la|los|las) /.test(x.t)) : pool, 2);
      const art = (x) => x.t.replace(/^el /, 'un ').replace(/^la /, 'una ').replace(/^los /, 'unos ').replace(/^las /, 'unas ');
      if (lang === 'es') out.push({ pic: it, q: { t: LINES.es.whatIs, say: LINES.es.whatIs, en: 'What is this?' }, opts: [it, ...ds].map((x, i) => ({ x: { t: 'Es ' + art(x) + '.', say: 'Es ' + art(x) + '.' }, ok: i === 0 })), ans: { t: 'Es ' + art(it) + '.', say: 'Es ' + art(it) + '.' }, extra: [it.t.replace(/^(el|la|los|las) /, ''), art(it)] });
      else out.push({ pic: it, q: T('fa', LINES.fa.whatIs), opts: [it, ...ds].map((x, i) => ({ x, ok: i === 0 })), ans: it });
    } else {
      const n = 2 + Math.floor(Math.random() * 4);
      const others = shuffle([2, 3, 4, 5].filter((x) => x !== n)).slice(0, 2);
      const fem = lang === 'es' && /^las? /.test(it.t);
      const qx = lang === 'es' ? { t: fem ? '¿Cuántas hay?' : '¿Cuántos hay?', say: fem ? '¿Cuántas hay?' : '¿Cuántos hay?', en: 'How many are there?' } : T('fa', LINES.fa.howMany);
      const cx = (k) => (lang === 'es' ? { t: COUNT.es[k], say: COUNT.es[k] } : T('fa', COUNT.fa[k]));
      out.push({ pic: it, count: n, q: qx, opts: [n, ...others].map((k, i) => ({ x: cx(k), ok: i === 0 })), ans: cx(n) });
    }
  }
  // spiral: one question from an earlier unit's boss (or from the story so far)
  if (unit.n > 1) {
    const en = 1 + Math.floor(Math.random() * (unit.n - 1)); const eu = getUnit(lang, en);
    const el = eu && eu.boss && eu.boss.lines && eu.boss.lines[Math.floor(Math.random() * eu.boss.lines.length)];
    if (el) out.push({ spiral: true, q: T(lang, el.q, variety, el.en), opts: el.opts.map((o, i) => ({ x: T(lang, o, variety), ok: i === el.a })), ans: T(lang, el.opts[el.a], variety) });
  } else {
    const st = getStory(lang, unit.n); const k = Math.max(0, (u.story || 1) - 1);
    const sq = st && st.parts[k] && st.parts[k].qs[2];
    if (sq) out.push({ q: T(lang, sq.q, variety, sq.en), opts: sq.opts.map((o, i) => ({ x: T(lang, o), ok: i === sq.a })), ans: T(lang, sq.opts[sq.a]) });
  }
  while (out.length < 3 && lines.length) { const l = lines[(out.length * 3 + (u.bossSeen || 0)) % lines.length]; out.push({ q: T(lang, l.q, variety, l.en), opts: l.opts.map((o, i) => ({ x: T(lang, o, variety), ok: i === l.a })), ans: T(lang, l.opts[l.a], variety) }); }
  return out.slice(0, 3);
}
export function Boss({ lang, unit, items, sess, onDone }) {
  const { S, set, setBg } = useApp();
  const place = PLACES[unit.n];
  const variety = S.settings.variety;
  const qs = useMemo(() => bossQuestions(lang, unit, S, variety), []);
  const total = items.length || 1;
  const metCount = () => items.filter((it) => S[lang].srs[it.id]).length;
  const hpStart = useRef(1 - (S[lang].units[unit.n] && S[lang].units[unit.n].metAtBoss != null ? S[lang].units[unit.n].metAtBoss : 0) / total).current;
  const [phase, setPhase] = useState('intro');
  const [k, setK] = useState(0);
  const [right, setRight] = useState(0);
  const [result, setResult] = useState(null);
  const [shake, setShake] = useState(false);
  useEffect(() => { if (place.bossBg && setBg) setBg(place.bossBg); sfx('boss'); return () => setBg && setBg(null); }, []);
  const hpNow = phase === 'end' ? Math.max(0, 1 - metCount() / total) : hpStart;
  const Hearts = ({ hp }) => { const n = 10, full = Math.round(hp * n); return <div className="hearts bossbar" aria-label={`Boss hearts ${full} of ${n}`}>{Array.from({ length: n }, (_, i) => <span key={i} style={{ opacity: i < full ? 1 : 0.2 }}>💜</span>)}</div>; };
  const end = (r) => {
    let res;
    const met = metCount();
    set((s) => {
      const uu = unitState(s[lang], unit.n); uu.bossSeen = (uu.bossSeen || 0) + 1; uu.metAtBoss = met;
      if (met >= total && r >= 2) { uu.done = true; uu.doneAt = Date.now(); uu.hp = 0; res = 'defeated'; if (!hintsUsed()) s.treasure.flags.nohint = 1; s.rupees += 20; if (place.reward) s.hc = (s.hc || 0) + 1; s.toys.ocarina = true; }
      else res = met >= total ? 'almost' : 'hit';
    });
    sess.boss = `${name(place.boss)}: ${res}`;
    setResult(res); setPhase('end'); sfx(res === 'defeated' ? 'win' : 'good');
  };
  if (!qs.length) return <div className="card"><Navi>The boss is resting today.</Navi><ActionBar><button className="btn primary wide" onClick={() => onDone({})} data-testid="next">Next</button></ActionBar></div>;
  if (phase === 'intro') return (
    <div className="card pop center boss" data-testid="boss-intro">
      <Portrait who={place.boss} size="lg" className="pop" />
      <h2>{cap(name(place.boss))}!</h2><Hearts hp={hpStart} />
      <Navi>{(unit.boss && unit.boss.intro) || 'Answer in the language to calm the boss down!'}</Navi>
      <div className="muted small">Every word you learn here takes a heart away.</div>
      <ActionBar><button className="btn primary wide" onClick={() => setPhase('fight')} data-testid="boss-start">⚔️ Talk to {name(place.boss)}</button></ActionBar>
    </div>
  );
  if (phase === 'fight') {
    const q = qs[k];
    return <VoiceAnswer key={k} lang={lang} sess={sess} sayText={q.ans.say} targets={[q.ans.t, q.ans.w, ...(q.extra || [])].filter(Boolean)} opts={q.opts} praise={'💥 ' + (lang === 'es' ? '¡Golpe directo!' : 'Direct hit!')}
      prompt={<div className="boss"><div className="row"><Portrait who={place.boss} size="sm" className={shake ? 'shake' : ''} /><div className="grow"><b>{cap(name(place.boss))}</b><Hearts hp={hpStart} /></div><span className="chip">⚡ {right}/{qs.length}</span></div>
        {q.pic && <div className="huge emoji center" style={{ margin: '8px 0' }}>{q.count ? Array.from({ length: q.count }, (_, i) => <span key={i}><Pic item={q.pic} /></span>) : <Pic item={q.pic} />}</div>}
        <div className="ex row" style={{ marginTop: 8 }}><PlayBtn lang={lang} text={q.q.say} sm auto /><div><div className="big"><TT lang={lang} x={q.q} showTr={showTr(S, lang)} /></div><div className="muted">{q.q.en}{q.spiral ? ' · from an earlier place' : ''}</div></div></div></div>}
      onDone={(r) => { const nr = right + (r.ok ? 1 : 0); setRight(nr); if (r.ok) { setShake(true); setTimeout(() => setShake(false), 450); } if (k + 1 < qs.length) setK(k + 1); else end(nr); }} />;
  }
  const reward = place.reward && result === 'defeated';
  return (
    <div className="card pop center boss" data-testid="boss-end">
      <Portrait who={place.boss} size="lg" pose={result === 'defeated' ? 'defeated' : undefined} />
      <Hearts hp={result === 'defeated' ? 0 : hpNow} />
      {result === 'defeated' && <><h2>🎉 You won!</h2><Navi>{(unit.boss && unit.boss.win) || 'The boss smiles and waves goodbye!'}</Navi>
        {reward && <div className="reward"><div className="item emoji"><SafeImg src={(rewardImg(place.reward) || {}).url} label={rewardNameK(place.reward)} fallback={rewardIcon(place.reward)} width={120} height={120} /></div><h3>You got {rewardNameK(place.reward)}!</h3></div>}
        <div className="fb good">🎯 New “I can” goal: <b>{unit.ican}</b></div>
        {unit.culture && unit.culture.text && <div className="card soft" style={{ marginTop: 10, textAlign: 'left' }} data-testid="culture"><b>📜 Did you know? {unit.culture.title}</b><div>{unit.culture.text}</div></div>}</>}
      {result === 'hit' && <><h2>💥 {cap(name(place.boss))} lost hearts!</h2><Navi>{'Every new word you learn here takes a heart away. See you next quest!'}</Navi></>}
      {result === 'almost' && <><h2>💨 Almost!</h2><Navi>{'One more good talk next quest and the boss is beaten!'}</Navi></>}
      <ActionBar><button className="btn primary wide" onClick={() => onDone({ result })} data-testid="next">Open the treasure</button></ActionBar>
    </div>
  );
}

// ---------- 7. Chest: rupees, how often he spoke, and a home mission ----------
export function Reward({ lang, unit, sess, finishSession }) {
  const { S, set, go } = useApp();
  const [open, setOpen] = useState(false);
  const story = getStory(lang, unit.n);
  const ms = (story && story.missions) || [];
  const mi = (S[lang].missionIdx || 0);
  const mission = ms.length ? ms[mi % ms.length] : null;
  useEffect(() => { finishSession(); if (mission) set((s) => { s[lang].mission = { day: today(), en: mission.en, say: mission.say, done: false }; s[lang].missionIdx = mi + 1; }); }, []);
  const earned = S.rupees - sess.rupees0;
  const lv = levelOf(unit.n);
  const levelDone = Array.from({ length: lv.to - lv.from + 1 }, (_, k) => lv.from + k).every((n) => S[lang].units[n] && S[lang].units[n].done);
  const ms_ = mission ? T(lang, mission.say) : null;
  return (
    <div className="card pop center" data-testid="reward">
      {!open ? (<>
        <h2>Quest complete!</h2>
        <div className="reward"><div className="item emoji"><SafeImg src={kitIcon('chest')} width={160} height={160} fallback="🧰" /></div></div>
        <Navi>You found a treasure chest!</Navi>
        <ActionBar><button className="btn primary wide" onClick={() => { sfx('chest'); setOpen(true); set((s) => { s.chests++; s.rupees += 5; }); }} data-testid="open-chest">Open it!</button></ActionBar>
      </>) : (<>
        <div className="reward"><div className="item emoji"><SafeImg src={kitIcon('chestOpen')} width={160} height={160} fallback="💎" /></div><h2>+{Math.max(5, earned)} rupees!</h2></div>
        <div className="big">🗣️ You spoke {LANG[lang].name} {sess.speak.tries} times!</div>
        {levelDone && <div className="fb good" style={{ marginTop: 10 }}>🏅 You finished the {lv.name} level! Your certificate is on the I can map.</div>}
        {mission && <div className="card soft" style={{ marginTop: 12, textAlign: 'left' }} data-testid="mission"><div style={{ fontWeight: 800 }}>🏠 Home mission</div><div>{mission.en}</div>
          <div className="row" style={{ marginTop: 6 }}><PlayBtn lang={lang} text={ms_.say} sm /><TT lang={lang} x={ms_} showTr={lang === 'fa'} showW={false} /></div></div>}
        <ActionBar><button className="btn primary wide" onClick={() => go('lang', { lang })} data-testid="finish">Back to Hyrule Field</button></ActionBar>
      </>)}
    </div>
  );
}

// ---------- Quest runner ----------
function reviewAct(lang, L, item, k) {
  if (k % 2 === 0) return 'say';
  if (item.kind === 'p') return 'meaning';
  if (lang === 'es' && L.diff >= 3 && k % 3 === 1 && item.t.length <= 14) return 'spell';
  const acts = lang === 'es' ? ['wordpic', 'listen', 'picword'] : ['listen', 'meaning', 'picword'];
  return acts[(k + L.quests) % acts.length];
}
export function Quest({ lang, unitN }) {
  const { S, set, go } = useApp();
  const variety = S.settings.variety;
  const unit = getUnit(lang, unitN);
  const items = unitItems(lang, unitN, variety);
  const all = useMemo(() => allItems(lang, variety), [lang, variety]);
  useEffect(() => { resetHints(); }, []);
  const sess = useRef({ lang, unit: unitN, start: Date.now(), total: 0, correct: 0, newItems: 0, reviewed: 0, mistakes: {}, speak: { tries: 0, good: 0 }, writing: [], boss: '', rupees0: S.rupees }).current;
  const cards = useMemo(() => {
    const L = S[lang];
    const st = getStory(lang, unitN); const u = unitState(L, unitN);
    const storyOn = st && (u.story || 0) < st.parts.length;
    const storyIds = storyOn ? storyTargets(lang, unitN, u.story || 0, variety).map((x) => x.id) : [];
    const plan = planQuest(S, lang, unit, items, all, { storyIds });
    const out = [];
    const pool = (it) => { const p = unitItems(lang, it.n, variety); return p.length >= 4 ? p : all; };
    plan.forEach((st, si) => {
      if (st.type === 'greeting') out.push({ si, kind: 'greeting' });
      if (st.type === 'review') {
        const nouns = unitNouns(lang, unitN, variety); const metN = nouns.filter((x) => L.srs[x.id]); const kk = (L.quests || 0) + unitN;
        const noun = metN.length ? metN[kk % metN.length] : null;
        st.items.forEach((it, k) => { out.push({ si, kind: 'act', act: reviewAct(lang, L, it, k), item: it, pool: pool(it), review: true }); if (k === 1 && noun && nouns.length >= 3) out.push({ si, kind: 'chunk', noun, nouns, k: kk }); });
        if (st.items.length >= 6 && L.diff >= 2 && L.quests % 3 === 1) out.push({ si, kind: 'speed', items: st.items });
        const tri = triplets(variety).filter((t) => S.es.srs[t.es.id] && S.fa.srs[t.fa.id] && S.es.srs[t.es.id].b >= 3 && S.fa.srs[t.fa.id].b >= 3);
        if (tri.length >= 4 && L.quests % 4 === 2) out.push({ si, kind: 'triplets', list: tri });
      }
      if (st.type === 'story') out.push({ si, kind: storyOn ? 'story' : 'role' });
      if (st.type === 'learn') {
        if (lang === 'fa') st.items.forEach((it) => out.push({ si, kind: 'newfa', item: it, pool: pool(it) }));
        else for (let g = 0; g < st.items.length; g += 3) {
          const grp = st.items.slice(g, g + 3);
          grp.forEach((it) => out.push({ si, kind: 'learn', item: it }));
          grp.forEach((it, k) => out.push({ si, kind: 'act', act: it.kind === 'p' ? 'meaning' : (k % 2 ? 'wordpic' : 'listen'), item: it, pool: pool(it), fresh: true }));
        }
      }
      if (st.type === 'tpr') out.push({ si, kind: 'tpr' });
      if (st.type === 'grammar') out.push({ si, kind: 'grammar', first: st.first, optional: true });
      if (st.type === 'script') out.push({ si, kind: 'script', optional: true });
      if (st.type === 'write') out.push({ si, kind: 'write', wkind: st.kind, optional: true });
      if (st.type === 'boss') out.push({ si, kind: 'boss' });
    });
    out.push({ si: plan.length, kind: 'reward' });
    out.steps = plan.length; out.plan = plan;
    return out;
  }, []);
  const [i, setI] = useState(0);
  const [quit, setQuit] = useState(false);
  const c = cards[i];
  const next = () => setI((x) => {
    let n = Math.min(x + 1, cards.length - 1);
    const mins = (Date.now() - sess.start) / 60000;
    // out of time: skip grammar / letters / writing and go straight to the boss, so every session ends on a win
    while (cards[n] && cards[n].optional && mins > (S.settings.daily || 15) - 3) n++;
    return n;
  });
  // Mac speed: keys 1-4 pick an answer, Enter = next/check
  useEffect(() => {
    const f = (e) => {
      if (/input|textarea|select/i.test((e.target && e.target.tagName) || '')) return;
      if (/^[1-5]$/.test(e.key)) { const b = [...document.querySelectorAll('.main .choice')].filter((x) => !x.classList.contains('gone'))[+e.key - 1]; if (b) { e.preventDefault(); b.click(); } }
      if (e.key === 'Enter') { const b = document.querySelector('.actionbar [data-testid=next]:not([disabled])') || document.querySelector('.actionbar [data-testid=check]:not([disabled])') || document.querySelector('.actionbar [data-testid=open-chest]'); if (b) { e.preventDefault(); b.click(); } }
    };
    window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f);
  }, []);
  const labels = { greeting: 'Hello', review: 'Review', story: 'Story', learn: 'New words', tpr: 'Training', grammar: 'Grammar', script: 'Letters', write: 'Writing', boss: 'Boss' };
  const stepLabel = cards.plan[c.si] ? labels[cards.plan[c.si].type] : 'Treasure';
  const finishSession = () => endSession(S, set, sess, true);
  let body = null;
  if (c.kind === 'greeting') body = <Greeting key={i} lang={lang} unit={unit} sess={sess} onDone={next} />;
  else if (c.kind === 'learn') body = <LearnCard key={i} lang={lang} item={c.item} onNext={() => { set((s) => introduce(s[lang], c.item.id)); sess.newItems++; next(); }} />;
  else if (c.kind === 'newfa') body = <NewWordFa key={i} item={c.item} pool={c.pool} sess={sess} onDone={() => { sess.newItems++; next(); }} />;
  else if (c.kind === 'act') {
    const done = () => { if (c.review) sess.reviewed++; next(); };
    if (c.act === 'say') body = <ReviewSay key={i} lang={lang} item={c.item} pool={c.pool} sess={sess} onDone={next} />;
    else if (c.act === 'spell') body = <SpellIt key={i} item={c.item} sess={sess} onDone={done} />;
    else body = <Pick key={i} lang={lang} item={c.item} pool={c.pool} mode={c.act} sess={sess} onDone={done} />;
  } else if (c.kind === 'chunk') body = <PowerPhrase key={i} lang={lang} noun={c.noun} nouns={c.nouns} k={c.k} sess={sess} onDone={next} />;
  else if (c.kind === 'speed') body = <SpeedRound key={i} lang={lang} items={c.items} pool={all.filter((x) => S[lang].srs[x.id])} onDone={next} />;
  else if (c.kind === 'triplets') body = <Triplets key={i} list={c.list} onDone={next} />;
  else if (c.kind === 'story') body = <OwlStory key={i} lang={lang} unit={unit} sess={sess} onDone={next} />;
  else if (c.kind === 'role') body = <RolePlay key={i} lang={lang} unit={unit} sess={sess} onDone={next} />;
  else if (c.kind === 'tpr') body = <SwordTraining key={i} lang={lang} onDone={next} />;
  else if (c.kind === 'grammar') body = <GrammarStep key={i} lang={lang} unit={unit} first={c.first} sess={sess} onDone={next} />;
  else if (c.kind === 'script') body = <ScriptLesson key={i} idx={Math.min(S.fa.script.step || 0, LESSONS.length - 1)} mini onDone={next} />;
  else if (c.kind === 'write') body = <WriteStep key={i} lang={lang} unit={unit} kind={c.wkind} sess={sess} onDone={next} />;
  else if (c.kind === 'boss') body = <Boss key={i} lang={lang} unit={unit} items={items} sess={sess} onDone={next} />;
  else if (c.kind === 'reward') body = <Reward lang={lang} unit={unit} sess={sess} finishSession={finishSession} />;
  if (!body) body = <div className="card center" data-testid="skip-card"><ActionBar><button className="btn primary wide" onClick={next} data-testid="next">Next</button></ActionBar></div>;
  return (<>
    <div className="top">
      <button className="iconbtn" onClick={() => (c.kind === 'reward' ? go('lang', { lang }) : setQuit(true))} aria-label="Leave quest" data-testid="quit"><Icon n="close" /></button>
      <div className="title"><div className="small muted">{placeName(unitN)} · {stepLabel}</div><Dots total={cards.steps + 1} at={c.si} /></div>
      <QuestChips />
    </div>
    <div className="main" data-card={i}>{body}</div>
    {quit && <Modal onClose={() => setQuit(false)}><h2>Take a break?</h2><p>Everything you learned so far is saved.</p><div className="row"><button className="btn" onClick={() => setQuit(false)}>Keep playing</button><button className="btn primary" onClick={() => { endSession(S, set, sess, false); go('lang', { lang }); }} data-testid="quit-yes">Leave quest</button></div></Modal>}
  </>);
}
function QuestChips() {
  const { S } = useApp();
  const ru = kitIcon('rupee');
  return <span className="chip" title="Rupees"><SafeImg src={ru} width={20} height={20} fallback="💎" /> {S.rupees}</span>;
}
export function endSession(S, set, sess, complete) {
  if (sess.saved) return; sess.saved = true;
  const mins = (Date.now() - sess.start) / 60000;
  set((s) => {
    const L = s[sess.lang];
    if (complete) { if (L.lastDay !== today()) { L.streak = L.lastDay === today() - 1 ? L.streak + 1 : 1; } L.lastDay = today(); L.quests++; }
    L.minutes = (L.minutes || 0) + mins;
    s.reports = [{ date: Date.now(), lang: sess.lang, unit: sess.unit, mins, total: sess.total, correct: sess.correct, newItems: sess.newItems, reviewed: sess.reviewed, mistakes: sess.mistakes, speak: sess.speak, writing: sess.writing, boss: sess.boss, complete, rupees: s.rupees - sess.rupees0 }, ...(s.reports || [])].slice(0, 120);
  });
}
