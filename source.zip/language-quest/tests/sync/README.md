# Family Sync 1.1.0 (several kid laptops) + Family Wallet 1.2.0 (anti-farming) + Code.gs 1.1 + Family Hub 1.1

| File | What | sha256 |
|---|---|---|
| `family-sync.js` | 1.1.0. Copy it byte-identical into all 4 apps and the Hub. | `4d9125f0c869a864f7cdc999a354f1c4e9defbef2fc7e4843a4607684695f5eb` |
| `family-wallet.js` | 1.2.0. Copy it byte-identical into all 4 apps and the Hub. | `d7809808f8d78e5b248468eb89a903e5904c880a00e35a23e1f03623d6c84088` |
| `server/Code.gs` | 1.1. Same deployment and URL; follow `UPDATE.md` (Manage deployments → Edit → New version). | `de02817a3bba13fdd864a36c9275dd5831d94a0849bb0ad45445c399648284b8` |
| `server/appsscript.json` | Unchanged from 1.0 (same scopes). Do not re-paste it. | |
| `family/` | The Hub 1.1 dist for sina2jp/family. Only 5 files changed vs the deployed 1.0.0 (see `HUB-CHANGES.md`). | |
| `preview/index.html` | The single-file Hub preview: no eval, tested under the viewer's CSP. | |

- **Docs:**
  - `INTEGRATION-1.1.md`: what the app builders change, for both modules.
  - `UPDATE.md`: server update steps for the parent's Claude.
  - `HUB-CHANGES.md`: the Hub upload list.
  - `TEST-REPORT.md`: results of every suite.
  - `diffs/`: diffs against the previous versions.
  - `INTEGRATION.md` and `DEPLOY.md`: the 1.0 base docs, still valid.
- **Tools:**
  - `check-deploy.mjs`: 1.1 adds the server-version check and 5 several-laptop checks. Run `node check-deploy.mjs <exec-url> --link '<family link>'`, or `--self-test`.
  - `tools/mock-server.mjs`: runs the real Code.gs.
  - `tools/scrub.mjs`: the scrub, with its two short words matched only as whole words.
  - `tools/build.mjs`: the build.
- **Test-only files:** `legacy/` holds the 1.0.0 module and Code.gs 1.0, which the tests use for the legacy-client and server-swap cases.
