import React, { useState, useEffect, useRef, useMemo } from 'react';
import { emit } from './hooks.js';
import { useApp, Navi, PlayBtn, TT, HintLadder, Hints, Why, AccentBar, insertAt, PersianKeyboard, Stars, Portrait, ActionBar, Rich, useReading, SafeImg, noteHint } from './ui.jsx';
import { canRead } from './scriptdata.js';
import { getUnit } from './content.js';
import { VoiceAnswer } from './voice.jsx';
import { LESSONS, LT } from './scriptdata.js';
import { Trace } from './script.jsx';
import { say, sfx, srAvailable, listen, recAvailable, startRecording, playRecording } from './audio.js';
import { normEs, normFa, normTr, stripAcc, sim, shuffle, classifyEs, classifyFa, checkFree, grade, record, nOptions, isFaScript, MT, emojiClass } from './engine.js';
import { T, fill, esLexicon } from './content.js';
import { name } from './skin.js';

const PRAISE = { es: [['¡Muy bien!', 'Very good!'], ['¡Excelente!', 'Excellent!'], ['¡Genial!', 'Great!']], fa: [['آفرین!', 'âfarin!'], ['عالیه!', 'âliye!'], ['ایول!', 'eyval!']] };
export function praise(lang, first) {
  const l = PRAISE[lang][Math.floor(Math.random() * 3)];
  if (!first) return lang === 'es' ? '👍 ¡Bien! (Good!)' : <>👍 <span className="fa" lang="fa">خوبه!</span> <span className="tr">(khube!)</span></>;
  return lang === 'es' ? `✨ ${l[0]} (${l[1]})` : <>✨ <span className="fa" lang="fa">{l[0]}</span> <span className="tr">({l[1]})</span></>;
}
export const showTr = (S, lang, item) => lang === 'fa' && (S.settings.translit === 'on' || (S.settings.translit === 'fade' && (!item || !S.fa.srs[item.id] || S.fa.srs[item.id].b < 3)));
const Q = (lang, it) => (lang === 'es' ? it.t : it.tr || it.t);
export function tally(S, lang, mt, sess) { if (!mt) return; S[lang].mistakes[mt] = (S[lang].mistakes[mt] || 0) + 1; if (sess) sess.mistakes[mt] = (sess.mistakes[mt] || 0) + 1; }

export const picKey = (x) => (globalThis.__lqPicKey && globalThis.__lqPicKey(x)) || emojiClass(x.e);
export function distractors(item, pool, n, key = picKey) {
  // same kind first (words with words, phrases with phrases)
  const same = pool.filter((x) => x.kind === item.kind);
  if (same.length > n + 1) pool = same;
  const seen = new Set([key(item), item.en]);
  const out = [];
  for (const x of shuffle(pool)) { if (out.length >= n) break; if (x.id === item.id || seen.has(key(x)) || seen.has(x.en)) continue; seen.add(key(x)); seen.add(x.en); out.push(x); }
  return out;
}

// ---------- Learn card ----------
const bare = (t) => stripAcc((t || '').toLowerCase()).replace(/^(el|la|los|las|un|una) /, '').replace(/[^a-z]/g, '');
export const isCognate = (it) => { const a = bare(it.t), b = bare((it.en || '').split(/[,(;/]/)[0]); return a.length >= 4 && b.length >= 4 && sim(a, b) >= 0.75; };
export function LearnCard({ lang, item, onNext }) {
  const { S } = useApp();
  const tr = showTr(S, lang, item);
  const gender = lang === 'es' && item.g ? (item.g === 'f' ? 'feminine (la / una)' : 'masculine (el / un)') : '';
  const cog = lang === 'es' && item.n <= 8 && isCognate(item);
  return (
    <div className="card learn pop" data-testid="learn">
      <div className="pic emoji"><Pic item={item} /></div>
      <div className="row c"><TT lang={lang} x={item} big showTr={tr} /><PlayBtn lang={lang} text={item.say} auto /></div>
      <div className="big">{item.en}</div>
      {cog && <div className="chip">✨ Looks like English! Same idea, Spanish sound.</div>}
      {gender && <div className="chip">{item.g === 'f' ? '🔴' : '🔵'} {gender}</div>}
      {item.fem && <div className="muted">feminine form: <b lang="es">{item.fem}</b></div>}
      {lang === 'fa' && item.w && item.w !== item.t && <div className="muted small">Both are right: people <b>say</b> one way and books <b>write</b> it another way.</div>}
      {item.ex && item.ex.t && (
        <div className="ex row c"><PlayBtn lang={lang} text={item.ex.say} sm label="Listen to the example" />
          <div><TT lang={lang} x={item.ex} showTr={tr} /><div className="muted">{item.ex.en}</div></div></div>
      )}
      <ActionBar><button className="btn primary wide" onClick={onNext} data-testid="next">Got it!</button></ActionBar>
    </div>
  );
}
// Picture for an item: painted vocabulary icon when the kit has one, else the emoji
export function Pic({ item, e }) {
  const url = item && globalThis.__lqIcon ? globalThis.__lqIcon(item) : null;
  if (url) return <SafeImg className="vicon" src={url} fallback={e || (item && item.e) || '✨'} />;
  return <>{e || (item && item.e) || '✨'}</>;
}

// ---------- multiple choice vocabulary (listen / wordpic / picword / meaning) ----------
export function Pick({ lang, item, pool, mode, onDone, sess }) {
  const { S, set } = useApp();
  const L = S[lang];
  const n = nOptions(L);
  const opts = useMemo(() => shuffle([item, ...distractors(item, pool, n - 1, mode === 'meaning' ? (x) => x.en : picKey)]), [item.id]);
  const [gone, setGone] = useState([]);
  const [right, setRight] = useState(false);
  const [tries, setTries] = useState(0);
  const [nudge, setNudge] = useState('');
  const [hinted, setHinted] = useState(0);
  const done = useRef(false);
  const tr = showTr(S, lang, item);
  useEffect(() => { if (mode === 'listen' || mode === 'meaning') { const t = setTimeout(() => say(lang, item.say), 300); return () => clearTimeout(t); } }, [item.id]);
  const first = Q(lang, item).replace(/^(el|la|los|las|un|una) /, '').slice(0, 2);
  const finish = (ok) => { if (done.current) return; done.current = true; onDone({ ok }); };
  const choose = (o) => {
    if (right || gone.includes(o.id)) return;
    if (o.id === item.id) {
      sfx('good'); setRight(true); setNudge('');
      set((s) => { grade(s[lang], item.id, tries === 0 && hinted < 2 ? 'first' : 'retry'); record(s[lang], tries === 0); s.rupees += tries === 0 ? 2 : 1; });
      emit('answer', { correct: true, itemId: item.id, label: item.t }); if (tries > 0) emit('comeback', { why: 'retry' });
      if (sess) { sess.total++; if (tries === 0) sess.correct++; }
      if (lang === 'fa' || mode !== 'listen') say(lang, item.say);
      if (!globalThis.__LQ_NOAUTO__) setTimeout(() => finish(tries === 0), 1000);
    } else {
      sfx('try'); const g = [...gone, o.id]; setGone(g); setTries(tries + 1);
      const mt = mode === 'listen' || mode === 'meaning' ? 'listening' : 'word';
      set((s) => { tally(s, lang, mt, sess); if (tries >= 1) grade(s[lang], item.id, 'wrong'); record(s[lang], false); });
      emit('answer', { correct: false });
      setNudge(mode === 'listen' || mode === 'meaning' ? 'Not that one. Listen again: check the first sound.' : 'Not quite. Check the picture again: what is it in English?');
      if (mode === 'listen' || mode === 'meaning') setTimeout(() => say(lang, item.say), 500);
      if (tries + 1 >= 2) { setRight(true); setNudge(''); say(lang, item.say); }
    }
  };
  const prompt = { listen: 'Listen. Which picture is it?', meaning: 'Listen. What does it mean?', wordpic: 'Which picture matches the word?', picword: `How do you say “${item.en}”?` }[mode];
  const removeOne = () => { const w = opts.find((o) => o.id !== item.id && !gone.includes(o.id)); if (w) setGone([...gone, w.id]); setHinted(2); };
  return (
    <div className="card pop" data-testid={`pick-${mode}`}>
      <Navi small>{prompt}</Navi>
      <div className="center" style={{ margin: '14px 0' }}>
        {(mode === 'listen' || mode === 'meaning') && <PlayBtn lang={lang} text={item.say} />}
        {mode === 'wordpic' && <div className="row c"><TT lang={lang} x={item} big showTr={tr} /><PlayBtn lang={lang} text={item.say} sm /></div>}
        {mode === 'picword' && <div className="huge emoji"><Pic item={item} /></div>}
        {mode === 'meaning' && lang === 'fa' && tr && <div className="tr">{item.tr}</div>}
      </div>
      <div className={`choices ${mode === 'listen' || mode === 'wordpic' ? 'pics' : ''}`}>
        {opts.map((o, k) => (
          <button key={o.id} className={`choice ${right && o.id === item.id ? 'right' : ''} ${gone.includes(o.id) ? 'wrong gone' : ''}`} onClick={() => choose(o)} data-ok={o.id === item.id ? '1' : '0'} data-key={k + 1}>
            {mode === 'listen' || mode === 'wordpic' ? <span className="pic emoji"><Pic item={o} /></span> : null}
            {mode === 'picword' ? <TT lang={lang} x={o} showTr={tr} showW={false} /> : null}
            {mode === 'meaning' ? <span>{o.en}</span> : null}
          </button>
        ))}
      </div>
      {nudge && !right && <div className="fb try" style={{ marginTop: 10 }}>{nudge}</div>}
      {right && <div className="fb good" style={{ marginTop: 10 }}>{tries === 0 ? praise(lang, true) : tries >= 2 ? '👂 Here it is — it will come back later.' : praise(lang, false)} <b>{item.en}</b> = <TT lang={lang} x={item} showTr={lang === 'fa'} showW={false} /></div>}
      {!right && <div style={{ marginTop: 10 }}><Hints question={mode === 'picword' ? `Do you remember the first sound of “${item.en}”?` : 'What sound did you hear at the very start?'} clue={`It starts with “${first}…”.`} onRemove={removeOne} onPlay={() => say(lang, item.say)} /></div>}
      <ActionBar>
        <button className="btn primary wide" disabled={!right} onClick={() => finish(tries === 0)} data-testid="next">Next</button>
      </ActionBar>
    </div>
  );
}

// ---------- Say it (speech recognition, or record-and-compare self-check) ----------
export function SayIt({ lang, item, onDone, sess, title }) {
  const { S, set } = useApp();
  const [state, setState] = useState('idle'); // idle | listening | scored | rec | recorded
  const [score, setScore] = useState(null);
  const [heard, setHeard] = useState('');
  const [blob, setBlob] = useState(null);
  const [done, setDone] = useState(false);
  const recRef = useRef(null);
  const tr = showTr(S, lang, item);
  const useSR = srAvailable(lang);
  const targets = [item.t, item.w].filter(Boolean);
  const scoreOf = (alts) => {
    let best = 0, h = '';
    for (const a of alts) for (const t of targets) {
      const s = lang === 'es' ? sim(stripAcc(normEs(t)), stripAcc(normEs(a))) : sim(normFa(t).replace(/ /g, ''), normFa(a).replace(/ /g, ''));
      if (s > best) { best = s; h = a; }
    }
    return [best, h];
  };
  const finish = (good, mt) => {
    set((s) => { s[lang].speak.tries++; if (good) s[lang].speak.good++; if (!good) tally(s, lang, mt || 'pron', sess); s.rupees += good ? 2 : 1; });
    if (sess) { sess.speak.tries++; if (good) sess.speak.good++; }
    setDone(true);
  };
  const doListen = async () => {
    setState('listening'); setHeard('');
    const r = await listen(lang);
    if (r.error && !r.alts.length) {
      if (!srAvailable(lang)) { setState('idle'); return; } // broken → fallback UI shows
      setState('idle'); setHeard('(I didn\'t hear anything. Tap the mic and speak a bit louder.)'); return;
    }
    const [s, h] = scoreOf(r.alts);
    setScore(s); setHeard(h); setState('scored');
    sfx(s >= 0.5 ? 'good' : 'try');
    finish(s >= 0.5);
  };
  const doRec = async () => {
    if (state === 'rec') { const b = await recRef.current.stop(); setBlob(b); setState('recorded'); return; }
    try { recRef.current = await startRecording(); setState('rec'); setTimeout(async () => { if (recRef.current && state !== 'recorded') { /* auto stop after 6s */ } }, 6000); }
    catch { setState('norec'); }
  };
  const stars = score == null ? 0 : score >= 0.75 ? 3 : score >= 0.5 ? 2 : 1;
  return (
    <div className="card pop" data-testid="sayit">
      <Navi small>{title || 'Listen, then say it out loud!'}</Navi>
      <div className="learn" style={{ margin: '12px 0' }}>
        <div className="pic emoji" style={{ fontSize: '3.4rem' }}>{item.e}</div>
        <div className="row c"><TT lang={lang} x={item} big showTr={tr} /><PlayBtn lang={lang} text={item.say} auto /></div>
        <div className="muted">{item.en}</div>
      </div>
      {useSR ? (
        <div className="center">
          <button className={`btn ${state === 'listening' ? 'good' : 'primary'}`} onClick={doListen} disabled={state === 'listening'} data-testid="mic">{state === 'listening' ? '👂 Listening…' : '🎤 Say it'}</button>
          {state === 'scored' && (
            <div className={`fb ${stars >= 2 ? 'good' : 'try'}`} style={{ marginTop: 10 }}>
              <Stars n={stars} /> {stars === 3 ? 'Wonderful!' : stars === 2 ? 'Close! Try once more if you like.' : 'Let\'s listen again and try once more.'}
              {heard && <div className="small">I heard: <span lang={lang} className={lang === 'fa' ? 'fa' : ''}>{heard}</span></div>}
            </div>
          )}
          {heard && state !== 'scored' && <div className="muted">{heard}</div>}
        </div>
      ) : (
        <div className="center">
          {recAvailable() && state !== 'norec' ? (
            <div className="row c">
              <button className={`btn ${state === 'rec' ? 'good' : 'primary'}`} onClick={doRec} data-testid="rec">{state === 'rec' ? '⏹ Stop' : '🎙️ Record me'}</button>
              {blob && <button className="btn" onClick={() => playRecording(blob)}>▶️ My voice</button>}
              {blob && <button className="btn" onClick={() => say(lang, item.say)}>🔈 Model</button>}
            </div>
          ) : <div className="muted">Say it out loud, then tell Navi how it went.</div>}
          {(blob || state === 'norec' || !recAvailable()) && !done && (
            <div style={{ marginTop: 12 }}>
              <div style={{ fontWeight: 800, marginBottom: 6 }}>Did yours sound like the model?</div>
              <div className="row c">
                <button className="btn" onClick={() => { sfx('good'); setScore(0.9); finish(true); }} data-testid="self-yes">😀 Same!</button>
                <button className="btn" onClick={() => { sfx('good'); setScore(0.6); finish(true); }}>🙂 Almost</button>
                <button className="btn" onClick={() => { setScore(0.3); finish(false); say(lang, item.say); }}>🤔 Not yet</button>
              </div>
            </div>
          )}
          {done && <div className="fb good" style={{ marginTop: 10 }}>Great practice! Saying it out loud is how you learn to speak. 🎉</div>}
        </div>
      )}
      <ActionBar>
        <button className="btn ghost" onClick={() => onDone({ ok: false, skipped: true })}>Skip</button>
        <button className="btn primary wide" disabled={!done} onClick={() => onDone({ ok: (score || 0) >= 0.5 })} data-testid="next">Next</button>
      </ActionBar>
    </div>
  );
}

// ---------- Spell it (Spanish typing with accent buttons) ----------
export function SpellIt({ item, onDone, sess }) {
  const { S, set } = useApp();
  const [val, setVal] = useState('');
  const [fb, setFb] = useState(null);
  const [tries, setTries] = useState(0);
  const [ok, setOk] = useState(false);
  const ref = useRef(null);
  const bare = item.t.replace(/^(el|la|los|las) /i, '');
  const check = () => {
    const a = normEs(val), full = normEs(item.t), b = normEs(bare);
    if (a === full || a === b) {
      sfx('good'); setOk(true); setFb({ good: true, msg: '✨ Perfect spelling!' });
      set((s) => { grade(s.es, item.id, tries === 0 ? 'first' : 'retry'); record(s.es, tries === 0); s.rupees += 2; });
      emit('answer', { correct: true, itemId: item.id, label: item.t });
      if (sess) { sess.total++; if (!tries) sess.correct++; }
      return;
    }
    const c = classifyEs(a.split(' ').length === full.split(' ').length ? item.t : bare, val) || { mt: 'spelling', msg: 'Check your spelling.' };
    sfx('try'); setTries(tries + 1); setFb({ good: false, msg: <><b>{MT[c.mt]}:</b> {c.msg}</> });
    set((s) => { tally(s, 'es', c.mt, sess); if (tries >= 1) grade(s.es, item.id, 'wrong'); record(s.es, false); });
  };
  const blanks = bare.replace(/[a-záéíóúñü]/gi, '_ ');
  // Type ↔ Choose: one tap to choose the right spelling instead (counts as help)
  const [mode, setMode] = useState('type');
  const opts3 = useMemo(() => shuffle([bare, bare.length > 3 ? bare.slice(0, -1) + (bare.endsWith('a') ? 'o' : 'a') : bare + 's', bare.length > 4 ? bare[0] + bare.slice(2) : bare + 'n'].filter((v, i, a) => a.indexOf(v) === i)), [bare]);
  const choose = (o) => { if (ok) return; if (o === bare) { sfx('good'); setOk(true); setFb({ good: true, msg: '✨ Yes! ' + bare }); set((s) => { grade(s.es, item.id, 'retry'); record(s.es, false); s.rupees += 1; }); } else { sfx('try'); setTries(tries + 1); setFb({ good: false, msg: 'Not that one. Listen again!' }); } };
  return (
    <div className="card pop" data-testid="spell">
      <Navi small>Spell it! Use the accent buttons for á, é, ñ…</Navi>
      <div className="learn" style={{ margin: '10px 0' }}><div className="pic emoji">{item.e}</div><div className="row c"><span className="big">{item.en}</span><PlayBtn lang="es" text={item.say} auto sm /></div></div>
      <input ref={ref} className="field" data-answer={(globalThis.__LQ_TEST__ ? bare : undefined)} value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && val.trim() && !ok) check(); }} placeholder="Type in Spanish" autoCapitalize="off" autoComplete="off" spellCheck="false" lang="es" data-testid="spell-input" />
      <div style={{ marginTop: 8 }}><AccentBar onInsert={(c) => insertAt(ref, val, setVal, c)} /></div>
      {!ok && (mode === 'type' ? <div className="center" style={{ marginTop: 6 }}><button className="btn sm ghost" onClick={() => { noteHint(); setMode('choose'); }} data-testid="choose-mode">👆 Choose instead</button></div>
        : <div className="choices" style={{ marginTop: 10 }}>{opts3.map((o) => <button key={o} className="choice" onClick={() => choose(o)} data-ok={o === bare ? '1' : '0'} lang="es">{o}</button>)}</div>)}
      {!ok && tries >= 2 && <div className="fb info" style={{ marginTop: 8 }}>The answer is <b lang="es">{bare}</b>. Type it once for practice!</div>}
      {fb && <div className={`fb ${fb.good ? 'good' : 'try'}`} style={{ marginTop: 10 }}>{fb.msg}</div>}
      {!ok && <div style={{ marginTop: 10 }}><HintLadder questions={['How many letters do you think it has?', 'What letter does it start with?', 'Which vowels can you hear?']} hints={[`It has ${bare.replace(/[^a-záéíóúñü]/gi, '').length} letters: ${blanks}`, `It starts with “${bare[0]}”.`, `Vowels: ${bare.replace(/[^aeiouáéíóú ]/gi, '·')}`]} /></div>}
      <ActionBar>
        {!ok ? <button className="btn primary wide" disabled={!val.trim()} onClick={check} data-testid="check">Check</button>
          : <button className="btn primary wide" onClick={() => onDone({ ok: tries === 0 })} data-testid="next">Next</button>}
        {!ok && tries >= 2 && <button className="btn" onClick={() => onDone({ ok: false })}>Later</button>}
      </ActionBar>
    </div>
  );
}

// ---------- Speed round (never punitive: beat your best) ----------
export function SpeedRound({ lang, items, pool, onDone }) {
  const { S, set } = useApp();
  const [t, setT] = useState(globalThis.__LQ_TEST__ ? 3 : 45);
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [started, setStarted] = useState(false);
  const order = useMemo(() => shuffle(items.length >= 6 ? items : pool.slice(0, 30)), []);
  const cur = order[i % order.length];
  const opts = useMemo(() => cur ? shuffle([cur, ...distractors(cur, pool, 2)]) : [], [i, started]);
  useEffect(() => { if (!started || t <= 0) return; const h = setTimeout(() => setT(t - 1), 1000); return () => clearTimeout(h); }, [t, started]);
  const best = S[lang].speedBest || 0;
  useEffect(() => { if (t === 0) set((s) => { s[lang].speedBest = Math.max(s[lang].speedBest || 0, score); s.rupees += score; }); }, [t]);
  if (!cur) return null;
  return (
    <div className="card pop center" data-testid="speed">
      <h2>⚡ Speed round</h2>
      {!started ? (<>
        <Navi small>Match as many as you can in 45 seconds! Your best: {best}</Navi>
        <ActionBar><button className="btn primary wide" onClick={() => setStarted(true)} data-testid="start">Go!</button></ActionBar>
      </>) : t > 0 ? (<>
        <div className="row c"><span className="chip">⏱ {t}s</span><span className="chip">⭐ {score}</span></div>
        <div className="huge emoji" style={{ margin: 10 }}>{cur.e}</div>
        <div className="choices">{opts.map((o) => <button key={o.id + i} className="choice" onClick={() => { if (o.id === cur.id) { sfx('rupee'); setScore(score + 1); } else sfx('try'); setI(i + 1); }} data-ok={o.id === cur.id ? '1' : '0'}><TT lang={lang} x={o} showTr={lang === 'fa'} showW={false} /></button>)}</div>
      </>) : (<>
        <div className="reward"><div className="item">⚡</div><h2>{score} matches!</h2><div>{score > best ? '🎉 New best!' : `Your best is ${best}. Great practice!`}</div></div>
        <ActionBar><button className="btn primary wide" onClick={() => onDone({ ok: true })} data-testid="next">Next</button></ActionBar>
      </>)}
    </div>
  );
}

// ---------- Spanish–Farsi–English triplets ----------
export function Triplets({ list, onDone }) {
  const rounds = useMemo(() => shuffle(list).slice(0, 4), []);
  const [r, setR] = useState(0);
  const [pickEs, setEs] = useState(null), [pickFa, setFa] = useState(null);
  const cur = rounds[r];
  const esOpts = useMemo(() => cur ? shuffle([cur.es, ...shuffle(list.filter((x) => x !== cur)).slice(0, 2).map((x) => x.es)]) : [], [r]);
  const faOpts = useMemo(() => cur ? shuffle([cur.fa, ...shuffle(list.filter((x) => x !== cur)).slice(0, 2).map((x) => x.fa)]) : [], [r]);
  if (!cur) return null;
  const done = pickEs === cur.es.id && pickFa === cur.fa.id;
  return (
    <div className="card pop" data-testid="triplets">
      <Navi small>Triplets! Find this word in Spanish AND in Farsi.</Navi>
      <div className="center"><div className="huge emoji">{cur.e}</div><div className="big">{cur.en}</div></div>
      <div className="row" style={{ alignItems: 'flex-start', marginTop: 10 }}>
        <div className="grow"><h3>Español</h3><div className="choices" style={{ gridTemplateColumns: '1fr' }}>{esOpts.map((o) => <button key={o.id} className={`choice ${pickEs === o.id ? (o.id === cur.es.id ? 'right' : 'wrong') : ''}`} data-ok={o.id === cur.es.id ? '1' : '0'} onClick={() => { setEs(o.id); say('es', o.say); sfx(o.id === cur.es.id ? 'good' : 'try'); }}>{o.t}</button>)}</div></div>
        <div className="grow"><h3>فارسی</h3><div className="choices" style={{ gridTemplateColumns: '1fr' }}>{faOpts.map((o) => <button key={o.id} className={`choice ${pickFa === o.id ? (o.id === cur.fa.id ? 'right' : 'wrong') : ''}`} data-ok={o.id === cur.fa.id ? '1' : '0'} onClick={() => { setFa(o.id); say('fa', o.say); sfx(o.id === cur.fa.id ? 'good' : 'try'); }}><span className="fa" lang="fa">{o.t}</span><span className="sub">{o.tr}</span></button>)}</div></div>
      </div>
      <ActionBar><button className="btn primary wide" disabled={!done} onClick={() => { if (r + 1 < rounds.length) { setR(r + 1); setEs(null); setFa(null); } else onDone({ ok: true }); }} data-testid="next">Next</button></ActionBar>
    </div>
  );
}

// ---------- Grammar: tiny explanation, then practice with Why? ----------
export function GrammarStep({ lang, unit, first, onDone, sess, count = 3 }) {
  const { S, set } = useApp();
  const g = unit.grammar || {};
  const L = S[lang];
  const all = (g.practice || []).filter((p) => p && p.opts && p.opts.length >= 2);
  const startAt = ((L.units[unit.n] && L.units[unit.n].gi) || 0) % Math.max(1, all.length);
  const items = useMemo(() => {
    const out = [];
    const cb = (L.comeback || []).filter((c) => { const u = getUnit(lang, c.n); return u && u.grammar && u.grammar.practice && u.grammar.practice[c.gi]; }).slice(0, 1);
    cb.forEach((c) => { const u = getUnit(lang, c.n); out.push({ p: u.grammar.practice[c.gi], g: u.grammar, n: c.n, gi: c.gi, comeback: true }); });
    for (let k = 0; out.length < Math.min(count, all.length + cb.length); k++) out.push({ p: all[(startAt + k) % all.length], g, n: unit.n, gi: (startAt + k) % all.length, why: (startAt + k) % 3 === 0 });
    // spiral: every other day one item comes from an earlier unit
    if (unit.n > 1 && (startAt % 2 === 1) && out.length >= 2) {
      const en = 1 + Math.floor(Math.random() * (unit.n - 1)); const eu = getUnit(lang, en);
      const ep = eu && eu.grammar && (eu.grammar.practice || []).filter((x) => x && x.opts && x.opts.length >= 2);
      if (ep && ep.length) { const gi = Math.floor(Math.random() * ep.length); out[out.length - 1] = { p: ep[gi], g: eu.grammar, n: en, gi: eu.grammar.practice.indexOf(ep[gi]), spiral: true }; }
    }
    return out;
  }, [unit.n]);
  const [phase, setPhase] = useState(first || !items.length ? 'explain' : 'practice');
  const [k, setK] = useState(0);
  if (phase === 'explain') {
    return (
      <div className="card pop" data-testid="grammar-explain">
        <h2>📜 {g.name}</h2>
        <Navi>{g.explain}</Navi>
        <div style={{ display: 'grid', gap: 8, marginTop: 12 }}>
          {(g.examples || []).map((ex, i) => { const x = T(lang, ex); return <div key={i} className="ex row"><PlayBtn lang={lang} text={x.say} sm /><div><TT lang={lang} x={x} showTr={lang === 'fa'} /><div className="muted">{x.en}</div></div></div>; })}
        </div>
        <ActionBar><button className="btn primary wide" onClick={() => { set((s) => { const u = s[lang].units[unit.n] || (s[lang].units[unit.n] = {}); u.gseen = true; }); items.length ? setPhase('practice') : onDone({ ok: true }); }} data-testid="next">Let's practice</button></ActionBar>
      </div>
    );
  }
  const it = items[k];
  return <GrammarItem key={k} lang={lang} it={it} sess={sess} idx={k} total={items.length} onNext={(res) => {
    set((s) => {
      const u = s[lang].units[unit.n] || (s[lang].units[unit.n] = {}); if (!it.comeback && !it.spiral) u.gi = (u.gi || 0) + 1;
      s[lang].comeback = s[lang].comeback || [];
      if (it.comeback && res.good) { s[lang].comeback = s[lang].comeback.filter((c) => !(c.n === it.n && c.gi === it.gi)); s.rupees += 5; }
      if (res.revealed && !s[lang].comeback.some((c) => c.n === it.n && c.gi === it.gi)) s[lang].comeback.push({ n: it.n, gi: it.gi });
    });
    if (k + 1 < items.length) setK(k + 1); else onDone({ ok: true });
  }} onExplain={() => setPhase('explain')} />;
}

const MT_NUDGE = {
  gender: 'Check the little word in front: is the noun masculine or feminine?', verb: 'Check the ending: who is doing the action?',
  order: 'Check the order of the words.', spelling: 'Check the spelling and accents.', word: 'Check the meaning: does that word fit here?',
};
function GrammarItem({ lang, it, sess, idx, total, onNext, onExplain }) {
  const { S, set } = useApp();
  const { p, g } = it;
  const q = T(lang, p.q, S.settings.variety, p.en);
  const opts = useMemo(() => shuffle(p.opts.map((o, i) => ({ ...T(lang, o), i }))), [p]);
  const reasons = useMemo(() => shuffle((p.why || []).map((w, i) => ({ w, i }))), [p]);
  const [sel, setSel] = useState(null);
  const [why, setWhy] = useState(null);
  const [clue, setClue] = useState(null); // after a miss: "What was the clue?"
  const [res, setRes] = useState(null);
  const [tries, setTries] = useState(0);
  const [gone, setGone] = useState([]);
  const needWhy = it.why && reasons.length > 1 && tries === 0;
  const trueReason = (p.why || [])[p.wa];
  const correctOpt = opts.find((o) => o.i === p.a);
  const check = () => {
    if (sel.i === p.a) {
      sfx('good');
      const whyOk = why && reasons[why.i] && reasons[why.i].i === p.wa;
      setRes({ good: true, whyOk });
      set((s) => { record(s[lang], tries === 0); s.rupees += tries === 0 ? 3 : 1; });
      if (sess) { sess.total++; if (!tries) sess.correct++; }
      say(lang, fill(q, correctOpt).say);
    } else {
      sfx('try'); const t2 = tries + 1; setTries(t2); setGone([...gone, sel.i]); setSel(null);
      set((s) => { tally(s, lang, p.mt || 'word', sess); record(s[lang], false); });
      if (t2 >= 2) { setRes({ good: false, revealed: true }); say(lang, fill(q, correctOpt).say); }
      else setRes({ good: false });
    }
  };
  const full = res && (res.good || res.revealed) ? fill(q, correctOpt) : null;
  const over = res && (res.good || res.revealed);
  return (
    <div className="card pop" data-testid="grammar-item">
      <div className="row"><h3 className="grow">📜 {g.name}{it.comeback ? ' · Comeback! +5 💎' : it.spiral ? ' · Remember this?' : ''}</h3><span className="muted">{idx + 1}/{total}</span></div>
      <div className="center" style={{ margin: '8px 0 12px' }}>
        <div className="big"><TT lang={lang} x={full || q} showTr={lang === 'fa'} showW={!!full} /></div>
        <div className="muted">{q.en || p.en}</div>
      </div>
      <div className="choices">
        {opts.map((o, k) => <button key={o.i} data-key={k + 1} className={`choice ${over && o.i === p.a ? 'right' : ''} ${sel && sel.i === o.i ? 'sel' : ''} ${gone.includes(o.i) && !over ? 'wrong gone' : ''}`} onClick={() => { if (over || gone.includes(o.i)) return; setSel(o); setRes(null); }} data-ok={o.i === p.a ? '1' : '0'}><TT lang={lang} x={o} showTr={lang === 'fa'} showW={false} /></button>)}
      </div>
      {sel && !over && needWhy && <div style={{ marginTop: 10 }}><Why reasons={reasons.map((r) => r.w)} value={why} onChange={setWhy} /></div>}
      {res && !res.good && !res.revealed && (
        <div style={{ marginTop: 10 }}>
          <div className="fb try">🔎 <b>{MT[p.mt] || MT.word}:</b> {MT_NUDGE[p.mt] || MT_NUDGE.word}</div>
          {reasons.length > 1 && !clue && <div style={{ marginTop: 8 }}><Why prompt="What was the clue?" reasons={reasons.map((r) => r.w)} value={null} onChange={(v) => setClue(v)} /></div>}
          {clue && <div className="fb info" style={{ marginTop: 8 }}>{reasons[clue.i] && reasons[clue.i].i === p.wa ? '✨ Yes, that is the clue! Now try again.' : <>The clue is: <b>{trueReason}</b> Try again!</>}</div>}
        </div>
      )}
      {res && res.good && <div className="fb good" style={{ marginTop: 10 }}>{praise(lang, tries === 0)} {trueReason ? <> {needWhy || it.why ? (res.whyOk ? 'And your reason is right: ' : 'The reason: ') : 'Because: '}<b>{trueReason}</b></> : null}</div>}
      {res && res.revealed && <div className="fb info" style={{ marginTop: 10 }}>Here's the answer: <b><TT lang={lang} x={correctOpt} showW={false} /></b>{trueReason ? <> — {trueReason}</> : null} It will come back as a comeback for bonus rupees!</div>}
      {!over && <div style={{ marginTop: 10 }}><Hints question="What is this sentence about? Read the English." clue={trueReason || g.explain || ''} onRemove={() => { const w = opts.find((o) => o.i !== p.a && !gone.includes(o.i)); if (w) setGone([...gone, w.i]); }} onPlay={() => say(lang, fill(q, correctOpt).say)} /></div>}
      <ActionBar>
        {over ? <button className="btn primary wide" onClick={() => onNext(res)} data-testid="next">Next</button>
          : <button className="btn primary wide" disabled={!sel || (needWhy && !why)} onClick={check} data-testid="check">{!sel ? 'Pick an answer' : needWhy && !why ? 'Pick a reason' : 'Check'}</button>}
        {tries >= 1 && !over && <button className="btn sm ghost" onClick={onExplain}>Rule</button>}
      </ActionBar>
    </div>
  );
}

// ---------- Writing ----------
const WHY_BUILD = {
  es: ['The person comes first, then the verb', 'Describing words go after the noun', 'Questions start with ¿', 'no goes right before the verb'],
  fa: ['The verb goes at the END', 'The person comes first', 'Describing words go after the noun', 'Question words can stay in place'],
};
export function WriteStep({ lang, unit, kind, onDone, sess }) {
  const { S, set } = useApp();
  const R = useReading();
  const w = unit.write || {};
  const L = S[lang];
  const u = L.units[unit.n] || {};
  const [traced, setTraced] = useState(!(lang === 'fa' && R.step >= 1 && R.step < 8));
  const pickOne = (arr) => (arr && arr.length ? arr[(u.wstep || 0) % arr.length] : null);
  const finish = (ok, sample, mts) => {
    set((s) => {
      const uu = s[lang].units[unit.n] || (s[lang].units[unit.n] = {});
      uu.wstep = (uu.wstep || 0) + 1; uu.wrt = (uu.wrt || 0) + 1;
      if (sample) s[lang].writing = [{ d: Date.now(), unit: unit.n, kind, text: sample, mts: mts || [] }, ...(s[lang].writing || [])].slice(0, 40);
      s.rupees += ok ? 3 : 1;
    });
    if (sess && sample) sess.writing.push({ kind, text: sample });
    onDone({ ok });
  };
  if (!traced) {
    const letters = LESSONS.slice(0, R.step).flatMap((l) => l.letters).filter((c) => LT[c]);
    const g = letters[(u.wstep || 0) % letters.length];
    return <div className="card pop" data-testid="script-lesson"><h3>✍️ Warm-up: trace <bdi className="fa" lang="fa">{g}</bdi></h3><Trace glyph={g} onDone={() => setTraced(true)} /></div>;
  }
  const scriptReady = lang === 'fa' && R.step >= 8;
  if (kind === 'build') { const b = pickOne(w.build); if (b) return <Builder lang={lang} b={b} sess={sess} onDone={(ok, txt) => finish(ok, txt)} />; }
  if (kind === 'fill') { const f = pickOne(w.fill); if (f) return <FillIn lang={lang} f={f} sess={sess} onDone={(ok, txt) => finish(ok, txt)} />; }
  if (kind === 'one' && w.one) return <FreeWrite lang={lang} task={w.one} need={1} unit={unit} sess={sess} scriptReady={scriptReady} onDone={finish} />;
  if (kind === 'three' && w.three) return <FreeWrite lang={lang} task={w.three} need={3} unit={unit} sess={sess} scriptReady={scriptReady} onDone={finish} />;
  const c = pickOne(w.copy) || (w.build && w.build[0] ? { f: '', t: '' } : null);
  return <CopyIt lang={lang} x={T(lang, c)} sess={sess} scriptReady={scriptReady} onDone={(ok, txt) => finish(ok, txt)} />;
}

function TextEntry({ lang, val, setVal, scriptReady, multiline, placeholder, testid }) {
  const ref = useRef(null);
  const [kbd, setKbd] = useState(lang === 'fa' && scriptReady);
  const El = multiline ? 'textarea' : 'input';
  return (
    <div style={{ display: 'grid', gap: 8 }}>
      <El ref={ref} className={`field ${kbd ? 'fa' : ''}`} dir={kbd ? 'rtl' : 'auto'} lang={lang === 'fa' && kbd ? 'fa' : lang === 'es' ? 'es' : 'en'} value={val}
        onChange={(e) => setVal(e.target.value)} placeholder={placeholder} autoCapitalize="off" autoComplete="off" spellCheck="false" data-testid={testid || 'write-input'} />
      {lang === 'es' && <AccentBar onInsert={(c) => insertAt(ref, val, setVal, c)} />}
      {lang === 'fa' && (
        <div className="row"><button className="btn sm" onClick={() => setKbd(!kbd)}>{kbd ? 'Type with English letters' : 'Type with Persian letters ⌨️'}</button></div>
      )}
      {lang === 'fa' && kbd && <PersianKeyboard onKey={(k) => setVal(k === 'BACK' ? val.slice(0, -1) : val + k)} />}
    </div>
  );
}

function CopyIt({ lang, x, onDone, scriptReady }) {
  const [val, setVal] = useState('');
  const [fb, setFb] = useState(null);
  const target = lang === 'fa' ? (isFaScript(val) ? (x.w || x.t) : (x.wt || x.tr)) : x.t;
  const check = () => {
    const ok = lang === 'es' ? normEs(val) === normEs(x.t) : (isFaScript(val) ? normFa(val) === normFa(x.w || x.t) || normFa(val) === normFa(x.t) : normTr(val) === normTr(x.tr) || normTr(val) === normTr(x.wt || ''));
    if (ok) { sfx('good'); setFb({ good: true, msg: '✨ Perfect copy!' }); }
    else { const c = lang === 'es' ? classifyEs(x.t, val) : classifyFa(x.w || x.t, val, x.wt || x.tr); sfx('try'); setFb({ good: false, msg: c ? <><b>{MT[c.mt]}:</b> {c.msg}</> : 'Check each word carefully.' }); }
  };
  return (
    <div className="card pop" data-testid="write-copy" data-answer={(globalThis.__LQ_TEST__ ? (lang === 'fa' ? (x.wt || x.tr) : x.t) : undefined)}>
      <Navi small>✍️ Copy this sentence. Look carefully at every letter{lang === 'es' ? ' and accent' : ''}!</Navi>
      <div className="center ex" style={{ margin: '12px 0' }}><PlayBtn lang={lang} text={x.say} sm /> <TT lang={lang} x={lang === 'fa' ? { ...x, t: x.w || x.t, tr: x.wt || x.tr, w: '' } : x} showTr={lang === 'fa'} /><div className="muted">{x.en}</div></div>
      <TextEntry lang={lang} val={val} setVal={setVal} scriptReady={scriptReady} placeholder={lang === 'fa' ? 'Type it here' : 'Escribe aquí'} />
      {fb && <div className={`fb ${fb.good ? 'good' : 'try'}`} style={{ marginTop: 10 }}>{fb.msg}</div>}
      <ActionBar>
        {fb && fb.good ? <button className="btn primary wide" onClick={() => onDone(true, val)} data-testid="next">Next</button>
          : <button className="btn primary wide" disabled={!val.trim()} onClick={check} data-testid="check">Check</button>}
        {fb && !fb.good && <button className="btn" onClick={() => onDone(false, val)}>Later</button>}
      </ActionBar>
    </div>
  );
}

function FillIn({ lang, f, onDone, sess }) {
  const { S, set } = useApp();
  const q = T(lang, f.t, S.settings.variety, f.en);
  const ans = T(lang, f.a);
  const opts = useMemo(() => shuffle((f.opts || [f.a]).map((o) => T(lang, o))), [f]);
  const [sel, setSel] = useState(null);
  const [res, setRes] = useState(null);
  const [tries, setTries] = useState(0);
  const isAns = (o) => (lang === 'es' ? normEs(o.t) === normEs(ans.t) : normFa(o.t) === normFa(ans.t));
  const check = () => {
    if (sel && isAns(sel)) { sfx('good'); setRes({ good: true }); say(lang, fill(q, ans).say); if (sess) { sess.total++; if (!tries) sess.correct++; } set((s) => record(s[lang], !tries)); }
    else { sfx('try'); const t2 = tries + 1; setTries(t2); setRes({ good: false, revealed: t2 >= 2 }); set((s) => { tally(s, lang, f.mt || 'word', sess); record(s[lang], false); }); if (t2 >= 2) say(lang, fill(q, ans).say); }
  };
  const over = res && (res.good || res.revealed);
  return (
    <div className="card pop" data-testid="write-fill">
      <Navi small>✍️ Fill in the missing word.</Navi>
      <div className="center big" style={{ margin: '12px 0' }}><TT lang={lang} x={over ? fill(q, ans) : q} showTr={lang === 'fa'} /></div>
      <div className="muted center">{q.en}</div>
      <div className="choices" style={{ marginTop: 10 }}>{opts.map((o, i) => <button key={i} data-key={i + 1} className={`choice ${over && isAns(o) ? 'right' : sel === o ? (res ? 'wrong' : 'sel') : ''}`} onClick={() => { if (over) return; setSel(o); setRes(null); }} data-ok={isAns(o) ? '1' : '0'}><TT lang={lang} x={o} showTr={lang === 'fa'} showW={false} /></button>)}</div>
      {res && <div className={`fb ${res.good ? 'good' : res.revealed ? 'info' : 'try'}`} style={{ marginTop: 10 }}>{res.good ? praise(lang, !tries) : res.revealed ? <>Here's the word: <b><TT lang={lang} x={ans} showW={false} /></b></> : <>🔎 <b>{MT[f.mt] || MT.word}:</b> {MT_NUDGE[f.mt] || MT_NUDGE.word}</>}</div>}
      <ActionBar>
        {over ? <button className="btn primary wide" onClick={() => onDone(!!res.good, fill(q, ans).t)} data-testid="next">Next</button>
          : <button className="btn primary wide" disabled={!sel} onClick={check} data-testid="check">{!sel ? 'Pick a word' : 'Check'}</button>}
      </ActionBar>
    </div>
  );
}

function Builder({ lang, b, onDone, sess }) {
  const { S, set } = useApp();
  const words = (b.w || []).map((x, i) => ({ ...T(lang, x), i }));
  const [pool, setPool] = useState(() => { let s = shuffle(words); if (s.every((x, k) => x.i === k) && s.length > 1) s = s.slice(1).concat(s[0]); return s; });
  const [ans, setAns] = useState([]);
  const [why, setWhy] = useState(null);
  const [res, setRes] = useState(null);
  const [tries, setTries] = useState(0);
  const sentence = (arr) => arr.map((x) => x.t).join(' ');
  const check = () => {
    const ok = ans.length === words.length && ans.every((x, k) => x.t === words[k].t);
    if (ok) { sfx('good'); setRes({ good: true }); say(lang, sentence(words)); if (sess) { sess.total++; if (!tries) sess.correct++; } set((s) => { record(s[lang], !tries); s.rupees += 2; }); }
    else {
      const c = lang === 'es' ? classifyEs(sentence(words), sentence(ans)) : classifyFa(sentence(words), sentence(ans));
      sfx('try'); setTries(tries + 1); setRes({ good: false, msg: <><b>{MT[(c && c.mt) || 'order']}:</b> {(c && c.msg) || 'Check the order.'}</>, i: c ? c.i : -1 });
      set((s) => { tally(s, lang, (c && c.mt) || 'order', sess); record(s[lang], false); });
    }
  };
  const drag = useRef(null);
  const moveTo = (x, where, before) => {
    if (res && res.good) return;
    const a = ans.filter((y) => y !== x), p = pool.filter((y) => y !== x);
    if (where === 'ans') { const k = before ? a.indexOf(before) : -1; if (k >= 0) a.splice(k, 0, x); else a.push(x); } else p.push(x);
    setAns(a); setPool(p); setRes(null);
  };
  const R = useReading();
  const Tile = ({ x, onClick, hi, zone }) => <button className={`tile ${lang === 'fa' && canRead(x.t, R.set) ? 'fa' : ''}`} draggable onDragStart={(e) => { drag.current = x; e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', x.t); } catch (er) {} }}
    onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); e.stopPropagation(); if (drag.current && drag.current !== x) moveTo(drag.current, zone, zone === 'ans' ? x : null); drag.current = null; }}
    onClick={onClick} style={hi ? { outline: '3px solid #ffb070' } : null} data-tile={x.t}>{lang === 'fa' && !canRead(x.t, R.set) ? (x.tr || x.t) : x.t}{lang === 'fa' && x.tr && canRead(x.t, R.set) ? <span className="tr">{x.tr}</span> : null}</button>;
  return (
    <div className="card pop" data-testid="write-build" data-answer={(globalThis.__LQ_TEST__ ? words.map((w) => w.t).join('|') : undefined)}>
      <Navi small>✍️ Build the sentence: “{b.en}” (tap or drag the words)</Navi>
      <div className="tiles ans" dir={lang === 'fa' ? 'rtl' : 'ltr'} style={{ marginTop: 12 }} data-testid="build-answer" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); if (drag.current) moveTo(drag.current, 'ans'); drag.current = null; }}>
        {ans.length === 0 && <span className="muted">Tap the words in order</span>}
        {ans.map((x, k) => <Tile key={x.i} x={x} zone="ans" hi={res && !res.good && res.i === k} onClick={() => { if (res && res.good) return; setAns(ans.filter((y) => y !== x)); setPool([...pool, x]); setRes(null); }} />)}
      </div>
      <div className="tiles" dir={lang === 'fa' ? 'rtl' : 'ltr'} style={{ marginTop: 10 }} data-testid="build-pool" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); if (drag.current) moveTo(drag.current, 'pool'); drag.current = null; }}>
        {pool.map((x) => <Tile key={x.i} x={x} zone="pool" onClick={() => { if (res && res.good) return; setPool(pool.filter((y) => y !== x)); setAns([...ans, x]); setRes(null); }} />)}
      </div>

      {res && <div className={`fb ${res.good ? (res.shown ? 'info' : 'good') : 'try'}`} style={{ marginTop: 10 }}>{res.good ? <>{res.shown ? 'Here is the order.' : '✨ Perfect!'} {lang === 'fa' ? 'In Farsi the verb comes at the end.' : ''}</> : <>🔎 {res.msg}</>}</div>}
      {!(res && res.good) && <div style={{ marginTop: 10 }}><HintLadder questions={['Who is doing something in this sentence?', 'Where does the action word (verb) go?', 'Which word comes first?']} hints={[lang === 'fa' ? 'Start with who or what the sentence is about.' : 'Start with who the sentence is about.', lang === 'fa' ? 'In Farsi the verb goes at the END.' : 'In Spanish the verb usually comes right after the person.', `The first word is “${words[0] ? words[0].t : ''}”.`]} /></div>}
      <ActionBar>
        {res && res.good ? <button className="btn primary wide" onClick={() => onDone(true, sentence(words))} data-testid="next">Next</button>
          : tries >= 2 ? <button className="btn primary wide" onClick={() => { setAns(words); setPool([]); setRes({ good: true, shown: true }); say(lang, sentence(words)); }} data-testid="show">Show me</button>
          : <button className="btn primary wide" disabled={ans.length !== words.length} onClick={check} data-testid="check">{ans.length !== words.length ? 'Use all the words' : 'Check'}</button>}
      </ActionBar>
    </div>
  );
}

function FreeWrite({ lang, task, need, unit, onDone, scriptReady }) {
  const [val, setVal] = useState('');
  const [saved, setSaved] = useState(false);
  const model = need === 3 ? (task.model || []).map((m) => T(lang, m)) : [T(lang, task.model)];
  return (
    <div className="card pop" data-testid={`write-${need === 3 ? 'three' : 'one'}`} data-answer={globalThis.__LQ_TEST__ ? model.map((m) => (lang === 'fa' ? m.tr : m.t)).join('. ') : undefined}>
      <Navi small>{'✍️ ' + task.prompt}</Navi>
      {task.pic && <div className="huge emoji center" style={{ margin: '10px 0' }}>{task.pic}</div>}
      {!saved ? <TextEntry lang={lang} val={val} setVal={setVal} scriptReady={scriptReady} multiline={need === 3} placeholder={need === 3 ? 'Write 3 short sentences' : 'Write one sentence'} />
        : <div className="fb good">Saved for your grown-up ⭐<div className="small" lang={lang} dir="auto" style={{ marginTop: 6 }}>{val}</div></div>}
      {saved && (
        <div className="card soft" style={{ marginTop: 10 }}>
          <div className="muted">Navi's example:</div>
          {model.map((m, i) => <div key={i} className="row"><PlayBtn lang={lang} text={m.say} sm /><TT lang={lang} x={m} showTr={lang === 'fa'} /></div>)}
        </div>
      )}
      <ActionBar>
        {!saved ? <button className="btn primary wide" disabled={!val.trim()} onClick={() => { sfx('good'); setSaved(true); }} data-testid="check">Done</button>
          : <button className="btn primary wide" onClick={() => onDone(true, val, [])} data-testid="next">Next</button>}
      </ActionBar>
    </div>
  );
}

// ---------- Speaking tasks: picture description and role-play ----------
export function RolePlay({ lang, unit, onDone, sess }) {
  const { S, set } = useApp();
  const role = unit.role || { lines: [] };
  const lines = role.lines || [];
  const [k, setK] = useState(0);
  const who = (role.who || '').toLowerCase().includes('villager') ? 'villagers' : ['saria', 'deku', 'kaepora', 'darunia', 'ruto', 'zelda', 'malon', 'impa', 'talon'].find((x) => (role.who || '').toLowerCase().includes(x)) || 'saria';
  const line = lines[k];
  const npc = line ? T(lang, line.npc, S.settings.variety, line.en) : null;
  useEffect(() => { if (npc) { const t = setTimeout(() => say(lang, npc.say), 400); return () => clearTimeout(t); } }, [k]);
  useEffect(() => { if (!line) onDone({ ok: true }); }, [line]);
  if (!line) return null;
  const opts = (line.opts || []).map((o, i) => ({ x: T(lang, o), ok: i === line.a, sub: T(lang, o).en }));
  const ans = T(lang, line.opts[line.a]);
  return <VoiceAnswer key={k} lang={lang} sess={sess} sayText={ans.say} targets={[ans.t, ans.w].filter(Boolean)} opts={opts} praise={praise(lang, true)}
    prompt={<><div className="row"><Portrait who={who} size="sm" /><h3 className="grow">Talk with {name(who)}</h3><span className="muted">{k + 1}/{lines.length}</span></div>
      <div className="ex row" style={{ marginTop: 10 }}><PlayBtn lang={lang} text={npc.say} sm /><div><TT lang={lang} x={npc} showTr={lang === 'fa'} /><div className="muted">{npc.en}</div></div></div>
      <div style={{ fontWeight: 800, margin: '12px 0 0' }}>What do you answer? Say it!</div></>}
    onDone={() => { if (k + 1 >= lines.length) { set((s) => { const u = s[lang].units[unit.n] || (s[lang].units[unit.n] = {}); u.spk = (u.spk || 0) + 1; }); onDone({ ok: true }); } else setK(k + 1); }} />;
}

export function PicDescribe({ lang, unit, onDone, sess }) {
  const { S, set } = useApp();
  const sp = unit.speak || {};
  const model = (sp.model || []).map((m) => T(lang, m, S.settings.variety));
  const [k, setK] = useState(-1);
  if (k >= 0 && k < model.length) return <SayIt key={k} lang={lang} item={{ ...model[k], e: sp.pic || '🖼️', id: 'pic' + k }} sess={sess} title={`Describe the picture (${k + 1}/${model.length})`} onDone={() => { if (k + 1 < model.length) setK(k + 1); else { set((s) => { const u = s[lang].units[unit.n] || (s[lang].units[unit.n] = {}); u.spk = (u.spk || 0) + 1; }); onDone({ ok: true }); } }} />;
  return (
    <div className="card pop center" data-testid="picdescribe">
      <h2>🗣️ Speaking task</h2>
      <div className="huge emoji" style={{ margin: 10 }}>{sp.pic || '🖼️'}</div>
      <Navi small>{sp.task || 'Describe the picture.'}</Navi>
      <div className="muted" style={{ marginTop: 8 }}>First listen to Navi's example, then say each sentence yourself.</div>
      <ActionBar><button className="btn primary wide" onClick={() => setK(0)} data-testid="next">Start</button></ActionBar>
    </div>
  );
}
