import json, os, sys
lang, fixfile = sys.argv[1], sys.argv[2]
C = json.load(open(fixfile))
R = f'/tmp/lq/content/{lang}'
cache = {}; ok = skip = 0; other = []
for c in C:
    f = c['file']
    if not f.startswith('s'): other.append(c); continue
    if f not in cache: cache[f] = json.load(open(f'{R}/{f}'))
    d = cache[f]; parts = [p for p in str(c['path']).split('/') if p]
    try:
        cur = d
        for p in parts[:-1]: cur = cur[int(p)] if isinstance(cur, list) else cur.setdefault(p, {})
        last = parts[-1]
        val = cur[int(last)] if isinstance(cur, list) else cur.get(last)
        if c.get('old') is not None and val != c['old'] and val != c['new']: skip += 1; print('SKIP', f, c['path']); continue
        if isinstance(cur, list): cur[int(last)] = c['new']
        else: cur[last] = c['new']
        ok += 1
    except Exception as e: skip += 1; print('ERR', f, c['path'], e)
for f, d in cache.items(): json.dump(d, open(f'{R}/{f}.tmp', 'w'), ensure_ascii=False, indent=1); os.replace(f'{R}/{f}.tmp', f'{R}/{f}')
print(lang, 'applied', ok, 'skipped', skip, 'non-story', len(other))
for c in other: print('  OTHER', c['file'], c['path'], json.dumps(c.get('old'), ensure_ascii=False)[:80], '->', json.dumps(c.get('new'), ensure_ascii=False)[:100])
