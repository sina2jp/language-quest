// Packs (kit images, Farsi audio) are classic <script> files that register base64 data on window.__lqPack, so the app
// works from https://, from a file opened straight from disk (file://, where fetch() is blocked) and inside the sandboxed
// artifact viewer (which only loads STATIC references: there the packs are <script data-lqpack> tags in index.html).
import { KITIDX, FAIDX } from './packs.gen.js';
export { KITIDX, FAIDX };
const cache = {};
const OPAQUE = (() => { try { return self.origin === 'null' || location.origin === 'null'; } catch (e) { return true; } })();
function viaScript(src, key) {
  return new Promise((res, rej) => {
    const P = window.__lqPack || {};
    if (P[key]) return res(P[key]);
    const tag = document.querySelector(`script[data-lqpack="${key}"]`);
    if (tag) {
      const to = setTimeout(() => rej(new Error('pack timeout')), 20000);
      tag.addEventListener('load', () => { clearTimeout(to); const v = window.__lqPack && window.__lqPack[key]; v ? res(v) : rej(new Error('pack missing')); });
      tag.addEventListener('error', () => { clearTimeout(to); rej(new Error('pack failed')); });
      return;
    }
    if (OPAQUE && window.__LQ_PREVIEW__) return rej(new Error('pack not in preview'));
    const s = document.createElement('script'); s.src = src; s.async = true;
    s.onload = () => { const v = window.__lqPack && window.__lqPack[key]; v ? res(v) : rej(new Error('pack missing')); };
    s.onerror = () => rej(new Error('pack script failed'));
    document.head.appendChild(s);
  });
}
const b64buf = (b64) => { const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u.buffer; };
export function getPack(_unused, jsUrl, key) {
  if (!cache[key]) {
    cache[key] = viaScript(jsUrl, key).then(b64buf);
    cache[key].catch(() => { delete cache[key]; });
  }
  return cache[key];
}
