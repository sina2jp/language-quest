// Secret Treasures: 18 hidden Gold Skulltula tokens (golden beetles in the Starlit Grove look). Every N tokens earn a
// real-world Reward Ticket from the parent's list; a grown-up approves it with the PIN. Shared rules/tickets: rewards.js.
import React, { useState, useEffect, useRef } from 'react';
import { useApp, Navi, ActionBar } from './ui.jsx';
import { sfx } from './audio.js';
import { emit } from './hooks.js';
import { effectiveSkin } from './sync.js';
import { checkPin, pinIsSet } from './store.js';
import { SECRETS, TOTAL, progress, foundCount, newlyAchieved, bestStreak } from './secrets.js';
import { treasureOf, convertTokens, foundSecret } from './treasure-core.js';
export { treasureOf, convertTokens, foundSecret };
import { readConfig, writeConfig, readTickets, addTicket, markUsed, ticketsAvailable, ts, APP_ID, APP_NAME, APP_NAMES } from './rewards.js';

export const tokenIcon = (S) => (effectiveSkin(S) === 'fallback' ? '🪲' : '🕷️');
const tokenWord = (S) => (effectiveSkin(S) === 'fallback' ? 'golden beetle' : 'Gold Skulltula');
export const CAP_MSG = 'Your treasure chest is full this week. Your Skulltulas will wait for next week!';

// ---- toast ----
export function toast(msg) { try { window.dispatchEvent(new CustomEvent('lq-toast', { detail: msg })); } catch (e) {} }
export function ToastHost() {
  const [m, setM] = useState(null);
  useEffect(() => { let to; const h = (e) => { setM(e.detail); clearTimeout(to); to = setTimeout(() => setM(null), 3200); }; window.addEventListener('lq-toast', h); return () => { window.removeEventListener('lq-toast', h); clearTimeout(to); }; }, []);
  return m ? <div className="toast" role="status" data-testid="toast">{m}</div> : null;
}
function announce(S, ids) {
  for (const id of ids || []) emit('secret', { id });
  const n = foundCount(S);
  sfx('chest');
  toast(`✨ Secret found! ${n}/${TOTAL} · +1 Courage shard`);
}
// ---- find a hidden secret (one-time) ----
export function useFind() {
  const { S, set } = useApp();
  return (id) => { let ok = false; set((s) => { ok = foundSecret(s, id); }); if (ok) announce(S, [id]); return ok; };
}
// A subtle tappable with a faint shimmer about every 20 s; disappears once found. taps: how many quick taps it needs.
export function SecretTap({ id, taps = 1, className = '', style, label = 'sparkle', children }) {
  const { S } = useApp(); const find = useFind();
  const [n, setN] = useState(0); const [last, setLast] = useState(0);
  if (S.treasure && S.treasure.found && S.treasure.found[id]) return children ? <span className={className.replace('secret', '')} style={style}>{children}</span> : null;
  const tap = (e) => { e.stopPropagation(); e.preventDefault(); const now = Date.now(); const k = now - last < 2500 ? n + 1 : 1; setN(k); setLast(now); if (k >= taps) find(id); else sfx('tap'); };
  return <span role="button" tabIndex={0} aria-label={label} className={`secret glow ${className}`} style={style} onClick={tap} onKeyDown={(e) => { if (e.key === 'Enter') tap(e); }} data-secret={id}>{children || '✦'}</span>;
}
// ---- app-level watcher: unlock achievements, convert waiting tokens (new week), open the ticket flow ----
// calm screens where the chest may open (never mid-activity: quest, lesson, story, speaking round)
const CALM = ['home', 'lang', 'treasure', 'ican'];
let ACTIONS = 0; // bumped by the app's set()/go(); the watcher writes only after an action, never at load
export const noteAction = () => { ACTIONS++; };
export function useTreasureWatch(route, go) {
  const { S, set } = useApp();
  const seen = useRef(0);
  useEffect(() => {
    if (ACTIONS === seen.current) return; // nothing is written at load; only after an action
    seen.current = ACTIONS;
    if (!S.nick) return;
    const best = bestStreak(S);
    if (best > ((S.treasure && S.treasure.best) || 0)) { set((s) => { s.treasure.best = best; }); return; }
    const newly = newlyAchieved(S);
    if (newly.length) { set((s) => { for (const id of newly) foundSecret(s, id); }); announce(S, newly); return; }
  });
  // reward tickets are claimed in the Family Wallet (a full Triforce), not from Skulltulas
}
// ---- top-bar counter ----
export function TokenChip() {
  const { S, go } = useApp(); // shown even with rewards off: secrets still collect (no chest or tickets)
  return <button className="chip tokchip" title="Secret treasures" aria-label={`Secret treasures: ${foundCount(S)} of ${TOTAL} found`} onClick={() => go('treasure')} data-testid="tokens"><span className="tok emoji">{tokenIcon(S)}</span> {foundCount(S)}</button>;
}
// ---- PIN check for a grown-up ----
function PinAsk({ onOk, onCancel }) {
  const [pin, setPin] = useState(''); const [err, setErr] = useState('');
  const go = async () => { if (!pinIsSet()) { setErr('A grown-up needs to set a PIN in the Parent corner first.'); return; } if (await checkPin(pin)) { onOk(); } else { setErr('That PIN isn’t right.'); setPin(''); } };
  return (
    <div className="card soft center" data-testid="pin-ask">
      <b>Grown-up: type your PIN to approve</b>
      <input className="field" type="password" inputMode="numeric" maxLength={4} style={{ width: 140, textAlign: 'center', margin: '10px auto', display: 'block' }} value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))} onKeyDown={(e) => { if (e.key === 'Enter') go(); }} data-testid="pin-ask-input" autoFocus />
      {err && <div className="fb info small" data-testid="pin-ask-err">{err}</div>}
      <div className="row c"><button className="btn" onClick={onCancel}>Cancel</button><button className="btn primary" disabled={pin.length !== 4} onClick={go} data-testid="pin-ask-ok">Approve</button></div>
    </div>
  );
}
// "Grown-up: approve" button → PIN → marks the ticket used
function Approve({ t, onChange }) {
  const [ask, setAsk] = useState(false);
  if (t.status === 'used') return null;
  return ask ? <PinAsk onCancel={() => setAsk(false)} onOk={() => { markUsed(t.id); setAsk(false); sfx('win'); onChange && onChange(); }} /> : <button className="btn primary" onClick={() => setAsk(true)} data-testid="approve">Grown-up: approve</button>;
}
export function TicketCard({ t, onChange }) {
  const [ask, setAsk] = useState(false);
  return (
    <div className={`ticket ${t.status}`} data-testid="ticket">
      <div className="tk-emoji emoji">{t.emoji}</div>
      <div className="grow"><div className="tk-text">{t.rewardText}</div><div className="muted small">earned in {APP_NAMES[t.app] || t.app} · {new Date(ts(t.earnedAt)).toLocaleDateString()}</div>
        {t.status === 'used' ? <div className="small">✅ Used {t.usedAt ? new Date(ts(t.usedAt)).toLocaleDateString() : ''}</div> : <div className="tk-show">Show a grown-up!</div>}</div>
      {t.status !== 'used' && !ask && <button className="btn sm primary" onClick={() => setAsk(true)} data-testid="approve">Grown-up: approve</button>}
      {ask && <div style={{ gridColumn: '1 / -1' }}><PinAsk onCancel={() => setAsk(false)} onOk={() => { markUsed(t.id); setAsk(false); sfx('win'); onChange && onChange(); }} /></div>}
    </div>
  );
}
// ---- the Secrets page: "House of Skulltula" ----
export function TreasurePage() {
  const { S, go } = useApp(); const [, setT] = useState(0);
  const c = readConfig(); const t = S.treasure || { found: {}, tokens: 0, toChoose: 0 };
  const mine = readTickets().filter((x) => x.app === APP_ID);
  const finds = SECRETS.filter((x) => x.kind === 'find'); const achs = SECRETS.filter((x) => x.kind === 'achieve');
  return (
    <div style={{ display: 'grid', gap: 14 }} data-testid="treasure">
      <div className="card center"><div className="huge emoji">{tokenIcon(S)}</div><h2 data-testid="found-count">{foundCount(S)} of {TOTAL} found</h2>
        <Navi small>{`Find hidden ${tokenWord(S)}s! Each one gives you a Courage shard for your Triforce.`}</Navi>
      </div>
      <div className="card"><h3>Hidden treasures</h3>
        <div className="secgrid">{finds.map((x) => t.found[x.id] ? <div key={x.id} className="sec found" data-testid="sec-found"><span className="emoji">{x.icon}</span><b>{x.name}</b></div> : <div key={x.id} className="sec hidden" data-testid="sec-hidden"><span className="sil" aria-hidden="true">{tokenIcon(S)}</span><span className="small">{x.hint}</span></div>)}</div>
      </div>
      <div className="card"><h3>Hero challenges</h3>
        <div className="plist">{achs.map((x) => { const v = progress(S, x); const done = !!t.found[x.id]; return (
          <div key={x.id} className="prow" data-testid="ach"><span>{done ? x.icon : '▫️'} <b>{x.name}</b> <span className="muted small">· {x.goal}</span></span>
            <span style={{ minWidth: 120 }}>{done ? '✅' : <><div className="bar sm"><i style={{ width: `${(v / x.target) * 100}%` }} /></div><span className="muted small">{v}/{x.target}</span></>}</span></div>); })}</div>
      </div>
    </div>
  );
}
// ---- earning a ticket: chest → choose your reward → ticket card ----
export function TicketFlow() {
  const { S, set, go } = useApp();
  const [stage, setStage] = useState('chest'); const [tk, setTk] = useState(null); const [, setT] = useState(0);
  const c = readConfig();
  if (!S.treasure || (!S.treasure.toChoose && !tk) || !c.enabled) return <div className="card center" data-testid="ticket-none"><Navi>No ticket to open right now. Keep exploring!</Navi><ActionBar><button className="btn primary wide" onClick={() => go('treasure')}>My secrets</button></ActionBar></div>;
  if (stage === 'chest') return (
    <div className="card center" data-testid="ticket-chest"><div className="reward"><div className="item emoji" style={{ fontSize: '5rem' }}>🧰</div></div><h2>You earned a Reward Ticket!</h2>
      <ActionBar><button className="btn primary wide" onClick={() => { sfx('chest'); setStage('choose'); }} data-testid="open-ticket-chest">Open the chest</button></ActionBar></div>);
  if (stage === 'choose') return (
    <div className="card center" data-testid="ticket-choose"><h2>Choose your reward</h2>
      <div className="rewgrid">{c.rewards.map((r) => <button key={r.id} className="rewcard" onClick={() => { const t = addTicket(r); set((s) => { const tr = treasureOf(s); tr.toChoose = Math.max(0, tr.toChoose - 1); }); setTk(t); setStage('card'); sfx('win'); }} data-testid="reward-card"><span className="emoji">{r.emoji}</span><span>{r.text}</span></button>)}</div>
    </div>);
  const cur = readTickets().find((x) => x.id === tk.id) || tk;
  return (
    <div className="card center" data-testid="ticket-card"><h2>🎟️ Your Reward Ticket</h2>
      <div className="bigticket"><span className="emoji">{cur.emoji}</span> <b>{cur.rewardText}</b> · earned in {APP_NAME} · {cur.status === 'used' ? '✅ approved by a grown-up' : <b className="tk-show">Show a grown-up!</b>}</div>
      <div style={{ marginTop: 12 }}><Approve t={cur} onChange={() => setT((k) => k + 1)} /></div>
      <ActionBar><button className="btn primary wide" onClick={() => go(S.treasure.toChoose ? 'ticket' : 'treasure')} data-testid="ticket-done">{S.treasure.toChoose ? 'Next ticket' : 'My secrets'}</button></ActionBar>
    </div>
  );
}
// ---- Parent corner → Rewards ----
export function ParentRewards() {
  const [c, setC] = useState(readConfig()); const [, setT] = useState(0);
  const save = (patch) => setC(writeConfig(patch)); // re-reads, merges, writes
  const tickets = readTickets();
  // edits stay local while typing and are saved on blur (an emptied reward would otherwise vanish mid-edit)
  const upd = (i, k, v) => setC((cc) => ({ ...cc, rewards: cc.rewards.map((r, j) => (j === i ? { ...r, [k]: v } : r)) }));
  const commit = () => save({ rewards: c.rewards });
  return (
    <div className="plist" data-testid="parent-rewards">
      <div className="muted small">Shared by Math Arena, Language Quest and Code Quest on this browser.</div>
      <label className="prow"><span>Secret treasures and reward tickets</span><input type="checkbox" checked={c.enabled} onChange={(e) => save({ enabled: e.target.checked })} data-testid="rw-on" /></label>
      <label className="prow"><span>Treasures per ticket (1–10)</span><input className="field" type="number" min="1" max="10" style={{ width: 90 }} value={c.tokensPerTicket} onChange={(e) => save({ tokensPerTicket: +e.target.value })} data-testid="rw-tpt" /></label>
      <label className="prow"><span>Tickets per week, all apps (0–14)</span><input className="field" type="number" min="0" max="14" style={{ width: 90 }} value={c.weeklyCap} onChange={(e) => save({ weeklyCap: +e.target.value })} data-testid="rw-cap" /></label>
      <div className="card soft"><b>Reward list</b> <span className="muted small">(up to 8)</span>
        {c.rewards.map((r, i) => (
          <div key={r.id} className="row" style={{ marginTop: 6 }}>
            <input className="field" style={{ width: 64, textAlign: 'center' }} value={r.emoji} onChange={(e) => upd(i, 'emoji', e.target.value)} onBlur={commit} aria-label="emoji" data-testid="rw-emoji" />
            <input className="field grow" value={r.text} onChange={(e) => upd(i, 'text', e.target.value)} onBlur={commit} onKeyDown={(e) => { if (e.key === 'Enter') commit(); }} aria-label="reward" data-testid="rw-text" />
            <button className="btn sm" onClick={() => save({ rewards: readConfig().rewards.filter((x) => x.id !== r.id) })} aria-label="remove" data-testid="rw-del">✕</button>
          </div>))}
        {c.rewards.length < 8 && <button className="btn sm" style={{ marginTop: 8 }} onClick={() => save({ rewards: [...readConfig().rewards, { id: 'r' + Date.now().toString(36), emoji: '🎁', text: 'New reward' }] })} data-testid="rw-add">+ Add a reward</button>}
      </div>
      <div className="card soft"><b>Tickets</b>
        {tickets.length ? tickets.slice(0, 40).map((t) => (
          <div key={t.id} className="prow" data-testid="rw-ticket"><span><span className="emoji">{t.emoji}</span> {t.rewardText} <span className="muted small">· {APP_NAMES[t.app] || t.app} · {new Date(ts(t.earnedAt)).toLocaleDateString()}</span></span>
            {t.status === 'used' ? <span className="muted small">used</span> : <button className="btn sm" onClick={() => { markUsed(t.id); setT((k) => k + 1); }} data-testid="rw-use">Mark as used</button>}</div>)) : <div className="muted small">No tickets yet.</div>}
      </div>
    </div>
  );
}
// mounted inside the app's context provider
export function TreasureWatch({ route }) { const { go } = useApp(); useTreasureWatch(route, go); return null; }
