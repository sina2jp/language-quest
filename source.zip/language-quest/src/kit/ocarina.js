/* Hyrule kit — ocarina.js
 * Five-note ocarina (D4 F4 A4 B4 D5) with big tappable buttons, keyboard keys, and a staff
 * strip showing the notes played. Uses HyruleMusic when present, else a tiny built-in voice.
 * Classic script, also valid as an ES module. Defines globalThis.HyruleOcarina.
 * No song detection for any existing game songs; apps may register their OWN songs via setSongs().
 */
(function () {
  'use strict';
  var G = typeof globalThis !== 'undefined' ? globalThis : window;
  if (G.HyruleOcarina && G.HyruleOcarina.__kit) return;

  var NOTES = [
    { n: 'D4', icon: 'A', shape: 'a', keys: ['1', 'a', ' '], codes: ['Space'], label: 'A / 1' },
    { n: 'F4', icon: '\u25BC', shape: 'c', keys: ['2', 's'], codes: ['ArrowDown'], label: '\u2193 / 2' },
    { n: 'A4', icon: '\u25B6', shape: 'c', keys: ['3', 'd'], codes: ['ArrowRight'], label: '\u2192 / 3' },
    { n: 'B4', icon: '\u25C0', shape: 'c', keys: ['4', 'f'], codes: ['ArrowLeft'], label: '\u2190 / 4' },
    { n: 'D5', icon: '\u25B2', shape: 'c', keys: ['5', 'g'], codes: ['ArrowUp'], label: '\u2191 / 5' }
  ];
  var MIN_HOLD = 0.14; // seconds: quick taps still sound

  var CSS = '' +
    '.hk-ocarina{--o-f9:var(--hk-forest-900,#0f2a1d);--o-f7:var(--hk-forest-700,#1f4a2e);--o-f5:var(--hk-forest-500,#3f7a3a);--o-leaf:var(--hk-leaf-300,#9cc06a);' +
    '--o-g5:var(--hk-gold-500,#d4a73c);--o-g3:var(--hk-gold-300,#f0d58a);--o-p1:var(--hk-parchment-100,#f6ecd2);--o-p3:var(--hk-parchment-300,#e3cf9f);' +
    '--o-wood:var(--hk-wood-700,#5a3a22);--o-ink:var(--hk-ink-900,#1b1a17);--o-navi:var(--hk-navi-300,#a9e4ff);--o-ruby:var(--hk-ruby-500,#c0392b);' +
    'font-family:var(--hk-font-body,"Nunito",system-ui,sans-serif);color:var(--o-ink);box-sizing:border-box;width:100%;max-width:760px;margin:0 auto;' +
    'background:linear-gradient(180deg,var(--o-p1),var(--o-p3));border:3px solid var(--o-wood);border-radius:18px;padding:14px 14px 16px;' +
    'box-shadow:inset 0 0 0 2px var(--o-g5),0 6px 18px rgba(0,0,0,.28);user-select:none;-webkit-user-select:none;touch-action:manipulation}' +
    '.hk-ocarina *{box-sizing:border-box}' +
    '.hk-ocarina .hk-o-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px}' +
    '.hk-ocarina .hk-o-title{font-family:var(--hk-font-title,"Cinzel",Georgia,serif);font-weight:700;font-size:20px;letter-spacing:.04em;color:var(--o-f7)}' +
    '.hk-ocarina .hk-o-clear{font:inherit;font-weight:700;font-size:15px;min-height:40px;padding:6px 16px;border-radius:999px;border:2px solid var(--o-wood);' +
    'background:var(--o-p1);color:var(--o-wood);cursor:pointer}' +
    '.hk-ocarina .hk-o-clear:focus-visible,.hk-ocarina .hk-o-btn:focus-visible{outline:3px solid var(--o-f5);outline-offset:2px}' +
    '.hk-ocarina .hk-o-staff{position:relative;height:118px;border-radius:12px;background:var(--o-p1);border:2px solid var(--o-wood);overflow:hidden;margin-bottom:12px}' +
    '.hk-ocarina .hk-o-line{position:absolute;left:10px;right:10px;height:2px;background:rgba(90,58,34,.55)}' +
    '.hk-ocarina .hk-o-notes{position:absolute;inset:0;display:flex;align-items:stretch;justify-content:flex-start;padding:0 14px;gap:0}' +
    '.hk-ocarina .hk-o-slot{position:relative;flex:0 0 calc((100% - 28px)/var(--o-max,8));height:100%;animation:hkOIn .18s ease-out}' +
    '.hk-ocarina .hk-o-note{position:absolute;left:50%;width:30px;height:30px;margin:-15px 0 0 -15px;border-radius:50%;display:flex;align-items:center;justify-content:center;' +
    'font-weight:800;font-size:15px;line-height:1;border:2px solid var(--o-ink)}' +
    '.hk-ocarina .hk-o-note.a{background:var(--o-navi);color:var(--o-f9)}' +
    '.hk-ocarina .hk-o-note.c{background:var(--o-g3);color:var(--o-wood)}' +
    '.hk-ocarina .hk-o-name{position:absolute;bottom:3px;left:0;right:0;text-align:center;font-size:12px;font-weight:700;color:var(--o-wood)}' +
    '.hk-ocarina .hk-o-empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:15px;color:var(--o-wood);opacity:.75}' +
    '.hk-ocarina .hk-o-pad{display:grid;grid-template-columns:repeat(5,1fr);gap:10px}' +
    '.hk-ocarina .hk-o-btn{font:inherit;position:relative;min-height:84px;border-radius:16px;border:3px solid var(--o-wood);cursor:pointer;display:flex;flex-direction:column;' +
    'align-items:center;justify-content:center;gap:4px;padding:6px 2px;background:linear-gradient(180deg,var(--o-f5),var(--o-f7));color:var(--o-p1);' +
    'box-shadow:0 4px 0 var(--o-wood);transition:transform .06s,box-shadow .06s,background .06s;touch-action:none}' +
    '.hk-ocarina .hk-o-btn .hk-o-ic{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:20px;border:2px solid var(--o-ink)}' +
    '.hk-ocarina .hk-o-btn.a .hk-o-ic{background:var(--o-navi);color:var(--o-f9)}' +
    '.hk-ocarina .hk-o-btn.c .hk-o-ic{background:var(--o-g3);color:var(--o-wood)}' +
    '.hk-ocarina .hk-o-btn .hk-o-nn{font-family:var(--hk-font-title,"Cinzel",Georgia,serif);font-weight:700;font-size:16px}' +
    '.hk-ocarina .hk-o-btn .hk-o-key{font-size:12px;font-weight:700;opacity:.9;background:rgba(15,42,29,.45);border-radius:6px;padding:1px 6px}' +
    '.hk-ocarina .hk-o-btn.on{transform:translateY(3px);box-shadow:0 1px 0 var(--o-wood);background:linear-gradient(180deg,var(--o-leaf),var(--o-f5))}' +
    '.hk-ocarina .hk-o-match{margin-top:10px;min-height:22px;text-align:center;font-family:var(--hk-font-title,"Cinzel",Georgia,serif);font-weight:700;color:var(--o-f7)}' +
    '.hk-ocarina.hk-o-small .hk-o-btn{min-height:70px}.hk-ocarina.hk-o-small .hk-o-btn .hk-o-key{display:none}' +
    '@media (max-width:520px){.hk-ocarina{padding:10px}.hk-ocarina .hk-o-pad{gap:6px}.hk-ocarina .hk-o-btn{min-height:76px;border-radius:14px}' +
    '.hk-ocarina .hk-o-btn .hk-o-ic{width:34px;height:34px;font-size:17px}.hk-ocarina .hk-o-btn .hk-o-nn{font-size:14px}.hk-ocarina .hk-o-btn .hk-o-key{font-size:11px;padding:1px 4px}' +
    '.hk-ocarina .hk-o-staff{height:104px}.hk-ocarina .hk-o-note{width:26px;height:26px;margin:-13px 0 0 -13px;font-size:13px}}' +
    '@keyframes hkOIn{from{transform:translateX(14px);opacity:0}to{transform:none;opacity:1}}' +
    '@media (prefers-reduced-motion:reduce){.hk-ocarina .hk-o-slot{animation:none}}';

  function injectCSS() {
    if (!G.document || G.document.getElementById('hk-ocarina-css')) return;
    var s = G.document.createElement('style'); s.id = 'hk-ocarina-css'; s.textContent = CSS;
    (G.document.head || G.document.documentElement).appendChild(s);
  }

  // fallback tiny voice when HyruleMusic is absent
  var fctx = null;
  function fallbackOn(nm) {
    var AC = G.AudioContext || G.webkitAudioContext; if (!AC) return null;
    if (!fctx) fctx = new AC(); if (fctx.state !== 'running') fctx.resume();
    var P = { D4: 62, F4: 65, A4: 69, B4: 71, D5: 74 }, f = 440 * Math.pow(2, (P[nm] - 69) / 12), t = fctx.currentTime;
    var o = fctx.createOscillator(), g = fctx.createGain(), l = fctx.createOscillator(), lg = fctx.createGain();
    o.type = 'sine'; o.frequency.value = f; l.frequency.value = 5.2; lg.gain.setValueAtTime(0, t); lg.gain.linearRampToValueAtTime(f * 0.006, t + 0.5);
    l.connect(lg); lg.connect(o.frequency); o.connect(g); g.connect(fctx.destination);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.25, t + 0.04);
    o.start(t); l.start(t);
    return { off: function () { var e = fctx.currentTime; g.gain.cancelScheduledValues(e); g.gain.setValueAtTime(g.gain.value, e); g.gain.setTargetAtTime(0, e, 0.04); o.stop(e + 0.3); l.stop(e + 0.3); } };
  }
  function soundOn(nm) {
    var M = G.HyruleMusic;
    if (M && M.noteOn) {
      if (!M.isUnlocked || !M.isUnlocked()) M.unlock();
      return M.noteOn('ocarina', nm, 0.85);
    }
    return fallbackOn(nm);
  }

  function mount(container, opts) {
    if (typeof container === 'string') container = G.document.querySelector(container);
    if (!container) throw new Error('HyruleOcarina.mount: container not found');
    opts = opts || {};
    var useKeys = opts.keys !== false, showStaff = opts.showStaff !== false, maxShown = opts.maxShown || 8;
    injectCSS();
    var doc = G.document, root = doc.createElement('div');
    root.className = 'hk-ocarina' + (opts.size === 'small' ? ' hk-o-small' : '');
    root.style.setProperty('--o-max', String(maxShown));
    root.setAttribute('role', 'group'); root.setAttribute('aria-label', 'Ocarina');
    root.innerHTML = '<div class="hk-o-head"><div class="hk-o-title">' + (opts.title || 'Ocarina') + '</div>' +
      '<button type="button" class="hk-o-clear">Clear</button></div>' +
      (showStaff ? '<div class="hk-o-staff" aria-live="polite"><div class="hk-o-notes"></div><div class="hk-o-empty">Play a note!</div></div>' : '') +
      '<div class="hk-o-pad"></div><div class="hk-o-match" aria-live="polite"></div>';
    container.appendChild(root);
    var staff = root.querySelector('.hk-o-staff'), notesEl = root.querySelector('.hk-o-notes'), emptyEl = root.querySelector('.hk-o-empty');
    var pad = root.querySelector('.hk-o-pad'), matchEl = root.querySelector('.hk-o-match');
    // 5 staff lines; note y positions (D4 lowest .. D5 highest) as % of staff height
    var Y = { D4: 78, F4: 64, A4: 50, B4: 36, D5: 22 };
    if (staff) [22, 36, 50, 64, 78].forEach(function (y) { var l = doc.createElement('div'); l.className = 'hk-o-line'; l.style.top = 'calc(' + y + '% - 1px)'; staff.insertBefore(l, notesEl); });

    var history = [], songs = [], active = {}, btns = {}, destroyed = false;
    NOTES.forEach(function (N) {
      var b = doc.createElement('button');
      b.type = 'button'; b.className = 'hk-o-btn ' + N.shape; b.setAttribute('aria-label', 'Note ' + N.n + ' (key ' + N.label + ')');
      b.innerHTML = '<span class="hk-o-ic">' + N.icon + '</span><span class="hk-o-nn">' + N.n.replace(/\d/, '') + '</span>' + (useKeys ? '<span class="hk-o-key">' + N.label + '</span>' : '');
      pad.appendChild(b); btns[N.n] = b;
      b.addEventListener('pointerdown', function (e) {
        e.preventDefault();
        try { b.setPointerCapture(e.pointerId); } catch (x) { /* noop */ }
        press(N.n, 'p' + e.pointerId);
      });
      var up = function (e) { release(N.n, 'p' + e.pointerId); };
      b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('lostpointercapture', up);
      b.addEventListener('contextmenu', function (e) { e.preventDefault(); });
      b.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.repeat) { e.preventDefault(); press(N.n, 'kEnter'); } });
      b.addEventListener('keyup', function (e) { if (e.key === 'Enter') release(N.n, 'kEnter'); });
    });

    function press(nm, src) {
      if (destroyed) return;
      var a = active[nm];
      if (a) { a.srcs[src] = 1; return; }
      var srcs = {}; srcs[src] = 1;
      active[nm] = { h: soundOn(nm), t: Date.now(), srcs: srcs };
      btns[nm].classList.add('on');
      record(nm);
    }
    function release(nm, src) {
      var a = active[nm]; if (!a) return;
      if (src) { delete a.srcs[src]; if (Object.keys(a.srcs).length) return; }
      delete active[nm];
      btns[nm].classList.remove('on');
      var left = MIN_HOLD * 1000 - (Date.now() - a.t);
      if (a.h) { if (left > 0) setTimeout(function () { a.h.off(); }, left); else a.h.off(); }
    }
    function releaseAll() { Object.keys(active).forEach(function (nm) { release(nm, null); }); }
    function record(nm) {
      history.push(nm); if (history.length > 200) history.shift();
      if (opts.onNote) try { opts.onNote(nm); } catch (e) { /* app error */ }
      draw(true);
      checkSongs();
    }
    function draw(animateLast) {
      if (!notesEl) return;
      var shown = history.slice(-maxShown);
      notesEl.innerHTML = '';
      emptyEl.style.display = shown.length ? 'none' : '';
      shown.forEach(function (nm, i) {
        var N = NOTES.filter(function (x) { return x.n === nm; })[0], s = doc.createElement('div');
        s.className = 'hk-o-slot'; if (!(animateLast && i === shown.length - 1)) s.style.animation = 'none';
        s.innerHTML = '<div class="hk-o-note ' + N.shape + '" style="top:' + Y[nm] + '%">' + N.icon + '</div><div class="hk-o-name">' + nm.replace(/\d/, '') + '</div>';
        notesEl.appendChild(s);
      });
    }
    var since = 0; // index after last match, so a song matches once per performance
    function checkSongs() {
      for (var i = 0; i < songs.length; i++) {
        var sg = songs[i], L = sg.notes.length;
        if (!L || history.length - since < L) continue;
        var tail = history.slice(-L), ok = true;
        for (var j = 0; j < L; j++) if (tail[j] !== sg.notes[j]) { ok = false; break; }
        if (ok) {
          since = history.length;
          matchEl.textContent = '\u2605 ' + (sg.name || sg.id) + ' \u2605';
          setTimeout(function () { if (!destroyed) matchEl.textContent = ''; }, 2500);
          if (sg.onMatch) try { sg.onMatch(sg); } catch (e) { /* app error */ }
          break;
        }
      }
    }
    function clear() { history = []; since = 0; matchEl.textContent = ''; draw(false); }
    root.querySelector('.hk-o-clear').addEventListener('click', clear);

    function typing(e) { var t = e.target; return t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)); }
    function keyNote(e) {
      if (e.ctrlKey || e.metaKey || e.altKey) return null;
      var k = (e.key || '').toLowerCase();
      for (var i = 0; i < NOTES.length; i++) if (NOTES[i].keys.indexOf(k) >= 0 || NOTES[i].codes.indexOf(e.code) >= 0) return NOTES[i].n;
      return null;
    }
    function kd(e) {
      if (typing(e) || (e.target && e.target.closest && e.target.closest('button') && e.key === ' ' && !root.contains(e.target))) return;
      var nm = keyNote(e); if (!nm) return;
      if (!root.isConnected) return;
      e.preventDefault(); if (e.repeat) return;
      press(nm, 'k' + (e.code || e.key));
    }
    function ku(e) { var nm = keyNote(e); if (nm) release(nm, 'k' + (e.code || e.key)); }
    function vis() { if (doc.hidden) releaseAll(); }
    if (useKeys) { G.addEventListener('keydown', kd); G.addEventListener('keyup', ku); }
    G.addEventListener('blur', releaseAll); doc.addEventListener('visibilitychange', vis);
    draw(false);

    return {
      el: root,
      destroy: function () {
        destroyed = true; releaseAll();
        if (useKeys) { G.removeEventListener('keydown', kd); G.removeEventListener('keyup', ku); }
        G.removeEventListener('blur', releaseAll); doc.removeEventListener('visibilitychange', vis);
        if (root.parentNode) root.parentNode.removeChild(root);
      },
      clear: clear,
      played: function () { return history.slice(); },
      setSongs: function (list) {
        songs = (list || []).filter(function (s) { return s && s.notes && s.notes.length; }).map(function (s) { return { id: s.id, name: s.name, notes: s.notes.slice(), onMatch: s.onMatch }; });
        since = history.length;
      },
      play: function (nm, ms) { if (!btns[nm]) return; press(nm, 'api'); setTimeout(function () { release(nm, 'api'); }, ms || 300); }
    };
  }

  G.HyruleOcarina = { __kit: true, version: '1.0', notes: NOTES.map(function (n) { return n.n; }), mount: mount };
})();
