# Family Sync: integration guide for the 4 app builders

`family-sync.js` 1.0.1 gives every app on `https://sina2jp.github.io/` one shared, opt-in sync. The parent sets everything up in the **Family Hub** (`/family/`) on his own laptop. His son's laptop connects once, with one link. All 4 apps share the origin, so one connect covers all of them.

**When a device is not connected, nothing changes.** The module makes no network calls and writes no localStorage keys, and every call below is a safe no-op. Apps keep rendering from local data first.

## 1. Add the file (byte-identical, like family-wallet.js)

- Copy `family-sync.js` unchanged next to `family-wallet.js`. Check its sha256 (it is in `SHA256SUMS`). Publish it as its own dist file, or inline it unchanged into your bundle.
- Load it after `family-wallet.js`: `<script src="family-sync.js"></script>` gives you `window.FamilySync`. ES modules can use `import './family-sync.js'; const FS = globalThis.FamilySync;`.
- Add it to `sw.js` precache, and keep the app shell network-first, as today.
- Packaging scrub: the file contains none of the scrubbed words.

## 2. Start it after your first render

```js
const FS = globalThis.FamilySync;
FS.register('math', { /* your keys: section 3, already built in */ });
FS.start({ app: 'math', version: BUILD_ID });   // never blocks; no-op when not connected
window.addEventListener('familysync:update', (e) => onFamilyUpdate(e.detail.keys));
```

- `start()` waits about 300 ms. It then pulls with a 3 s timeout, pushes his changes, and keeps going:
  - It snapshots hashes every 10 s.
  - It pulls every 60 s while the page is visible, and on focus.
  - It flushes with `fetch keepalive` on `visibilitychange` (hidden) and on `pagehide`.
  - It queues changes while offline and retries with backoff.
  - Tabs coordinate through `navigator.locks`, or through a localStorage lease where locks are missing.
- You never call push or pull yourself. Keep writing localStorage exactly as today, and the snapshot loop picks up the changes.

## 3. Keys per app

Every key has one writer:
- **settings** keys are written only by the Hub (a grown-up device). His laptop only receives them.
- **progress** keys are written only by his laptop. They are never pushed from a grown-up device.
- **localOnly** keys are never synced.

These lists are already built into `family-sync.js`, so every tab knows every app's rules. Call `register()` with the same lists anyway. It documents the keys and covers anything you add later.

| App id | settings (Hub → his laptop) | progress (his laptop → cloud) | localOnly (never synced) |
|---|---|---|---|
| `math` | `mathArena.v3.schoolSync.v1` with `keepLocal: ['done']` (his book "done" marks stay on his laptop) | `mathArena.v3.data.v1`, `mathArena.v3.nickname`, `mathArena.v3.comebackStart`, `mathArena.v3.mockResults` | `mathArena.v3.active.v1`, `.questTab`, `.muted`, `.keypad`, `.migration`, `.lastBackup`, `.aiUsage`, `.test`; all classic `mathArena.*` keys (read by `/classic/`) |
| `language` | (none) | `langQuest.state` | `langQuest.pin`; IndexedDB `langQuest.voices` (family voice recordings) |
| `code` | (none) | `codeQuest.progress.v1`, `codeQuest.settings.v1`, `codeQuest.secrets.v1`, `codeQuest.schema` | `codeQuest.parentPin.v1`, `codeQuest.usage.v1`, `familyApps.usage.v1`; IndexedDB `codeQuest.db` (projects, versions: too big) |
| `music` | `musicQuest.myLessons.v1` | `musicQuest.v1` | IndexedDB `musicQuest` (recordings) |

The family keys are built in, so don't register them:
- **Settings** (Hub only):
  - `familyApps.rewards.v1`: shape unchanged, plus an optional `wallet` field holding `{mode, appsInSet, perApp, costs, …}` in family-wallet.js's settings shape. His laptop applies that field through `FamilyWallet.setSettings`.
  - `familyApps.pin.v1`: one family PIN, stored as a salted PBKDF2 hash.
  - `familyApps.anthropicKey.v1`: AES-GCM encrypted in transit and at rest. His laptop decrypts it into the same plain-string key, so your AI code is unchanged.
  - `familyApps.walletAdjust.v1`, `familyApps.ticketApprovals.v1`: the parent's requests.
  - `familyApps.look.v1`: `{v:1, skin:'hyrule'|'grove'}`.
- **Progress** (his laptop):
  - `familyApps.wallet.v1`, `familyApps.walletTime.v1`, `familyApps.tickets.v1`, `familyApps.inventory.v1`.
  - `familyApps.requestsDone.v1`: which requests were applied.
  - `familyApps.summary.<app>.v1` (section 6).
  - `familyApps.syncHealth.v1` (1.0.1): his laptop's sync health for the Hub (`state`, `paused: 'too-big'|'not-writer'`, `tooBig: [{key, size}]`). The module writes it itself, only when it changes.

## 4. PIN: route every check to the family PIN when it is set

`FS.pinIsSet()` is synchronous. `FS.checkPin(pin)` returns `Promise<boolean>`. The family PIN is 4 digits. When it is set, it **replaces** your local PIN. Your local PIN stays as it is and is used again only if the device is disconnected.

```js
async function pinOk(entered) {
  if (FS.pinIsSet()) return FS.checkPin(entered);
  return localCheck(entered);                       // today's code
}
```

- **Math:**
  - The `app.jsx` PIN pad (`v !== data.settings.pin`), the `ParentGate` in `parent.jsx`, the PIN prop in `play.jsx` and the book-confirm PIN: use `await pinOk(v)`.
  - `setup.jsx needsPin`: return `false` when `FS.pinIsSet()`, which skips the PIN step on his laptop.
- **Language:**
  - `store.js`: `pinIsSet = () => FS.pinIsSet() || !!getRaw('pin')`.
  - `checkPin(p)`: `if (FS.pinIsSet()) return FS.checkPin(p)` first.
- **Code:**
  - The `parent.js` unlock: if `FS.pinIsSet()`, check with `FS.checkPin(pin)`.
  - Skip "Set your PIN" and the default-PIN path.
- **Music:**
  - `14-parent.js askPin`: if `FS.pinIsSet()`, resolve with `await FS.checkPin(val)`.
  - Skip the first-time "choose a PIN" step.
- **All apps:** when `FS.pinIsSet()`, replace "Change PIN" with the line "The PIN is set in the Family Hub."

## 5. When his laptop is connected, family settings come from the Hub

Check `FS.isConnected() && FS.role() === 'kid'`. When it is true, show these panels read-only, with one line: "Set in the Family Hub on the grown-up's laptop."

- Rewards: replace `FamilyWallet.mountParent` with that line. Approving a ticket with the PIN on his laptop still works.
- AI key: keep the Test button, but no Save or Remove.
- PIN.
- Look picker.
- Math School sync paste/clear, and Music lesson-code Import/Clear.

If an app writes a family setting locally anyway, the next start puts the Hub's value back (drift repair).

**Look:** on start and on update, read `const skin = FS.look()`. It returns `'hyrule'`, `'grove'` or `null`. If it is not null, it overrides your own look setting.
- Math: `data.settings.skin`; map `'grove'` to your Starlit Grove id.
- Language: `state.skin`.
- Code: `'grove'` → `'original'`.
- Music: `settings.look`.

The module already writes `hyruleKit.skin`, so `HyruleKit` starts in the right skin. Call `HyruleKit.use(skin)` live only on a calm screen; otherwise it applies on the next load.

## 6. Weekly summary for the parent's dashboard

Call `FS.writeSummary(app, { week: {...}, total: {...}, lastActive })` after a lesson, quest, boss or mastery change. It is cheap, deduplicated and writes about 8 KB at most.
- It writes only on his connected laptop, and never on a grown-up device or a disconnected one.
- Values are numbers, short strings or booleans. Nesting can go one level deep (for example `total.words: {es, fa}`).
- The Hub computes **active minutes and shards** itself from `familyApps.walletTime.v1` and the wallet ledger, so don't repeat them.

| App | `week` (this Sun–Sat) | `total` |
|---|---|---|
| math | `lessons` (quests and codex pages finished), `problems`, `correct`, `readChecks`, `readAccuracy` (% careful reads passed, 0–100), `mastered` (pages reaching Mastered this week) | `mastered`, `confirmed`, `learning` (mastery counts), `codexPages` |
| language | `lessons` (quests and lessons finished), `wordsLearned` (new words reaching "learned"), `speakingTries` | `wordsLearned` (or `words: {es, fa}`), `level` |
| code | `lessons`, `gamesBuilt` (new games saved), `robotMissions` | `gamesBuilt`, `lessons` |
| music | `lessons`, `practiceMin` (My Piano Lessons and instrument practice), `piecesPracticed` | `lessons`, `beltsEarned` |

`lastActive` defaults to now. For example:

```js
FS.writeSummary('math', { week: { lessons: 3, problems: 41, correct: 35, readChecks: 12, readAccuracy: 83, mastered: 1 }, total: { mastered: 7, confirmed: 2, learning: 4, codexPages: 13 } });
```

## 7. Parent corner: the status dot and the Connect panel

- **Status dot:** call `FS.mountStatus(el)` in the Parent corner header. It shows a tiny "☁ synced" (or "saving…", "offline · saved here", "sync paused", or in 1.0.1 "sync paused · too big" when a key is over 300 KB), with the last sync time and any too-big keys as a tooltip. It shows nothing when not connected.
- **Connect panel:** call `FS.mountConnect(el)` in a "Family sync" card in the Parent corner, behind the PIN. It is the fallback for typing the 6-character code from the Hub.
  - When connected, it shows "This laptop is connected to the family ✓".
  - The code needs `/family/endpoint.json` to be published. Otherwise it tells the user to open the family link instead.
- **Practice banner:** call `FS.mountPracticeBanner(el)` in your top bar. On a grown-up device it shows "Your laptop: practice copy · his progress is not changed here"; everywhere else it shows nothing. The grown-up's laptop never pushes progress.

## 8. Handle `familysync:update`

`detail.keys` lists what changed. `detail.source` is `'pull'`, `'connect'`, `'repair'`, `'requests'`, `'guard'` (1.0.1: a stale overwrite of just-downloaded progress was undone) or `'tab'` (another tab applied it). Treat `'guard'` like `'connect'`: re-read your progress key from storage before your next save.
- **Family settings** (`familyApps.rewards.v1`, `.pin.v1`, `.look.v1`, `.anthropicKey.v1`): re-read them where you cache them. FamilyWallet reads storage on every call, so the wallet UI only needs its `update()`.
- **`mathArena.v3.schoolSync.v1` / `musicQuest.myLessons.v1`:** re-read them (`loadSync()`, `L.load()`) and refresh Today's quest and My Piano Lessons when the screen is calm.
- **Your own progress key:** this only happens after a first connect that downloaded his cloud progress (the join page, in another tab). Soft-refresh at a calm moment: `if (calm) location.reload(); else pendingReload = true;`. Never interrupt a quest, lesson or boss.

Parent requests (`walletAdjust`, `ticketApprovals`) are applied automatically on his laptop, exactly once by id, through `FamilyWallet`. They arrive as a `requests` update for the wallet and tickets keys. Call `FS.applyParentRequests()` yourself only if you load FamilyWallet late.

## 8b. 1.0.1: the first minute after joining

When his laptop joins and the cloud copy of a progress group wins, the module watches the downloaded keys for 60 s. If one of them is overwritten with less progress than the downloaded copy (an app saving stale in-memory state), it is not pushed. The module puts the cloud copy back and sends `familysync:update` with `source: 'guard'`. Real new progress (more than the download) goes up at once. `FS.log()` lists the last 20 guard events. Your part: never save a cached copy in response to a `connect` or `guard` update. Re-read storage first.

## 9. Don'ts and the test checklist

- Don't write a family settings key from an app on a connected kid device. Don't write progress keys on a grown-up device from Hub code.
- Don't cache `familyApps.*` values for the life of the page without re-reading them on `familysync:update`.
- Don't call `FS.connect` or `FS.disconnect` from app code. The Hub and the Connect panel own them.
- Test checklist:
  1. When not connected, the app behaves exactly as before, and `localStorage` gains no `familyApps.sync.*` keys.
  2. Use the mock: `node tools/mock-server.mjs --static <site>`, set up in `/family/` (paste `http://127.0.0.1:8787/exec`), then open the join link in another browser profile.
  3. After joining, the family PIN unlocks your Parent corner, and your summary shows up in the Hub.
  4. Two tabs of your app plus offline/online in DevTools: nothing doubles and nothing is lost.
