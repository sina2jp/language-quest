// React wrappers around the Family Wallet's mountable parts (family-wallet.js renders its own DOM).
import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { FW, APP, imageFor, skinOf, pinCheck } from './wallet.js';
import { AppCtx, useApp } from './ui.jsx';

function useMount(mountFn, deps) {
  const ref = useRef(null);
  useEffect(() => {
    if (!FW || !ref.current) return undefined;
    let m = null; try { m = mountFn(ref.current); } catch (e) { try { (globalThis.__lqDiagAdd || console.warn)('wallet UI: ' + (e && e.message)); } catch (e2) {} }
    let off = null; try { off = FW.onChange(() => { try { m && m.update && m.update(); } catch (e) {} }); } catch (e) {}
    const onSync = () => { try { m && m.update && m.update(); } catch (e) {} }; // family settings / parent requests arrived
    window.addEventListener('familysync:update', onSync);
    return () => { window.removeEventListener('familysync:update', onSync); try { off && off(); } catch (e) {} try { m && m.destroy && m.destroy(); } catch (e) {} };
  }, deps);
  return ref;
}
// top bar: the mini Triforce (shards per app) + shared rupees; opens the Treasure Wallet
export function WalletCounter() {
  const { S, go } = useApp(); const skin = skinOf(S);
  const ref = useMount((el) => FW.mountCounter(el, { app: APP, skin, onOpen: () => go('wallet') }), [skin]);
  if (!FW) return null;
  return <span ref={ref} className="lq-fw-counter" data-testid="fw-counter" />;
}
// the Treasure Wallet (Triforce progress, Claim a reward, My tickets, Secrets tab = our House of Skulltula)
export function WalletScreen({ renderSecretsInto }) {
  const ctx = useApp(); const { S, go, kitReady } = ctx; const skin = skinOf(S);
  const roots = useRef([]);
  const ref = useMount((el) => FW.mountWallet(el, {
    app: APP, skin, imageFor, pinCheck, onOpenMarket: () => go('market'),
    renderSecrets: (box) => { try { const r = createRoot(box); r.render(<AppCtx.Provider value={ctx}>{renderSecretsInto()}</AppCtx.Provider>); roots.current.push(r); } catch (e) {} },
  }), [skin, kitReady]);
  useEffect(() => () => { for (const r of roots.current) { try { r.unmount(); } catch (e) {} } }, []);
  return <div ref={ref} className="lq-fw" data-testid="fw-wallet" />;
}
export function MarketScreen() {
  const { S, kitReady } = useApp(); const skin = skinOf(S);
  const ref = useMount((el) => FW.mountMarket(el, { app: APP, skin, imageFor }), [skin, kitReady]);
  return <div ref={ref} className="lq-fw" data-testid="fw-market" />;
}
export function GoalBar() {
  const { S, go, kitReady } = useApp(); const skin = skinOf(S);
  const ref = useMount((el) => FW.mountGoal(el, { app: APP, skin, imageFor, onOpen: () => go('market') }), [skin, kitReady]);
  if (!FW) return null;
  return <div ref={ref} className="lq-fw-goal" data-testid="fw-goal" />;
}
export function ParentWallet() {
  const { S } = useApp(); const skin = skinOf(S);
  const ref = useMount((el) => FW.mountParent(el, { app: APP, skin }), [skin]);
  return <div ref={ref} className="lq-fw" data-testid="fw-parent" />;
}
// equipped cosmetics (background, buddy, Navi color, music, title, plus our old shop slots)
export function useEquipped() {
  const [eq, setEq] = useState({});
  useEffect(() => {
    if (!FW) return undefined;
    const cur = {};
    const set = (k) => (item) => { cur[k] = item || null; setEq({ ...cur }); };
    let off = null;
    try { off = FW.applyEquipped({ setBackground: set('background'), setBuddy: set('buddy'), setNaviColor: set('naviColor'), setMusic: set('music'), setTitle: set('title') }); } catch (e) {}
    const legacy = () => { try { const inv = FW.inventory() || {}; const e = inv.equipped || {}; document.body.dataset.navi = (e['language.navi'] || '').replace('language.', ''); document.body.dataset.tunic = (e['language.tunic'] || '').replace('language.', ''); } catch (e) {} };
    legacy(); let off2 = null; try { off2 = FW.onChange(legacy); } catch (e) {}
    return () => { try { off && off(); off2 && off2(); } catch (e) {} };
  }, []);
  return eq;
}
