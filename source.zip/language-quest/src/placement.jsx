import React, { useState, useMemo, useEffect } from 'react';
import { useApp, Navi, PlayBtn, TT, ActionBar, Portrait } from './ui.jsx';
import { say, sfx } from './audio.js';
import { shuffle, LEVELS } from './engine.js';
import { unitItems, getUnit } from './content.js';
import { LESSONS } from './script.jsx';

// 5-minute, game-like placement: 3 rounds of 4 questions, from easy to hard. Stops when a round is too hard.
export function Placement({ lang, onDone }) {
  const { S, set } = useApp();
  const variety = S.settings.variety;
  const [phase, setPhase] = useState('intro');
  const [round, setRound] = useState(0);
  const [q, setQ] = useState(0);
  const [score, setScore] = useState([0, 0, 0]);
  const [sel, setSel] = useState(null);
  const [result, setResult] = useState(null);
  const [reads, setReads] = useState(null);
  const bands = useMemo(() => LEVELS.slice(0, 3).map((lv) => {
    const pool = [];
    for (let n = lv.from; n <= lv.to; n++) pool.push(...unitItems(lang, n, variety).filter((it) => it.kind === 'w' || lv.id !== 'sprout'));
    return shuffle(pool).slice(0, 4).map((it) => ({ it, opts: shuffle([it, ...shuffle(pool.filter((x) => x.e !== it.e && x.en !== it.en)).slice(0, 3)]) }));
  }), []);
  const cur = bands[round] && bands[round][q];
  const mode = lang === 'fa' ? (round === 0 ? 'listen' : 'meaning') : round === 0 ? 'wordpic' : round === 1 ? 'listen' : 'meaning';
  useEffect(() => { if (phase === 'play' && cur && (mode === 'listen' || mode === 'meaning')) { const t = setTimeout(() => say(lang, cur.it.say), 350); return () => clearTimeout(t); } }, [phase, round, q]);
  const [knownEst, setKnownEst] = useState(0);
  const finish = (passed, sc) => {
    const lv = LEVELS[Math.min(3, passed)];
    // celebrate what he already knows: estimate from the share right in each band
    const scores = sc || score; let est = 0;
    bands.forEach((b, r) => { if (!b.length) return; const lvb = LEVELS[r]; let words = 0; for (let n = lvb.from; n <= lvb.to; n++) words += unitItems(lang, n, variety).filter((it) => it.kind === 'w').length; est += Math.round((scores[r] / b.length) * words); });
    setKnownEst(est);
    setResult(lv); setPhase('result'); sfx('chest');
  };
  const answer = (o) => {
    if (sel) return;
    setSel(o);
    const ok = o.id === cur.it.id;
    sfx(ok ? 'good' : 'try');
    const ns = score.slice(); if (ok) ns[round]++; setScore(ns);
    setTimeout(() => {
      setSel(null);
      if (q + 1 < bands[round].length) { setQ(q + 1); return; }
      const passed = ns[round] >= 3;
      if (passed && round + 1 < bands.length && bands[round + 1].length) { setRound(round + 1); setQ(0); }
      else finish(round + (passed ? 1 : 0), ns);
    }, ok ? 700 : 1100);
  };
  const accept = (lv) => {
    set((s) => { s[lang].level = lv.id; s[lang].placed = true; s[lang].diff = lv.diff; if (lang === 'fa' && reads != null) s.fa.script.step = Math.max(s.fa.script.step, reads); });
    onDone(lv);
  };
  if (phase === 'intro') {
    return (
      <div className="card pop center" data-testid="placement-intro">
        <Portrait who="kaepora" size="lg" className="pop" />
        <h2>Where should your quest start?</h2>
        <Navi>{lang === 'es' ? 'Have you learned Spanish before?' : 'Let’s see how much Farsi you understand. Just listen and tap!'}</Navi>
        <ActionBar>
          {lang === 'es' ? (<>
            <button className="btn wide" onClick={() => finish(0)} data-testid="pl-new">It’s new to me</button>
            <button className="btn primary wide" onClick={() => setPhase('play')} data-testid="pl-start">A little — test me!</button>
          </>) : <button className="btn primary wide" onClick={() => setPhase('play')} data-testid="pl-start">Let’s play!</button>}
        </ActionBar>
      </div>
    );
  }
  if (phase === 'play' && cur) {
    const total = bands.reduce((a, b) => a + b.length, 0); const at = bands.slice(0, round).reduce((a, b) => a + b.length, 0) + q;
    return (
      <div className="card pop" data-testid="placement-q">
        <div className="bar"><i style={{ width: `${(at / total) * 100}%` }} /></div>
        <div style={{ marginTop: 10 }}><Navi small>{mode === 'wordpic' ? 'Which picture matches the word?' : mode === 'listen' ? 'Listen. Which picture is it?' : 'Listen. What does it mean?'}</Navi></div>
        <div className="center" style={{ margin: '12px 0' }}>
          {mode === 'wordpic' ? <div className="row c"><TT lang={lang} x={cur.it} big showTr={false} /><PlayBtn lang={lang} text={cur.it.say} sm /></div> : <PlayBtn lang={lang} text={cur.it.say} />}
        </div>
        <div className={`choices ${mode !== 'meaning' ? 'pics' : ''}`}>
          {cur.opts.map((o) => <button key={o.id} className={`choice ${sel ? (o.id === cur.it.id ? 'right' : sel === o ? 'wrong' : '') : ''}`} onClick={() => answer(o)} data-ok={o.id === cur.it.id ? '1' : '0'}>{mode === 'meaning' ? o.en : <span className="pic emoji">{o.e}</span>}</button>)}
        </div>
        <ActionBar><button className="btn ghost wide" onClick={() => finish(round)}>I don’t know these yet — stop here</button></ActionBar>
      </div>
    );
  }
  if (phase === 'play' && !cur) { finish(0); return null; }
  if (phase === 'result' && lang === 'fa' && reads == null) {
    return (
      <div className="card pop center" data-testid="placement-read">
        <h2>One more question</h2>
        <Navi>Can you read Persian letters yet? Which word says <b>bâbâ</b> (dad)?</Navi>
        <div className="choices" style={{ marginTop: 12 }}>
          {shuffle(['بابا', 'نان', 'آب']).map((w) => <button key={w} className="choice fa" lang="fa" style={{ fontSize: '2rem' }} onClick={() => setReads(w === 'بابا' ? 3 : 0)}>{w}</button>)}
        </div>
        <ActionBar><button className="btn wide" onClick={() => setReads(0)} data-testid="pl-noread">I can’t read them yet</button></ActionBar>
      </div>
    );
  }
  return (
    <div className="card pop center" data-testid="placement-result">
      <div className="reward"><div className="item">🗺️</div></div>
      {knownEst >= 10 && <h2 data-testid="known-est">⭐ You already know about {knownEst} words!</h2>}
      <h2>Your quest starts at: {result.name}</h2>
      <Navi>{result.id === 'sprout' ? 'We start with the basics. You’ll grow fast!' : 'Great listening! We skip what you already know.'}</Navi>
      <ActionBar><button className="btn primary wide" onClick={() => accept(result)} data-testid="pl-accept">Start here</button></ActionBar>
    </div>
  );
}
