// Secret Treasures state helpers (pure; used inside set(...)): each secret unlocks once, tokens turn into tickets
// within the weekly cap (shared by all apps), extra tokens wait.
import { SECRETS } from './secrets.js';
import { readConfig, ticketsAvailable } from './rewards.js';
// ---- state helpers (inside set(...)) ----
export function treasureOf(s) { if (!s.treasure) s.treasure = { found: {}, tokens: 0, toChoose: 0, flags: {}, capped: false }; const t = s.treasure; t.found = t.found || {}; t.flags = t.flags || {}; t.tokens = t.tokens || 0; t.toChoose = t.toChoose || 0; return t; }
export function convertTokens(s) {
  const t = treasureOf(s); const c = readConfig();
  const n = ticketsAvailable(t.tokens, t.toChoose);
  if (n > 0) { t.tokens -= n * c.tokensPerTicket; t.toChoose += n; }
  t.capped = c.enabled && t.tokens >= c.tokensPerTicket;
  return n;
}
export function foundSecret(s, id) {
  const t = treasureOf(s);
  if (t.found[id] || !SECRETS.some((x) => x.id === id)) return false; // each secret unlocks once
  t.found[id] = Date.now(); // +1 Courage shard via the Family Wallet (hooks.js 'secret' → FW.secret)
  return true;
}
