// "Secret Treasures": real-world reward tickets shared by Math Arena, Language Quest and Code Quest on this browser.
// Shared keys (same origin): familyApps.rewards.v1 (the parent's list + rules) and familyApps.tickets.v1 (all apps' tickets).
// Always re-read before use; read-modify-write; never drop other apps' entries.
export const REWARDS_KEY = 'familyApps.rewards.v1';
export const TICKETS_KEY = 'familyApps.tickets.v1';
export const APP_ID = 'language';
export const APP_NAME = 'Language Quest';
export const APP_NAMES = { language: 'Language Quest', math: 'Math Arena', code: 'Code Quest' };
export const DEFAULT_REWARDS = [
  { id: 'youtube', emoji: '📺', text: '15 minutes of YouTube' },
  { id: 'switch', emoji: '🎮', text: '20 minutes of Nintendo Switch' },
  { id: 'pet', emoji: '🐾', text: 'Play time with our pet' },
  { id: 'treat', emoji: '🍦', text: 'Pick a special treat' },
  { id: 'game', emoji: '🎲', text: 'Family game pick' },
];
const mem = {}; // used only where storage is unavailable (sandboxed preview)
const store = () => { try { const s = globalThis.localStorage; s.getItem('x'); return s; } catch (e) { return null; } };
const getRaw = (k) => { const s = store(); if (s) { try { return s.getItem(k); } catch (e) {} } return k in mem ? mem[k] : null; };
const setRaw = (k, v) => { const s = store(); if (s) { try { s.setItem(k, v); return true; } catch (e) {} } mem[k] = v; return false; };
const int = (v, d) => (Number.isFinite(+v) ? Math.round(+v) : d);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export function defaultConfig() { return { version: 1, enabled: true, tokensPerTicket: 3, weeklyCap: 5, rewards: DEFAULT_REWARDS.map((r) => ({ ...r })), updatedAt: Date.now() }; }
export function sanitizeConfig(c) {
  const d = defaultConfig();
  if (!c || typeof c !== 'object') return d;
  const rewards = Array.isArray(c.rewards) ? c.rewards.filter((r) => r && String(r.text || '').trim()).slice(0, 8).map((r, i) => ({ id: String(r.id || 'r' + i), emoji: String(r.emoji || '🎁').slice(0, 8), text: String(r.text).trim().slice(0, 80) })) : d.rewards;
  return { version: 1, enabled: c.enabled !== false, tokensPerTicket: clamp(int(c.tokensPerTicket, 3), 1, 10), weeklyCap: clamp(int(c.weeklyCap, 5), 0, 14), rewards, updatedAt: int(c.updatedAt, 0) };
}
// Reading never writes (nothing is written at load). The defaults are written by the first action that needs them
// (a parent edit or a new ticket), and only if the key is still missing; the default ids match the other apps.
export function readConfig() {
  const raw = getRaw(REWARDS_KEY);
  if (raw == null) return defaultConfig();
  try { return sanitizeConfig(JSON.parse(raw)); } catch (e) { return defaultConfig(); }
}
export function ensureConfig() { if (getRaw(REWARDS_KEY) == null) setRaw(REWARDS_KEY, JSON.stringify(defaultConfig())); }
// ticket dates: written as ISO strings; read as ISO strings or epoch ms (other apps may use either)
export const ts = (v) => (typeof v === 'number' ? v : typeof v === 'string' ? (/^\d+$/.test(v) ? +v : Date.parse(v) || 0) : 0);
export function writeConfig(patch) {
  const next = sanitizeConfig({ ...readConfig(), ...patch });
  next.updatedAt = Date.now();
  setRaw(REWARDS_KEY, JSON.stringify(next));
  return next;
}
export function readTickets() {
  try { const a = JSON.parse(getRaw(TICKETS_KEY) || '[]'); return Array.isArray(a) ? a.filter((t) => t && t.id) : []; } catch (e) { return []; }
}
function writeTickets(list) {
  const keep = list.slice().sort((a, b) => ts(b.earnedAt) - ts(a.earnedAt)).slice(0, 200); // newest 200
  setRaw(TICKETS_KEY, JSON.stringify(keep));
  return keep;
}
export function addTicket(reward, now = Date.now()) {
  ensureConfig();
  const list = readTickets(); // re-read: another app may have written since
  const t = { id: `${APP_ID}-${now}-${Math.random().toString(36).slice(2, 8)}`, app: APP_ID, rewardId: reward.id, rewardText: reward.text, emoji: reward.emoji, earnedAt: new Date(now).toISOString(), status: 'earned' };
  list.push(t); writeTickets(list);
  return t;
}
export function markUsed(id, now = Date.now()) {
  const list = readTickets(); const t = list.find((x) => x.id === id);
  if (t && t.status !== 'used') { t.status = 'used'; t.usedAt = new Date(now).toISOString(); }
  writeTickets(list);
  return t || null;
}
// local Sunday 00:00 to Saturday 23:59
export function weekStart(ts = Date.now()) { const d = new Date(ts); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - d.getDay()); return d.getTime(); }
export function ticketsThisWeek(now = Date.now()) { const s = weekStart(now); return readTickets().filter((t) => { const e = ts(t.earnedAt); return e > 0 && weekStart(e) === s; }).length; } // every app's tickets
// Tickets that can be earned now: limited by tokens AND by the weekly cap across all apps (tickets this app has earned but
// not chosen yet count too). Over the cap, tokens wait for next week.
export function ticketsAvailable(tokens, pending = 0, now = Date.now()) {
  const c = readConfig(); if (!c.enabled) return 0;
  const byTokens = Math.floor((tokens || 0) / c.tokensPerTicket);
  const room = Math.max(0, c.weeklyCap - ticketsThisWeek(now) - (pending || 0));
  return Math.max(0, Math.min(byTokens, room));
}
