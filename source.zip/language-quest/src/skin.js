// Skin contract: names, portraits, scene art, map art. Two skins: 'hyrule' (OoT remake fan theme) and
// 'fallback' (original names). A team "Hyrule kit" can override portraits/scenes/music via applyKit().
export const PLACES = [
  null,
  { key: 'kokiri', name: 'Kokiri Forest', alt: 'Sprout Woods', teacher: 'saria', boss: 'madscrub', bg: 'forest', x: 84, y: 74 },
  { key: 'deku', name: 'Inside the Deku Tree', alt: 'The Great Oak', teacher: 'deku', boss: 'gohma', bg: 'deku', x: 91, y: 84, reward: 'emerald' },
  { key: 'field', name: 'Hyrule Field', alt: 'Wide Meadow', teacher: 'kaepora', boss: 'bigpoe', bg: 'field', x: 52, y: 56 },
  { key: 'goron', name: 'Goron City', alt: 'Rock Town', teacher: 'darunia', boss: 'dodongo', bg: 'mountain', x: 78, y: 12, reward: 'ruby' },
  { key: 'zora', name: "Zora's Domain", alt: 'River Palace', teacher: 'ruto', boss: 'bigocto', bg: 'zora', x: 93, y: 36 },
  { key: 'jabu', name: "Jabu-Jabu's Belly", alt: 'The Whale Fish', teacher: 'ruto', boss: 'barinade', bg: 'zora', bossBg: 'jabu', x: 95, y: 22, reward: 'sapphire' },
  { key: 'castle', name: 'Hyrule Castle', alt: 'The Castle', teacher: 'zelda', boss: 'stalfos', bg: 'castle', x: 50, y: 22 },
  { key: 'forest', name: 'Forest Temple', alt: 'Green Temple', teacher: 'saria', boss: 'phantom', bg: 'ftemple', x: 74, y: 88, reward: 'forest' },
  { key: 'kakariko', name: 'Kakariko Village', alt: 'Hill Village', teacher: 'villagers', boss: 'lizalfos', bg: 'kakariko', x: 70, y: 30 },
  { key: 'fire', name: 'Fire Temple', alt: 'Flame Temple', teacher: 'darunia', boss: 'volvagia', bg: 'firetemple', x: 84, y: 5, reward: 'fire' },
  { key: 'ranch', name: 'Lon Lon Ranch', alt: 'Sunny Ranch', teacher: 'malon', boss: 'dekubaba', bg: 'ranch', x: 46, y: 64 },
  { key: 'water', name: 'Water Temple', alt: 'Deep Temple', teacher: 'ruto', boss: 'morpha', bg: 'watertemple', x: 40, y: 93, reward: 'water' },
  { key: 'lake', name: 'Lake Hylia', alt: 'Moon Lake', teacher: 'kaepora', boss: 'flaredancer', bg: 'lake', x: 50, y: 85 },
  { key: 'shadow', name: 'Shadow Temple', alt: 'Night Temple', teacher: 'impa', boss: 'bongo', bg: 'shadow', x: 64, y: 22, reward: 'shadow' },
  { key: 'barn', name: 'Lon Lon Ranch barn', alt: 'The Barn', teacher: 'talon', boss: 'skullkid', bg: 'ranch', x: 40, y: 60 },
  { key: 'spirit', name: 'Spirit Temple', alt: 'Sand Temple', teacher: 'impa', boss: 'twinrova', bg: 'spirit', x: 8, y: 42, reward: 'spirit' },
  { key: 'kaknight', name: 'Kakariko at night', alt: 'Village by Night', teacher: 'villagers', boss: 'poesisters', bg: 'kakariko', x: 74, y: 36 },
  { key: 'time', name: 'Temple of Time', alt: 'Clock Temple', teacher: 'zelda', boss: 'darklink', bg: 'timetemple', x: 56, y: 28, reward: 'light' },
  { key: 'market', name: 'Castle Town market', alt: 'Market Square', teacher: 'talon', boss: 'ironknuckle', bg: 'castle', x: 44, y: 30 },
  { key: 'ganon', name: "Ganon's Castle", alt: 'Dark Tower', teacher: 'zelda', boss: 'ganondorf', bg: 'ganon', x: 50, y: 8, reward: 'triforce' },
];

const C = {
  // key: [hyrule name, fallback name, emoji, color]
  link: ['Link', 'the Hero', '🧝', '#3a8a3a'], navi: ['Navi', 'Lumi', '🧚', '#6ec8ff'],
  deku: ['the Great Deku Tree', 'the Great Oak', '🌳', '#3d6b2a'], saria: ['Saria', 'Sela', '🧝‍♀️', '#2f9e5a'],
  zelda: ['Princess Zelda', 'the Princess', '👸', '#c79ad8'], impa: ['Impa', 'the Guardian', '🥷', '#5b5b8a'],
  darunia: ['Darunia', 'the Rock Chief', '🪨', '#a0642c'], ruto: ['Princess Ruto', 'the River Princess', '🧜‍♀️', '#3d8fd0'],
  malon: ['Malon', 'Mila', '👩‍🌾', '#d0603d'], talon: ['Talon', 'Tal', '👨‍🌾', '#b07b3a'],
  kaepora: ['Kaepora Gaebora', 'the Wise Owl', '🦉', '#8a7350'], villagers: ['the Kakariko villagers', 'the villagers', '🏘️', '#9a6a4a'],
  madscrub: ['a Mad Scrub', 'a Grumpy Sprout', '🌰', '#7a5a2a'], gohma: ['Queen Gohma', 'the Giant Eye Spider', '🕷️', '#8a2a2a'],
  bigpoe: ['a Big Poe', 'a Lantern Ghost', '🏮', '#6a5acd'], dodongo: ['King Dodongo', 'the Lava Lizard', '🦖', '#a04a1a'],
  bigocto: ['Big Octo', 'the Big Squid', '🐙', '#c04a8a'], barinade: ['Barinade', 'the Jelly Lord', '🪼', '#4ab0c0'],
  stalfos: ['a Stalfos', 'a Bone Knight', '💀', '#909090'], phantom: ['Phantom Ganon', 'the Phantom Rider', '👻', '#5a3a8a'],
  lizalfos: ['a Lizalfos', 'a Lizard Knight', '🦎', '#4a8a3a'], volvagia: ['Volvagia', 'the Fire Dragon', '🐉', '#d04a1a'],
  dekubaba: ['a Big Deku Baba', 'a Snappy Plant', '🌿', '#3a7a2a'], morpha: ['Morpha', 'the Water Blob', '💧', '#2a7ad0'],
  flaredancer: ['a Flare Dancer', 'a Fire Dancer', '🔥', '#e06a1a'], bongo: ['Bongo Bongo', 'the Drum Shadow', '🥁', '#4a3a5a'],
  skullkid: ['Skull Kid', 'the Forest Imp', '🎭', '#8a6a3a'], twinrova: ['Twinrova', 'the Twin Witches', '🧙‍♀️', '#b03a6a'],
  poesisters: ['the Poe Sisters', 'the Lantern Sisters', '🕯️', '#7a5ad0'], darklink: ['Dark Link', 'the Shadow Hero', '🌑', '#2a2a3a'],
  ironknuckle: ['an Iron Knuckle', 'an Iron Guard', '🛡️', '#707a8a'], ganondorf: ['Ganondorf', 'the Dark King', '👑', '#3a1a2a'],
};
export const REWARDS = {
  emerald: ["Kokiri's Emerald", 'the Forest Stone', '💚'], ruby: ["Goron's Ruby", 'the Fire Stone', '❤️‍🔥'],
  sapphire: ["Zora's Sapphire", 'the Water Stone', '💎'], forest: ['the Forest Medallion', 'the Leaf Medal', '🟢'],
  fire: ['the Fire Medallion', 'the Flame Medal', '🔴'], water: ['the Water Medallion', 'the Wave Medal', '🔵'],
  shadow: ['the Shadow Medallion', 'the Night Medal', '🟣'], spirit: ['the Spirit Medallion', 'the Sun Medal', '🟠'],
  light: ['the Light Medallion', 'the Light Medal', '🟡'], triforce: ['the Triforce', 'the Golden Crown', '🔺'],
};

let skinId = 'hyrule';
let kit = null; // { portraits: {key: url}, scenes: {bgKey: url}, map: url, music: {...}, names: {...} }
export const setSkin = (id) => { skinId = id === 'fallback' ? 'fallback' : 'hyrule'; };
export const getSkin = () => skinId;
export const applyKit = (k) => { kit = k; };
export const kitLoaded = () => !!kit;
const fb = () => skinId === 'fallback';
export const _name0 = (k) => (kit && kit.names && kit.names[skinId] && kit.names[skinId][k]) || (C[k] ? C[k][fb() ? 1 : 0] : k);
export const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
export const _placeName0 = (n) => (PLACES[n] ? (fb() ? PLACES[n].alt : PLACES[n].name) : '');
export const rewardName = (r) => (REWARDS[r] ? REWARDS[r][fb() ? 1 : 0] : r);
export const rewardIcon = (r) => (kit && kit.icons && kit.icons[r]) || (REWARDS[r] ? REWARDS[r][2] : '⭐');
export function _portrait0(k) {
  const url = kit && kit.portraits && kit.portraits[skinId === 'fallback' && kit.portraitsFallback ? 'x' : 'y'] ? null : (kit && kit.portraits && kit.portraits[k]);
  return { url: url || null, emoji: C[k] ? C[k][2] : '✨', color: C[k] ? C[k][3] : '#2a5a4a' };
}

// ---------- placeholder painted scenes (SVG, layered, soft light) ----------
const PAL = {
  forest: ['#0f3b2c', '#3f8f5a', '#1d5a3a', '#0c2a1c', '#ffe9a8'], deku: ['#1a2f1a', '#5a8a3a', '#2f4f22', '#162414', '#d8f0a0'],
  field: ['#5fa8d8', '#bfe6ff', '#6fae4a', '#3f7a32', '#fff4c0'], mountain: ['#4a1f1a', '#e07a4a', '#7a3a24', '#3a1a12', '#ffd090'],
  zora: ['#0f3a5a', '#5ac0e8', '#1f6a8a', '#0a2a40', '#d0f4ff'], jabu: ['#3a1a3a', '#e08ab0', '#6a2a5a', '#2a0f2a', '#ffd0e8'],
  castle: ['#2a2a5a', '#c0a0e0', '#5a6a9a', '#1f2440', '#ffe8c0'], ftemple: ['#10301f', '#4a9a6a', '#1f4a30', '#0a1f14', '#c8ffd8'],
  kakariko: ['#3a2a3a', '#f0a070', '#6a4a4a', '#2a1a20', '#ffd8a8'], firetemple: ['#3a0f0a', '#ff7a2a', '#7a1f0f', '#2a0a06', '#ffcf7a'],
  ranch: ['#6a3a2a', '#ffc070', '#8aa04a', '#4a6a2a', '#fff0b0'], watertemple: ['#0a2040', '#3a8ad0', '#164a7a', '#081830', '#c0e8ff'],
  lake: ['#1a4a7a', '#9ad8f8', '#2f7aa8', '#14405a', '#fff8d8'], shadow: ['#14101f', '#5a4a7a', '#241a35', '#0a0812', '#c0b0ff'],
  spirit: ['#5a3a1a', '#ffc87a', '#b07a3a', '#5a3a1f', '#fff0c0'], timetemple: ['#1f2a3a', '#d8d0b0', '#4a5a6a', '#141a24', '#fff8e0'],
  ganon: ['#1a0a14', '#7a2a4a', '#3a1424', '#0f050a', '#ffb0c0'], home: ['#0f3b2c', '#3f8f5a', '#1d5a3a', '#0c2a1c', '#ffe9a8'],
};
function hills(seed, h, color, amp) {
  let d = `M0 ${h}`; let s = seed;
  for (let x = 0; x <= 1600; x += 80) { s = (s * 9301 + 49297) % 233280; const y = h - (s / 233280) * amp; d += ` Q${x + 40} ${y - 20} ${x + 80} ${y}`; }
  return `<path d="${d} L1600 1000 L0 1000Z" fill="${color}"/>`;
}
function trees(seed, base, color, n) {
  let out = ''; let s = seed;
  for (let i = 0; i < n; i++) { s = (s * 9301 + 49297) % 233280; const x = (s / 233280) * 1600; const hgt = 120 + (i % 5) * 30; out += `<path d="M${x} ${base} l${-hgt * 0.28} 0 l${hgt * 0.28} ${-hgt} l${hgt * 0.28} ${hgt}Z" fill="${color}" opacity=".9"/>`; }
  return out;
}
const cache = {};
export function _sceneArt0(key) {
  if (kit && kit.scenes && kit.scenes[key]) return `url(${kit.scenes[key]})`;
  if (cache[key]) return cache[key];
  const [sky1, sky2, mid, near, light] = PAL[key] || PAL.forest;
  const tr = ['forest', 'deku', 'ftemple', 'home', 'field', 'ranch'].includes(key);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 1000" preserveAspectRatio="xMidYMid slice">
<defs><linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${sky1}"/><stop offset=".65" stop-color="${sky2}"/></linearGradient>
<radialGradient id="l" cx=".72" cy=".18" r=".6"><stop offset="0" stop-color="${light}" stop-opacity=".85"/><stop offset="1" stop-color="${light}" stop-opacity="0"/></radialGradient>
<filter id="b"><feGaussianBlur stdDeviation="6"/></filter></defs>
<rect width="1600" height="1000" fill="url(#s)"/><rect width="1600" height="1000" fill="url(#l)"/>
<g filter="url(#b)" opacity=".75">${hills(3, 560, mid, 160)}</g>
${tr ? `<g filter="url(#b)" opacity=".55">${trees(7, 640, near, 18)}</g>` : ''}
<g opacity=".95">${hills(11, 720, near, 120)}</g>
${tr ? trees(19, 800, '#06140e', 10) : ''}
${hills(23, 880, '#050a08', 60)}</svg>`;
  cache[key] = `url("data:image/svg+xml;utf8,${encodeURIComponent(svg)}")`;
  return cache[key];
}
export function _mapArt0() {
  if (kit && kit.map) return `url(${kit.map})`;
  if (cache.map) return cache.map;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 1000" preserveAspectRatio="none">
<defs><radialGradient id="g" cx=".5" cy=".55" r=".7"><stop offset="0" stop-color="#7fbf5a"/><stop offset="1" stop-color="#2f5a2a"/></radialGradient>
<filter id="b"><feGaussianBlur stdDeviation="14"/></filter></defs>
<rect width="1600" height="1000" fill="url(#g)"/>
<g filter="url(#b)">
<ellipse cx="1380" cy="800" rx="260" ry="200" fill="#1f5a2a"/><ellipse cx="1300" cy="90" rx="320" ry="140" fill="#8a4a2a"/>
<ellipse cx="1500" cy="330" rx="140" ry="220" fill="#3a8ac0"/><ellipse cx="760" cy="880" rx="300" ry="110" fill="#4aa0d8"/>
<ellipse cx="140" cy="420" rx="200" ry="300" fill="#d8b070"/><ellipse cx="800" cy="200" rx="220" ry="120" fill="#8a8ab0"/>
<ellipse cx="1110" cy="300" rx="140" ry="90" fill="#a07a5a"/><ellipse cx="740" cy="610" rx="120" ry="80" fill="#c8a060"/></g>
<path d="M800 260 C 820 450, 700 520, 760 640 S 1100 700 1340 760" stroke="#e8d8a0" stroke-width="10" fill="none" opacity=".5" stroke-dasharray="4 18" stroke-linecap="round"/>
</svg>`;
  cache.map = `url("data:image/svg+xml;utf8,${encodeURIComponent(svg)}")`;
  return cache.map;
}

// ---------- Hyrule kit adapter (team kit: HyruleKit / HyruleMusic / HyruleOcarina) ----------
let kitOn = false;
export const setKitOn = (v) => { kitOn = v !== false; };
// The kit is used only after its image pack is installed (no requests for files that are not shipped).
export const KIT = () => { if (!kitOn) return null; const H = typeof globalThis !== 'undefined' ? globalThis.HyruleKit : null; return H && H.skin ? H : null; };
const IDS = { link: ['link'], navi: ['navi'], deku: ['deku_tree', 'deku'], saria: ['saria'], zelda: ['zelda'], impa: ['impa'], darunia: ['darunia'], ruto: ['ruto'],
  malon: ['malon'], talon: ['talon'], kaepora: ['kaepora', 'kaepora_gaebora', 'owl'], villagers: ['villagers', 'kakariko_villagers', 'villager', 'kakariko'],
  gohma: ['gohma', 'queen_gohma'], dodongo: ['king_dodongo', 'dodongo'], barinade: ['barinade'], phantom: ['phantom_ganon'], volvagia: ['volvagia'], morpha: ['morpha'],
  bongo: ['bongo_bongo', 'bongo'], twinrova: ['twinrova'], darklink: ['dark_link'], ganondorf: ['ganondorf'], madscrub: ['mad_scrub', 'deku_scrub', 'business_scrub'],
  bigpoe: ['big_poe', 'poe'], bigocto: ['big_octo'], stalfos: ['stalfos'], lizalfos: ['lizalfos'], dekubaba: ['big_deku_baba', 'deku_baba'], flaredancer: ['flare_dancer'],
  skullkid: ['skull_kid'], poesisters: ['poe_sisters'], ironknuckle: ['iron_knuckle'] };
const firstRef = (o) => (o && typeof o === 'object' ? (o['512'] || o['256'] ? o : Object.values(o).find((v) => v && typeof v === 'object')) : o);
function kitChar(k, pose) {
  const H = KIT(); if (!H) return null; const s = H.skin;
  if (k === 'link' && s.hero) return { name: s.hero.name, ref: s.hero.bust && (s.hero.bust.happy || firstRef(s.hero.bust)) };
  if (k === 'navi' && s.guide) return { name: s.guide.name, ref: s.guide.poses && (s.guide.poses.idle || firstRef(s.guide.poses)) };
  if (H.skins && H.skins.hyrule && s !== H.skins.hyrule) {
    const hb = H.skins.hyrule.bosses || [], hm = H.skins.hyrule.mentors || [];
    for (const id of IDS[k] || [k]) {
      const bi = hb.findIndex((x) => x.id === id);
      if (bi >= 0 && (s.bosses || [])[bi]) { const b = s.bosses[bi]; return { name: b.name, ref: firstRef((pose === 'defeated' && b.defeated) || b.battle || b.bust || b.img), boss: b }; }
      if (id === 'deku_tree' && (s.mentors || [])[0]) { const m = s.mentors[0]; return { name: m.name, ref: m.bust && (m.bust.happy || m.bust.default || firstRef(m.bust)) }; }
      if (hm.find((x) => x.id === id)) return null;
    }
  }
  for (const id of IDS[k] || [k]) {
    const m = (s.mentors || []).find((x) => x.id === id);
    if (m) return { name: m.name, ref: m.bust && (m.bust.happy || m.bust.default || firstRef(m.bust)) };
    const b = (s.bosses || []).find((x) => x.id === id);
    if (b) return { name: b.name, ref: firstRef((pose === 'defeated' && b.defeated) || b.battle || b.bust || b.img || b.portrait), boss: b };
  }
  return null;
}
const PLACE_IDS = { forest: ['kokiri', 'hub'], home: ['kokiri', 'hub'], deku: ['deku_tree_inside', 'deku_tree', 'inside_deku_tree', 'hub'], field: ['hyrule_field', 'lon_lon_ranch', 'meadow'],
  mountain: ['goron_city', 'death_mountain', 'deathmountain', 'caves'], zora: ['zoras_domain', 'zora_domain', 'zora', 'meadow'], jabu: ['jabu_jabu', 'jabu_jabus_belly', 'jabu', 'caves'],
  castle: ['hyrule_castle', 'castle', 'castle_town', 'market', 'temple_of_time', 'meadow'], ftemple: ['forest_temple', 'caves'], kakariko: ['kakariko', 'kakariko_village', 'meadow'], firetemple: ['fire_temple', 'caves'],
  ranch: ['lon_lon_ranch', 'ranch', 'meadow'], watertemple: ['water_temple', 'caves'], lake: ['lake_hylia', 'lake', 'meadow'], shadow: ['shadow_temple', 'caves'], spirit: ['spirit_temple', 'desert_colossus', 'desert', 'caves'],
  timetemple: ['temple_of_time', 'caves'], ganon: ['ganon_castle', 'ganons_castle', 'ganons_tower', 'caves'], dodongo: ['dodongo_cavern', 'caves'] };
function kitPlace(bgKey) {
  const H = KIT(); if (!H) return null;
  for (const id of PLACE_IDS[bgKey] || [bgKey]) { const p = (H.skin.places || []).find((x) => x.id === id); if (p) return p; }
  return null;
}
export const name = (k) => { const c = kitChar(k); return c && c.name ? c.name : _name0(k); };
export const placeName = (n) => { const P = PLACES[n]; if (!P) return ''; const kp = kitPlace(P.bg); return kp && kp.name && P.key === kp.id ? kp.name : _placeName0(n); };
export function portrait(k, pose) {
  const c = kitChar(k, pose); const H = KIT();
  const base = _portrait0(k);
  return c && c.ref && H ? { ...base, url: H.src(c.ref, 150) } : base;
}
export function sceneArt(key) { const p = kitPlace(key); const H = KIT(); let u = ''; try { u = p && H ? H.bg(p) : ''; } catch (e) {} return u ? `url("${u}")` : _sceneArt0(key); }
export function mapArt() { const H = KIT(); let u = ''; try { u = H && H.skin.map ? H.bg(H.skin.map) : ''; } catch (e) {} return u ? `url("${u}")` : _mapArt0(); }
export const mapTall = () => { const H = KIT(); return !!(H && H.skin.map && H.isTall()); };
const SPOT = [null, ['kokiri', 0, 0], ['kokiri', 0.05, 0.07], ['ranch', -0.1, -0.06], ['deathmountain', 0, 0], ['zora', 0, 0], ['zora', -0.02, -0.09], ['castle', 0, 0],
  ['kokiri', -0.07, 0.05], ['kakariko', 0, 0], ['deathmountain', 0.06, -0.07], ['ranch', 0, 0], ['lake', 0.02, 0.08], ['lake', 0, 0], ['kakariko', 0.05, 0.08],
  ['ranch', 0.06, 0.06], ['desert', 0, 0], ['kakariko', -0.06, 0.06], ['castle', 0.06, 0.05], ['castle', -0.07, 0.06], ['castle', 0, -0.12]];
export function pinPos(n) {
  const H = KIT(); const P = PLACES[n];
  if (!H || !H.skin.map || !H.skin.map.spots) return { x: P.x, y: P.y };
  const tall = H.isTall(); const sp = H.skin.map.spots[tall ? 'tall' : 'wide'] || {}; const [key, dx, dy] = SPOT[n]; const s = sp[key];
  if (!s) return { x: P.x, y: P.y };
  return { x: Math.max(3, Math.min(97, (s.x + dx * (tall ? 1.6 : 1)) * 100)), y: Math.max(3, Math.min(97, (s.y + dy * (tall ? 0.55 : 1)) * 100)) };
}
const MUSIC_OF = { forest: 'forest', home: 'forest', deku: 'forest', ftemple: 'forest', field: 'field', ranch: 'ranch', kakariko: 'village', castle: 'village', mountain: 'fire',
  firetemple: 'fire', zora: 'water', jabu: 'water', watertemple: 'water', lake: 'water', shadow: 'shadow', spirit: 'spirit', timetemple: 'spirit', ganon: 'boss' };
export const musicFor = (bgKey) => { const p = kitPlace(bgKey); return (p && p.music) || MUSIC_OF[bgKey] || 'field'; };
export const credit = () => { const H = KIT(); return (H && H.credit) || 'Fan art inspired by The Legend of Zelda: Ocarina of Time. Not affiliated with or endorsed by Nintendo.'; };
export function kitSkin(id) { const H = KIT(); if (H && H.use) { try { H.use(id === 'fallback' ? 'grove' : 'hyrule'); } catch (e) {} } }

export function kitIcon(kind) {
  const H = KIT(); if (!H) return null; const s = H.skin;
  try {
    if (kind === 'rupee') { const d = (s.currency && s.currency.denominations) || []; const g = d.find((x) => /green/.test(x.id)) || d[0]; return g && g.icon ? H.src(g.icon, 28) : null; }
    if (kind === 'heart') return s.heart && s.heart.container ? H.src(s.heart.container, 28) : null;
    if (kind === 'chest') return s.chest && s.chest.closed ? H.src(s.chest.closed, 160) : null;
    if (kind === 'chestOpen') return s.chest && s.chest.open ? H.src(s.chest.open, 160) : null;
    if (kind === 'ocarina') return s.items && s.items.ocarina ? H.src(s.items.ocarina.img || s.items.ocarina, 64) : null;
    if (kind === 'heroCheer') return s.hero && s.hero.bust ? H.src(s.hero.bust.cheering, 160) : null;
    if (kind === 'heroHappy') return s.hero && s.hero.full ? H.src(s.hero.full.happy, 200) : null;
  } catch (e) {}
  return null;
}

const REWARD_IDS = { emerald: ['kokiri_emerald', 'emerald'], ruby: ['gorons_ruby', 'goron_ruby', 'ruby'], sapphire: ['zoras_sapphire', 'zora_sapphire', 'sapphire'],
  forest: ['forest_medallion', 'forest'], fire: ['fire_medallion', 'fire'], water: ['water_medallion', 'water'], shadow: ['shadow_medallion', 'shadow'],
  spirit: ['spirit_medallion', 'spirit'], light: ['light_medallion', 'light'], triforce: ['triforce'] };
export function rewardImg(r) {
  const H = KIT(); if (!H) return null; const it = H.skin.items || {};
  const list = [...(it.stones || []), ...(it.medallions || [])];
  for (const id of REWARD_IDS[r] || [r]) {
    const x = list.find((o) => o && (o.id === id || (o.id || '').includes(id)));
    if (x) { const ref = firstRef(x.img || x.icon || x.ref || x); try { return { url: H.src(ref, 120), name: x.name }; } catch (e) { return null; } }
  }
  return null;
}
export const rewardNameK = (r) => { const x = rewardImg(r); return (x && x.name) || rewardName(r); };
export function guideImg() { const H = KIT(); if (!H || !H.skin.guide || !H.skin.guide.poses) return null; try { return H.src(H.skin.guide.poses.idle || firstRef(H.skin.guide.poses), 64); } catch (e) { return null; } }
