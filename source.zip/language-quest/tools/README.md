# Farsi audio for Language Quest — what worked

Goal: natural Iranian Persian (everyday Tehrani) audio for every Farsi string in the app, because Macs and iPhones have no
Farsi voice.

## Tried
| Candidate | How | Result |
|---|---|---|
| Internal Meta TTS | searched internal knowledge and the Meta CLI (speech.recording, etc.deck narrate) | no callable Persian voice for this use (the fa_IR Gemini TTS work in D130229530 is an internal pipeline, not a CLI) |
| **MMS-TTS Persian** (`facebook/mms-tts-fas`, VITS) | transformers 5.24 + torch 2.15 (CPU) from PyPI; model files from Hugging Face; tokenizer is Persian script (no uroman) | works; Whisper CER **0.52** (1.15x slower speech: 0.65); Bible-reading style |
| **Piper fa_IR-ganji-medium** | `piper-tts` from PyPI; voice from `rhasspy/piper-voices` on HF | **chosen**: Whisper CER **0.30**, natural, fast (≈40 clips/s on this node) |
| Piper fa_IR-gyro-medium | same | CER 0.41 |
| Piper fa_IR-reza_ibrahim-medium | same | CER 0.54 |
| Piper fa_IR-amir-medium | same | CER 0.56 |

Intelligibility test (`eval_voices.py`, `eval_mms.py`): 40 items (single words, family words, numbers, short colloquial
sentences such as «خونه‌ی ما بزرگه»، «فردا مدرسه نمی‌رم»), synthesized at length_scale 1.1, transcribed with
faster-whisper `small` (int8, language=fa), character error rate after normalizing ی/ک, diacritics, ZWNJ and punctuation.
Whisper-small itself is weak on isolated Persian words, so the absolute numbers are pessimistic; the ranking is what matters.

## Pipeline (`build_audio.py`)
items JSON `[{id, text}]` (id = FNV-1a hash of the spoken text, identical in the app) → Piper ganji (length_scale 1.1,
noise 0.6/0.7) → trim silence → loudness-normalize (no clipping) → 60 ms padding → MP3 mono 22.05 kHz 32 kbps (lameenc) →
concatenated into ≤4 MB packs `fa-N.mp3pack` + `fa-index.json` {packs, clips: id → [pack, offset, length, ms]}.
Incremental: clips are cached by id, so a content edit only re-synthesizes changed lines.

## Coverage
2,458 clips, 0 failures, 12.9 MB in 4 packs: every Farsi word (spoken form), phrase, example sentence, grammar example and
filled-in practice sentence, speaking model, writing model, role-play and boss line (questions and answers), song line,
unit title, script-track word and letter name. The app plays family recordings first, then these clips, then a browser
fa voice if one exists; otherwise the play button dims and points the parent to Family voices.


Note: the AI content-drafting scripts used to write the first drafts are not included; all content was reviewed and is in `content/`.
