// Headless Chromium walkthrough "like a 9-year-old": placement, full quests (Spanish + Farsi), a boss win, speaking with and
// without recognition (mocked), the script track, parent corner (PIN, reports, settings, backup + restore), offline.
// Usage: node tests/e2e.mjs [distDir] [shotsDir]
import { chromium } from 'playwright-core';
import chromiumPkg from '@sparticuz/chromium';
import http from 'http';
import fs from 'fs';
import { WHITELIST } from '../src/nouns.js';
const chunkSeen = [];
import path from 'path';

const SPARTI = chromiumPkg.default || chromiumPkg;
const DIST = path.resolve(process.argv[2] || 'dist');
const PREVIEW = path.resolve(process.env.LQ_PREVIEW || '/tmp/lq/preview');
const PORT = +process.env.PORT || 8123;
const OUT = path.resolve(process.argv[3] || '/tmp/lq/shots');
fs.mkdirSync(OUT, { recursive: true });
const TYPES = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.woff2': 'font/woff2', '.webp': 'image/webp', '.md': 'text/plain' };
const srv = http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname); if (p.endsWith('/')) p += 'index.html';
  if (p.startsWith('/language-quest/')) p = p.slice('/language-quest'.length); // GitHub Pages project subpath
  if (p === '/family/endpoint.json') { if (globalThis.__SYNC_ENDPOINT) { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ endpoint: globalThis.__SYNC_ENDPOINT })); } else { res.writeHead(404); res.end('not found'); } return; }
  // headless Chromium can't paint color (COLRv1) emoji, so screenshots use the monochrome Noto Emoji under the color font's name
  const EMO = path.join(path.dirname(new URL(import.meta.url).pathname), '../node_modules/@fontsource/noto-emoji');
  if (p.startsWith('/preview/')) { const pf = path.join(PREVIEW, p.slice(9)); if (fs.existsSync(pf) && fs.statSync(pf).isFile()) { res.writeHead(200, { 'content-type': TYPES[path.extname(pf)] || 'application/octet-stream', 'access-control-allow-origin': '*' }); fs.createReadStream(pf).pipe(res); return; } res.writeHead(404); res.end(); return; }
  if (p === '/viewer/x/__viewer.html') {
    // Emulates the Meta artifact viewer: an opaque-origin srcdoc iframe whose STATIC references were rewritten to absolute URLs;
    // relative URLs requested dynamically resolve under /viewer/x/ and 404.
    res.writeHead(200, { 'content-type': 'text/html' });
    res.end(`<!doctype html><body style="margin:0"><iframe id="f" sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-pointer-lock" style="width:100vw;height:100vh;border:0"></iframe>
<script>fetch('/preview/index.html').then(r=>r.text()).then(h=>{h=h.replace(/(src|href)="(?!https?:|data:|#)([^"]+)"/g,(m,a,u)=>a+'="http://localhost:${PORT}/preview/'+u+'"');document.getElementById('f').srcdoc=h;});</script></body>`);
    return;
  }
  if (p === '/__sandbox.html') { res.writeHead(200, { 'content-type': 'text/html' }); res.end('<!doctype html><title>sandbox</title><body style="margin:0"><iframe sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-pointer-lock" src="/index.html" style="width:100vw;height:100vh;border:0"></iframe></body>'); return; }
  if (p.startsWith('/__emoji/')) { const ef = path.join(EMO, p.slice(9)); if (fs.existsSync(ef)) { res.writeHead(200, { 'content-type': ef.endsWith('.css') ? 'text/css' : 'font/woff2', 'access-control-allow-origin': '*' }); if (ef.endsWith('.css')) res.end(fs.readFileSync(ef, 'utf8').replace(/font-family: 'Noto Emoji'/g, "font-family: 'Noto Color Emoji'")); else fs.createReadStream(ef).pipe(res); return; } }
  const f = path.join(DIST, p);
  if (!f.startsWith(DIST) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); res.end('not found'); return; }
  res.writeHead(200, { 'content-type': TYPES[path.extname(f)] || 'application/octet-stream', 'access-control-allow-origin': '*' }); fs.createReadStream(f).pipe(res);
}).listen(PORT);
const URL0 = `http://localhost:${PORT}/`;
const results = []; const errors = [];
const ok = (name, pass, info = '') => { results.push({ name, pass, info }); console.log((pass ? 'PASS ' : 'FAIL ') + name + (info ? ' — ' + info : '')); };

const exe = await SPARTI.executablePath();
// outside AWS Lambda the bundled shared libraries (libnspr4, libnss3…) are not unpacked automatically
const { inflate } = await import('@sparticuz/chromium/build/lambdafs.js').catch(() => import(path.join(path.dirname(new URL(import.meta.url).pathname), '../node_modules/@sparticuz/chromium/build/lambdafs.js')));
const binDir = path.join(path.dirname(new URL(import.meta.url).pathname), '../node_modules/@sparticuz/chromium/bin');
if (!fs.existsSync('/tmp/al2023/lib')) await inflate(path.join(binDir, 'al2023.tar.br'));
const LIBENV = { ...process.env, LD_LIBRARY_PATH: ['/tmp/al2023/lib', '/tmp', process.env.LD_LIBRARY_PATH || ''].filter(Boolean).join(':'), FONTCONFIG_PATH: '/tmp/fonts' };
const browser = await chromium.launch({ executablePath: exe, headless: true, env: LIBENV, args: [...SPARTI.args.filter((a) => a !== '--single-process'), '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox', '--ignore-gpu-blocklist', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--autoplay-policy=no-user-gesture-required'] });

async function newCtx(vp, sr) {
  const phone = vp === 'phone';
  const ctx = await browser.newContext(phone ? { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1', acceptDownloads: true } : { viewport: { width: 1440, height: 900 }, acceptDownloads: true });
  await ctx.grantPermissions(['microphone'], { origin: URL0 }).catch(() => {});
  await ctx.addInitScript(`window.__LQ_PORT__ = ${PORT};`);
  await ctx.addInitScript((srOn) => {
    window.__LQ_TEST__ = true; window.__LQ_NOAUTO__ = true;
    // reward tickets are off unless a test turns them on (seeded progress would otherwise open the ticket flow mid-test)
    try { if (!localStorage.getItem('familyApps.rewards.v1')) localStorage.setItem('familyApps.rewards.v1', JSON.stringify({ version: 1, enabled: false, tokensPerTicket: 3, weeklyCap: 5, rewards: [{ id: 'youtube', emoji: '📺', text: '15 minutes of YouTube' }], updatedAt: 1 })); } catch (e) {}
    // headless Chromium has no emoji font (Macs and iPhones do): load Noto Color Emoji for the screenshots only
    document.addEventListener('DOMContentLoaded', () => { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'http://localhost:' + (window.__LQ_PORT__ || location.port) + '/__emoji/index.css'; document.head.appendChild(l); });
    try {
      const fakeSynth = { speaking: false, pending: false, paused: false, getVoices: () => [], speak(u) { setTimeout(() => { u.onend && u.onend({}); }, 40); }, cancel() {}, pause() {}, resume() {}, onvoiceschanged: null, addEventListener() {}, removeEventListener() {} };
      Object.defineProperty(window, 'speechSynthesis', { value: fakeSynth, configurable: true });
    } catch (e) {}
    if (srOn) {
      class FakeSR {
        start() {
          setTimeout(() => {
            const el = document.querySelector('[data-say]');
            let t = (el && el.getAttribute('data-say')) || 'hola';
            if (window.__LQ_MISS__ > 0) { window.__LQ_MISS__--; t = 'zzz qqq'; }
            const r = [{ transcript: t }]; const ev = { results: [r] };
            this.onresult && this.onresult(ev); this.onend && this.onend();
          }, 150);
        }
        abort() {} stop() {}
      }
      window.SpeechRecognition = FakeSR; window.webkitSpeechRecognition = FakeSR;
    } else { try { delete window.SpeechRecognition; delete window.webkitSpeechRecognition; window.SpeechRecognition = undefined; window.webkitSpeechRecognition = undefined; } catch (e) {} }
    // faster audio element in tests
    const P = HTMLMediaElement.prototype.play;
    HTMLMediaElement.prototype.play = function () { const p = P.call(this); setTimeout(() => this.dispatchEvent(new Event('ended')), 60); return p.catch(() => {}); };
  }, sr);
  return ctx;
}
function watch(page, tag) {
  page.on('response', (r) => { if (r.status() >= 400) console.log(`HTTP${r.status()} [${tag}] ${r.url().slice(0, 160)}`); });
  page.on('console', (m) => { if (m.type() === 'error') errors.push(`[${tag}] console: ${m.text()}`); });
  page.on('pageerror', (e) => { errors.push(`[${tag}] pageerror: ${e.message}`); console.log(`PAGEERROR [${tag}] ${e.message} ${(e.stack || '').split('\n').slice(0, 3).join(' | ')}`); });
}
const imgIssues = []; let imgScreens = 0;
async function checkImgs(page, name) {
  imgScreens++;
  for (const fr of page.frames()) {
    try {
      await fr.waitForFunction(() => [...document.images].every((i) => i.complete), null, { timeout: 4000 }).catch(() => {});
      const bad = await fr.evaluate(() => [...document.images].filter((i) => { const s = i.getAttribute('src'); return !s || !/\S/.test(s) || (i.complete && i.naturalWidth === 0); }).map((i) => (i.getAttribute('src') || '(no src)').slice(0, 50) + ' [' + (i.getAttribute('aria-label') || i.className || 'img') + ']'));
      for (const b of bad) imgIssues.push(`${name}: ${b}`);
    } catch (e) { /* frame navigated away */ }
  }
}
const imgSummary = (tag) => ok(`${tag}: no broken images (${imgScreens} screens checked; every <img> has a src and naturalWidth > 0, or is the fallback badge)`, imgIssues.length === 0, imgIssues.slice(0, 6).join(' | '));
const shot = async (page, name) => {
  const f = path.join(OUT, name + '.png');
  await checkImgs(page, name);
  try { await Promise.race([page.evaluate(() => document.fonts && document.fonts.ready), new Promise((r) => setTimeout(r, 2000))]); } catch (e) {}
  await page.waitForTimeout(120);
  for (let k = 0; k < 2; k++) { try { await page.screenshot({ path: f, fullPage: false, timeout: 15000 }); return f; } catch (e) { console.log('screenshot retry', name, e.message.split('\n')[0]); await page.waitForTimeout(1000); } }
  return f;
};
const tid = (page) => page.evaluate(() => { if (document.querySelector('[data-testid=map]')) return 'langhome'; const el = document.querySelector('.main .card[data-testid]'); return el ? el.getAttribute('data-testid') : null; });
const cardNo = (page) => page.evaluate(() => { const m = document.querySelector('.main[data-card]'); return m ? m.getAttribute('data-card') : null; });
async function waitChange(page, before, ms = 3000) { for (let t = 0; t < ms; t += 150) { await page.waitForTimeout(150); if ((await cardNo(page)) !== before || (await tid(page)) === 'langhome') return true; } return false; }
async function voice(page) {
  const before = await cardNo(page); const t0 = await page.evaluate(() => document.querySelector('[data-testid=voice]') && document.querySelector('[data-testid=voice]').innerText.slice(0, 60));
  if (await page.locator('[data-testid=mic]').count()) await click(page, '[data-testid=mic]');
  else await click(page, '.main [data-testid=voice] .choice[data-ok="1"]');
  for (let k = 0; k < 20; k++) {
    await page.waitForTimeout(200);
    if ((await cardNo(page)) !== before) return;
    const t1 = await page.evaluate(() => document.querySelector('[data-testid=voice]') && document.querySelector('[data-testid=voice]').innerText.slice(0, 60));
    if (t1 !== t0) return; // next question inside the same card
    const nb = page.locator('.actionbar [data-testid=next]:not([disabled])');
    if (await nb.count()) { await nb.first().click(); return; }
    if (await page.locator('[data-testid=compare]').count()) continue;
    if (await page.locator('.main [data-testid=voice] .choice[data-ok="1"]').count() && k > 6) { await page.locator('.main [data-testid=voice] .choice[data-ok="1"]').first().click(); }
  }
}
const click = async (page, sel, opt = {}) => { const el = page.locator(sel).first(); await el.waitFor({ state: 'visible', timeout: opt.timeout || 8000 }); await el.evaluate((e) => e.scrollIntoView({ block: 'center' })); await el.click({ timeout: 30000 }); };
const nextBtn = async (page) => { const b = page.locator('[data-testid=next]').first(); await b.waitFor({ timeout: 4000 }); for (let k = 0; k < 20 && !(await b.isEnabled()); k++) await page.waitForTimeout(150); await b.click({ timeout: 5000 }); };

async function sayIt(page) {
  if (await page.locator('[data-testid=mic]').count()) { await click(page, '[data-testid=mic]'); await page.waitForTimeout(500); }
  else if (await page.locator('[data-testid=rec]').count()) { await click(page, '[data-testid=rec]'); await page.waitForTimeout(700); await click(page, '[data-testid=rec]'); await page.waitForTimeout(400); await click(page, '[data-testid=self-yes]'); }
  else await click(page, '[data-testid=self-yes]');
  await nextBtn(page);
}
async function drawTrace(page) {
  const c = page.locator('[data-testid=trace-canvas]'); const b = await c.boundingBox();
  for (let row = 0; row < 9; row++) { // zig-zag over the middle of the box
    await page.mouse.move(b.x + b.width * 0.2, b.y + b.height * (0.15 + row * 0.08)); await page.mouse.down();
    await page.mouse.move(b.x + b.width * 0.8, b.y + b.height * (0.15 + row * 0.08), { steps: 8 }); await page.mouse.up();
  }
  await click(page, '[data-testid=trace-check]');
  await page.waitForTimeout(200);
  if (await page.locator('[data-testid=trace-next]').count()) await click(page, '[data-testid=trace-next]'); else await page.getByText('Next anyway').click();
}
async function typeFa(page, word) {
  for (const ch of [...word]) { if (ch === '\u200c') { await page.getByText('half-space').click(); continue; } await page.locator('.kbd button', { hasText: ch }).first().click(); }
}

async function playCards(page, tag, maxSteps = 160) {
  const seen = {}; let steps = 0; let unknown = 0; let nulls = 0;
  for (; steps < maxSteps; steps++) {
    await page.waitForTimeout(220);
    const t = await tid(page);
    if (!t) { nulls++; if (nulls === 4) { const h = await page.evaluate(() => { const m = document.querySelector('.main'); return (m ? m.outerHTML : document.body.innerHTML).slice(0, 900); }); console.log(`NULLCARD [${tag}] ${h}`); } await page.waitForTimeout(400); continue; }
    nulls = 0;
    if (!seen[t]) { seen[t] = 1; await shot(page, `${tag}-${t}`); }
    try {
      if (t === 'langhome') break;
      if (t === 'voice') { const nn = await page.locator('[data-noun]').first().getAttribute('data-noun').catch(() => null); if (nn != null) chunkSeen.push(nn); await voice(page); continue; }
      if (t === 'story') { await nextBtn(page); continue; }
      if (t === 'tpr') { await page.waitForTimeout(3600); await nextBtn(page); continue; }
      if (t === 'mission-check') { await click(page, '[data-testid=mission-yes]'); continue; }
      if (t === 'learn') await nextBtn(page);
      else if (t.startsWith('pick-')) { await click(page, '.main .choice[data-ok="1"]'); await nextBtn(page); }
      else if (t === 'sayit') await sayIt(page);
      else if (t === 'spell') { const a = await page.locator('[data-testid=spell-input]').getAttribute('data-answer'); await page.fill('[data-testid=spell-input]', a); await click(page, '[data-testid=check]'); await nextBtn(page); }
      else if (t === 'speed') { await click(page, '[data-testid=start]'); await page.waitForTimeout(3800); await nextBtn(page); }
      else if (t === 'triplets') { for (let r = 0; r < 4; r++) { await page.locator('.main [data-testid=triplets] .choice[data-ok="1"]').nth(0).click(); await page.locator('.main [data-testid=triplets] .choice[data-ok="1"]').nth(1).click(); await nextBtn(page); await page.waitForTimeout(150); if ((await tid(page)) !== 'triplets') break; } }
      else if (t === 'grammar-explain') await nextBtn(page);
      else if (t === 'grammar-item') { await click(page, '.main .choice[data-ok="1"]'); if (await page.locator('.main .why button').count()) await click(page, '.main .why button'); await click(page, '[data-testid=check]'); await nextBtn(page); }
      else if (t === 'write-copy') { const a = await page.locator('[data-testid=write-copy]').getAttribute('data-answer'); await page.fill('[data-testid=write-input]', a); await click(page, '[data-testid=check]'); await nextBtn(page); }
      else if (t === 'write-fill') { await click(page, '.main .choice[data-ok="1"]'); await click(page, '[data-testid=check]'); await nextBtn(page); }
      else if (t === 'write-build') {
        const a = (await page.locator('[data-testid=write-build]').getAttribute('data-answer')).split('|');
        for (const w of a) { await page.locator(`[data-testid=build-pool] .tile[data-tile="${w.replace(/"/g, '\\"')}"]`).first().click(); }
        await click(page, '[data-testid=check]'); await nextBtn(page);
      }
      else if (t === 'write-one' || t === 'write-three') { const a = await page.locator(`[data-testid=${t}]`).getAttribute('data-answer'); await page.fill('[data-testid=write-input]', a || 'hola'); await click(page, '[data-testid=check]'); await nextBtn(page); }

      else if (t === 'picdescribe') await nextBtn(page);
      else if (t === 'boss-intro') await click(page, '[data-testid=boss-start]');
      else if (t === 'boss-fight') { await click(page, '.main .choice[data-ok="1"]'); await nextBtn(page); }
      else if (t === 'boss-end') await nextBtn(page);
      else if (t === 'reward') { if (await page.locator('[data-testid=open-chest]').count()) { await click(page, '[data-testid=open-chest]'); await page.waitForTimeout(300); await shot(page, `${tag}-reward-open`); } await click(page, '[data-testid=finish]'); }
      else if (t === 'script-lesson') {
        if (await page.locator('[data-testid=trace]').count()) await drawTrace(page);
        else if (await page.locator('[data-testid=type-value]').count()) { const a = await page.locator('[data-testid=type-value]').getAttribute('data-answer'); await typeFa(page, a); await nextBtn(page); }
        else if (await page.locator('.main .choice[data-ok="1"]').count()) { await click(page, '.main .choice[data-ok="1"]'); await nextBtn(page); }
        else await nextBtn(page);
      }
      else if (t === 'script-home') break;
      else { console.log('unknown card', t); unknown++; if (unknown > 3) break; await nextBtn(page); }
    } catch (e) { console.log(`[${tag}] step ${steps} on ${t}: ${e.message.split('\n')[0]}`); await page.waitForTimeout(300); }
  }
  return { steps, seen: Object.keys(seen) };
}

async function walkthrough(vp, srOn) {
  const tag = `${vp}`;
  const ctx = await newCtx(vp, srOn); const page = await ctx.newPage(); watch(page, tag);
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]', { timeout: 15000 });
  await shot(page, `${tag}-01-welcome`);
  await page.fill('[data-testid=nick]', 'Hero'); await click(page, '[data-testid=nick-ok]');
  await page.waitForSelector('[data-testid=door-es]'); await page.waitForTimeout(1200); await shot(page, `${tag}-02-home`);
  // Spanish placement (game-like test)
  await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=fs-start]'); await shot(page, `${tag}-03a-es-start`);
  await click(page, '[data-testid=fs-test-start]');
  await page.waitForSelector('[data-testid=placement-intro]'); await shot(page, `${tag}-03-placement-intro`);
  await click(page, '[data-testid=pl-new]');
  await page.waitForSelector('[data-testid=placement-result]'); await shot(page, `${tag}-05-placement-result`);
  await click(page, '[data-testid=pl-accept]');
  await page.waitForSelector('[data-testid=map], [data-testid=fs-path]');
  if (await page.locator('[data-testid=fs-path]').count()) { await shot(page, `${tag}-05b-fs-path`); await click(page, '[data-testid=fs-skip]'); }
  await page.waitForSelector('[data-testid=map]'); await page.waitForTimeout(800); await shot(page, `${tag}-06-es-map`);
  ok(`${tag}: Spanish placement`, true);
  await click(page, '[data-testid=start-quest]');
  const q1 = await playCards(page, `${tag}-es`);
  ok(`${tag}: full Spanish quest`, (await tid(page)) === 'langhome', `${q1.steps} steps; cards: ${q1.seen.join(', ')}`);
  // Farsi: placement with listening rounds, then a full quest
  await click(page, '[data-testid=back]'); await click(page, '[data-testid=door-fa]'); await page.waitForSelector('[data-testid=placement-intro]');
  await shot(page, `${tag}-03b-home-one-door`);
  await click(page, '[data-testid=pl-start]');
  for (let k = 0; k < 14; k++) { await page.waitForTimeout(250); if (!(await page.locator('[data-testid=placement-q]').count())) break; if (k === 0) await shot(page, `${tag}-07-fa-placement-q`); const right = k < 4; try { await click(page, right ? '.main .choice[data-ok="1"]' : '.main .choice[data-ok="0"]'); } catch (e) {} await page.waitForTimeout(1300); }
  if (await page.locator('[data-testid=placement-read]').count()) { await shot(page, `${tag}-08-fa-placement-read`); await click(page, '[data-testid=pl-noread]'); }
  await page.waitForSelector('[data-testid=placement-result]'); await shot(page, `${tag}-09-fa-placement-result`);
  ok(`${tag}: Farsi placement celebrates known words`, (await page.locator('[data-testid=known-est]').count()) > 0);
  await click(page, '[data-testid=pl-accept]'); await page.waitForSelector('[data-testid=map]'); await page.waitForTimeout(600); await shot(page, `${tag}-10-fa-map`);
  await click(page, '[data-testid=start-quest]');
  const q2 = await playCards(page, `${tag}-fa`);
  ok(`${tag}: full Farsi quest`, (await tid(page)) === 'langhome', `${q2.steps} steps; cards: ${q2.seen.join(', ')}`);
  // second Farsi quest = script step day
  await click(page, '[data-testid=start-quest]');
  const q3 = await playCards(page, `${tag}-fa2`);
  ok(`${tag}: second Farsi quest (letters step)`, (await tid(page)) === 'langhome' && q3.seen.includes('script-lesson'), q3.seen.join(', '));
  // Script track: lesson 1 from the letters screen
  await click(page, '[data-testid=script-btn]'); await page.waitForSelector('[data-testid=script-home]'); await shot(page, `${tag}-11-script-home`);
  await page.locator('[data-testid=script-home] .prow').first().click();
  const s1 = await playCards(page, `${tag}-script`, 40);
  ok(`${tag}: script lesson 1`, (await tid(page)) === 'script-home', s1.seen.join(', '));
  return { ctx, page };
}

async function bossWin(page, tag) {
  // seed: Spanish unit 1 fully introduced with the boss on its last heart, then play a quest to the boss
  await page.evaluate(() => {
    const s = JSON.parse(localStorage.getItem('langQuest.state'));
    s.es.units['1'] = Object.assign(s.es.units['1'] || {}, { hp: 1, done: false });
    const d = Math.floor((Date.now() - new Date().getTimezoneOffset() * 60000) / 86400000);
    for (let i = 0; i < 60; i++) { s.es.srs['es1w' + i] = s.es.srs['es1w' + i] || { b: 2, d: d + 3, r: 2, w: 0, s: d }; s.es.srs['es1p' + i] = s.es.srs['es1p' + i] || { b: 2, d: d + 3, r: 2, w: 0, s: d }; }
    localStorage.setItem('langQuest.state', JSON.stringify(s));
  });
  await page.goto(URL0); await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=map]');
  await click(page, '[data-testid=start-quest]');
  const r = await playCards(page, `${tag}-boss`);
  const won = await page.evaluate(() => JSON.parse(localStorage.getItem('langQuest.state')).es.units['1'].done === true);
  ok(`${tag}: boss defeated (unit 1, ${'Mad Scrub'})`, won, r.seen.join(', '));
  await click(page, '[data-testid=ican-btn]'); await page.waitForSelector('[data-testid=ican]'); await shot(page, `${tag}-12-ican`);
  await click(page, '[data-testid=back]');
}

async function speedAndTriplets(page, tag) {
  // seed: many known words due today in both languages and a quest count that schedules the speed round + triplets
  await page.evaluate(() => {
    const s = JSON.parse(localStorage.getItem('langQuest.state'));
    const d = Math.floor((Date.now() - new Date().getTimezoneOffset() * 60000) / 86400000);
    for (const l of ['es', 'fa']) for (let u = 1; u <= 8; u++) for (let i = 0; i < 40; i++) s[l].srs[l + u + 'w' + i] = { b: 3, d, r: 3, w: i % 5 === 0 ? 2 : 0, s: d - 5 };
    s.es.quests = 10; s.es.diff = 3; s.es.lastDay = 0; s.es.fs = { skipped: true };
    s.es.mission = { day: d - 1, en: 'Say good morning in Spanish.', say: '¡Buenos días!', done: false };
    localStorage.setItem('langQuest.state', JSON.stringify(s));
  });
  await page.goto(URL0); await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=map]');
  await click(page, '[data-testid=start-quest]');
  await page.evaluate(() => { window.__LQ_MISS__ = 2; });
  const r = await playCards(page, `${tag}-extra`);
  const nrev = await page.evaluate(() => JSON.parse(localStorage.getItem('langQuest.state')).reports[0].reviewed);
  const okNouns = chunkSeen.length > 0 && chunkSeen.every((n) => WHITELIST.some((w) => w.en === n));
  ok(`${tag}: power phrases use whitelisted nouns`, okNouns, `seen: ${chunkSeen.join(', ') || 'none'}`);
  ok(`${tag}: speed round + triplets + home-mission check + review cap (<=12)`, r.seen.includes('speed') && r.seen.includes('triplets') && r.seen.includes('mission-check') && nrev <= 12, `reviewed ${nrev}; ${r.seen.join(', ')}`);
}

async function extras(page, tag) {
  await page.goto(URL0); await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=map]');
  // rupee shop: he buys by saying the phrase
  await page.evaluate(() => { const s = JSON.parse(localStorage.getItem('langQuest.state')); s.rupees = Math.max(s.rupees, 100); localStorage.setItem('langQuest.state', JSON.stringify(s)); });
  await page.goto(URL0); await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=map]');
  await click(page, '[data-testid=shop-btn]');
  if (await page.locator('[data-testid=talon-shop]').count() || await page.waitForSelector('[data-testid=talon-shop]', { timeout: 4000 }).then(() => true).catch(() => false)) { await shot(page, `${tag}-21-market`); await click(page, '[data-testid=talon-shop]'); }
  await page.waitForSelector('[data-testid=shop]'); await shot(page, `${tag}-22-shop`);
  await click(page, '[data-testid=shop-navi_pink]'); await page.waitForSelector('[data-testid=voice]'); await shot(page, `${tag}-23-shop-say`);
  await voice(page); await page.waitForSelector('[data-testid=shop-bought]', { timeout: 6000 }); await shot(page, `${tag}-24-shop-bought`);
  const owned = await page.evaluate(() => JSON.parse(localStorage.getItem('langQuest.state')).shop.owned);
  ok(`${tag}: rupee shop (buy by saying the phrase)`, owned.includes('navi_pink'), owned.join(','));
  await click(page, '[data-testid=next]'); await click(page, '[data-testid=back]');
  // songbook: play the unit tune on the keys, then say the line to open the door
  await click(page, '[data-testid=songs-btn]'); await page.waitForSelector('[data-testid=songbook]'); await shot(page, `${tag}-25-songbook`);
  await click(page, '[data-testid=song-door]'); await page.waitForSelector('[data-testid=songbook-tune]'); await page.waitForTimeout(400);
  const ic = await page.$$eval('.tune .tn', (els) => els.map((e) => e.textContent));
  const keyOf = { 'A': '1', '▼': '2', '▶': '3', '◀': '4', '▲': '5' };
  for (const c of ic) { await page.keyboard.press(keyOf[c]); await page.waitForTimeout(250); }
  await shot(page, `${tag}-26-songbook-tune-played`);
  await page.waitForSelector('[data-testid=voice]', { timeout: 5000 }).catch(() => {});
  if (await page.locator('[data-testid=voice]').count()) { await shot(page, `${tag}-27-songbook-karaoke`); await voice(page); }
  const door = await page.waitForSelector('[data-testid=door-open]', { timeout: 6000 }).then(() => true).catch(() => false);
  ok(`${tag}: ocarina songbook (tune on keys + say the line opens the door)`, door, `tune ${ic.join(' ')}`);
  await click(page, '[data-testid=next]'); await click(page, '[data-testid=back]');
  // ocarina toy: he plays Saria's song himself; Navi reacts (the app never plays or shows it)
  await page.goto(URL0); await page.waitForSelector('[data-testid=door-es]');
  const hasToy = await page.locator('text=Ocarina').count();
  await page.evaluate(() => { const s = JSON.parse(localStorage.getItem('langQuest.state')); s.toys.ocarina = true; localStorage.setItem('langQuest.state', JSON.stringify(s)); });
  await page.goto(URL0); await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=map]');
  await page.locator('button', { hasText: 'Ocarina' }).first().click(); await page.waitForSelector('[data-testid=ocarina]'); await page.waitForTimeout(400);
  for (const k of ['2', '3', '4', '2', '3', '4']) { await page.keyboard.press(k); await page.waitForTimeout(220); }
  const secret = await page.waitForSelector('[data-testid=secret-song]', { timeout: 3000 }).then(() => true).catch(() => false);
  await shot(page, `${tag}-28-ocarina-secret`);
  ok(`${tag}: ocarina recognizes a secret song he plays (heart piece)`, secret);
}

async function parentCorner(page, tag, ctx) {
  await page.goto(URL0); await click(page, '[data-testid=parent-btn]'); await page.waitForSelector('[data-testid=pinpad]'); await shot(page, `${tag}-13-pin`);
  for (const d of '0000') await click(page, `[data-testid=pin-${d}]`);
  for (const d of '2468') await click(page, `[data-testid=pin-${d}]`);
  for (const d of '2468') await click(page, `[data-testid=pin-${d}]`);
  await page.waitForSelector('[data-testid=setup]'); await shot(page, `${tag}-13b-setup`);
  await click(page, '[data-testid=allow-mic]'); await page.waitForTimeout(500); await click(page, '[data-testid=setup-done]');
  await page.waitForSelector('[data-testid=parent]'); await page.waitForTimeout(300); await shot(page, `${tag}-14-parent-report`);
  ok(`${tag}: parent PIN must be changed on first visit`, true);
  await page.waitForSelector('[data-testid=week-card]');
  await click(page, '[data-testid=tab-report]'); await page.waitForTimeout(300); await shot(page, `${tag}-14b-full-reports`);
  const reports = await page.locator('[data-testid=session-report]').count();
  ok(`${tag}: session reports saved`, reports >= (process.env.ONLY === 'desktop2' ? 1 : 2), `${reports} reports`);
  await click(page, '[data-testid=tab-settings]'); await shot(page, `${tag}-15-parent-settings`);
  await click(page, '[data-testid=tab-voices]'); await page.waitForTimeout(300); await shot(page, `${tag}-16-parent-voices`);
  await click(page, '[data-testid=open-queue]'); await page.waitForSelector('[data-testid=rec-queue]'); await shot(page, `${tag}-16b-rec-queue`);
  await click(page, '[data-testid=rec-one]'); await page.waitForTimeout(6800); await shot(page, `${tag}-16c-rec-queue-next`);
  const recs = await page.evaluate(() => new Promise((res) => { const r = indexedDB.open('langQuest.voices', 1); r.onsuccess = () => { const t = r.result.transaction('voices', 'readonly').objectStore('voices').count(); t.onsuccess = () => res(t.result); }; r.onerror = () => res(-1); }));
  ok(`${tag}: guided recording queue saves a family voice`, recs >= 1, `${recs} recordings`);
  await click(page, '[data-testid=open-ear]'); await page.waitForSelector('[data-testid=ear-check]'); await click(page, '[data-testid=thumbs-down]'); await shot(page, `${tag}-16d-ear-check`);
  await click(page, '[data-testid=tab-ai]'); await shot(page, `${tag}-17-parent-ai`);
  await click(page, '[data-testid=tab-help]'); await shot(page, `${tag}-18-parent-help`);
  await click(page, '[data-testid=tab-backup]');
  const [dl] = await Promise.all([page.waitForEvent('download'), click(page, '[data-testid=download-backup]')]);
  const bf = path.join(OUT, `${tag}-backup.json`); await dl.saveAs(bf);
  const b = JSON.parse(fs.readFileSync(bf, 'utf8'));
  ok(`${tag}: backup download`, b.app === 'langQuest' && !!b.localStorage['langQuest.state'], `${fs.statSync(bf).size} bytes`);
  // wipe, then import with confirmation
  await page.evaluate(() => { const s = JSON.parse(localStorage.getItem('langQuest.state')); s.nick = 'Changed'; localStorage.setItem('langQuest.state', JSON.stringify(s)); });
  await page.setInputFiles('[data-testid=import-file]', bf);
  await page.waitForSelector('[data-testid=confirm-import]'); await shot(page, `${tag}-19-import-confirm`);
  await click(page, '[data-testid=confirm-import]'); await page.waitForTimeout(1500);
  const nick = await page.evaluate(() => JSON.parse(localStorage.getItem('langQuest.state')).nick);
  ok(`${tag}: restore from backup`, nick === 'Hero', `nick=${nick}`);
}

async function offline(ctx, page, tag) {
  await page.goto(URL0); await page.waitForTimeout(2500);
  const sw = await page.evaluate(async () => { const r = await navigator.serviceWorker.getRegistration(); return !!(r && r.active); });
  await ctx.setOffline(true);
  await page.reload(); await page.waitForTimeout(1500);
  const okHome = await page.locator('[data-testid=door-es]').count();
  await shot(page, `${tag}-20-offline-home`);
  await click(page, '[data-testid=door-fa]'); await page.waitForSelector('[data-testid=map]'); await click(page, '[data-testid=start-quest]'); await page.waitForTimeout(1500);
  await shot(page, `${tag}-21-offline-quest`);
  ok(`${tag}: works offline after first load`, sw && okHome > 0, `sw=${sw}`);
  await ctx.setOffline(false);
}

// ---- image tour: every screen with pictures, opened directly through the test hook (window.__lqTest) ----
async function imageTour(label, url, { frame = false, vp = 'desktop', dist = true, only = 'all' } = {}) {
  const ctx = await newCtx(vp, true);
  await ctx.addInitScript(() => { window.__LQ_TEST__ = { unlock: true }; });
  const page = await ctx.newPage(); const e0 = errors.length; watch(page, label);
  await page.goto(url);
  const F = async () => { if (!frame) return page.mainFrame(); for (let i = 0; i < 80; i++) { const f = page.frames().find((x) => x !== page.mainFrame()); if (f) return f; await page.waitForTimeout(250); } throw new Error('no frame'); };
  const fr = await F();
  await fr.waitForFunction(() => !!window.__lqTest, null, { timeout: 30000 });
  await fr.evaluate(() => { try { localStorage.removeItem('familyApps.rewards.v1'); localStorage.removeItem('familyApps.tickets.v1'); } catch (e) {} }); // tickets on (defaults)
  await fr.evaluate(() => window.__lqTest.set((s) => {
    s.nick = 'Hero'; s.setupDone = true; s.rupees = 60; s.toys.ocarina = true;
    for (const l of ['es', 'fa']) { s[l].placed = true; s[l].level = 'sprout'; s[l].quests = 3; }
    for (let n = 1; n <= 5; n++) s.es.units[n] = { done: true, hp: 0, doneAt: Date.now() };
  }));
  const visit = async (name, screen, params, after) => {
    await fr.evaluate(([sc, pr]) => window.__lqTest.go(sc, pr), [screen, params]);
    await page.waitForTimeout(900);
    if (after) await after();
    await shot(page, `tour-${label}-${name}`);
  };
  if (only === 'new') {
    // v6 screens: token counter + hidden things, House of Skulltula, the ticket flow, Parent corner → Rewards
    await fr.evaluate(() => window.__lqTest.set((s) => { s.treasure = { found: { moon: 1, unit1: 1, unit3: 1, unit5: 1, speak20: 1 }, tokens: 1, toChoose: 0, flags: {}, capped: false }; }));
    await visit('new-home', 'home', {});
    await visit('new-lang-es', 'lang', { lang: 'es' });
    await visit('new-ican-es', 'ican', { lang: 'es' });
    await visit('new-treasure', 'treasure', {});
    await visit('new-wallet', 'wallet', {});
    await visit('new-market', 'market', { lang: 'es' });
    const L = (sel) => (frame ? page.frameLocator('iframe') : page).locator(sel);
    await visit('new-parent-rewards', 'parent', {}, async () => { await L('[data-testid=tab-rewards]').click(); await page.waitForTimeout(700); });
    const diagN = await fr.evaluate(() => (window.__lqDiag || []).map((d) => d.m));
    const overlayN = await fr.evaluate(() => { const b = document.getElementById('lq-diag'); return !!(b && b.offsetParent !== null); });
    ok(`${label}: wallet screens (mini Triforce counter, Treasure Wallet, Hyrule Market, House of Skulltula, Parent → Rewards), zero errors${dist ? ', no overlay' : ''}`, errors.length === e0 && diagN.length === 0 && (!dist || !overlayN), errors.slice(e0, e0 + 3).join(' | ') || diagN.slice(0, 3).join(' | '));
    await ctx.close(); return;
  }
  await visit('home', 'home', {});
  await visit('lang-es', 'lang', { lang: 'es' });
  await visit('ican-es', 'ican', { lang: 'es' });
  await visit('ican-fa', 'ican', { lang: 'fa' });
  await visit('cert-es', 'cert', { lang: 'es', level: 'sprout' });
  await visit('songbook', 'songs', { lang: 'es' });
  await visit('shop', 'shop', { lang: 'es' });
  await visit('ocarina', 'ocarina', { lang: 'es' });
  await visit('letters', 'script', { lang: 'fa' });
  await visit('parent', 'parent', {});
  for (const t of ['week', 'report', 'settings', 'voices', 'backup', 'ai', 'help']) {
    await visit('parent-' + t, 'parent', {}, async () => { const b = (frame ? page.frameLocator('iframe') : page).locator(`[data-testid=tab-${t}]`); if (await b.count()) { await b.first().click(); await page.waitForTimeout(700); } });
  }
  const diag = await fr.evaluate(() => (window.__lqDiag || []).map((d) => d.m));
  const overlayShown = await fr.evaluate(() => { const b = document.getElementById('lq-diag'); return !!(b && b.offsetParent !== null); });
  const helpDiag = await fr.evaluate(() => !!document.querySelector('[data-testid=diagnostics]'));
  if (dist) ok(`${label}: no error overlay in the dist (diagnostics list in Parent corner → Help)`, !overlayShown && helpDiag, `recorded problems: ${diag.length}${diag.length ? ' — ' + diag.slice(0, 3).join(' | ') : ''}`);
  ok(`${label}: image tour, zero errors (home, I can maps with stones/medallions, certificate, songbook, shop, ocarina, letters, 8 parent screens)`, errors.length === e0 && diag.length === 0, errors.slice(e0, e0 + 3).join(' | ') || diag.slice(0, 3).join(' | '));
  await ctx.close();
}
async function treasureTest(page, tag) {
  await page.evaluate(async () => {
    localStorage.removeItem('familyApps.rewards.v1'); localStorage.removeItem('familyApps.tickets.v1');
    await window.__lqTest.setPin('1234');
    // achievements already earned in this profile are marked found, so only the hidden things below change the count
    const ach = ['speak20', 'unit1', 'unit3', 'unit5', 'nohint', 'streak3', 'firststeps', 'words50', 'helpfinish', 'story', 'chant', 'farsi'];
    window.__lqTest.set((s) => { s.treasure = { found: Object.fromEntries(ach.map((k) => [k, 1])), tokens: 2, toChoose: 0, flags: {}, capped: false, best: 0 }; });
    window.__lqTest.go('home');
  });
  await page.waitForTimeout(900);
  const chip = await page.locator('[data-testid=tokens]').count();
  await page.locator('[data-secret=glint]').click({ force: true });
  const toastTxt = await page.locator('[data-testid=toast]').first().textContent({ timeout: 3000 }).catch(() => '');
  await page.locator('[data-testid=ticket-chest]').waitFor({ timeout: 8000 });
  await shot(page, `${tag}-treasure-chest`);
  // another app writes a ticket and edits the shared list meanwhile
  await page.evaluate(() => {
    const t = JSON.parse(localStorage.getItem('familyApps.tickets.v1') || '[]'); t.push({ id: 'math-x1', app: 'math', rewardId: 'pet', rewardText: 'Play time with our pet', emoji: '🐾', earnedAt: Date.now() - 5000, status: 'earned' }); localStorage.setItem('familyApps.tickets.v1', JSON.stringify(t));
    // nothing was written at load, so the other app (first to write) stores the shared defaults plus its edit
    const c = JSON.parse(localStorage.getItem('familyApps.rewards.v1') || 'null') || { version: 1, enabled: true, tokensPerTicket: 3, weeklyCap: 5, rewards: [{ id: 'youtube', emoji: '📺', text: '15 minutes of YouTube' }, { id: 'switch', emoji: '🎮', text: '20 minutes of Nintendo Switch' }, { id: 'pet', emoji: '🐾', text: 'Play time with our pet' }, { id: 'treat', emoji: '🍦', text: 'Pick a special treat' }, { id: 'game', emoji: '🎲', text: 'Family game pick' }], updatedAt: new Date().toISOString() };
    c.rewards.push({ id: 'zoo', emoji: '🦁', text: 'Zoo trip' }); localStorage.setItem('familyApps.rewards.v1', JSON.stringify(c));
  });
  await click(page, '[data-testid=open-ticket-chest]');
  await page.locator('[data-testid=ticket-choose]').waitFor({ timeout: 5000 });
  const zoo = await page.locator('[data-testid=reward-card]', { hasText: 'Zoo trip' }).count();
  await shot(page, `${tag}-treasure-choose`);
  await page.locator('[data-testid=reward-card]').nth(1).click();
  await page.locator('[data-testid=ticket-card]').waitFor({ timeout: 5000 });
  await shot(page, `${tag}-treasure-ticket`);
  await page.locator('[data-testid=ticket-card] [data-testid=approve]').first().click();
  await page.fill('[data-testid=pin-ask-input]', '9999'); await page.click('[data-testid=pin-ask-ok]'); await page.waitForTimeout(500);
  const wrong = await page.locator('[data-testid=pin-ask-err]').count();
  const mid = JSON.parse(await page.evaluate(() => localStorage.getItem('familyApps.tickets.v1')));
  const stillEarned = (mid.find((t) => t.app === 'language') || {}).status === 'earned';
  await page.fill('[data-testid=pin-ask-input]', '1234'); await page.click('[data-testid=pin-ask-ok]'); await page.waitForTimeout(700);
  await shot(page, `${tag}-treasure-approved`);
  const tk = JSON.parse(await page.evaluate(() => localStorage.getItem('familyApps.tickets.v1')));
  const mine = tk.filter((t) => t.app === 'language');
  ok(`${tag}: secret → toast, ticket chest → choose (re-reads the shared list) → ticket; PIN gate refuses a wrong PIN, the right PIN marks it used; other apps' tickets kept`,
    chip > 0 && /Secret found! 13\/18 · A Reward Ticket is waiting for you!/.test(toastTxt || '') && zoo === 1 && wrong === 1 && stillEarned && mine.length === 1 && mine[0].status === 'used' && mine[0].rewardText === '20 minutes of Nintendo Switch' && /^language-\d{13}-/.test(mine[0].id) && /T/.test(mine[0].earnedAt) && /T/.test(mine[0].usedAt) && tk.some((t) => t.id === 'math-x1' && t.status === 'earned'),
    `toast: ${toastTxt}; tickets: ${tk.map((t) => t.app + ':' + t.status).join(', ')}`);
  // one-time: the glint is gone; the moon needs 3 taps
  await page.evaluate(() => window.__lqTest.go('home')); await page.waitForTimeout(800);
  const glintGone = (await page.locator('[data-secret=glint]').count()) === 0;
  await page.locator('[data-secret=moon]').first().click(); const after1 = await page.evaluate(() => !!window.__lqTest.get().treasure.found.moon);
  await page.locator('[data-secret=moon]').first().click(); await page.locator('[data-secret=moon]').first().click(); await page.waitForTimeout(300);
  const moon = await page.evaluate(() => !!window.__lqTest.get().treasure.found.moon);
  await page.evaluate(() => window.__lqTest.go('home')); await page.waitForTimeout(400);
  await click(page, '[data-testid=tokens]'); await page.locator('[data-testid=treasure]').waitFor({ timeout: 5000 });
  const cnt = await page.locator('[data-testid=found-count]').textContent();
  await shot(page, `${tag}-treasure-page`);
  ok(`${tag}: each secret unlocks once (glint gone; moon only after 3 taps); House of Skulltula shows "${(cnt || '').trim()}"`, glintGone && !after1 && moon && /14 of 18/.test(cnt || ''), cnt);
  // weekly cap: cap 1 is already used this week → new tokens wait with the message
  await page.evaluate(() => { const c = JSON.parse(localStorage.getItem('familyApps.rewards.v1') || '{"version":1,"enabled":true,"rewards":[]}'); c.weeklyCap = 1; c.tokensPerTicket = 1; localStorage.setItem('familyApps.rewards.v1', JSON.stringify(c)); window.__lqTest.go('lang', { lang: 'es' }); });
  await page.waitForTimeout(800);
  await page.locator('[data-secret=cow]').click({ force: true }); await page.waitForTimeout(500);
  await page.evaluate(() => window.__lqTest.go('treasure')); await page.waitForTimeout(700);
  const capped = await page.locator('[data-testid=capped]').count(); const st = await page.evaluate(() => window.__lqTest.get().treasure);
  await shot(page, `${tag}-treasure-capped`);
  ok(`${tag}: weekly cap across apps — over the cap the token waits ("chest is full this week")`, capped === 1 && st.toChoose === 0 && st.tokens >= 1, `tokens waiting: ${st.tokens}`);
}

// ---- First Steps: a fresh beginner, no mic ----
async function fsPlay(page, tag, { shots = false, typeBuild = false, useHelp = false, accents = false, miss = 0 } = {}) {
  const seen = []; let steps = 0; const t0 = Date.now(); let missLeft = miss; let win = null;
  for (let guard = 0; guard < 40; guard++) {
    const k = await page.evaluate(() => { const el = document.querySelector('[data-testid=fs-lesson-wrap] .card[data-testid]'); return el ? el.getAttribute('data-testid') : null; });
    if (!k) { if (await page.locator('[data-testid=fs-path], [data-testid=map]').count()) break; await page.waitForTimeout(300); continue; }
    const cardNo0 = await page.evaluate(() => document.querySelector('[data-testid=fs-lesson-wrap]').getAttribute('data-card'));
    if (!seen.includes(k)) seen.push(k);
    if (process.env.FS_TRACE) console.log(`  [${tag}] step ${steps}: ${k} (card ${cardNo0})`);
    if (shots || process.env.FS_TRACE) await shot(page, `${tag}-${String(steps).padStart(2, '0')}-${k}`);
    steps++;
    if (k === 'fs-meet') await click(page, '[data-testid=next]');
    else if (k === 'fs-tap') {
      if (useHelp && !seen.includes('help-used')) { for (let h = 0; h < 4; h++) { await click(page, '[data-testid=help-btn]'); await page.waitForTimeout(150); } seen.push('help-used'); if (shots) await shot(page, `${tag}-help-ladder`); }
      if (missLeft > 0 && await page.locator('[data-testid=fs-tap] [data-ok="0"]').count()) { missLeft--; await click(page, '[data-testid=fs-tap] [data-ok="0"]'); await page.waitForTimeout(300); seen.push('missed'); }
      await click(page, '[data-testid=fs-tap] [data-ok="1"]');
    }
    else if (k === 'fs-match') { const ids = await page.locator('[data-testid=fs-word]').evaluateAll((els) => els.map((e) => e.getAttribute('data-id'))); for (const id of ids) { await click(page, `[data-testid=fs-word][data-id="${id}"]`); await click(page, `[data-testid=fs-matchpic][data-id="${id}"]`); } }
    else if (k === 'fs-say') await click(page, '[data-testid=fs-skip-say]');
    else if (k === 'fs-build') {
      const ans = await page.locator('[data-testid=fs-input]').getAttribute('data-answer').catch(() => null);
      if (typeBuild && ans) {
        await click(page, '[data-testid=fs-choose-mode]'); if (shots) await shot(page, `${tag}-build-choose`); seen.push('choose-mode');
        await click(page, '[data-testid=fs-type-mode]'); seen.push('type-mode');
        if (accents && /[áéíóúñ]/.test(ans)) { for (const ch of ans) { if (/[áéíóúñ]/.test(ch)) await click(page, `.accents button:text-is("${ch}")`); else await page.locator('[data-testid=fs-input]').press(ch === ' ' ? 'Space' : ch); } seen.push('accent-tiles'); }
        else await page.fill('[data-testid=fs-input]', ans);
        if (shots) await shot(page, `${tag}-build-typed`);
        await click(page, '[data-testid=fs-check]');
      } else { await click(page, '[data-testid=fs-choose-mode]'); await click(page, '[data-testid=fs-build-choice][data-ok="1"]'); }
    }
    else if (k === 'fs-chat') { for (let c = 0; c < 6 && await page.locator('[data-testid=fs-chat]').count(); c++) { await click(page, '[data-testid=fs-chat-choice][data-ok="1"]'); await page.waitForTimeout(1100); } continue; }
    else if (k === 'fs-win' || k === 'fs-champion' || k === 'fs-review-done') {
      win = await page.evaluate(() => { const c = document.querySelector('[data-testid=fs-win], [data-testid=fs-review-done], [data-testid=fs-champion]'); const t = (sel) => { const e = c && c.querySelector(sel); return e ? e.textContent : null; }; return c ? { kind: c.getAttribute('data-testid'), passed: c.getAttribute('data-passed'), pay: t('[data-testid=fs-pay]'), banked: t('[data-testid=fs-banked]'), score: t('[data-testid=fs-score]'), title: t('h2') } : null; });
      if (shots) await shot(page, `${tag}-win`);
      await click(page, '[data-testid=fs-continue]'); await page.waitForTimeout(500); break;
    }
    for (let w = 0; w < 30; w++) { await page.waitForTimeout(120); const c = await page.evaluate(() => { const e = document.querySelector('[data-testid=fs-lesson-wrap]'); return e ? e.getAttribute('data-card') : 'gone'; }); if (c !== cardNo0) break; }
  }
  return { seen, steps, win, secs: Math.round((Date.now() - t0) / 1000) };
}
// ---- v7.3: graduation, locked replay, practice (no treasure), retry below 80%, test-out, due review once ----
async function gradTest(vp) {
  const ctx = await newCtx(vp, false); const page = await ctx.newPage(); const e0 = errors.length; watch(page, vp + '-grad');
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
  await page.fill('[data-testid=nick]', 'Hero'); await click(page, '[data-testid=nick-ok]');
  await click(page, '[data-testid=door-es]'); await click(page, '[data-testid=fs-new]'); await page.waitForSelector('[data-testid=fs-path]');
  const bal = () => page.evaluate(() => { const b = FamilyWallet.balance(); return { s: b.language || 0, r: b.rupees || 0 }; });
  const toPath = async () => { await page.evaluate(() => window.__lqTest.go('lang', { lang: 'es' })); await page.waitForSelector('[data-testid=fs-path]'); };
  const b0 = await bal();
  await click(page, '[data-testid=fs-node-1]'); const r1 = await fsPlay(page, `${vp}-grad-l1`, { shots: true });
  await toPath(); await shot(page, `${vp}-grad-01-path-step1-graduated`);
  const b1 = await bal(); const lock1 = await page.locator('[data-testid=fs-node-1]').isDisabled(); const tag1 = await page.locator('[data-testid=fs-grad-1]').count();
  ok(`${vp}: a clean step graduates (🎓, 100% without help); its node is locked; a single micro-step pays no shards, only rupees for first-correct answers`, r1.win && r1.win.passed === '1' && /Graduated/.test(r1.win.title || '') && lock1 && tag1 === 1 && b1.s === b0.s && b1.r > b0.r, JSON.stringify({ win: r1.win, lock1, b0, b1 }));
  for (const n of [2, 3]) { await click(page, `[data-testid=fs-node-${n}]`); await fsPlay(page, `${vp}-grad-l${n}`, {}); await toPath(); }
  const b3 = await bal();
  await click(page, '[data-testid=fs-node-4]'); const r4 = await fsPlay(page, `${vp}-grad-l4`, { shots: true }); await toPath();
  const b4 = await bal();
  ok(`${vp}: micro-step scaling — steps 2–3 pay 0 shards; graduating step 4 completes the "Hello!" group: +2 Courage shards, once`, b3.s === b0.s && b4.s === b0.s + 2 && /\+2 Courage/.test(r4.win.pay || ''), JSON.stringify({ b3, b4, pay: r4.win.pay }));
  // grown-up unlocks practice in the Parent corner (PIN); a practice replay pays nothing
  await page.evaluate(() => window.__lqTest.go('parent')); await page.waitForSelector('[data-testid=pinpad]');
  for (const d of '0000') await click(page, `[data-testid=pin-${d}]`); for (const d of '2468') await click(page, `[data-testid=pin-${d}]`); for (const d of '2468') await click(page, `[data-testid=pin-${d}]`);
  await page.waitForSelector('[data-testid=setup]'); await click(page, '[data-testid=setup-done]'); await page.waitForSelector('[data-testid=parent]');
  await click(page, '[data-testid=tab-settings]'); await click(page, '[data-testid=practice-toggle]'); await shot(page, `${vp}-grad-02-parent-practice-toggle`);
  await toPath(); const prBtn = await page.locator('[data-testid=fs-node-1]').isEnabled(); const prTag = await page.locator('[data-testid=fs-grad-1]').textContent();
  await click(page, '[data-testid=fs-node-1]'); const rp = await fsPlay(page, `${vp}-grad-practice`, { shots: true }); await toPath();
  const bp = await bal();
  ok(`${vp}: practice replay (unlocked by a grown-up with the PIN) pays nothing — repeats = practice`, prBtn && /Practice/.test(prTag || '') && /Practice round/.test((rp.win && rp.win.title) || '') && bp.s === b4.s && bp.r === b4.r, JSON.stringify({ prBtn, prTag, title: rp.win && rp.win.title, b4, bp }));
  await page.evaluate(() => window.__lqTest.set((s) => { s.settings.practice = false; })); await toPath();
  // due review: short, mixed; pays once per due review
  const due = async () => page.evaluate(() => window.__lqTest.set((s) => { const t = Math.floor((Date.now() - new Date().getTimezoneOffset() * 60000) / 86400000); for (const id of ['es1w0', 'es1w1', 'es1w2', 'es1w10', 'es1w11', 'es1w5']) if (s.es.fs.srs[id]) s.es.fs.srs[id] = { b: 2, d: t }; }));
  await due(); await toPath(); const rvBtn = await page.locator('[data-testid=fs-review]').count(); await shot(page, `${vp}-grad-04-review-button`);
  const br0 = await bal();
  await click(page, '[data-testid=fs-review]'); const rv = await fsPlay(page, `${vp}-grad-review`, { shots: true }); await toPath();
  const br1 = await bal();
  await due(); await toPath(); await click(page, '[data-testid=fs-review]'); const rv2 = await fsPlay(page, `${vp}-grad-review2`, {}); await toPath();
  const br2 = await bal();
  ok(`${vp}: a due review passed pays a small amount once (+1 shard); the same due review again pays 0`, rvBtn === 1 && rv.win && rv.win.passed === '1' && br1.s === br0.s + 1 && rv2.win && rv2.win.passed === '1' && br2.s === br1.s, JSON.stringify({ rvBtn, br0, br1, br2, pay1: rv.win && rv.win.pay, pay2: rv2.win && rv2.win.pay }));
  // below 80% → not graduated, "try again for 🎓"; a clean retry graduates
  await click(page, '[data-testid=fs-node-5]'); const f5 = await fsPlay(page, `${vp}-grad-l5-miss`, { miss: 3 }); await toPath();
  const retry = await page.locator('[data-testid=fs-node-5] .retrytag').count(); const g5a = await page.locator('[data-testid=fs-grad-5]').count();
  await click(page, '[data-testid=fs-node-5]'); const p5 = await fsPlay(page, `${vp}-grad-l5-clean`, {}); await toPath();
  const g5b = await page.locator('[data-testid=fs-grad-5]').count();
  ok(`${vp}: below 80% without help → not graduated ("Try again for 🎓"); a clean retry graduates`, f5.win && f5.win.passed === '0' && retry === 1 && g5a === 0 && p5.win.passed === '1' && g5b === 1, JSON.stringify({ fail: f5.win && f5.win.score, retry, pass: p5.win && p5.win.score }));
  // test-out of not-yet-started steps
  const to7 = await page.locator('[data-testid=fs-testout-7]').count();
  await click(page, '[data-testid=fs-testout-7]'); const t7 = await fsPlay(page, `${vp}-grad-testout7`, { shots: true }); await toPath();
  const g7 = await page.locator('[data-testid=fs-grad-7]').count();
  await click(page, '[data-testid=fs-testout-8]'); const t8 = await fsPlay(page, `${vp}-grad-testout8-miss`, { miss: 3 });
  const learn8 = await page.waitForFunction(() => { const w = document.querySelector('[data-testid=fs-lesson-wrap] .card[data-testid]'); const t = document.querySelector('[data-testid=fs-lesson-wrap] .muted.small'); return !!w && !!t && !/Test out/.test(t.textContent) && !/Test out|test out/.test(document.title + (document.querySelector('.title') || {}).textContent); }, null, { timeout: 8000 }).then(() => true).catch(() => false);
  await shot(page, `${vp}-grad-03-testout-fail-starts-lesson`);
  ok(`${vp}: test-out — a clean test graduates a not-yet-started step without the lesson; a weak test says "Not yet" and starts the lesson`, to7 === 1 && t7.win && t7.win.passed === '1' && /tested out/.test(t7.win.title || '') && g7 === 1 && t8.win && t8.win.passed === '0' && learn8, JSON.stringify({ t7: t7.win, t8: t8.win && t8.win.title, learn8 }));
  await toPath();
  // rapid guessing right before a pass: the module pauses treasure; the pass is kept and paid later (onceId not lost)
  const gq = await page.evaluate(() => { for (let k = 0; k < 4; k++) FamilyWallet.answer('language', false, 'g'); return true; });
  await click(page, '[data-testid=fs-node-6]'); const g6 = await fsPlay(page, `${vp}-grad-l6-guessing`, {}); await toPath();
  const pend = await page.evaluate(() => JSON.parse(localStorage.getItem('langQuest.oncePending') || '[]').map((x) => x.onceId));
  ok(`${vp}: a pass during the rapid-guessing pause is kept for later (group "Numbers" pending), not lost`, gq && g6.win && g6.win.passed === '1' && pend.includes('firststeps:group-count:pass'), JSON.stringify({ pay: g6.win && g6.win.pay, guess: g6.win, pend }));
  // after First Steps (finished or skipped), due First Steps words come back from the Hyrule Field map
  await due(); await page.evaluate(() => window.__lqTest.set((s) => { s.es.fs.skipped = true; s.es.placed = true; })); await page.evaluate(() => window.__lqTest.go('lang', { lang: 'es' }));
  const mapRev = await page.waitForSelector('[data-testid=map-review]', { timeout: 8000 }).then(() => true).catch(() => false);
  await shot(page, `${vp}-grad-05-map-review`);
  if (mapRev) await click(page, '[data-testid=map-review]');
  const revOpen = await page.waitForSelector('[data-testid=fs-lesson-wrap] [data-testid=fs-tap], [data-testid=fs-lesson-wrap] [data-testid=fs-match]', { timeout: 8000 }).then(() => true).catch(() => false);
  ok(`${vp}: after First Steps, due First Steps words come back from the Hyrule Field map (⭐ Review)`, mapRev && revOpen, JSON.stringify({ mapRev, revOpen }));
  const once = await page.evaluate(() => FamilyWallet.events({ app: 'language', limit: 300 }).filter((e) => /^once:|firststeps|review/.test(String(e.tag || e.id || e.ref || e.reason || ''))).map((e) => (e.tag || e.id) + ':' + e.amount));
  ok(`${vp}: graduation — zero console errors`, errors.length === e0, errors.slice(e0, e0 + 3).join(' | ') || once.slice(0, 6).join(', '));
  await ctx.close();
}
async function firstStepsTest(vp, all) {
  const ctx = await newCtx(vp, false); const page = await ctx.newPage(); const e0 = errors.length; watch(page, vp + '-fs');
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
  await page.fill('[data-testid=nick]', 'Hero'); await click(page, '[data-testid=nick-ok]');
  await page.waitForSelector('[data-testid=door-es]'); await shot(page, `${vp}-fs-00-home`);
  const tHome = Date.now();
  await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=fs-start]'); await shot(page, `${vp}-fs-01-start`);
  await click(page, '[data-testid=fs-new]'); await page.waitForSelector('[data-testid=fs-path]'); await page.waitForTimeout(500); await shot(page, `${vp}-fs-02-path`);
  const glow = await page.locator('.fsnode.now').count(); const here = await page.locator('.fsnode.now .here').count();
  await click(page, '[data-testid=fs-node-1]');
  const l1 = await fsPlay(page, `${vp}-fs-l1`, { shots: false, typeBuild: true, useHelp: true });
  const secs1 = Math.round((Date.now() - tHome) / 1000);
  await page.waitForSelector('[data-testid=fs-path]'); await page.evaluate(() => window.__lqTest.set((s) => { s.settings.practice = true; })); await page.evaluate(() => window.__lqTest.go('lang', { lang: 'es' }));
  await page.waitForSelector('[data-testid=fs-path]'); await click(page, '[data-testid=fs-node-1]');
  await fsPlay(page, `${vp}-fs-l1`, { shots: true, typeBuild: true, useHelp: true });
  await page.evaluate(() => window.__lqTest.set((s) => { s.settings.practice = false; }));
  await page.waitForSelector('[data-testid=fs-path]'); await shot(page, `${vp}-fs-03-path-after-1`);
  const st1 = await page.evaluate(() => JSON.parse(localStorage.getItem('langQuest.state')).es.fs);
  ok(`${vp}: fresh beginner — Home → First Steps lesson 1 done in ${secs1}s (≤120 s), no mic; path with "You are here" and a glowing next step`, secs1 <= 120 && glow === 1 && here === 1 && st1.done && st1.done[0] >= 1 && l1.seen.includes('fs-win'), `steps: ${l1.seen.join(', ')}`);
  ok(`${vp}: help ladder (hear slowly → English → fewer choices → answer) and Type ↔ Choose`, l1.seen.includes('help-used') && l1.seen.includes('choose-mode') && l1.seen.includes('type-mode'));
  await click(page, '[data-testid=fs-node-2]');
  const first2 = await page.evaluate(() => document.querySelector('[data-testid=fs-lesson-wrap] .card[data-testid]') && document.querySelector('[data-testid=fs-lesson-wrap] .muted.small').textContent);
  await shot(page, `${vp}-fs-l2-00-review`);
  const l2 = await fsPlay(page, `${vp}-fs-l2`, { shots: false });
  ok(`${vp}: lesson 2 starts with 2 quick review items (spaced repetition)`, /Quick review/.test(first2 || '') && l2.seen.includes('fs-win'), first2 || '');
  if (all) {
    for (let n = 3; n <= 16; n++) {
      await page.waitForSelector('[data-testid=fs-path]'); await click(page, `[data-testid=fs-node-${n}]`);
      const r = await fsPlay(page, `${vp}-fs-l${n}`, { shots: n === 10 || n === 15 || n === 16, typeBuild: n === 10, accents: n === 10 });
      if (n === 10) ok(`${vp}: accent tiles — typed "mamá" with the á button`, r.seen.includes('accent-tiles'), r.seen.join(', '));
    }
    await page.waitForSelector('[data-testid=map]', { timeout: 10000 }).catch(() => {}); await shot(page, `${vp}-fs-99-after-champion-map`);
    const fin = await page.evaluate(() => { const s = JSON.parse(localStorage.getItem('langQuest.state')); return { done: Object.keys(s.es.fs.done || {}).length, champ: !!s.es.fs.champion, map: !!document.querySelector('[data-testid=map]'), secret: !!(s.treasure.found || {}).firststeps }; });
    ok(`${vp}: all 16 First Steps lessons complete → champion → the Hyrule Field map; "First Steps Champion" treasure`, fin.done === 16 && fin.champ && fin.map && fin.secret, JSON.stringify(fin));
  }
  ok(`${vp}: First Steps — zero console errors`, errors.length === e0, errors.slice(e0, e0 + 3).join(' | '));
  await ctx.close();
}

// ---- Family Wallet integration (family-wallet.js shared by all apps) ----
async function walletTest(vp) {
  const ctx = await newCtx(vp, false); const page = await ctx.newPage(); const e0 = errors.length; watch(page, vp + '-wallet');
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
  // an existing save with 37 unspent rupees, 2 waiting Skulltula tokens and an old shop item → migrated once
  await page.evaluate(() => { localStorage.clear(); localStorage.setItem('langQuest.state', JSON.stringify({ v: 3, nick: 'Hero', rupees: 37, shop: { owned: ['navi_pink'] }, treasure: { found: {}, tokens: 2, flags: {} }, es: { level: 'sprout', placed: true }, fa: { level: 'sprout', placed: true }, settings: { mix: 'es' }, setupDone: true })); });
  await page.goto(URL0); await page.waitForSelector('[data-testid=door-es]'); await page.waitForTimeout(800);
  const b0 = await page.evaluate(() => FamilyWallet.balance());
  const owned = await page.evaluate(() => FamilyWallet.owns('language.navi_pink'));
  await page.reload(); await page.waitForSelector('[data-testid=door-es]'); await page.waitForTimeout(500);
  const b1 = await page.evaluate(() => FamilyWallet.balance());
  ok(`${vp}: wallet migration once — 37 local rupees, 2 tokens and the pink Navi light moved; a reload does not move them again`, b0.rupees === 37 && owned && b1.rupees === 37 && (b0.language || 0) >= 2 && b1.language === b0.language, JSON.stringify({ rupees: b0.rupees, language: b0.language, again: b1.rupees }));
  const counter = await page.locator('[data-testid=fw-counter] .fw-counter').count();
  await shot(page, `${vp}-wallet-01-home`);
  // v7.3: First Steps step 1 → rupees for first-correct answers only; shards come per graduated GROUP (gradTest)
  await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=fs-path]'); await click(page, '[data-testid=fs-node-1]');
  await fsPlay(page, `${vp}-wallet-l1`, {});
  const b2 = await page.evaluate(() => FamilyWallet.balance());
  const ev = await page.evaluate(() => FamilyWallet.events({ app: 'language', limit: 50 }).map((e) => e.kind + ':' + e.amount));
  ok(`${vp}: finishing one First Steps step pays shared rupees for first-correct answers and no shards (shards come per graduated group of steps)`, b2.language === b1.language && b2.rupees >= b1.rupees + 3, `shards ${b1.language}→${b2.language}, rupees ${b1.rupees}→${b2.rupees}; events: ${ev.slice(0, 8).join(', ')}`);
  // a hidden Gold Skulltula (a find, not learning) → 10 rupees, no shard; a hero challenge (learning) → +1 shard once
  await page.evaluate(() => window.__lqTest.go('home')); await page.waitForTimeout(600);
  const before = await page.evaluate(() => FamilyWallet.balance());
  await page.locator('[data-secret=glint]').click({ force: true }); await page.waitForTimeout(600);
  const after = await page.evaluate(() => FamilyWallet.balance());
  const ch = await page.evaluate(() => { const b0 = FamilyWallet.balance().language; window.__lqTest.set((s) => { s.treasure.flags.helpfinish = 1; }); return b0; });
  await page.evaluate(() => window.__lqTest.go('lang', { lang: 'es' })); await page.waitForTimeout(400); await page.evaluate(() => window.__lqTest.go('home')); await page.waitForTimeout(900);
  const ch1 = await page.evaluate(() => FamilyWallet.balance().language);
  ok(`${vp}: a hidden Gold Skulltula pays 10 rupees (finding isn't learning, no shard); a hero challenge ("Never Give Up") pays +1 Courage shard once`, after.language === before.language && after.rupees === before.rupees + 10 && ch1 === ch + 1, `find: shards ${before.language}→${after.language}, rupees ${before.rupees}→${after.rupees}; challenge: ${ch}→${ch1}`);
  // top-bar mini Triforce → Treasure Wallet (Secrets tab = House of Skulltula) → Hyrule Market (buy with shared rupees)
  await page.locator('[data-testid=fw-counter] .fw-counter').first().click(); await page.waitForSelector('[data-testid=fw-wallet] .fw-root, [data-testid=fw-wallet] *', { timeout: 8000 });
  await page.waitForTimeout(600); await shot(page, `${vp}-wallet-02-wallet`);
  const secretsTab = page.locator('[data-testid=fw-wallet] button', { hasText: /Skulltula|Secret|Beetle/i }).first();
  let secretsOk = false; if (await secretsTab.count()) { await secretsTab.click(); await page.waitForTimeout(700); secretsOk = (await page.locator('[data-testid=fw-wallet] [data-testid=treasure]').count()) > 0; await shot(page, `${vp}-wallet-03-secrets`); }
  await page.evaluate(() => window.__lqTest.go('market', { lang: 'es' })); await page.waitForTimeout(900); await shot(page, `${vp}-wallet-04-market`);
  const marketOk = await page.locator('[data-testid=fw-market] *').count();
  const buy = await page.evaluate(() => { const r = FamilyWallet.buy('language.tunic_red'); return { r, owns: FamilyWallet.owns('language.tunic_red'), bal: FamilyWallet.balance().rupees }; });
  // parent corner → Rewards shows the wallet's parent panel (after the PIN)
  await page.evaluate(() => { window.__LQ_TEST__ = { unlock: true }; window.__lqTest.go('parent'); }); await page.waitForTimeout(700);
  if (await page.locator('[data-testid=tab-rewards]').count()) { await page.locator('[data-testid=tab-rewards]').click(); await page.waitForTimeout(700); }
  const parentOk = await page.locator('[data-testid=fw-parent] *').count();
  await shot(page, `${vp}-wallet-05-parent`);
  ok(`${vp}: wallet UI — counter in the top bar, Treasure Wallet with our Secrets tab, Hyrule Market (bought the red tunic with shared rupees), Parent → Rewards`, counter > 0 && secretsOk && marketOk > 0 && buy.r.ok && buy.owns && parentOk > 0, JSON.stringify({ counter, secretsOk, marketOk, buy: buy.r, parentOk }));
  ok(`${vp}: wallet — zero console errors`, errors.length === e0, errors.slice(e0, e0 + 3).join(' | '));
  await ctx.close();
}

// ---- Family Sync e2e: the real Code.gs on the mock backend, a grown-up laptop and his laptop (two browser contexts) ----
async function syncTest() {
  const { startMock } = await import('./sync/tools/mock-server.mjs');
  const mock = await startMock({}); globalThis.__SYNC_ENDPOINT = mock.endpoint;
  const e0 = errors.length;
  const pin = async (page, digits) => { await page.waitForSelector('[data-testid=pinpad]'); for (const d of digits) await click(page, `[data-testid=pin-${d}]`); };
  const openParent = async (page, digits) => { await page.evaluate(() => window.__lqTest.go('parent')); await pin(page, digits); };
  // his progress key as stored in the family backend (the grown-up's mirror holds only the family keys and summaries)
  const cloud = (key) => { const rows = mock.app().shim.sheetRows('data'); const r = rows.find((x) => x[0] === key); if (!r) return null; const n = Number(r[7]) || 0; let v = ''; for (let i = 0; i < n; i++) { const part = String(r[8 + i] == null ? '' : r[8 + i]); v += part.charAt(0) === '~' ? part.slice(1) : part; } try { return JSON.parse(v); } catch (e) { return null; } };
  const mirror = (page) => page.evaluate(async () => { await FamilySync.syncNow().catch(() => {}); const m = FamilySync.mirror(); const st = m.items['langQuest.state']; const sm = m.items['familyApps.summary.language.v1']; const tk = m.items['familyApps.tickets.v1']; return { state: st ? st.raw : null, summary: sm ? sm.value : null, tickets: tk ? tk.value : null }; });
  // (e) NOT connected: today's app, plus only the small Connect card; no sync keys, no network
  const N = await newCtx('desktop', false); const pn = await N.newPage(); watch(pn, 'sync-notconnected');
  const req0 = mock.stats.requests;
  await pn.goto(URL0); await pn.waitForSelector('[data-testid=welcome]'); await pn.fill('[data-testid=nick]', 'Hero'); await click(pn, '[data-testid=nick-ok]');
  await click(pn, '[data-testid=door-es]'); await click(pn, '[data-testid=fs-new]'); await click(pn, '[data-testid=fs-node-1]'); await fsPlay(pn, 'sync-n-l1', {});
  await click(pn, '[data-testid=back]').catch(() => {}); await pn.goto(URL0); await click(pn, '[data-testid=parent-btn]'); await pin(pn, '0000'); await pin(pn, '2468'); await pin(pn, '2468');
  await pn.waitForSelector('[data-testid=setup]'); await click(pn, '[data-testid=setup-done]'); await pn.waitForSelector('[data-testid=parent]');
  await click(pn, '[data-testid=tab-settings]'); await pn.waitForSelector('[data-testid=family-sync] .fs-connect'); await shot(pn, 'sync-e-notconnected-settings');
  const nState = await pn.evaluate(() => ({ keys: Object.keys(localStorage).filter((k) => k.startsWith('familyApps.sync.')), st: FamilySync.status().state, dot: (document.querySelector('[data-testid=sync-dot]') || {}).innerText || '', changePin: !!document.querySelector('[data-testid=pin-hub]'), connectText: (document.querySelector('.fs-connect') || {}).innerText || '' }));
  ok('sync (e): not connected — app unchanged (first-visit PIN change, lesson), only the Connect card is new; no familyApps.sync.* keys, no network, status "off"', nState.keys.length === 0 && nState.st === 'off' && !nState.dot.trim() && !nState.changePin && /Connect this laptop/.test(nState.connectText) && mock.stats.requests === req0, JSON.stringify({ ...nState, requests: mock.stats.requests - req0 }));
  await N.close();
  // grown-up laptop: create the family, set the PIN, rewards (+ wallet costs) and look in the Hub
  const G = await newCtx('desktop', false); const pg = await G.newPage(); watch(pg, 'sync-grownup');
  await pg.goto(URL0); await pg.waitForSelector('[data-testid=welcome]');
  const code = await pg.evaluate(async (endpoint) => {
    await FamilySync.createFamily({ endpoint });
    await FamilySync.setPin('2468');
    FamilySync.setSetting('familyApps.rewards.v1', { version: 1, enabled: true, tokensPerTicket: 3, weeklyCap: 5, updatedAt: new Date().toISOString(),
      rewards: [{ id: 'bike', emoji: '🚲', text: 'Bike ride with Dad' }, { id: 'youtube', emoji: '📺', text: '15 minutes of YouTube' }], wallet: { appsInSet: ['language'], perApp: { language: 3 } } });
    FamilySync.setSetting('familyApps.look.v1', { v: 1, skin: 'grove' });
    await FamilySync.syncNow();
    return (await FamilySync.pairCreate()).code;
  }, mock.endpoint);
  await pg.reload(); await pg.waitForSelector('[data-testid=welcome]'); await pg.waitForTimeout(600);
  const banner = await pg.locator('.fs-practice').innerText().catch(() => '');
  await shot(pg, 'sync-grownup-practice-banner');
  // his laptop: some progress and a local PIN first, then connect with the 6-character code in Parent corner → Settings
  const K = await newCtx('desktop', false); const pk = await K.newPage(); watch(pk, 'sync-kid');
  await pk.goto(URL0); await pk.waitForSelector('[data-testid=welcome]'); await pk.fill('[data-testid=nick]', 'Hero'); await click(pk, '[data-testid=nick-ok]');
  await click(pk, '[data-testid=door-es]'); await click(pk, '[data-testid=fs-new]'); await click(pk, '[data-testid=fs-node-1]'); await fsPlay(pk, 'sync-k-l1', {});
  await pk.evaluate(async () => { await window.__lqTest.setPin('1357'); window.__lqTest.set((s) => { s.setupDone = true; }); });
  await openParent(pk, '1357'); await pk.waitForSelector('[data-testid=parent]'); await click(pk, '[data-testid=tab-settings]');
  await pk.waitForSelector('.fs-connect input'); await shot(pk, 'sync-kid-connect-card');
  await pk.fill('.fs-connect input', code); await pk.locator('.fs-connect button').click();
  await pk.waitForFunction(() => FamilySync.isConnected() && FamilySync.role() === 'kid', null, { timeout: 30000 });
  await pk.waitForTimeout(1500); await shot(pk, 'sync-kid-connected');
  // (a) the grown-up's PIN, rewards and look are on his laptop
  await pk.evaluate(() => window.__lqTest.go('home')); await pk.waitForTimeout(600);
  await pk.evaluate(() => window.__lqTest.go('parent')); await pin(pk, '1357'); await pk.waitForTimeout(400);
  const localRefused = (await pk.locator('[data-testid=parent]').count()) === 0;
  await pk.evaluate(() => window.__lqTest.go('home')); await openParent(pk, '2468'); await pk.waitForSelector('[data-testid=parent]');
  await click(pk, '[data-testid=tab-rewards]'); const hub = await pk.locator('[data-testid=hub-line]').count(); await shot(pk, 'sync-kid-rewards-hub');
  await click(pk, '[data-testid=tab-settings]'); const lookHub = await pk.locator('[data-testid=look-hub]').count(); const pinHub = await pk.locator('[data-testid=pin-hub]').count();
  const dot = await pk.locator('[data-testid=sync-dot]').innerText(); await shot(pk, 'sync-kid-settings-dot');
  const a = await pk.evaluate(() => ({ skin: window.__lqSkin(), stored: window.__lqTest.get().settings.skinSel, rewards: FamilyWallet.rewards().list.map((r) => r.text), sync: Object.keys(localStorage).filter((k) => k.startsWith('familyApps.sync.')).length }));
  ok('sync (a): the grown-up\'s family PIN (local PIN refused), rewards and look (Starlit Grove) arrive on his laptop; Rewards/Look/PIN show "Set in the Family Hub"; practice-copy banner on the grown-up laptop',
    localRefused && hub === 1 && lookHub === 1 && pinHub === 1 && a.skin === 'fallback' && a.rewards.includes('Bike ride with Dad') && /practice copy/.test(banner) && /synced|connected|saving/.test(dot), JSON.stringify({ localRefused, hub, lookHub, pinHub, a, banner, dot }));
  // (b) his progress and the weekly summary land in the grown-up's mirror
  await pk.evaluate(() => window.__lqTest.go('lang', { lang: 'es' })); await click(pk, '[data-testid=fs-node-2]'); await fsPlay(pk, 'sync-k-l2', {});
  await pk.evaluate(async () => { await FamilySync.syncNow(); });
  const m1 = await mirror(pg);
  const st1 = cloud('langQuest.state');
  const mw = await pg.evaluate(() => { const it = FamilySync.mirror().items['familyApps.wallet.v1']; return it && it.value ? (it.value.events || []).filter((e) => e.app === 'language' && e.kind === 'rupee').reduce((n, e) => n + (e.amount || 0), 0) : 0; });
  ok('sync (b): his progress (First Steps steps 1–2) reaches the family backend; the grown-up mirror gets his summary (lessons, words, level) and wallet', !!st1 && Object.keys(st1.es.fs.done || {}).length >= 2 && !!m1.summary && m1.summary.week.lessons >= 1 && m1.summary.total.words.es > 0 && m1.summary.total.level === 'First Steps' && mw > 0,
    JSON.stringify({ fs: st1 && Object.keys(st1.es.fs.done || {}).length, walletEarned: mw, summary: m1.summary && { week: m1.summary.week, total: m1.summary.total } }));
  // (c) a ticket approved and a ± adjust by the grown-up are applied exactly once on his laptop
  const tk = await pk.evaluate(async () => { const b = FamilyWallet.balance(); if ((b.language || 0) < 3) FamilyWallet.earn('language', 'progress', 3, 'test shards'); const r = FamilyWallet.claim('bike', 'language'); await FamilySync.syncNow(); return { r, list: FamilyWallet.tickets().map((t) => ({ id: t.id, status: t.status, rewardId: t.rewardId })) }; });
  const ticket = (tk.list || []).find((t) => t.rewardId === 'bike');
  const m2 = await mirror(pg);
  const seen = (m2.tickets || []).some((t) => ticket && t.id === ticket.id);
  await pg.evaluate(async (tid) => { FamilySync.request('approve', { ticketId: tid }); FamilySync.request('adjust', { app: 'language', amount: 2, reason: 'Great job' }); await new Promise((r) => setTimeout(r, 400)); await FamilySync.syncNow(); }, ticket && ticket.id);
  const before = await pk.evaluate(() => FamilyWallet.balance().language);
  for (let i = 0; i < 3; i++) await pk.evaluate(async () => { await FamilySync.syncNow(); });
  await pk.reload(); await pk.waitForSelector('[data-testid=door-es]'); await pk.waitForTimeout(800);
  for (let i = 0; i < 2; i++) await pk.evaluate(async () => { await FamilySync.syncNow(); });
  const c = await pk.evaluate((tid) => ({ bal: FamilyWallet.balance().language, adj: FamilyWallet.events({ app: 'language', limit: 200 }).filter((e) => e.kind === 'adjust').length, t: (FamilyWallet.tickets().find((x) => x.id === tid) || {}).status }), ticket && ticket.id);
  ok('sync (c): an approved ticket and a +2 adjust from the grown-up are applied exactly once (after repeated syncs and a reload)', !!ticket && seen && c.t === 'used' && c.adj === 1 && c.bal === before + 2,
    JSON.stringify({ ticket: ticket && ticket.id, seen, before, after: c }));

  // (d) offline: he keeps learning, the dot says "offline · saved here"; online again: everything arrives, nothing doubles
  await K.setOffline(true);
  await pk.evaluate(() => window.__lqTest.go('lang', { lang: 'es' })); await click(pk, '[data-testid=fs-node-3]'); await fsPlay(pk, 'sync-k-l3', {});
  await pk.evaluate(async () => { await FamilySync.syncNow().catch(() => {}); });
  await openParent(pk, '2468'); await pk.waitForSelector('[data-testid=parent]'); await click(pk, '[data-testid=tab-settings]'); await pk.waitForTimeout(500);
  const offDot = await pk.locator('[data-testid=sync-dot]').innerText(); const offState = await pk.evaluate(() => FamilySync.status().state);
  await shot(pk, 'sync-kid-offline-dot');
  await K.setOffline(false);
  await pk.evaluate(async () => { await FamilySync.syncNow(); await FamilySync.syncNow(); });
  const m3 = await mirror(pg); const st3 = cloud('langQuest.state');
  const c2 = await pk.evaluate(() => ({ adj: FamilyWallet.events({ app: 'language', limit: 200 }).filter((e) => e.kind === 'adjust').length }));
  ok('sync (d): offline → keeps working, dot "offline · saved here"; back online → step 3 reaches the grown-up, the adjust is still applied once', /offline/.test(offDot) && !!st3 && Object.keys(st3.es.fs.done || {}).length >= 3 && c2.adj === 1, JSON.stringify({ offDot, offState, fs: st3 && Object.keys(st3.es.fs.done || {}).length, adj: c2.adj }));
  // sync paused: if his save were ever too big for the family backend, the app keeps working and the dot says so
  await pk.evaluate(() => { const raw = localStorage.getItem('langQuest.state'); const o = JSON.parse(raw); o.padding = 'x'.repeat(310000); localStorage.setItem('langQuest.state', JSON.stringify(o)); });
  await pk.evaluate(async () => { await FamilySync.syncNow().catch(() => {}); });
  const paused = await pk.waitForSelector('[data-testid=sync-paused]', { timeout: 8000 }).then(() => true).catch(() => false);
  await shot(pk, 'sync-kid-paused-dot');
  await pk.evaluate(() => window.__lqTest.go('home')); const works = await pk.waitForSelector('[data-testid=door-es]', { timeout: 5000 }).then(() => true).catch(() => false);
  ok('sync: a save too big to sync → the app still works here and the Parent corner shows "☁ sync paused"', paused && works, JSON.stringify({ paused, works }));

  // FOUND 2: a second laptop of his connects while a settings update (look) arrives in the same pull: his cloud progress
  // must survive byte-identical (the new laptop must never save its stale in-memory copy over the downloaded one)
  const rawCloud = (key) => { const rows = mock.app().shim.sheetRows('data'); const r = rows.find((x) => x[0] === key); if (!r) return null; const n = Number(r[7]) || 0; let v = ''; for (let i = 0; i < n; i++) { const part = String(r[8 + i] == null ? '' : r[8 + i]); v += part.charAt(0) === '~' ? part.slice(1) : part; } return v; };
  await pk.evaluate(async () => { localStorage.setItem('langQuest.state', localStorage.getItem('langQuest.state').replace(/,"padding":"x+"/, '')); });
  await pk.reload(); await pk.waitForSelector('[data-testid=door-es]'); await pk.evaluate(async () => { await FamilySync.syncNow().catch(() => {}); });
  const cloudBefore = rawCloud('langQuest.state');
  const code2 = await pg.evaluate(async () => { FamilySync.setSetting('familyApps.look.v1', { v: 1, skin: 'hyrule' }); await new Promise((r) => setTimeout(r, 400)); await FamilySync.syncNow(); return (await FamilySync.pairCreate()).code; });
  const K2 = await newCtx('desktop', false); const p2 = await K2.newPage(); watch(p2, 'sync-kid2');
  await p2.goto(URL0); await p2.waitForSelector('[data-testid=welcome]'); await p2.fill('[data-testid=nick]', 'Hero'); await click(p2, '[data-testid=nick-ok]');
  await p2.evaluate(async () => { await window.__lqTest.setPin('1357'); window.__lqTest.set((s) => { s.setupDone = true; s.es.placed = true; }); });
  await openParent(p2, '1357'); await p2.waitForSelector('[data-testid=parent]'); await click(p2, '[data-testid=tab-settings]'); await p2.waitForSelector('.fs-connect input');
  await p2.fill('.fs-connect input', code2); await p2.locator('.fs-connect button').click();
  await p2.waitForFunction(() => FamilySync.isConnected() && FamilySync.role() === 'kid', null, { timeout: 30000 }); await p2.waitForTimeout(2500);
  await p2.evaluate(async () => { await FamilySync.syncNow().catch(() => {}); await FamilySync.syncNow().catch(() => {}); });
  await p2.waitForTimeout(1500);
  const f2 = await p2.evaluate(() => ({ local: localStorage.getItem('langQuest.state'), fs: Object.keys((window.__lqTest.get().es.fs || {}).done || {}).length, skin: window.__lqSkin() }));
  const cloudAfter = rawCloud('langQuest.state');
  await shot(p2, 'sync-kid2-after-connect');
  ok('sync FOUND 2: a second laptop of his connects while a look update arrives in the same pull — his cloud progress survives byte-identical, the new laptop shows it (First Steps steps) and the new look',
    !!cloudBefore && cloudAfter === cloudBefore && f2.local === cloudBefore && f2.fs >= 3 && f2.skin === 'hyrule', JSON.stringify({ before: cloudBefore && cloudBefore.length, after: cloudAfter && cloudAfter.length, same: cloudAfter === cloudBefore, localSame: f2.local === cloudBefore, fs: f2.fs, skin: f2.skin }));
  // v7.3 / sync 1.1 — nothing writes his progress at load on an idle laptop
  const idle0 = await p2.evaluate(() => localStorage.getItem('langQuest.state')); const cIdle0 = rawCloud('langQuest.state');
  await p2.reload(); await p2.waitForSelector('[data-testid=door-es]'); await p2.waitForTimeout(6000);
  const idle1 = await p2.evaluate(() => localStorage.getItem('langQuest.state'));
  ok('sync 1.1: nothing writes his progress at load — an idle laptop\'s langQuest.state and the cloud copy stay byte-identical after a reload + 6 s', idle0 === idle1 && rawCloud('langQuest.state') === cIdle0, JSON.stringify({ same: idle0 === idle1, len: idle1 && idle1.length }));
  // sync 1.1 — he plays on laptop A, then laptop B pulls: B re-reads at a calm moment and shows A's progress (never saves its old copy over it)
  await pk.evaluate(() => window.__lqTest.go('lang', { lang: 'es' })); await pk.waitForSelector('[data-testid=fs-path]');
  await click(pk, '[data-testid=fs-node-4]'); await fsPlay(pk, 'sync-k-l4', {}); await pk.evaluate(async () => { await FamilySync.syncNow(); });
  await p2.evaluate(() => window.__lqTest.go('home'));
  await p2.evaluate(async () => { await FamilySync.syncNow().catch(() => {}); }); await p2.waitForTimeout(1200);
  const pullB = await p2.evaluate(() => ({ g4: !!((window.__lqTest.get().es.fs || {}).grad || {})[3], ls: !!((JSON.parse(localStorage.getItem('langQuest.state')).es.fs || {}).grad || {})[3] }));
  const cl4 = cloud('langQuest.state');
  await p2.evaluate(() => window.__lqTest.go('lang', { lang: 'es' })); await p2.waitForSelector('[data-testid=fs-path]'); await shot(p2, 'sync-kid2-pulled-step4');
  const g4ui = await p2.locator('[data-testid=fs-grad-4]').count();
  ok('sync 1.1: he plays step 4 on laptop A; laptop B pulls and re-reads at a calm moment — B shows step 4 graduated 🎓, and the cloud keeps it', pullB.g4 && pullB.ls && g4ui === 1 && !!(cl4 && cl4.es.fs.grad && cl4.es.fs.grad[3]), JSON.stringify({ pullB, g4ui }));
  // v7.3 — both laptops offline graduate the same group ("Numbers": steps 5–6); online again, the shards count ONCE
  const balA0 = await pk.evaluate(() => FamilyWallet.balance().language);
  await K.setOffline(true); await K2.setOffline(true);
  for (const [pg_, tag] of [[pk, 'A'], [p2, 'B']]) {
    await pg_.evaluate(() => window.__lqTest.go('lang', { lang: 'es' })); await pg_.waitForSelector('[data-testid=fs-path]');
    for (const n of [5, 6]) { await click(pg_, `[data-testid=fs-node-${n}]`); const r = await fsPlay(pg_, `sync-once-${tag}-l${n}`, {}); if (n === 6) ok(`sync once: laptop ${tag} (offline) graduates step 6 → group "Numbers" complete → +2 shards here`, !!r.win && /\+2 Courage/.test(r.win.pay || ''), JSON.stringify(r.win)); await pg_.evaluate(() => window.__lqTest.go('lang', { lang: 'es' })); }
  }
  const offA = await pk.evaluate(() => FamilyWallet.balance().language); const offB = await p2.evaluate(() => FamilyWallet.balance().language);
  await K.setOffline(false); await K2.setOffline(false);
  for (let k = 0; k < 2; k++) { await pk.evaluate(async () => { await FamilySync.syncNow().catch(() => {}); }); await p2.evaluate(async () => { await FamilySync.syncNow().catch(() => {}); }); }
  await pk.evaluate(async () => { await FamilySync.syncNow().catch(() => {}); });
  const onceA = await pk.evaluate(() => ({ bal: FamilyWallet.balance().language, n: FamilyWallet.events({ app: 'language', limit: 1000 }).filter((e) => e.id === 'once:language:firststeps:group-count:pass').length }));
  const onceB = await p2.evaluate(() => ({ bal: FamilyWallet.balance().language, n: FamilyWallet.events({ app: 'language', limit: 1000 }).filter((e) => e.id === 'once:language:firststeps:group-count:pass').length }));
  const mwOnce = await pg.evaluate(async () => { await FamilySync.syncNow().catch(() => {}); const it = FamilySync.mirror().items['familyApps.wallet.v1']; const ev = (it && it.value && it.value.events) || []; return ev.filter((e) => e.id === 'once:language:firststeps:group-count:pass').length; });
  ok('sync once: two laptops paid the same pass offline (+2 each); after syncing, the group counts ONCE on both laptops and in the grown-up mirror (balance +2, not +4)',
    offA === balA0 + 2 && onceA.n === 1 && onceB.n === 1 && onceA.bal === onceB.bal && onceA.bal === balA0 + 2 && mwOnce === 1, JSON.stringify({ balA0, offA, offB, onceA, onceB, mwOnce }));
  await shot(p2, 'sync-kid2-once-merged');
  await K2.close();
  ok(`sync: zero console errors; ${mock.stats.preflights} CORS preflights (must be 0)`, errors.length === e0 && mock.stats.preflights === 0, errors.slice(e0, e0 + 4).join(' | '));
  await G.close(); await K.close(); await mock.close(); globalThis.__SYNC_ENDPOINT = null;
}
async function sandboxTest() {
  // exactly the Meta artifact viewer's iframe: sandbox without allow-same-origin (opaque origin: storage/IDB/SW throw)
  const ctx = await newCtx('desktop', true); const page = await ctx.newPage();
  const e0 = errors.length; watch(page, 'sandbox');
  await page.goto(URL0 + 'viewer/x/__viewer.html');
  const fr = page.frameLocator('iframe');
  await fr.locator('[data-testid=welcome]').waitFor({ timeout: 20000 });
  const note = await fr.locator('[data-testid=preview-note]').count();
  await fr.locator('[data-testid=nick]').fill('Hero'); await fr.locator('[data-testid=nick-ok]').click();
  await fr.locator('[data-testid=door-fa]').waitFor({ timeout: 8000 });
  await page.waitForTimeout(2500);
  const kitImgs = await fr.locator('img[src^="blob:"]').count();
  await shot(page, 'sandbox-01-home');
  await fr.locator('[data-testid=door-fa]').click(); await fr.locator('[data-testid=pl-start]').click(); await page.waitForTimeout(2500);
  await shot(page, 'sandbox-02-fa-placement');
  const overlay = await fr.locator('#lq-diag').count();
  const audioOk = await fr.locator('body').evaluate(async () => { const has = () => !!(window.__lqPack && Object.keys(window.__lqPack).some((k) => k.startsWith('fa-'))); for (let i = 0; i < 40 && !has(); i++) await new Promise((r) => setTimeout(r, 250)); return has(); });
  ok('artifact-viewer emulation (opaque srcdoc iframe, static refs only): boots, preview note, kit art, audio packs, no errors', note > 0 && kitImgs > 0 && !overlay && audioOk && errors.length === e0, `kit images: ${kitImgs}, audio pack: ${audioOk}, overlay: ${overlay}`);
  await ctx.close();
}

// ---- run ----
const t0 = Date.now();
if (process.env.ONLY === 'phone') {
  const p = await walkthrough('phone', false); await parentCorner(p.page, 'phone', p.ctx); await p.ctx.close();
  await browser.close(); srv.close();
  if (!results.some((r) => /no broken images/.test(r.name))) imgSummary(process.env.ONLY || 'all');
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
await sandboxTest();
if (process.env.ONLY === 'swupdate') {
  // an updated app.js must be picked up on reload (network-first), not served from the old cache. Run on a COPY of the dist.
  const ctx = await newCtx('desktop', true); const page = await ctx.newPage(); watch(page, 'swupdate');
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
  const ctl = await page.evaluate(async () => { const r = await navigator.serviceWorker.ready; for (let i = 0; i < 40 && !navigator.serviceWorker.controller; i++) await new Promise((x) => setTimeout(x, 250)); return !!navigator.serviceWorker.controller; });
  if (!ctl) { await page.reload(); await page.waitForSelector('[data-testid=welcome]'); }
  const cacheName = await page.evaluate(async () => (await caches.keys()).join(','));
  fs.appendFileSync(path.join(DIST, 'app.js'), '\nwindow.__lqMarker=2;\n');
  await page.reload(); await page.waitForSelector('[data-testid=welcome]');
  const marker = await page.evaluate(() => window.__lqMarker || 0);
  await ctx.setOffline(true); await page.reload(); await page.waitForSelector('[data-testid=welcome]', { timeout: 15000 }).catch(() => {});
  const offlineOk = await page.locator('[data-testid=welcome]').count();
  ok('service worker: an updated app.js is used on the next reload (network-first), and the page still opens offline', marker === 2 && offlineOk > 0 && /langQuest-v7-/.test(cacheName), `cache: ${cacheName}; marker: ${marker}; offline: ${offlineOk}`);
  await ctx.close(); await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'offline') {
  const ctx = await newCtx('desktop', true); const page = await ctx.newPage(); watch(page, 'offline');
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
  await page.evaluate(() => localStorage.setItem('langQuest.state', JSON.stringify({ v: 3, nick: 'Hero', es: { level: 'sprout', placed: true, fs: { skipped: true } }, fa: { level: 'sprout', placed: true }, settings: { mix: 'es' }, setupDone: true })));
  await page.goto(URL0); await page.waitForSelector('[data-testid=door-es]');
  await offline(ctx, page, 'desktop');
  await ctx.close(); await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'fs') {
  await firstStepsTest('desktop', true);
  await firstStepsTest('phone', !!process.env.FS_ALL_PHONE);
  imgSummary('fs');
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'wallet') {
  await walletTest('desktop'); await walletTest('phone');
  imgSummary('wallet');
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'treasure') {
  // the Secret Treasures flow at both sizes (fresh profile, rewards on)
  for (const vp of ['desktop', 'phone']) {
    const ctx = await newCtx(vp, true); const page = await ctx.newPage(); watch(page, vp + '-treasure');
    await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
    await page.evaluate(() => localStorage.setItem('langQuest.state', JSON.stringify({ v: 3, nick: 'Hero', es: { level: 'sprout', placed: true, fs: { skipped: true } }, fa: { level: 'sprout', placed: true }, settings: { mix: 'es' }, setupDone: true })));
    await page.goto(URL0); await page.waitForSelector('[data-testid=door-es]');
    await treasureTest(page, vp);
    await ctx.close();
  }
  imgSummary('treasure');
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'imgnew') {
  const T = { a: [URL0 + 'language-quest/', {}], 'a-phone': [URL0 + 'language-quest/', { vp: 'phone' }], b: ['file://' + path.join(DIST, 'index.html'), {}], 'b-phone': ['file://' + path.join(DIST, 'index.html'), { vp: 'phone' }], c: [URL0 + 'viewer/x/__viewer.html', { frame: true, dist: false }], 'c-phone': [URL0 + 'viewer/x/__viewer.html', { frame: true, dist: false, vp: 'phone' }] };
  for (const k of (process.env.TOURS || 'a,a-phone,b,b-phone,c,c-phone').split(',')) await imageTour('v6-' + k, T[k][0], { ...T[k][1], only: 'new' });
  imgSummary('imgnew ' + (process.env.TOURS || 'all'));
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'esphone') {
  const ctx = await newCtx('phone', false); const page = await ctx.newPage(); watch(page, 'esphone');
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
  await page.fill('[data-testid=nick]', 'Hero'); await click(page, '[data-testid=nick-ok]');
  await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=fs-start]'); await click(page, '[data-testid=fs-test-start]');
  await click(page, '[data-testid=pl-new]'); await click(page, '[data-testid=pl-accept]');
  await page.waitForSelector('[data-testid=map], [data-testid=fs-path]'); if (await page.locator('[data-testid=fs-path]').count()) await click(page, '[data-testid=fs-skip]');
  await click(page, '[data-testid=start-quest]'); const q = await playCards(page, 'esphone-es');
  ok('esphone: Spanish quest (phone, no recognition)', true, q.seen.join(', '));
  await ctx.close(); await browser.close(); srv.close();
  console.log(`errors: ${errors.length}`); errors.forEach((e) => console.log('  ' + e)); process.exit(0);
}
if (process.env.ONLY === 'parent404') {
  for (const vp of ['phone', 'desktop']) {
    const ctx = await newCtx(vp, false); const page = await ctx.newPage(); watch(page, 'p404-' + vp);
    await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
    await page.fill('[data-testid=nick]', 'Hero'); await click(page, '[data-testid=nick-ok]'); await page.waitForSelector('[data-testid=door-es]');
    await parentCorner(page, vp + '-p404', ctx);
    await ctx.close();
  }
  await browser.close(); srv.close();
  console.log(`errors: ${errors.length}`); errors.forEach((e) => console.log('  ' + e)); process.exit(0);
}
if (process.env.ONLY === 'grad') {
  await gradTest('desktop'); await gradTest('phone');
  imgSummary('grad');
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'sync') {
  await syncTest();
  imgSummary('sync');
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'imgab') {
  await imageTour('a-subpath', URL0 + 'language-quest/');
  await imageTour('a-subpath-phone', URL0 + 'language-quest/', { vp: 'phone' });
  await imageTour('b-file', 'file://' + path.join(DIST, 'index.html'));
  imgSummary('imgab');
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'imgc') {
  await imageTour('c-viewer', URL0 + 'viewer/x/__viewer.html', { frame: true, dist: false });
  imgSummary('imgc');
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'images') {
  await imageTour('a-subpath', URL0 + 'language-quest/');
  await imageTour('a-subpath-phone', URL0 + 'language-quest/', { vp: 'phone' });
  await imageTour('b-file', 'file://' + path.join(DIST, 'index.html'));
  await imageTour('c-viewer', URL0 + 'viewer/x/__viewer.html', { frame: true, dist: false });
  imgSummary('images');
  await browser.close(); srv.close();
  if (!results.some((r) => /no broken images/.test(r.name))) imgSummary(process.env.ONLY || 'all');
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'desktop2') {
  // the parts that changed in the fix round: power phrases (+ whitelist check), shop, songbook, ocarina, parent corner, offline
  const ctx = await newCtx('desktop', true); const page = await ctx.newPage(); watch(page, 'desktop');
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
  await page.evaluate(() => { const L = (extra) => Object.assign({ level: 'sprout', placed: true, srs: {}, units: {}, quests: 0, mistakes: {}, speak: { tries: 0, good: 0 }, writing: [], weekly: {}, songs: {}, comeback: [], script: { step: 0, done: {} } }, extra);
    localStorage.setItem('langQuest.state', JSON.stringify({ v: 3, nick: 'Hero', rupees: 0, hc: 0, chests: 0, toys: { ocarina: false }, shop: { owned: [] }, secrets: {}, reports: [], settings: { mix: 'es' }, es: L({ units: { 1: { done: true, hp: 0 } } }), fa: L({}) })); });
  await page.goto(URL0); await page.waitForSelector('[data-testid=door-es]');
  await speedAndTriplets(page, 'desktop'); await extras(page, 'desktop'); await parentCorner(page, 'desktop', ctx); await offline(ctx, page, 'desktop');
  await ctx.close(); await browser.close(); srv.close();
  if (!results.some((r) => /no broken images/.test(r.name))) imgSummary(process.env.ONLY || 'all');
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'viewer') { await browser.close(); srv.close(); console.log(errors.join('\n')); process.exit(results.every((r) => r.pass) ? 0 : 1); }
const d = await walkthrough('desktop', true);
if (process.env.ONLY === 'quick') { imgSummary('quick'); await d.ctx.close(); await browser.close(); srv.close(); fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors }, null, 1)); console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e)); process.exit(0); }
await bossWin(d.page, 'desktop');
await speedAndTriplets(d.page, 'desktop');
await extras(d.page, 'desktop');
await parentCorner(d.page, 'desktop', d.ctx);
await offline(d.ctx, d.page, 'desktop');
await d.ctx.close();
// phone: no speech recognition (record-and-compare + self-check), iPhone size
const p = await walkthrough('phone', false);
await parentCorner(p.page, 'phone', p.ctx);
await p.ctx.close();
imgSummary('all');
await browser.close(); srv.close();
const fails = results.filter((r) => !r.pass);
fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
console.log(`\n${results.length - fails.length}/${results.length} checks passed; console errors: ${errors.length}`);
errors.slice(0, 20).forEach((e) => console.log('  ' + e));
process.exit(fails.length || errors.length ? 1 : 0);
