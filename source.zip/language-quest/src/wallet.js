// Family Wallet bridge: family-wallet.js (shared, copied byte-identical; never edited) + this app's hooks.
// Courage shards for Language Quest; rupees are shared by all the family apps.
import './family-wallet.js';
import { on } from './hooks.js';
import { KITIDX } from './packs.js';
import { checkPin, pinIsSet } from './store.js';
import { effectiveSkin } from './sync.js';
export const FW = globalThis.FamilyWallet || null;
export const APP = 'language';
let lessonId = 'language';
export const setLesson = (id) => { lessonId = 'language:' + id; };
// kit picture for a catalog kit id (e.g. "saria_bust_curious", "kokiri_16x9", "medallion_fire"): the largest size we ship
export function imageFor(kitId) {
  const H = globalThis.HyruleKit; if (!H || !kitId) return null;
  let best = null, bestN = 0;
  for (const p of Object.keys((KITIDX && KITIDX.files) || {})) {
    const base = p.split('/').pop();
    if (base.startsWith(kitId + '_')) { const m = base.slice(kitId.length + 1).match(/^(\d+)\.(webp|png)$/); if (m && +m[1] > bestN) { best = p; bestN = +m[1]; } }
  }
  if (!best) return null;
  // only pictures from the loaded kit pack (blob/data URLs): before the pack is ready, show the item's emoji instead of
  // letting the browser request a kit path that does not exist as a file
  try { const u = H.url(best); return u && /^(blob:|data:)/.test(u) ? u : null; } catch (e) { return null; }
}
export const skinOf = (S) => (effectiveSkin(S) === 'fallback' ? 'grove' : 'hyrule');
// the old shop items, priced in shared rupees (bought in the Hyrule Market or in Talon's say-it-to-buy shop)
export function legacyItems(SHOP) {
  return (SHOP.items || []).map((it) => ({ id: 'language.' + it.id, app: APP, cat: 'legacy', slot: it.id.startsWith('tunic') ? 'language.tunic' : it.id.startsWith('navi') ? 'language.navi' : 'language.shield', price: it.price, emoji: it.icon || '🎁', image: it.image || null,
    name: { hyrule: it.en, grove: it.en, classic: it.en } }));
}
// PIN pad for the wallet (approving tickets): resolves true after the right PIN
export function pinCheck() {
  return new Promise((resolve) => {
    const wrap = document.createElement('div'); wrap.className = 'lq-pin-modal'; wrap.setAttribute('role', 'dialog'); wrap.setAttribute('aria-label', 'Grown-up PIN');
    wrap.innerHTML = '<div class="card center"><b>Grown-up: type your PIN</b><input class="field" type="password" inputmode="numeric" maxlength="4" data-testid="fw-pin" style="width:140px;text-align:center;margin:10px auto;display:block"><div class="fb info small" data-testid="fw-pin-err" style="display:none">That PIN isn’t right.</div><div class="row c"><button class="btn" data-x="cancel">Cancel</button><button class="btn primary" data-x="ok" data-testid="fw-pin-ok">Approve</button></div></div>';
    document.body.appendChild(wrap);
    const inp = wrap.querySelector('input'); const err = wrap.querySelector('[data-testid=fw-pin-err]');
    const done = (v) => { wrap.remove(); resolve(v); };
    const ok = async () => { if (!pinIsSet()) { err.textContent = 'A grown-up needs to set a PIN in the Parent corner first.'; err.style.display = ''; return; } if (await checkPin(inp.value)) done(true); else { err.style.display = ''; inp.value = ''; } };
    wrap.querySelector('[data-x=ok]').onclick = ok; wrap.querySelector('[data-x=cancel]').onclick = () => done(false);
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') ok(); }); setTimeout(() => inp.focus(), 30);
  });
}
// earning moments from the app's events (see hooks.js); a wallet problem can never break the app
let wired = false;
export function wireWallet() {
  if (!FW || wired) return; wired = true;
  on((type, d) => {
    try {
      if (type === 'answer') FW.answer(APP, !!d.correct, d.lessonId || lessonId);
      else if (type === 'quest:done' || type === 'lesson:done' || type === 'story:done' || type === 'mission:done') FW.finishUnit(APP, type.split(':')[0]);
      else if (type === 'boss:won') FW.beatBoss(APP, 'boss');
      else if (type === 'comeback') FW.comeback(APP, d.why || 'comeback');
      else if (type === 'secret') FW.secret(APP, 'secret:' + (d.id || ''));
    } catch (e) { try { (globalThis.__lqDiagAdd || console.warn)('wallet: ' + (e && e.message)); } catch (e2) {} }
  });
}
// one-time migration of this app's local rupees, waiting Skulltula tokens and old shop items
export function migrateOnce(S) {
  if (!FW) return;
  try { FW.migrateApp(APP, { rupees: Math.max(0, S.rupees || 0), tokens: Math.max(0, (S.treasure && S.treasure.tokens) || 0), owned: ((S.shop && S.shop.owned) || []).map((id) => 'language.' + id) }); } catch (e) {}
}
export const owns = (id) => { try { return !!(FW && FW.owns(id)); } catch (e) { return false; } };
export const PARTNERS = ['zelda', 'impa', 'ruto', 'darunia', 'malon', 'saria'];
export const partner = () => PARTNERS.find((p) => owns('partner.' + p)) || null;
