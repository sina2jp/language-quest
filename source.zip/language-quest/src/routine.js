// Daily routine content: the mentor greeting (same questions every day, answers that grow over the weeks) and the
// "Kokiri sword training" movement break (TPR commands). Farsi entries carry spoken + written forms.
const F = (f, t, en, w, wt) => (w ? { f, t, en, w, wt } : { f, t, en });

export const GREET = {
  es: [
    { q: { t: '¡Hola! ¿Cómo estás?', en: 'Hi! How are you?' }, levels: [
      [['¡Bien!', 'Good!'], ['¡Feliz!', 'Happy!'], ['Cansado.', 'Tired.'], ['Más o menos.', 'So-so.']],
      [['Estoy bien.', 'I am fine.'], ['Estoy feliz.', 'I am happy.'], ['Estoy cansado.', 'I am tired.'], ['Más o menos.', 'So-so.']],
      [['Estoy muy bien, gracias. ¿Y tú?', 'I am very well, thanks. And you?'], ['Estoy feliz. ¿Y tú?', 'I am happy. And you?'], ['Estoy un poco cansado. ¿Y tú?', 'I am a little tired. And you?'], ['Más o menos. ¿Y tú?', 'So-so. And you?']],
    ] },
    { q: { t: '¿Qué tiempo hace hoy?', en: 'What is the weather like today?' }, levels: [
      [['¡Sol!', 'Sun!'], ['¡Lluvia!', 'Rain!'], ['¡Frío!', 'Cold!'], ['¡Calor!', 'Hot!']],
      [['Hace sol.', 'It is sunny.'], ['Llueve.', 'It is raining.'], ['Hace frío.', 'It is cold.'], ['Hace calor.', 'It is hot.'], ['Está nublado.', 'It is cloudy.']],
      [['Hoy hace sol y calor.', 'Today it is sunny and hot.'], ['Hoy llueve mucho.', 'Today it is raining a lot.'], ['Hoy hace mucho frío.', 'Today it is very cold.'], ['Hoy está nublado.', 'Today it is cloudy.']],
    ] },
    { from: 2, day: true, q: { t: '¿Qué día es hoy?', en: 'What day is it today?' } },
  ],
  fa: [
    { q: F('سلام! چطوری؟', 'salâm! chetori?', 'Hi! How are you?', 'سلام! چطور هستی؟', 'salâm! chetor hasti?'), levels: [
      [F('خوبم!', 'khubam!', 'I am good!', 'خوب هستم!', 'khub hastam!'), F('خوشحالم!', 'khoshhâlam!', 'I am happy!', 'خوشحال هستم!', 'khoshhâl hastam!'), F('خسته‌م.', 'khastam.', 'I am tired.', 'خسته هستم.', 'khaste hastam.'), F('بد نیستم.', 'bad nistam.', 'Not bad.')],
      [F('خوبم، مرسی.', 'khubam, mersi.', 'I am fine, thanks.', 'خوب هستم، متشکرم.', 'khub hastam, moteshakkeram.'), F('خیلی خوشحالم.', 'kheyli khoshhâlam.', 'I am very happy.', 'خیلی خوشحال هستم.', 'kheyli khoshhâl hastam.'), F('یه کم خسته‌م.', 'ye kam khastam.', 'I am a little tired.', 'کمی خسته هستم.', 'kami khaste hastam.'), F('بد نیستم، مرسی.', 'bad nistam, mersi.', 'Not bad, thanks.', 'بد نیستم، متشکرم.', 'bad nistam, moteshakkeram.')],
      [F('خوبم، مرسی. تو چطوری؟', 'khubam, mersi. to chetori?', 'I am fine, thanks. How are you?', 'خوب هستم، متشکرم. تو چطور هستی؟', 'khub hastam, moteshakkeram. to chetor hasti?'), F('خیلی خوشحالم. تو چطوری؟', 'kheyli khoshhâlam. to chetori?', 'I am very happy. How are you?', 'خیلی خوشحال هستم. تو چطور هستی؟', 'kheyli khoshhâl hastam. to chetor hasti?'), F('یه کم خسته‌م. تو چطوری؟', 'ye kam khastam. to chetori?', 'I am a little tired. How are you?', 'کمی خسته هستم. تو چطور هستی؟', 'kami khaste hastam. to chetor hasti?')],
    ] },
    { q: F('هوا چطوره؟', 'havâ chetor-e?', 'What is the weather like?', 'هوا چطور است؟', 'havâ chetor ast?'), levels: [
      [F('آفتابی!', 'âftâbi!', 'Sunny!'), F('بارونی!', 'bâruni!', 'Rainy!', 'بارانی!', 'bârâni!'), F('سرد!', 'sard!', 'Cold!'), F('گرم!', 'garm!', 'Hot!')],
      [F('آفتابیه.', 'âftâbi-ye.', 'It is sunny.', 'آفتابی است.', 'âftâbi ast.'), F('بارون میاد.', 'bârun miyâd.', 'It is raining.', 'باران می‌آید.', 'bârân miâyad.'), F('سرده.', 'sard-e.', 'It is cold.', 'سرد است.', 'sard ast.'), F('گرمه.', 'garm-e.', 'It is hot.', 'گرم است.', 'garm ast.'), F('ابریه.', 'abri-ye.', 'It is cloudy.', 'ابری است.', 'abri ast.')],
      [F('امروز هوا آفتابی و گرمه.', 'emruz havâ âftâbi o garm-e.', 'Today it is sunny and hot.', 'امروز هوا آفتابی و گرم است.', 'emruz havâ âftâbi va garm ast.'), F('امروز خیلی بارون میاد.', 'emruz kheyli bârun miyâd.', 'Today it is raining a lot.', 'امروز خیلی باران می‌آید.', 'emruz kheyli bârân miâyad.'), F('امروز هوا خیلی سرده.', 'emruz havâ kheyli sard-e.', 'Today it is very cold.', 'امروز هوا خیلی سرد است.', 'emruz havâ kheyli sard ast.'), F('امروز هوا ابریه.', 'emruz havâ abri-ye.', 'Today it is cloudy.', 'امروز هوا ابری است.', 'emruz havâ abri ast.')],
    ] },
    { from: 2, day: true, q: F('امروز چندشنبه‌ست؟', 'emruz chand-shanbe-st?', 'What day is it today?', 'امروز چندشنبه است؟', 'emruz chandshanbe ast?') },
  ],
};
// JS getDay(): 0 = Sunday
export const DAYS = {
  es: [['Hoy es domingo.', 'Today is Sunday.'], ['Hoy es lunes.', 'Today is Monday.'], ['Hoy es martes.', 'Today is Tuesday.'], ['Hoy es miércoles.', 'Today is Wednesday.'], ['Hoy es jueves.', 'Today is Thursday.'], ['Hoy es viernes.', 'Today is Friday.'], ['Hoy es sábado.', 'Today is Saturday.']],
  fa: [F('امروز یکشنبه‌ست.', 'emruz yekshanbe-st.', 'Today is Sunday.', 'امروز یکشنبه است.', 'emruz yekshanbe ast.'), F('امروز دوشنبه‌ست.', 'emruz doshanbe-st.', 'Today is Monday.', 'امروز دوشنبه است.', 'emruz doshanbe ast.'), F('امروز سه‌شنبه‌ست.', 'emruz seshanbe-st.', 'Today is Tuesday.', 'امروز سه‌شنبه است.', 'emruz seshanbe ast.'), F('امروز چهارشنبه‌ست.', 'emruz chahârshanbe-st.', 'Today is Wednesday.', 'امروز چهارشنبه است.', 'emruz chahârshanbe ast.'), F('امروز پنجشنبه‌ست.', 'emruz panjshanbe-st.', 'Today is Thursday.', 'امروز پنجشنبه است.', 'emruz panjshanbe ast.'), F('امروز جمعه‌ست.', "emruz jom'e-st.", 'Today is Friday.', 'امروز جمعه است.', "emruz jom'e ast."), F('امروز شنبه‌ست.', 'emruz shanbe-st.', 'Today is Saturday.', 'امروز شنبه است.', 'emruz shanbe ast.')],
};

export const TPR = {
  es: [
    ['¡Salta!', 'Jump!', '🦘'], ['¡Siéntate!', 'Sit down!', '🪑'], ['¡Levántate!', 'Stand up!', '🧍'], ['¡Corre en tu lugar!', 'Run in place!', '🏃'],
    ['¡Para!', 'Stop!', '✋'], ['¡Aplaude!', 'Clap!', '👏'], ['¡Da una vuelta!', 'Turn around!', '🔄'], ['¡Levanta la espada!', 'Raise your sword!', '🗡️'],
    ['¡Agáchate!', 'Duck down!', '⬇️'], ['¡Tócate la cabeza!', 'Touch your head!', '🙆'], ['¡Mira arriba!', 'Look up!', '👆'], ['¡Levanta el escudo!', 'Raise your shield!', '🛡️'],
  ],
  fa: [
    [F('بپر!', 'bepar!', 'Jump!'), '🦘'], [F('بشین!', 'beshin!', 'Sit down!', 'بنشین!', 'beneshin!'), '🪑'], [F('پاشو!', 'pâsho!', 'Stand up!', 'بلند شو!', 'boland sho!'), '🧍'],
    [F('بدو!', 'bedo!', 'Run!'), '🏃'], [F('وایسا!', 'vâysâ!', 'Stop!', 'بایست!', 'bâyest!'), '✋'], [F('دست بزن!', 'dast bezan!', 'Clap!'), '👏'],
    [F('بچرخ!', 'becharkh!', 'Turn around!'), '🔄'], [F('شمشیرت رو ببر بالا!', 'shamshiret ro bebar bâlâ!', 'Raise your sword!', 'شمشیرت را بالا ببر!', 'shamshirat râ bâlâ bebar!'), '🗡️'],
    [F('خم شو!', 'kham sho!', 'Bend down!'), '⬇️'], [F('دستت رو بذار رو سرت!', 'dastet ro bezâr ru saret!', 'Put your hand on your head!', 'دستت را روی سرت بگذار!', 'dastat râ ru-ye sarat begozâr!'), '🙆'],
    [F('بالا رو نگاه کن!', 'bâlâ ro negâh kon!', 'Look up!', 'بالا را نگاه کن!', 'bâlâ râ negâh kon!'), '👆'], [F('سپرت رو بگیر بالا!', 'separet ro begir bâlâ!', 'Raise your shield!', 'سپرت را بالا بگیر!', 'separat râ bâlâ begir!'), '🛡️'],
  ],
};

// Little fixed lines (Farsi audio is pre-generated for all of these)
export const LINES = {
  es: { whatIs: '¿Qué es esto?', howMany: '¿Cuántos hay?', again: '¿Otra vez?', bothRight: '', knew: '¡Ya lo sabías!' },
  fa: {
    whatIs: F('این چیه؟', 'in chiye?', 'What is this?', 'این چیست؟', 'in chist?'),
    howMany: F('چند تا هست؟', 'chand tâ hast?', 'How many are there?'),
    again: F('یه بار دیگه؟', 'ye bâr dige?', 'One more time?', 'یک بار دیگر؟', 'yek bâr digar?'),
    knew: F('اینو بلد بودی!', 'ino balad budi!', 'You already knew this!', 'این را بلد بودی!', 'in râ balad budi!'),
  },
};
export const COUNT = {
  es: ['', 'Hay uno.', 'Hay dos.', 'Hay tres.', 'Hay cuatro.', 'Hay cinco.'],
  fa: [null, F('یه دونه.', 'ye dune.', 'One.', 'یک دانه.', 'yek dâne.'), F('دو تا.', 'do tâ.', 'Two.'), F('سه تا.', 'se tâ.', 'Three.'), F('چهار تا.', 'chahâr tâ.', 'Four.'), F('پنج تا.', 'panj tâ.', 'Five.')],
};

// Ocarina: the child may play classic songs himself; we only RECOGNIZE his input (never play or show them).
export const SECRET_SONGS = [
  { id: 'saria', notes: ['F4', 'A4', 'B4', 'F4', 'A4', 'B4'], es: '¡La canción de Saria! ¡Qué bonito!', fa: F('آهنگ ساریا! چه قشنگ!', 'âhang-e Sâriyâ! che ghashang!', "Saria's song! How pretty!") },
  { id: 'zelda', notes: ['B4', 'D5', 'A4', 'B4', 'D5', 'A4'], es: '¡La canción de Zelda! ¡Muy bien!', fa: F('آهنگ زلدا! آفرین!', 'âhang-e Zeldâ! âfarin!', "Zelda's song! Well done!") },
  { id: 'epona', notes: ['D5', 'B4', 'A4', 'D5', 'B4', 'A4'], es: '¡La canción de Epona! ¡Un caballo feliz!', fa: F('آهنگ اپونا! یه اسب خوشحال!', 'âhang-e Eponâ! ye asb-e khoshhâl!', "Epona's song! A happy horse!", 'آهنگ اپونا! یک اسب خوشحال!', 'âhang-e Eponâ! yek asb-e khoshhâl!') },
  { id: 'sun', notes: ['A4', 'F4', 'D5', 'A4', 'F4', 'D5'], es: '¡La canción del sol! ¡Buenos días!', fa: F('آهنگ خورشید! صبح بخیر!', 'âhang-e khorshid! sobh bekheyr!', 'The sun song! Good morning!') },
  { id: 'time', notes: ['A4', 'D4', 'F4', 'A4', 'D4', 'F4'], es: '¡La canción del tiempo! ¡Increíble!', fa: F('آهنگ زمان! عالیه!', 'âhang-e zamân! âliye!', 'The song of time! Amazing!', 'آهنگ زمان! عالی است!', 'âhang-e zamân! âli ast!') },
  { id: 'storms', notes: ['D4', 'F4', 'D5', 'D4', 'F4', 'D5'], es: '¡La canción de la tormenta! ¡Llueve!', fa: F('آهنگ طوفان! بارون میاد!', 'âhang-e tufân! bârun miyâd!', 'The storm song! It is raining!', 'آهنگ طوفان! باران می‌آید!', 'âhang-e tufân! bârân miâyad!') },
];

// Rupee shop: the keeper speaks ONLY the target language; he buys by saying the phrase.
export const SHOP = {
  items: [
    { id: 'navi_pink', price: 20, icon: '🧚', es: ['la luz rosa', 'Quiero la luz rosa, por favor.'], fa: [F('نور صورتی', 'nur-e surati', 'the pink light'), F('نور صورتی رو می‌خوام، لطفاً.', 'nur-e surati ro mikhâm, lotfan.', 'I want the pink light, please.', 'نور صورتی را می‌خواهم، لطفاً.', 'nur-e surati râ mikhâham, lotfan.')], en: 'Pink glow for Navi' },
    { id: 'tunic_red', price: 30, icon: '🔴', es: ['la túnica roja', 'Quiero la túnica roja, por favor.'], fa: [F('پیرهن قرمز', 'pirhan-e ghermez', 'the red tunic', 'پیراهن قرمز', 'pirâhan-e ghermez'), F('پیرهن قرمز رو می‌خوام، لطفاً.', 'pirhan-e ghermez ro mikhâm, lotfan.', 'I want the red tunic, please.', 'پیراهن قرمز را می‌خواهم، لطفاً.', 'pirâhan-e ghermez râ mikhâham, lotfan.')], en: 'Red tunic' },
    { id: 'tunic_blue', price: 30, icon: '🔵', es: ['la túnica azul', 'Quiero la túnica azul, por favor.'], fa: [F('پیرهن آبی', 'pirhan-e âbi', 'the blue tunic', 'پیراهن آبی', 'pirâhan-e âbi'), F('پیرهن آبی رو می‌خوام، لطفاً.', 'pirhan-e âbi ro mikhâm, lotfan.', 'I want the blue tunic, please.', 'پیراهن آبی را می‌خواهم، لطفاً.', 'pirâhan-e âbi râ mikhâham, lotfan.')], en: 'Blue tunic' },
    { id: 'navi_gold', price: 40, icon: '✨', es: ['la luz dorada', 'Quiero la luz dorada, por favor.'], fa: [F('نور طلایی', 'nur-e talâyi', 'the golden light'), F('نور طلایی رو می‌خوام، لطفاً.', 'nur-e talâyi ro mikhâm, lotfan.', 'I want the golden light, please.', 'نور طلایی را می‌خواهم، لطفاً.', 'nur-e talâyi râ mikhâham, lotfan.')], en: 'Golden glow for Navi' },
    { id: 'shield', price: 50, icon: '🛡️', es: ['el escudo', 'Quiero el escudo, por favor.'], fa: [F('سپر', 'separ', 'the shield'), F('سپر رو می‌خوام، لطفاً.', 'separ ro mikhâm, lotfan.', 'I want the shield, please.', 'سپر را می‌خواهم، لطفاً.', 'separ râ mikhâham, lotfan.')], en: 'Hylian shield' },
  ],
  hello: { es: { t: '¡Hola! ¿Qué quieres?', en: 'Hi! What do you want?' }, fa: F('سلام! چی می‌خوای؟', 'salâm! chi mikhây?', 'Hi! What do you want?', 'سلام! چه می‌خواهی؟', 'salâm! che mikhâhi?') },
  thanks: { es: { t: '¡Aquí tienes! ¡Gracias!', en: 'Here you go! Thank you!' }, fa: F('بفرما! مرسی!', 'befarmâ! mersi!', 'Here you go! Thanks!', 'بفرمایید! متشکرم!', 'befarmâyid! moteshakkeram!') },
  more: { es: { t: 'Necesitas más rupias.', en: 'You need more rupees.' }, fa: F('روپیه‌ت کافی نیست!', 'rupiye-t kâfi nist!', "You don't have enough rupees!", 'روپیه‌ات کافی نیست!', 'rupiye-at kâfi nist!') },
  wrong: { es: (o) => [`Tengo ${o}.`, `Me gusta ${o}.`], fa: (o) => [F(o.f + ' دارم.', o.t + ' dâram.', 'I have ' + o.en + '.', o.w ? o.w + ' دارم.' : undefined, o.wt ? o.wt + ' dâram.' : undefined), F(o.f + ' قشنگه.', o.t + ' ghashang-e.', o.en + ' is pretty.', (o.w || o.f) + ' قشنگ است.', (o.wt || o.t) + ' ghashang ast.')] },
};
// Core phrase chunks, recycled with each unit's whitelisted nouns (power phrases). art: i = indefinite, d = definite.
export const CHUNKS = {
  es: [
    { en: 'I want ___.', art: 'i', make: (x) => `Quiero ${x}.` }, { en: 'I have ___.', art: 'i', make: (x) => `Tengo ${x}.` },
    { en: 'I like ___.', art: 'd', make: (x, pl) => (pl ? `Me gustan ${x}.` : `Me gusta ${x}.`) }, { en: 'Where is ___?', art: 'd', make: (x, pl) => (pl ? `¿Dónde están ${x}?` : `¿Dónde está ${x}?`) },
    { en: 'I need ___.', art: 'i', make: (x) => `Necesito ${x}.` }, { en: 'Do you have ___?', art: 'i', make: (x) => `¿Tienes ${x}?` },
    { en: 'Look at ___!', art: 'd', make: (x) => `¡Mira ${x}!` }, { en: 'I love ___!', art: 'd', make: (x, pl) => (pl ? `¡Me encantan ${x}!` : `¡Me encanta ${x}!`) },
    { en: 'I am looking for ___.', art: 'i', make: (x) => `Busco ${x}.` }, { en: "I don't have ___.", art: 'i', make: (x) => `No tengo ${x}.` },
  ],
  fa: [
    { en: 'I want ___.', art: 'i', f: (x) => x + ' می‌خوام.', t: (x) => x + ' mikhâm.', w: (x) => x + ' می‌خواهم.', wt: (x) => x + ' mikhâham.' },
    { en: 'I have ___.', art: 'i', f: (x) => x + ' دارم.', t: (x) => x + ' dâram.' },
    { en: 'Where is ___?', art: 'd', f: (x) => x + ' کجاست؟', t: (x) => x + ' kojâst?' },
    { en: 'I like ___.', art: 'd', f: (x) => x + ' رو دوست دارم.', t: (x) => x + ' ro dust dâram.', w: (x) => x + ' را دوست دارم.', wt: (x) => x + ' râ dust dâram.' },
    { en: 'I see ___.', art: 'd', f: (x) => x + ' رو می‌بینم.', t: (x) => x + ' ro mibinam.', w: (x) => x + ' را می‌بینم.', wt: (x) => x + ' râ mibinam.' },
    { en: "I don't have ___.", art: 'i', f: (x) => x + ' ندارم.', t: (x) => x + ' nadâram.' },
    { en: 'I need ___.', art: 'i', f: (x) => x + ' لازم دارم.', t: (x) => x + ' lâzem dâram.' },
    { en: 'Where is ___?', art: 'd', f: (x) => x + ' کو؟', t: (x) => x + ' ku?', w: (x) => x + ' کجاست؟', wt: (x) => x + ' kojâst?' },
  ],
};
// English for the noun: "a/an X" (indefinite count noun), "X" (mass or plural), "the X" (definite)
export const enNoun = (c, art, gen) => (art === 'd' ? (gen && c.mass ? c.en : 'the ' + c.en) : c.mass || c.pl || c.enPl ? c.en : (/^[aeiou]/i.test(c.en) ? 'an ' : 'a ') + c.en);
// Spanish article forms: definite = the item's own article; indefinite = un/una, or no article for mass and plural nouns
export function esForms(t, c) {
  const pl = /^(los|las) /.test(t);
  const bare = t.replace(/^(el|la|los|las) /, '');
  const indef = c.mass || pl ? bare : t.replace(/^el /, 'un ').replace(/^la /, 'una ');
  return { def: t, indef, bare, pl };
}
// Build one power phrase. noun = { t (text, with article in Spanish), tr, w, wt (Farsi), c (whitelist concept) }
export function makeChunk(lang, k, noun) {
  const c = CHUNKS[lang][k % CHUNKS[lang].length];
  let en = c.en.replace('___', enNoun(noun.c, c.art, /^I (like|love) /.test(c.en)));
  if (noun.c.pl || noun.c.enPl) en = en.replace(/^Where is /, 'Where are ');
  if (lang === 'es') { const F_ = esForms(noun.t, noun.c); const s = c.make(c.art === 'i' ? F_.indef : F_.def, F_.pl); return { t: s, say: s, en }; }
  const sf = c.f(noun.t), st = c.t(noun.tr || '');
  const wf = (c.w || c.f)(noun.w || noun.t), wt = (c.wt || c.t)(noun.wt || noun.tr || '');
  const x = { t: sf, tr: st, say: sf, en };
  if (wf !== sf) { x.w = wf; x.wt = wt; }
  return x;
}
export function allFaRoutine() {
  const out = [];
  const add = (x) => { if (x && x.f) out.push(x.f); };
  for (const g of GREET.fa) { add(g.q); (g.levels || []).forEach((lv) => lv.forEach(add)); }
  DAYS.fa.forEach(add); TPR.fa.forEach((x) => add(x[0])); Object.values(LINES.fa).forEach(add); COUNT.fa.forEach(add);
  SECRET_SONGS.forEach((s) => add(s.fa));
  SHOP.items.forEach((it) => { add(it.fa[1]); SHOP.wrong.fa(it.fa[0]).forEach(add); });
  add(SHOP.hello.fa); add(SHOP.thanks.fa); add(SHOP.more.fa);
  return out;
}
