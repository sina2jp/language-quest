// Unit tests: chunking (Code.gs on gas-shim), protocol rules, merge rules, crypto, and family-sync between two devices.
// Run: node tests/unit.mjs      (Node 20+, no dependencies)
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const here = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const ROOT = path.join(here, '..');
const { loadCodeGs, sha256, utf8Bytes } = require(path.join(ROOT, 'server', 'gas-shim.js'));
const CODE = fs.readFileSync(path.join(ROOT, 'server', 'Code.gs'), 'utf8');
const FSmod = require(path.join(ROOT, 'family-sync.js'));
const FWpath = path.join(ROOT, 'vendor', 'family-wallet.js');

let pass = 0, fail = 0;
const results = [];
async function test(name, fn) {
  try { await fn(); pass++; results.push('ok   ' + name); }
  catch (e) { fail++; results.push('FAIL ' + name + '\n     ' + (e && e.stack ? e.stack.split('\n').slice(0, 3).join('\n     ') : e)); }
}
function eq(a, b, msg) { const A = JSON.stringify(a), B = JSON.stringify(b); if (A !== B) throw new Error((msg || 'not equal') + ': ' + A.slice(0, 300) + ' !== ' + B.slice(0, 300)); }
function ok(v, msg) { if (!v) throw new Error(msg || 'expected truthy'); }

function memStore() {
  const m = new Map();
  const s = { writes: 0, getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => { s.writes++; m.set(k, String(v)); }, removeItem: (k) => { s.writes++; m.delete(k); }, key: (i) => [...m.keys()][i] ?? null, get length() { return m.size; }, map: m };
  return s;
}
function backend(opts) {
  const app = loadCodeGs(CODE, opts);
  const calls = [];
  const transport = (endpoint, body) => { calls.push(body.op); return Promise.resolve(app.handle(JSON.parse(JSON.stringify(body)))); };
  return { app, transport, calls };
}
function device(be, extra) {
  const store = memStore();
  const fs = FSmod.__new();
  fs.configure({ storage: store, transport: be.transport, locks: null, win: null, channel: null, wallet: null, online: () => true, visible: () => true, ...(extra || {}) });
  return { fs, store };
}
function freshWallet(store) {
  delete require.cache[require.resolve(FWpath)];
  const FW = require(FWpath);
  FW.configure({ storage: store, resetMemory: true });
  return FW;
}
const ENDPOINT = 'http://127.0.0.1:9/exec';
const AKFY = 'https://script.google.com/macros/s/AKfycbTESTdeploymentIdForUnitTests0123456789/exec';

// ---------------- crypto + hashing ----------------
await test('gas-shim SHA-256 matches node:crypto (ascii, unicode, long)', () => {
  for (const s of ['', 'abc', 'salt:token', 'فارسی 🐾 ñ', 'x'.repeat(100000)]) {
    const mine = Buffer.from(sha256(utf8Bytes(s))).toString('hex');
    eq(mine, crypto.createHash('sha256').update(s, 'utf8').digest('hex'), s.slice(0, 10));
  }
});
await test('HKDF auth token is deterministic per secret and differs between secrets', async () => {
  const t = FSmod._t;
  const s1 = t.b64u(crypto.randomBytes(16)), s2 = t.b64u(crypto.randomBytes(16));
  const a1 = (await t.familyKeys(s1)).auth, a1b = (await FSmod.__new()._t.familyKeys(s1)).auth, a2 = (await t.familyKeys(s2)).auth;
  eq(a1, a1b); ok(a1 !== a2); ok(/^[A-Za-z0-9_-]{43}$/.test(a1)); ok(a1 !== s1);
});
await test('AES-GCM round trip; tamper, wrong secret and wrong key name all fail', async () => {
  const t = FSmod._t;
  const s = t.b64u(crypto.randomBytes(16)), s2 = t.b64u(crypto.randomBytes(16));
  const plain = 'sk-ant-api03-EXAMPLE-not-a-real-key';
  const c = await t.aesEncrypt(s, 'famX', 'familyApps.anthropicKey.v1', plain);
  ok(/^fsenc1:/.test(c) && c.indexOf('EXAMPLE') < 0, 'ciphertext must not contain the key');
  eq(await t.aesDecrypt(s, 'famX', 'familyApps.anthropicKey.v1', c), plain);
  const c2 = await t.aesEncrypt(s, 'famX', 'familyApps.anthropicKey.v1', plain); ok(c !== c2, 'fresh IV each time');
  const bad = c.slice(0, -3) + (c.slice(-3) === 'AAA' ? 'BBB' : 'AAA');
  for (const [sec, fam, key, val] of [[s, 'famX', 'familyApps.anthropicKey.v1', bad], [s2, 'famX', 'familyApps.anthropicKey.v1', c], [s, 'famX', 'familyApps.other.v1', c], [s, 'famY', 'familyApps.anthropicKey.v1', c]]) {
    let threw = false; try { await t.aesDecrypt(sec, fam, key, val); } catch { threw = true; } ok(threw, 'should fail');
  }
});
await test('family PIN: salted PBKDF2 record, right PIN passes, wrong fails, salt differs', async () => {
  const { fs } = device(backend());
  const r1 = await fs.makePinRecord('2580'), r2 = await fs.makePinRecord('2580');
  ok(r1.salt !== r2.salt && r1.hash !== r2.hash); ok(JSON.stringify(r1).indexOf('2580') < 0, 'no plain PIN in the record');
  let threw = false; try { await fs.makePinRecord('12a4'); } catch { threw = true; } ok(threw);
});

// ---------------- chunking + Sheet rules (real Code.gs) ----------------
await test('chunking: values split into <=45,000-char cells and join back exactly', () => {
  const { app } = backend();
  for (const n of [0, 1, 44999, 45000, 45001, 90000, 135001, 299999, 300000]) {
    const v = 'é'.repeat(Math.min(n, 3)) + 'x'.repeat(Math.max(0, n - 3));
    const parts = app._splitValue(v);
    ok(parts.every((p) => p.length <= 45001), 'cell too big');
    ok(parts.length === Math.max(1, Math.ceil(n / 45000)), 'parts ' + n);
    const row = ['k', '', 1, '', '', n, 'kid', parts.length].concat(parts, Array(8 - parts.length).fill(''));
    eq(app._joinValue(row), v, 'join ' + n);
  }
  eq(app._joinValue(['k', '', 1, '', '', 0, 'kid', 0, '', '', '', '', '', '', '', '']), null, 'deleted');
});
await test('protocol round-trip keeps tricky values exact (numbers, TRUE, formulas, dates, Farsi, emoji, 300 KB)', async () => {
  const be = backend();
  const { fs } = device(be);
  await fs.createFamily({ endpoint: ENDPOINT });
  const vals = { 'familyApps.look.v1': '12345', 'familyApps.rewards.v1': 'TRUE', 'familyApps.pin.v1': '=SUM(A1:A9)', 'familyApps.walletAdjust.v1': '2026-11-27', 'familyApps.ticketApprovals.v1': 'سلام 🐾 ' + 'ب'.repeat(1000), 'musicQuest.myLessons.v1': 'y'.repeat(300000) };
  for (const [k, v] of Object.entries(vals)) ok(fs.setSetting(k, v), 'setSetting ' + k);
  await fs.syncNow();
  const res = be.app.handle({ v: 1, op: 'get', familyId: fs.config().familyId, auth: 'A'.repeat(43) });
  ok(!res.ok && res.error === 'auth', 'a made-up auth is refused');
  // read back through the real protocol with the right auth
  const st = JSON.parse(be.app.shim.props.FAMILY);
  ok(st.hash && st.salt && !st.secret, 'only a salted hash is stored');
  const rows = be.app.shim.sheetRows('data').slice(1);
  for (const r of rows) for (const c of r.slice(8)) ok(typeof c === 'string' && c.length <= 45001, 'cell <= 45,001');
  ok(be.app.shim.stats.coerced === 0, 'no Sheets coercion happened');
  const back = {};
  for (const r of rows) back[r[0]] = be.app._joinValue(r);
  for (const [k, v] of Object.entries(vals)) eq(back[k], v, k);
  const big = rows.find((r) => r[0] === 'musicQuest.myLessons.v1');
  eq(big[1], 'music'); eq(Number(big[7]), 7); eq(Number(big[5]), 300000);
});
await test('a value over 300,000 characters is refused (too-large), others still saved', async () => {
  const be = backend();
  const { fs, store } = device(be);
  await fs.createFamily({ endpoint: ENDPOINT });
  fs.setSetting('familyApps.look.v1', JSON.stringify({ v: 1, skin: 'grove' }));
  store.setItem('musicQuest.myLessons.v1', 'z'.repeat(300001));
  await fs.syncNow();
  const keys = be.app.shim.sheetRows('data').slice(1).map((r) => r[0]);
  ok(keys.includes('familyApps.look.v1')); ok(!keys.includes('musicQuest.myLessons.v1'));
  ok(fs.status().tooBig.includes('musicQuest.myLessons.v1'), 'status reports the too-big key');
});

// ---------------- protocol rules ----------------
await test('create once; second create is refused; wrong secret refused on every op', async () => {
  const be = backend();
  const g = device(be);
  await g.fs.createFamily({ endpoint: ENDPOINT });
  const other = device(be);
  let e1; try { await other.fs.createFamily({ endpoint: ENDPOINT }); } catch (e) { e1 = e; }
  eq(e1 && e1.code, 'exists');
  const link = g.fs.joinLink('https://example.test/family/');
  const j = FSmod.parseJoin(link);
  const badSecret = (j.secret[0] === 'A' ? 'B' : 'A') + j.secret.slice(1);
  const k = device(be);
  let e2; try { await k.fs.connect({ ...j, secret: badSecret }); } catch (e) { e2 = e; }
  eq(e2 && e2.code, 'auth'); ok(!k.fs.isConnected(), 'nothing saved'); eq(k.store.map.has('familyApps.sync.v1'), false);
});
await test('get filters: keys, sinceRev, writer role; unchanged put keeps its rev', async () => {
  const be = backend();
  const g = device(be);
  await g.fs.createFamily({ endpoint: ENDPOINT });
  g.fs.setSetting('familyApps.look.v1', '{"v":1,"skin":"hyrule"}');
  await g.fs.syncNow();
  const c = JSON.parse(g.store.getItem('familyApps.sync.v1'));
  const auth = (await FSmod._t.familyKeys(c.secret)).auth;
  const base = { v: 1, familyId: c.familyId, auth, device: { id: c.deviceId, role: 'grownup' } };
  const r1 = be.app.handle({ ...base, op: 'put', items: [{ key: 'familyApps.rewards.v1', value: '{"a":1}' }] });
  const r2 = be.app.handle({ ...base, op: 'put', items: [{ key: 'familyApps.rewards.v1', value: '{"a":1}' }] });
  eq(r2.revs['familyApps.rewards.v1'], r1.revs['familyApps.rewards.v1'], 'same value, same rev');
  const all = be.app.handle({ ...base, op: 'get' });
  eq(all.items.length, 2);
  eq(be.app.handle({ ...base, op: 'get', keys: ['familyApps.look.v1'] }).items.map((i) => i.key), ['familyApps.look.v1']);
  eq(be.app.handle({ ...base, op: 'get', sinceRev: r1.rev - 1 }).items.map((i) => i.key), ['familyApps.rewards.v1']);
  eq(be.app.handle({ ...base, op: 'get', role: 'kid' }).items.length, 0);
  const kidPut = be.app.handle({ ...base, device: { id: 'd-kid1', role: 'kid' }, op: 'put', items: [{ key: 'familyApps.look.v1', value: 'x' }] });
  eq(kidPut.refused['familyApps.look.v1'], 'wrong-role', 'a kid device can never overwrite a grown-up key');
});
await test('pairing: 6-character code, one use, expires after 10 minutes, tries are limited', async () => {
  let clock = Date.now();
  const be = backend({ now: () => clock });
  const g = device(be);
  await g.fs.createFamily({ endpoint: ENDPOINT });
  const p = await g.fs.pairCreate();
  ok(/^[A-HJ-NP-Z2-9]{6}$/.test(p.code), 'code ' + p.code);
  const r = be.app.handle({ v: 1, op: 'pairRedeem', code: p.code.toLowerCase() });
  ok(r.ok && r.familyId === g.fs.config().familyId && /^[A-Za-z0-9_-]{22}$/.test(r.secret));
  eq(be.app.handle({ v: 1, op: 'pairRedeem', code: p.code }).error, 'not-found', 'one use');
  const p2 = await g.fs.pairCreate();
  clock += 601000;
  eq(be.app.handle({ v: 1, op: 'pairRedeem', code: p2.code }).error, 'not-found', 'expired');
  let limited = false;
  for (let i = 0; i < 12; i++) if (be.app.handle({ v: 1, op: 'pairRedeem', code: 'ZZZZZZ' }).error === 'rate-limited') limited = true;
  ok(limited, 'rate limited');
});
await test('auth failures are rate limited', async () => {
  const be = backend();
  const g = device(be);
  await g.fs.createFamily({ endpoint: ENDPOINT });
  const fid = g.fs.config().familyId;
  let last;
  for (let i = 0; i < 25; i++) last = be.app.handle({ v: 1, op: 'get', familyId: fid, auth: 'x'.repeat(43) });
  eq(last.error, 'rate-limited');
});

// ---------------- merge rules ----------------
await test('merge rules: cloud empty -> local; local empty -> cloud; same -> same; more progress wins', () => {
  const t = FSmod._t;
  const W = (shards, rupees) => JSON.stringify({ totals: { math: { earned: shards, spent: 0 }, rupees: { earned: rupees, spent: 0 } } });
  const keys = ['familyApps.wallet.v1', 'familyApps.tickets.v1'];
  eq(t.decideMerge('family', keys, { 'familyApps.wallet.v1': W(3, 10) }, {}).use, 'local');
  eq(t.decideMerge('family', keys, {}, { 'familyApps.wallet.v1': W(3, 10) }).use, 'cloud');
  eq(t.decideMerge('family', keys, { 'familyApps.wallet.v1': W(3, 10) }, { 'familyApps.wallet.v1': W(3, 10) }).use, 'same');
  eq(t.decideMerge('family', keys, { 'familyApps.wallet.v1': W(9, 10) }, { 'familyApps.wallet.v1': W(3, 50) }).use, 'local', '9 shards beat 3 shards + 40 rupees');
  eq(t.decideMerge('family', keys, { 'familyApps.wallet.v1': W(1, 0) }, { 'familyApps.wallet.v1': W(2, 0), 'familyApps.tickets.v1': '[]' }).use, 'cloud');
  eq(t.decideMerge('math', ['mathArena.v3.data.v1'], { 'mathArena.v3.data.v1': '{"a":1}' }, { 'mathArena.v3.data.v1': '{"a":1,"b":[1,2,3]}' }).use, 'cloud', 'default: more data wins');
  eq(t.decideMerge('x', ['k'], {}, {}).use, 'none');
});
await test('keepLocal: school sync "done" marks stay on his laptop; drift hash ignores them', () => {
  const t = FSmod._t;
  const remote = JSON.stringify({ v: 1, programs: [{ id: 'p1' }], weeks: [] });
  const local = JSON.stringify({ v: 1, programs: [], weeks: [], done: { 'b-0': { doneAt: 5 } } });
  eq(JSON.parse(t.keepLocalMerge(remote, local, ['done'])), { v: 1, programs: [{ id: 'p1' }], weeks: [], done: { 'b-0': { doneAt: 5 } } });
  eq(JSON.parse(t.keepLocalMerge(remote, null, ['done'])), JSON.parse(remote));
  const rule = { keepLocal: ['done'] };
  eq(t.stripLocal(t.keepLocalMerge(remote, local, ['done']), rule), remote);
});

// ---------------- family-sync between two devices ----------------
async function family() {
  const be = backend();
  const g = device(be);
  await g.fs.createFamily({ endpoint: ENDPOINT });
  return { be, g };
}
await test('not connected: start() makes no network calls and writes nothing', async () => {
  const be = backend();
  const d = device(be);
  d.store.setItem('mathArena.v3.data.v1', '{"x":1}'); d.store.writes = 0;
  d.fs.start({ app: 'math' });
  ok(d.fs.writeSummary('math', { week: { lessons: 1 } }) === false);
  await d.fs.applyParentRequests();
  await d.fs.syncNow();
  eq(d.store.writes, 0, 'writes'); eq(be.calls.length, 0, 'network'); eq(d.fs.status().state, 'off');
  d.fs.stop();
});
await test('Hub setup -> kid joins -> settings + decrypted AI key land; ciphertext only in the Sheet', async () => {
  const { be, g } = await family();
  const pin = await g.fs.setPin('1357');
  g.fs.setSetting('familyApps.rewards.v1', { version: 1, enabled: true, tokensPerTicket: 3, weeklyCap: 4, rewards: [{ id: 'pet', emoji: '🐾', text: 'Walk with the dog' }], wallet: { appsInSet: ['math', 'music'], costs: { pet: 2 } } });
  g.fs.setSetting('familyApps.look.v1', { v: 1, skin: 'grove' });
  g.fs.setSetting('familyApps.anthropicKey.v1', 'sk-ant-test-123');
  g.fs.setSetting('mathArena.v3.schoolSync.v1', { v: 1, programs: [{ id: 'p', label: 'Class', day: 'Sat', time: '9:00' }], weeks: [], books: [], focus: [], methods: [], importedAt: 1 });
  await g.fs.syncNow();
  const rows = be.app.shim.sheetRows('data').slice(1);
  const keyRow = rows.find((r) => r[0] === 'familyApps.anthropicKey.v1');
  ok(keyRow && String(keyRow[8]).indexOf('sk-ant') < 0 && /^~fsenc1:/.test(keyRow[8]), 'encrypted at rest');
  const kid = device(be);
  const FW = freshWallet(kid.store);
  kid.fs.configure({ wallet: FW });
  kid.store.setItem('mathArena.v3.schoolSync.v1', JSON.stringify({ v: 1, programs: [], done: { 'x-0': { doneAt: 1 } } }));
  const rep = await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  eq(kid.fs.role(), 'kid');
  eq(kid.store.getItem('familyApps.anthropicKey.v1'), 'sk-ant-test-123', 'plain string for the apps');
  eq(JSON.parse(kid.store.getItem('familyApps.look.v1')).skin, 'grove'); eq(kid.store.getItem('hyruleKit.skin'), 'grove');
  ok(kid.fs.pinIsSet() && (await kid.fs.checkPin('1357')) && !(await kid.fs.checkPin('0000')), 'family PIN works on his laptop');
  eq(JSON.parse(kid.store.getItem('mathArena.v3.schoolSync.v1')).done, { 'x-0': { doneAt: 1 } }, 'done marks kept');
  eq(FW.settings().appsInSet, ['math', 'music'], 'wallet settings applied through FamilyWallet');
  eq(FW.settings().costs, { pet: 2 });
  ok(rep.settings.includes('familyApps.pin.v1')); void pin;
});
await test('kid progress reaches the grown-up mirror; summary written only on the kid device', async () => {
  const { be, g } = await family();
  const kid = device(be);
  const FW = freshWallet(kid.store);
  kid.fs.configure({ wallet: FW });
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  FW.finishUnit('math', 'lesson'); FW.beatBoss('music', 'boss');
  ok(kid.fs.writeSummary('math', { week: { lessons: 3, mastered: 2, readAccuracy: 87.5 }, total: { mastered: 9 } }));
  ok(!g.fs.writeSummary('math', { week: { lessons: 1 } }), 'grown-up never writes a summary');
  await kid.fs.syncNow();
  await g.fs.syncNow();
  const m = g.fs.mirror();
  eq(m.items['familyApps.wallet.v1'].value.totals.math.earned, 2);
  eq(m.items['familyApps.summary.math.v1'].value.week.readAccuracy, 87.5);
  ok(m.devices.some((d) => d.role === 'kid' && d.kidWriter), 'device list shows his laptop');
  ok(!g.store.getItem('familyApps.wallet.v1'), 'his wallet is not written into the grown-up practice copy');
});
await test('approval + adjust are applied exactly once (repeat calls, a second device instance, re-pull)', async () => {
  const { be, g } = await family();
  const kid = device(be);
  const FW = freshWallet(kid.store);
  kid.fs.configure({ wallet: FW });
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  for (let i = 0; i < 4; i++) FW.finishUnit('math', 'l' + i);
  for (const a of ['language', 'code', 'music']) for (let i = 0; i < 2; i++) FW.finishUnit(a, 'l' + i);
  const claim = FW.claim('youtube', 'math');
  ok(claim && claim.ok !== false, 'claimed a ticket');
  const ticket = FW.tickets()[0];
  await kid.fs.syncNow(); await g.fs.syncNow();
  const tk = g.fs.mirror().items['familyApps.tickets.v1'].value;
  eq(tk[0].status, 'earned');
  const before = FW.balance().math;
  g.fs.request('approve', { ticketId: ticket.id });
  g.fs.request('adjust', { app: 'math', amount: 2, reason: 'Great week' });
  g.fs.request('adjust', { app: 'rupees', amount: 25, reason: 'Helped at home' });
  await g.fs.syncNow();
  await kid.fs.syncNow();
  await kid.fs.applyParentRequests(); await kid.fs.applyParentRequests();
  const twin = FSmod.__new(); twin.configure({ storage: kid.store, transport: be.transport, locks: null, win: null, channel: null, wallet: FW, online: () => true, visible: () => true });
  await twin.applyParentRequests(); await twin.syncNow(); await kid.fs.syncNow();
  eq(FW.balance().math, before + 2, 'adjust once');
  eq(FW.events({ limit: 100 }).filter((e) => e.kind === 'rupee' && e.reason === 'Helped at home').length, 1, 'rupees once');
  eq(FW.tickets().find((t) => t.id === ticket.id).status, 'used');
  await g.fs.syncNow();
  const done = g.fs.mirror().items['familyApps.requestsDone.v1'].value.done;
  eq(Object.keys(done).length, 3); ok(Object.values(done).every((d) => d.ok));
});
await test('first connect: cloud empty -> uploads his local progress', async () => {
  const { be, g } = await family();
  const kid = device(be);
  const FW = freshWallet(kid.store);
  FW.finishUnit('code', 'x');
  kid.store.setItem('codeQuest.progress.v1', '{"lessons":5}');
  kid.fs.configure({ wallet: FW });
  const rep = await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  ok(rep.uploaded.includes('family') && rep.uploaded.includes('code'));
  const keys = be.app.shim.sheetRows('data').slice(1).map((r) => r[0]);
  ok(keys.includes('familyApps.wallet.v1') && keys.includes('codeQuest.progress.v1'));
});
await test('single writer: a kid device never pushes settings, a grown-up never pushes progress', async () => {
  const { be, g } = await family();
  const kid = device(be);
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  kid.store.setItem('familyApps.look.v1', '{"v":1,"skin":"grove"}');
  g.store.setItem('familyApps.wallet.v1', '{"totals":{}}');
  await kid.fs.syncNow(); await g.fs.syncNow();
  const rows = be.app.shim.sheetRows('data').slice(1);
  ok(!rows.some((r) => r[0] === 'familyApps.look.v1'), 'kid did not push a setting');
  ok(!rows.some((r) => r[0] === 'familyApps.wallet.v1'), 'grown-up did not push progress');
});
await test('drift repair: a local edit of a family setting on his laptop is put back on the next start', async () => {
  const { be, g } = await family();
  g.fs.setSetting('familyApps.look.v1', { v: 1, skin: 'hyrule' });
  await g.fs.syncNow();
  const kid = device(be);
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  kid.store.setItem('familyApps.look.v1', '{"v":1,"skin":"grove"}');
  const again = FSmod.__new(); again.configure({ storage: kid.store, transport: be.transport, locks: null, win: null, channel: null, wallet: null, online: () => true, visible: () => true });
  await again._t.cycle({ first: true });
  eq(JSON.parse(kid.store.getItem('familyApps.look.v1')).skin, 'hyrule');
});
await test('offline: changes queue up and go out when the backend is back (backoff, no loss)', async () => {
  const { be, g } = await family();
  let down = false;
  const flaky = (e, b) => (down ? Promise.reject(Object.assign(new Error('net'), { code: 'network' })) : be.transport(e, b));
  const kid = device(be, { transport: flaky });
  const FW = freshWallet(kid.store);
  kid.fs.configure({ wallet: FW });
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  down = true;
  FW.finishUnit('language', 'offline lesson');
  await kid.fs.syncNow();
  eq(kid.fs.status().state, 'offline'); ok(kid.fs.status().pending > 0);
  down = false;
  await kid.fs.syncNow();
  eq(kid.fs.status().pending, 0);
  await g.fs.syncNow();
  eq(g.fs.mirror().items['familyApps.wallet.v1'].value.totals.language.earned, 2);
});
await test('Apps Script URL: family id = deployment id; the join link has just id.secret', async () => {
  const be = backend();
  const g = device(be);
  await g.fs.createFamily({ endpoint: AKFY });
  const link = g.fs.joinLink('https://sina2jp.github.io/family/');
  ok(/^https:\/\/sina2jp\.github\.io\/family\/#join=AKfycbTEST[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{22}$/.test(link), link);
  eq(FSmod.parseJoin(link).endpoint, AKFY);
  ok(link.length < 120, 'short enough for a QR code: ' + link.length);
});
await test('lease fallback (no navigator.locks) serialises two tabs; requests still applied once', async () => {
  const { be, g } = await family();
  const kid = device(be);
  const FW = freshWallet(kid.store);
  kid.fs.configure({ wallet: FW });
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  FW.finishUnit('math', 'x');
  g.fs.request('adjust', { app: 'math', amount: 3, reason: 'Bonus' });
  await g.fs.syncNow();
  const tab2 = FSmod.__new(); tab2.configure({ storage: kid.store, transport: be.transport, locks: null, win: null, channel: null, wallet: FW, online: () => true, visible: () => true });
  await Promise.all([kid.fs.syncNow(), tab2.syncNow()]);
  await Promise.all([kid.fs.applyParentRequests(), tab2.applyParentRequests()]);
  eq(FW.events({ limit: 50 }).filter((e) => e.kind === 'adjust').length, 1);
});


// ---------------- 1.0.1 ----------------
await test('1.0.1: going back to the last synced value also clears "too big"', async () => {
  const { be, g } = await family();
  const kid = device(be);
  kid.store.setItem('musicQuest.v1', JSON.stringify({ lessons: 3 }));
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  await kid.fs.syncNow();
  const orig = kid.store.getItem('musicQuest.v1');
  kid.store.setItem('musicQuest.v1', 'z'.repeat(300001));
  await kid.fs.syncNow();
  eq(kid.fs.status().paused, 'too-big');
  kid.store.setItem('musicQuest.v1', orig);
  await kid.fs.syncNow(); await kid.fs.syncNow();
  eq(kid.fs.status().state, 'synced'); eq(kid.fs.status().tooBig, []); eq(kid.fs.status().pending, 0);
});
async function guardSetup() {
  let clock = Date.now();
  const be = backend();
  const g = device(be, { now: () => clock });
  await g.fs.createFamily({ endpoint: ENDPOINT });
  const big = JSON.stringify({ lessons: Array.from({ length: 40 }, (_, i) => 'lesson-' + i) });
  const small = JSON.stringify({ lessons: ['lesson-0'] });
  const k1 = device(be, { now: () => clock });
  k1.store.setItem('musicQuest.v1', big);
  await k1.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  const k2 = device(be, { now: () => clock });
  k2.store.setItem('musicQuest.v1', small);
  const rep = await k2.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  const cloud = () => { const r = be.app.shim.sheetRows('data').find((x) => x[0] === 'musicQuest.v1'); return r && be.app._joinValue(r); };
  return { be, g, k2, big, small, rep, cloud, tick: (ms) => { clock += ms; } };
}
await test('1.0.1 guard: a stale overwrite in the first minute after a cloud download is held back and the cloud copy restored', async () => {
  const { k2, big, small, rep, cloud } = await guardSetup();
  ok(rep.downloaded.includes('music'), JSON.stringify(rep));
  eq(k2.store.getItem('musicQuest.v1'), big);
  const seen = [];
  k2.fs.onUpdate((d) => seen.push(d));
  k2.store.setItem('musicQuest.v1', small); // an app saving its stale in-memory copy
  await k2.fs.syncNow();
  eq(cloud(), big, 'cloud keeps the downloaded copy');
  eq(k2.store.getItem('musicQuest.v1'), big, 'local copy restored');
  ok(k2.fs.log().some((l) => l.kind === 'guard' && /held back/.test(l.note)) && k2.fs.log().some((l) => /restored/.test(l.note)), JSON.stringify(k2.fs.log()));
  ok(seen.some((d) => d.source === 'guard' && d.keys.includes('musicQuest.v1')), 'apps are told to re-read');
});
await test('1.0.1 guard: real new progress on top of the download goes up at once', async () => {
  const { k2, big, cloud } = await guardSetup();
  const more = JSON.stringify({ lessons: JSON.parse(big).lessons.concat(['new-lesson']) });
  k2.store.setItem('musicQuest.v1', more);
  await k2.fs.syncNow();
  eq(cloud(), more);
  eq(k2.fs.log().filter((l) => l.kind === 'guard').length, 0);
});
await test('1.0.1 guard: after the first minute a smaller value is a normal change and is pushed', async () => {
  const { k2, small, cloud, tick } = await guardSetup();
  tick(61000);
  k2.store.setItem('musicQuest.v1', small);
  await k2.fs.syncNow();
  eq(cloud(), small);
});
await test('1.0.1 guard: pagehide flush (keepalive) never sends a held-back value', async () => {
  const { be, k2, small } = await guardSetup();
  const sent = [];
  k2.fs.configure({ transport: (e, b, o) => { if (o && o.keepalive) sent.push(b); return be.transport(e, b); } });
  k2.store.setItem('musicQuest.v1', small);
  k2.store.setItem('familyApps.walletTime.v1', JSON.stringify({ days: { '2026-11-27': { music: 60000 } } }));
  k2.fs.flush();
  const keys = sent.flatMap((b) => (b.items || []).map((i) => i.key));
  ok(keys.includes('familyApps.walletTime.v1'), 'the flush did send the other change: ' + keys.join(','));
  ok(!keys.includes('musicQuest.v1'), 'held-back value not sent: ' + keys.join(','));
});
await test('1.0.1 guard: not armed when his local copy won (uploaded), so nothing is held', async () => {
  const { be, g } = await family();
  const kid = device(be);
  kid.store.setItem('musicQuest.v1', JSON.stringify({ a: [1, 2, 3] }));
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  kid.store.setItem('musicQuest.v1', JSON.stringify({ a: [1] }));
  await kid.fs.syncNow();
  eq(be.app._joinValue(be.app.shim.sheetRows('data').find((x) => x[0] === 'musicQuest.v1')), JSON.stringify({ a: [1] }));
});


// ======================= 1.1: several kid laptops =======================
const CODE10 = fs.readFileSync(path.join(ROOT, 'legacy', 'Code-1.0.gs'), 'utf8');
const FS100path = path.join(ROOT, 'legacy', 'family-sync-1.0.0.js');
function legacyFS() { delete require.cache[require.resolve(FS100path)]; return require(FS100path).__new(); }
function backendFrom(source, opts) {
  const app = loadCodeGs(source, opts);
  const be = { app, calls: [], transport: null };
  be.transport = (endpoint, body) => { be.calls.push(body.op); return Promise.resolve(be.app.handle(JSON.parse(JSON.stringify(body)))); };
  be.swap = (src) => { be.app = loadCodeGs(src, { shim: be.app.shim }); }; // a server update: same Sheet, new code
  return be;
}
function laptop(be, extra) {
  const d = device(be, extra);
  d.FW = freshWallet(d.store);
  d.fs.configure({ wallet: d.FW });
  return d;
}
const cloudVal = (be, key) => { const r = be.app.shim.sheetRows('data').find((x) => x[0] === key); return r ? be.app._joinValue(r) : null; };
const sumMinutes = (raw, app) => { const t = JSON.parse(raw || '{"days":{}}'); let n = 0; for (const d of Object.values(t.days)) n += d[app] || 0; return n; };
const auth0 = async (store) => { const c = JSON.parse(store.getItem('familyApps.sync.v1')); return { c, auth: (await FSmod._t.familyKeys(c.secret)).auth }; };

await test('1.1 server: many kid laptops may write; the role rule stays (kid keys only from kid, settings only from grown-up)', async () => {
  const { be, g } = await family();
  const { c, auth } = await auth0(g.store);
  const base = { v: 1, familyId: c.familyId, auth, op: 'put' };
  ok(be.app.handle({ ...base, device: { id: 'd-kidA', role: 'kid' }, items: [{ key: 'familyApps.wallet.v1', value: '1', baseRev: 0 }] }).ok);
  const r = be.app.handle({ ...base, device: { id: 'd-kidB', role: 'kid' }, items: [{ key: 'familyApps.tickets.v1', value: '[]', baseRev: 0 }] });
  ok(r.ok && !r.error && r.revs['familyApps.tickets.v1'] > 0, 'a second kid laptop writes without claiming: ' + JSON.stringify(r));
  eq(be.app.handle({ ...base, device: { id: 'd-kidB', role: 'kid' }, items: [{ key: 'familyApps.look.v1', value: 'x' }] }).refused, {}, 'unknown row: role is set by the first writer');
  eq(be.app.handle({ ...base, device: { id: 'd-g', role: 'grownup' }, items: [{ key: 'familyApps.wallet.v1', value: '2' }] }).refused['familyApps.wallet.v1'], 'wrong-role');
});
await test('1.1 server: baseRev conflicts return the current value; the same value or the right baseRev pass', async () => {
  const { be, g } = await family();
  const { c, auth } = await auth0(g.store);
  const put = (dev, items) => be.app.handle({ v: 1, familyId: c.familyId, auth, op: 'put', device: { id: dev, role: 'kid' }, items });
  const r1 = put('d-A', [{ key: 'familyApps.wallet.v1', value: 'A1', baseRev: 0 }]);
  const rev1 = r1.revs['familyApps.wallet.v1'];
  const r2 = put('d-B', [{ key: 'familyApps.wallet.v1', value: 'B1', baseRev: 0 }]);
  eq(r2.refused['familyApps.wallet.v1'], 'conflict');
  eq(r2.conflicts['familyApps.wallet.v1'].value, 'A1'); eq(r2.conflicts['familyApps.wallet.v1'].rev, rev1); eq(r2.conflicts['familyApps.wallet.v1'].device, 'd-A');
  eq(put('d-B', [{ key: 'familyApps.wallet.v1', value: 'A1', baseRev: 0 }]).revs['familyApps.wallet.v1'], rev1, 'same value: no conflict');
  const r3 = put('d-B', [{ key: 'familyApps.wallet.v1', value: 'B2', baseRev: rev1 }]);
  ok(r3.revs['familyApps.wallet.v1'] > rev1 && !r3.refused['familyApps.wallet.v1']);
  eq(cloudVal(be, 'familyApps.wallet.v1'), 'B2');
});
await test('1.1 server: a legacy item (no baseRev) may not overwrite another laptop\u2019s value ("stale"); its own line still works', async () => {
  const { be, g } = await family();
  const { c, auth } = await auth0(g.store);
  const put = (dev, items) => be.app.handle({ v: 1, familyId: c.familyId, auth, op: 'put', device: { id: dev, role: 'kid' }, items });
  ok(put('d-old', [{ key: 'musicQuest.v1', value: 'old-1' }]).revs['musicQuest.v1'] > 0, 'new row');
  ok(put('d-old', [{ key: 'musicQuest.v1', value: 'old-2' }]).revs['musicQuest.v1'] > 0, 'same device continues');
  const rb = put('d-new', [{ key: 'musicQuest.v1', value: 'new-3', baseRev: put('d-new', []).rev && be.app.handle({ v: 1, familyId: c.familyId, auth, op: 'get', keys: ['musicQuest.v1'] }).items[0].rev }]);
  ok(!rb.refused['musicQuest.v1'], JSON.stringify(rb));
  const rs = put('d-old', [{ key: 'musicQuest.v1', value: 'old-4' }]);
  eq(rs.refused['musicQuest.v1'], 'stale'); eq(rs.conflicts['musicQuest.v1'].value, 'new-3');
  eq(cloudVal(be, 'musicQuest.v1'), 'new-3', 'the legacy tab did not clobber the newer value');
});
await test('1.1 server: the device list has lastPush and the version; every kid laptop shows as current', async () => {
  const { be, g } = await family();
  const A = laptop(be), B = laptop(be);
  await A.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  await B.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  A.FW.finishUnit('math', 'x');
  await A.fs.syncNow(); await g.fs.syncNow();
  const devs = g.fs.mirror().devices.filter((d) => d.role === 'kid');
  eq(devs.length, 2);
  ok(devs.every((d) => d.kidWriter === true && /^1\.1\.0/.test(d.version)), JSON.stringify(devs));
  ok(devs.find((d) => d.id === A.fs.config().deviceId).lastPush, 'A pushed');
});
await test('1.1: A -> B -> A, his progress follows him (adopted with source "pull", apps told about their own keys)', async () => {
  const { be, g } = await family();
  const A = laptop(be), B = laptop(be);
  await A.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  await B.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  const seenB = [], seenA = [];
  B.fs.onUpdate((d) => seenB.push(d)); A.fs.onUpdate((d) => seenA.push(d));
  A.FW.finishUnit('math', 'A1'); A.store.setItem('mathArena.v3.data.v1', JSON.stringify({ solved: [1, 2, 3] }));
  await A.fs.syncNow();
  await B.fs.syncNow();
  eq(B.FW.balance().math, 2, 'B has A\u2019s shards'); eq(B.store.getItem('mathArena.v3.data.v1'), JSON.stringify({ solved: [1, 2, 3] }));
  ok(seenB.some((d) => d.source === 'pull' && d.keys.includes('mathArena.v3.data.v1') && d.keys.includes('familyApps.wallet.v1')), JSON.stringify(seenB));
  B.FW.finishUnit('music', 'B1'); B.store.setItem('mathArena.v3.data.v1', JSON.stringify({ solved: [1, 2, 3, 4, 5] }));
  await B.fs.syncNow();
  await A.fs.syncNow();
  eq(A.FW.balance().music, 2); eq(A.FW.balance().math, 2); eq(JSON.parse(A.store.getItem('mathArena.v3.data.v1')).solved.length, 5);
  ok(seenA.some((d) => d.source === 'pull' && d.keys.includes('mathArena.v3.data.v1')));
  A.FW.finishUnit('code', 'A2');
  await A.fs.syncNow(); await B.fs.syncNow();
  eq(B.FW.balance().code, 2);
  eq(B.FW.events({ limit: 50 }).length, 6, 'three lessons = six events (shards + rupees each), none doubled');
  ok(!B.fs.log().some((l) => l.kind === 'merge'), 'no merges were needed: ' + JSON.stringify(B.fs.log()));
});
await test('1.1: both laptops offline, then online: wallet union, tickets/inventory union, minutes counted once, app loser backed up', async () => {
  const { be, g } = await family();
  let down = false;
  const flaky = (e, b) => (down ? Promise.reject(Object.assign(new Error('net'), { code: 'network' })) : be.transport(e, b));
  const A = laptop(be, { transport: flaky }), B = laptop(be, { transport: flaky });
  await A.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  await B.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  for (let i = 0; i < 5; i++) A.FW.tickActive('math', 120000); // 10 min = 1 shard, shared history
  A.FW.finishUnit('math', 'shared'); A.store.setItem('codeQuest.progress.v1', JSON.stringify({ lessons: ['l1'] }));
  await A.fs.syncNow(); await B.fs.syncNow();
  eq(sumMinutes(B.store.getItem('familyApps.walletTime.v1'), 'math'), 600000);
  down = true;
  for (let i = 0; i < 5; i++) A.FW.tickActive('math', 120000); // +10 min on A
  A.FW.finishUnit('language', 'A offline');
  for (let i = 0; i < 4; i++) B.FW.tickActive('math', 120000); // +8 min on B
  B.FW.finishUnit('music', 'B offline');
  A.store.setItem('familyApps.tickets.v1', JSON.stringify([{ id: 'tA', app: 'math', rewardId: 'youtube', rewardText: 'YouTube', earnedAt: '2026-11-27T10:00:00Z', status: 'earned' }]));
  B.store.setItem('familyApps.tickets.v1', JSON.stringify([{ id: 'tB', app: 'music', rewardId: 'pet', rewardText: 'Pet', earnedAt: '2026-11-27T10:05:00Z', status: 'earned' }]));
  A.store.setItem('codeQuest.progress.v1', JSON.stringify({ lessons: ['l1', 'l2', 'l3'] })); // A did more Code
  B.store.setItem('codeQuest.progress.v1', JSON.stringify({ lessons: ['l1', 'x'] }));
  A.store.setItem('familyApps.inventory.v1', JSON.stringify({ owned: ['bg.a'], equipped: {}, updatedAt: '2026-11-27T10:00:00Z' }));
  B.store.setItem('familyApps.inventory.v1', JSON.stringify({ owned: ['bg.b'], equipped: { background: 'bg.b' }, updatedAt: '2026-11-27T11:00:00Z' }));
  await A.fs.syncNow(); await B.fs.syncNow();
  eq(A.fs.status().state, 'offline');
  down = false;
  await A.fs.syncNow(); await B.fs.syncNow(); await A.fs.syncNow(); await B.fs.syncNow();
  for (const L of [A, B]) {
    const reasons = L.FW.events({ limit: 100 }).map((e) => e.reason);
    ok(['shared', 'A offline', 'B offline'].every((r) => reasons.includes(r)), JSON.stringify(reasons));
    eq(L.FW.balance().language, 2); eq(L.FW.balance().music, 2);
    eq(sumMinutes(L.store.getItem('familyApps.walletTime.v1'), 'math'), 600000 + 600000 + 480000, 'minutes: shared once + A + B');
    eq(L.FW.tickets().map((x) => x.id).sort(), ['tA', 'tB']);
    eq(JSON.parse(L.store.getItem('familyApps.inventory.v1')).owned.sort(), ['bg.a', 'bg.b']);
    eq(JSON.parse(L.store.getItem('familyApps.inventory.v1')).equipped.background, 'bg.b');
    eq(JSON.parse(L.store.getItem('codeQuest.progress.v1')).lessons.length, 3, 'the copy with more progress wins');
  }
  eq(cloudVal(be, 'familyApps.wallet.v1'), A.store.getItem('familyApps.wallet.v1'), 'cloud = A = B');
  eq(A.store.getItem('familyApps.wallet.v1'), B.store.getItem('familyApps.wallet.v1'));
  const bk = JSON.parse(cloudVal(be, 'familyApps.backup.code.v1'));
  ok(bk.entries.length === 1 && JSON.parse(bk.entries[0].items['codeQuest.progress.v1']).lessons.includes('x'), 'loser kept in the cloud backup: ' + JSON.stringify(bk));
  ok(B.fs.log().some((l) => l.kind === 'merge' && l.key === 'code' && /backup/.test(l.note)), JSON.stringify(B.fs.log()));
  const before = sumMinutes(A.store.getItem('familyApps.walletTime.v1'), 'math');
  await A.fs.syncNow(); await B.fs.syncNow(); await A.fs.syncNow();
  eq(sumMinutes(A.store.getItem('familyApps.walletTime.v1'), 'math'), before, 'repeated syncs never add minutes again');
});
await test('1.1: a legacy 1.0.0 tab left open on laptop A cannot clobber newer progress from laptop B', async () => {
  const { be, g } = await family();
  const A = laptop(be), B = laptop(be);
  await A.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  A.store.setItem('musicQuest.v1', JSON.stringify({ lessons: 1 }));
  await A.fs.syncNow();
  await B.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  const oldTab = legacyFS(); // the old app build still open on A: same storage, 1.0.0 module
  oldTab.configure({ storage: A.store, transport: be.transport, locks: null, win: null, channel: null, wallet: null, online: () => true, visible: () => true });
  B.store.setItem('musicQuest.v1', JSON.stringify({ lessons: 7 }));
  await B.fs.syncNow();
  A.store.setItem('musicQuest.v1', JSON.stringify({ lessons: 2 })); // the stale tab saves its in-memory copy
  await oldTab._t.cycle({ force: true });
  eq(JSON.parse(cloudVal(be, 'musicQuest.v1')).lessons, 7, 'B\u2019s newer progress survives the legacy tab');
  await A.fs.syncNow(); // the 1.1 module on A then merges: the higher progress wins, the stale copy goes to the backup
  eq(JSON.parse(A.store.getItem('musicQuest.v1')).lessons, 7);
  ok(JSON.parse(cloudVal(be, 'familyApps.backup.music.v1')).entries.some((e) => JSON.parse(e.items['musicQuest.v1']).lessons === 2));
});
await test('1.1: a second laptop joins with its own local play: both are kept (wallet union, minutes add up, app score + backup)', async () => {
  const { be, g } = await family();
  const A = laptop(be);
  await A.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  for (let i = 0; i < 5; i++) A.FW.tickActive('math', 120000);
  A.FW.finishUnit('math', 'A play'); A.store.setItem('langQuest.state', JSON.stringify({ es: { words: 40 } }));
  await A.fs.syncNow();
  const B = laptop(be); // today's play on B before it was connected
  for (let i = 0; i < 3; i++) B.FW.tickActive('math', 120000);
  B.FW.finishUnit('code', 'B play'); B.store.setItem('langQuest.state', JSON.stringify({ es: { words: 5 } }));
  const rep = await B.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  const reasons = B.FW.events({ limit: 50 }).map((e) => e.reason);
  ok(reasons.includes('A play') && reasons.includes('B play'), JSON.stringify(reasons));
  eq(B.FW.balance().code, 2); eq(B.FW.balance().math >= 2, true);
  eq(sumMinutes(B.store.getItem('familyApps.walletTime.v1'), 'math'), 600000 + 360000, 'separate laptops: the minutes add up');
  eq(JSON.parse(B.store.getItem('langQuest.state')).es.words, 40, 'the copy with more progress wins');
  ok(JSON.parse(cloudVal(be, 'familyApps.backup.language.v1')).entries.some((e) => JSON.parse(e.items['langQuest.state']).es.words === 5), 'B\u2019s smaller copy is in the 30-day backup');
  ok(rep.merged.includes('familyApps.wallet.v1') && rep.backups.includes('language'), JSON.stringify(rep));
  await A.fs.syncNow();
  ok(A.FW.events({ limit: 50 }).some((e) => e.reason === 'B play'), 'A gets B\u2019s play');
  eq(A.store.getItem('familyApps.wallet.v1'), B.store.getItem('familyApps.wallet.v1'));
});
await test('1.1: a parent adjustment applied by two laptops before they sync counts once', async () => {
  const { be, g } = await family();
  let down = false;
  const flaky = (e, b) => (down ? Promise.reject(Object.assign(new Error('net'), { code: 'network' })) : be.transport(e, b));
  const A = laptop(be, { transport: flaky }), B = laptop(be, { transport: flaky });
  await A.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  await B.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  A.FW.finishUnit('math', 'x'); await A.fs.syncNow(); await B.fs.syncNow();
  g.fs.request('adjust', { app: 'math', amount: 3, reason: 'Great week' });
  g.fs.request('adjust', { app: 'rupees', amount: 20, reason: 'Helped at home' });
  await g.fs.syncNow();
  await A.fs.syncNow(); await B.fs.syncNow(); // both pulled the requests ...
  down = true;
  await A.fs.applyParentRequests(); await B.fs.applyParentRequests(); // ... and applied them offline
  down = false;
  await A.fs.syncNow(); await B.fs.syncNow(); await A.fs.syncNow();
  for (const L of [A, B]) {
    eq(L.FW.events({ limit: 100 }).filter((e) => e.reason === 'Great week').length, 1);
    eq(L.FW.events({ limit: 100 }).filter((e) => e.reason === 'Helped at home').length, 1);
    eq(L.FW.balance().math, 5);
  }
});
await test('1.1: the 1.0.0 -> 1.1 server swap with live 1.0.0 clients loses nothing', async () => {
  const be = backendFrom(CODE10);
  const g = { store: memStore() }; g.fs = legacyFS(); g.fs.configure({ storage: g.store, transport: be.transport, locks: null, win: null, channel: null, wallet: null, online: () => true, visible: () => true });
  await g.fs.createFamily({ endpoint: ENDPOINT });
  const old = { store: memStore() }; old.FW = freshWallet(old.store); old.fs = legacyFS();
  old.fs.configure({ storage: old.store, transport: be.transport, locks: null, win: null, channel: null, wallet: old.FW, online: () => true, visible: () => true });
  await old.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  old.FW.finishUnit('math', 'before the update'); old.store.setItem('mathArena.v3.data.v1', JSON.stringify({ solved: [1, 2] }));
  g.fs.setSetting('familyApps.look.v1', { v: 1, skin: 'grove' });
  await old.fs._t.cycle({ force: true }); await g.fs._t.cycle({ force: true });
  const walletBefore = cloudVal(be, 'familyApps.wallet.v1');
  be.swap(CODE); // the parent's Claude: Manage deployments -> Edit -> New version
  eq(cloudVal(be, 'familyApps.wallet.v1'), walletBefore, 'data unchanged by the swap');
  old.FW.finishUnit('math', 'after the update, old app');
  await old.fs._t.cycle({ force: true });
  ok(/after the update, old app/.test(cloudVal(be, 'familyApps.wallet.v1')), 'a 1.0.0 kid laptop keeps syncing its own line');
  g.fs.setSetting('familyApps.rewards.v1', { version: 1, weeklyCap: 3, rewards: [{ id: 'r', emoji: '🎁', text: 'Movie' }] });
  await g.fs._t.cycle({ force: true });
  ok(/Movie/.test(cloudVal(be, 'familyApps.rewards.v1')), 'a 1.0.0 Hub keeps working');
  const B = laptop(be);
  B.FW.finishUnit('code', 'new laptop');
  await B.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  const reasons = B.FW.events({ limit: 50 }).map((e) => e.reason);
  ok(['before the update', 'after the update, old app', 'new laptop'].every((r) => reasons.includes(r)), JSON.stringify(reasons));
  old.FW.finishUnit('math', 'old app, after B');
  await old.fs._t.cycle({ force: true });
  ok(!/old app, after B/.test(cloudVal(be, 'familyApps.wallet.v1')), 'the 1.0.0 laptop cannot overwrite B\u2019s newer wallet');
  ok(/new laptop/.test(cloudVal(be, 'familyApps.wallet.v1')));
  const up = FSmod.__new(); // the old laptop's apps update to 1.1: its unsynced play merges in
  up.configure({ storage: old.store, transport: be.transport, locks: null, win: null, channel: null, wallet: old.FW, online: () => true, visible: () => true });
  await up.syncNow(); await up.syncNow();
  ok(['old app, after B', 'new laptop', 'before the update'].every((r) => cloudVal(be, 'familyApps.wallet.v1').includes(r)), cloudVal(be, 'familyApps.wallet.v1').slice(0, 300));
  eq(JSON.parse(old.store.getItem('familyApps.look.v1')).skin, 'grove');
});
await test('1.1: a laptop 1.0.x marked "replaced" (paused: not-writer) resumes by itself after the update', async () => {
  const { be, g } = await family();
  const A = laptop(be);
  await A.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  const st = JSON.parse(A.store.getItem('familyApps.sync.state.v1'));
  st.paused = 'not-writer'; st.lastError = 'Another laptop is now his main device.';
  A.store.setItem('familyApps.sync.state.v1', JSON.stringify(st));
  A.FW.finishUnit('music', 'while replaced');
  const up = FSmod.__new();
  up.configure({ storage: A.store, transport: be.transport, locks: null, win: null, channel: null, wallet: A.FW, online: () => true, visible: () => true });
  await up.syncNow();
  ok(up.status().state === 'synced' && !up.status().paused, JSON.stringify(up.status()));
  ok(/while replaced/.test(cloudVal(be, 'familyApps.wallet.v1')));
});
await test('1.1: a slow first pull keeps "syncing…" and retries before it says offline', async () => {
  const { be, g } = await family();
  let first = true;
  const slow = (e, b) => { if (b.op === 'get' && first) { first = false; return Promise.reject(Object.assign(new Error('t'), { code: 'timeout' })); } return be.transport(e, b); };
  const A = laptop(be);
  await A.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  const re = FSmod.__new();
  const states = [];
  re.configure({ storage: A.store, transport: slow, locks: null, win: null, channel: null, wallet: A.FW, online: () => true, visible: () => true });
  re.onStatus((s) => states.push(s.state));
  const s1 = await re._t.cycle({ first: true });
  eq(s1.state, 'syncing');
  await new Promise((r) => setTimeout(r, 50));
  await re.syncNow();
  ok(!states.includes('offline') && re.status().state === 'synced', states.join(','));
});
await test('1.1 merges: walletTime 3-way / new laptop / unknown base; wallet caps, once-a-day bonus and request refs', () => {
  const t = FSmod._t, D = (o) => JSON.stringify({ days: o });
  eq(JSON.parse(t.mergeTime(D({ d1: { math: 30 } }), D({ d1: { math: 25 } }), D({ d1: { math: 20 } }))).days.d1.math, 35, '3-way');
  eq(JSON.parse(t.mergeTime(D({ d1: { math: 30 } }), D({ d1: { math: 25 }, d0: { code: 5 } }), null)).days, { d1: { math: 55 }, d0: { code: 5 } }, 'new laptop adds up, keeps every day');
  eq(JSON.parse(t.mergeTime(D({ d1: { math: 30 } }), D({ d1: { math: 25 } }), undefined)).days.d1.math, 30, 'unknown base: no double counting');
  const ev = (id, o) => ({ id, app: 'math', kind: 'progress', amount: 2, reason: id, at: '2026-11-27T10:00:00Z', ...o });
  const W = (events) => { const totals = { math: { earned: 0, spent: 0 }, rupees: { earned: 0, spent: 0 } }; for (const e of events) { const b = e.kind === 'rupee' ? 'rupees' : e.app; totals[b] = totals[b] || { earned: 0, spent: 0 }; if (e.amount >= 0) totals[b].earned += e.amount; else totals[b].spent -= e.amount; } return JSON.stringify({ version: 1, settings: { dailyTimeCap: 6, comebackDailyCap: 3 }, totals, events, updatedAt: '2026-11-27T10:00:00Z' }); };
  const a = W([ev('s'), ev('a1'), ev('t1', { kind: 'time', tag: 'time', amount: 4 }), ev('tf1', { kind: 'rupee', tag: 'triforceDay', amount: 50 }), ev('p1', { kind: 'adjust', tag: 'parent', amount: 3, ref: 'rq:1' })]);
  const b = W([ev('s'), ev('b1'), ev('t2', { kind: 'time', tag: 'time', amount: 4 }), ev('tf2', { kind: 'rupee', tag: 'triforceDay', amount: 50 }), ev('p2', { kind: 'adjust', tag: 'parent', amount: 3, ref: 'rq:1' })]);
  const m = JSON.parse(t.mergeWallet(a, b));
  eq(m.events.map((e) => e.id).sort(), ['a1', 'b1', 'p1', 's', 't1', 't2', 'tf1'].sort());
  eq(m.events.find((e) => e.id === 't2').amount, 2, 'time shards capped at 6 a day');
  eq(m.totals.math.earned, 2 + 2 + 4 + 3 + 2 + 2, 'totals: X + only the missing events');
  eq(m.totals.rupees.earned, 50, 'one Triforce Day bonus a day');
  eq(t.mergeWallet(a, a), a, 'nothing new: unchanged');
  eq(JSON.parse(t.mergeTickets(JSON.stringify([{ id: 'x', status: 'earned', earnedAt: 1 }, { id: 'y', earnedAt: 2 }]), JSON.stringify([{ id: 'x', status: 'used', earnedAt: 1 }]))).find((x) => x.id === 'x').status, 'used');
  eq(Object.keys(JSON.parse(t.mergeHealth(JSON.stringify({ v: 1, device: 'd-1', at: '2026-01-01', state: 'ok' }), JSON.stringify({ v: 2, devices: { 'd-2': { at: '2026-01-02', state: 'paused' } } }))).devices).sort(), ['d-1', 'd-2']);
});
await test('1.1: "too big" pauses sync on that laptop and the Hub sees each laptop\u2019s health', async () => {
  const { be, g } = await family();
  const A = laptop(be), B = laptop(be);
  await A.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  await B.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  B.store.setItem('musicQuest.v1', 'x'.repeat(300001));
  await B.fs.syncNow(); await B.fs.syncNow(); await A.fs.syncNow(); await A.fs.syncNow(); await B.fs.syncNow();
  eq(B.fs.status().state, 'paused'); eq(B.fs.status().paused, 'too-big'); eq(A.fs.status().state, 'synced');
  await g.fs.syncNow();
  const h = g.fs.mirror().items['familyApps.syncHealth.v1'].value;
  eq(h.v, 2);
  eq(h.devices[B.fs.config().deviceId].paused, 'too-big'); eq(h.devices[A.fs.config().deviceId].state, 'ok');
  ok(!g.store.getItem('familyApps.syncHealth.v1') || true);
  ok(!cloudVal(be, 'musicQuest.v1'), 'the too-big value never reached the Sheet');
});
await test('1.1: opening the family link again on a connected laptop just syncs (no second merge, nothing doubled)', async () => {
  const { be, g } = await family();
  const A = laptop(be);
  await A.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  for (let i = 0; i < 5; i++) A.FW.tickActive('code', 120000);
  await A.fs.syncNow();
  for (let i = 0; i < 2; i++) A.FW.tickActive('code', 120000);
  const rep = await A.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  ok(rep.again, JSON.stringify(rep));
  eq(sumMinutes(A.store.getItem('familyApps.walletTime.v1'), 'code'), 840000);
  eq(sumMinutes(cloudVal(be, 'familyApps.walletTime.v1'), 'code'), 840000);
});

console.log(results.join('\n'));
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
