# Spanish unit file schema — /tmp/lq/content/es/uNN.json (NN = 01..20)

One JSON object per file, UTF-8, no comments. Validate each file after writing:
  python3 -c "import json,sys; d=json.load(open(sys.argv[1])); print(d['n'], len(d['words']), len(d['phrases']))" /tmp/lq/content/es/u01.json

Example (shortened — real files need the full counts listed below):
{
 "n": 1,
 "theme": "Greetings & feelings",
 "title": "¡Hola, amigos!",
 "titleEn": "Hello, friends!",
 "ican": "I can greet people and say how I feel.",
 "goals": ["I can say hello and goodbye.", "I can ask someone how they are.", "I can say how I feel."],
 "grammar": {
  "name": "Estoy + a feeling",
  "explain": "Say how you feel with estoy (I am): Estoy feliz. Ask a friend: ¿Cómo estás?",
  "examples": [["Estoy feliz.", "I am happy."], ["Estoy cansado.", "I am tired."], ["¿Cómo estás?", "How are you?"]],
  "practice": [
   {"q": "___ feliz.", "en": "I am happy.", "opts": ["Estoy", "Es"], "a": 0,
    "why": ["Estoy means 'I am'", "Es means 'it is'"], "wa": 0, "mt": "verb"}
  ]
 },
 "words": [
  {"es": "hola", "en": "hello", "e": "👋", "ex": "¡Hola, Saria!", "exEn": "Hello, Saria!"},
  {"es": "el amigo", "en": "friend (boy)", "e": "🧒", "g": "m", "ex": "Link es mi amigo.", "exEn": "Link is my friend."},
  {"es": "cansado", "fem": "cansada", "en": "tired", "e": "😴", "ex": "Navi está cansada.", "exEn": "Navi is tired."},
  {"es": "el jugo", "esp": "el zumo", "en": "juice", "e": "🧃", "g": "m", "ex": "Quiero jugo de naranja.", "exEn": "I want orange juice.", "exEsp": "Quiero zumo de naranja."}
 ],
 "phrases": [
  {"es": "¿Cómo estás?", "en": "How are you?", "e": "🙂"},
  {"es": "Mucho gusto.", "en": "Nice to meet you.", "e": "🤝"}
 ],
 "speak": {"task": "Say hello to Saria, tell her your name and how you feel.", "pic": "🧚🌳😀",
           "model": ["¡Hola, Saria!", "Me llamo Link.", "Estoy muy feliz."]},
 "write": {
  "copy": ["Hola, me llamo Link.", "Estoy bien, gracias."],
  "fill": [{"t": "Estoy muy ___.", "a": "bien", "opts": ["bien", "hola", "adiós"], "en": "I am very well.", "mt": "word"}],
  "build": [{"w": ["Me", "llamo", "Link."], "en": "My name is Link."}],
  "one": {"prompt": "Write how you feel today.", "model": "Hoy estoy feliz.", "keys": ["estoy"]},
  "three": {"pic": "🧒👋👧🌞", "prompt": "Write 3 sentences: two friends meet in the morning.",
            "model": ["¡Buenos días!", "¿Cómo estás?", "Estoy bien, gracias."], "keys": ["buenos días", "cómo", "estoy"]}
 },
 "culture": {"title": "A kiss on the cheek", "text": "In many Spanish-speaking countries, friends and family greet each other with one kiss on the right cheek."},
 "role": {"who": "Saria", "lines": [
   {"npc": "¡Hola! ¿Cómo te llamas?", "en": "Hi! What's your name?", "opts": ["Me llamo Link.", "Estoy cansado."], "a": 0}]},
 "boss": {"intro": "A Mad Scrub pops out of the grass! Answer him in Spanish to calm him down.",
          "win": "The Mad Scrub smiles: he only wanted someone to say hi!",
          "lines": [{"q": "¿Cómo estás?", "en": "How are you?", "opts": ["Estoy bien, gracias.", "Me llamo azul.", "Tres, adiós."], "a": 0}]},
 "song": {"title": "Canción del saludo", "lines": [["Hola, hola, ¿cómo estás?", "Hello, hello, how are you?"], ["Muy bien, muy bien, ¿y tú qué tal?", "Very well, very well, and you?"]]}
}

## Required counts per unit
- words: 45 (at least 40), in TEACHING ORDER (most essential first; the first ~15 must suit a K-2 "Sprout" learner).
  Nouns carry their article in "es" and "g": "m"/"f". Adjectives with a distinct feminine form carry "fem".
  Verbs: infinitive in "es" (optionally "yo": first-person form).
- phrases: 15 (at least 12): useful chunks a kid would say; pictured with an emoji.
- every word: "e" = 1 emoji (max 2) that pictures the meaning; "ex" = a short example sentence (4-9 words) using mostly known words; "exEn".
- grammar.examples: 3-4; grammar.practice: 8 items, each 2-3 "opts", "a" = correct option index,
  "why" = 2-3 short reasons where exactly one (index "wa") is the true reason (kid language, <= 8 words each),
  "mt" = mistake type: one of gender | verb | order | spelling | word.
- write.copy 2, write.fill 4 (each with "opts" of 3 and "mt"), write.build 4 (words in correct order; 3-7 tiles),
  write.one 1, write.three 1 ("keys" = words/chunks a good answer would use).
- role.lines: 4-5 turns with the unit's teacher (see units.md); boss.lines: 6 (3 options each, one correct, the
  wrong ones clearly wrong but not silly-random); song.lines: 4-8 ORIGINAL simple, rhythmic, singable lines that
  repeat the unit's words (never lyrics from any existing song).
- culture: 1-3 sentences, real-world facts about Spanish-speaking countries.

## Language rules
- Latin American Spanish (neutral Mexican) by default. Add "esp" (and "exEsp" when the example changes) only where
  Spain clearly uses a different everyday word (zumo, ordenador, coche, patatas, gafas, móvil, melocotón, conducir...).
- Every string must be correct and natural, with all accents, ñ, ü, ¿ and ¡. Use tú (not usted) with kids.
- If you are unsure of anything, add "flag": "<why>" on that item. An independent reviewer will check everything.
- Kid-safe, positive, funny where possible. Examples mostly about the player's real life (family, school, food,
  pets); sometimes use Hyrule characters (Link, Navi, Saria, Zelda, Malon, Darunia, Ruto, Impa, Talon).
- Never write any real child's name. Refer to the learner as "the player" (or use Link in examples).
- Avoid putting a word in your unit if it clearly belongs to another unit's theme (see units.md).
