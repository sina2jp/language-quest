#!/usr/bin/env python3
"""Farsi audio packs for Language Quest.
python3 build_audio.py --items items_fa.json --out /tmp/lq/audio/fa [--voice ganji] [--ls 1.1] [--procs 6]
items: [{"id": "f1abc", "text": "سلام"}, ...]  ->  fa-1.mp3pack ... + fa-index.json
Voice: Piper fa_IR-ganji-medium (chosen by Whisper CER test, see README)."""
import argparse, json, os, sys, time
from multiprocessing import Pool
import numpy as np

VOICE = None
CACHE = "/tmp/lq/tts/cache"

def init(voice, ls):
    global VOICE, CFG
    os.environ.setdefault("OMP_NUM_THREADS", "3")
    from piper import PiperVoice, SynthesisConfig
    VOICE = PiperVoice.load(f"/tmp/lq/tts/voices/fa_IR-{voice}-medium.onnx")
    CFG = SynthesisConfig(length_scale=ls, noise_scale=0.6, noise_w_scale=0.7)

def trim(a, sr, thr=0.012):
    idx = np.where(np.abs(a) > thr)[0]
    if len(idx) == 0: return a
    s = max(0, idx[0] - int(0.02 * sr)); e = min(len(a), idx[-1] + int(0.06 * sr))
    return a[s:e]

def encode_mp3(a, sr):
    import lameenc
    enc = lameenc.Encoder()
    enc.set_bit_rate(32); enc.set_in_sample_rate(sr); enc.set_channels(1); enc.set_quality(2)
    pcm = (np.clip(a, -1, 1) * 32767).astype("<i2").tobytes()
    return bytes(enc.encode(pcm) + enc.flush())

def work(item):
    iid, text = item["id"], item["text"]
    path = f"{CACHE}/{iid}.mp3"
    if os.path.exists(path) and os.path.getsize(path) > 200:
        return iid, path, None
    try:
        chunks = list(VOICE.synthesize(text, syn_config=CFG))
        sr = chunks[0].sample_rate
        a = np.concatenate([c.audio_float_array for c in chunks]).astype(np.float32)
        a = trim(a, sr)
        peak = float(np.max(np.abs(a))) or 1.0
        rms = float(np.sqrt(np.mean(a ** 2))) or 1e-4
        gain = min(0.89 / peak, 0.12 / rms)  # loudness-normalize, never clip
        a = a * gain
        pad = np.zeros(int(0.06 * sr), np.float32)
        a = np.concatenate([pad, a, pad])
        mp3 = encode_mp3(a, sr)
        open(path + ".tmp", "wb").write(mp3); os.replace(path + ".tmp", path)
        return iid, path, None
    except Exception as e:
        return iid, None, repr(e)[:200]

def mp3_ms(b):
    # duration from frame count (MPEG1/2 layer III, CBR-ish); good enough for UI timing
    br_tab = {1: [0,32,40,48,56,64,80,96,112,128,160,192,224,256,320], 2: [0,8,16,24,32,40,48,56,64,80,96,112,128,144,160]}
    sr_tab = {3: [44100, 48000, 32000], 2: [22050, 24000, 16000], 0: [11025, 12000, 8000]}
    i, frames, spf, sr = 0, 0, 1152, 22050
    while i + 4 <= len(b):
        if b[i] == 0xFF and (b[i + 1] & 0xE0) == 0xE0:
            ver = (b[i + 1] >> 3) & 3; bri = (b[i + 2] >> 4) & 15; sri = (b[i + 2] >> 2) & 3; padb = (b[i + 2] >> 1) & 1
            if bri in (0, 15) or sri == 3 or ver == 1: i += 1; continue
            sr = sr_tab[ver][sri]; br = br_tab[1 if ver == 3 else 2][bri] * 1000
            spf = 1152 if ver == 3 else 576
            flen = (144 if ver == 3 else 72) * br // sr + padb
            frames += 1; i += max(flen, 1)
        else:
            i += 1
    return int(frames * spf * 1000 / sr)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--items", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--voice", default="ganji"); ap.add_argument("--ls", type=float, default=1.1)
    ap.add_argument("--procs", type=int, default=6); ap.add_argument("--pack-mb", type=float, default=3.3)
    a = ap.parse_args()
    os.makedirs(CACHE, exist_ok=True); os.makedirs(a.out, exist_ok=True)
    items = json.load(open(a.items))
    seen, uniq = set(), []
    for it in items:
        if it["id"] not in seen and it["text"].strip(): seen.add(it["id"]); uniq.append(it)
    t0 = time.time(); fails = []; paths = {}
    with Pool(a.procs, initializer=init, initargs=(a.voice, a.ls)) as pool:
        for k, (iid, p, err) in enumerate(pool.imap_unordered(work, uniq, chunksize=8)):
            if err: fails.append((iid, err))
            else: paths[iid] = p
            if k % 200 == 0: print(f"{k}/{len(uniq)} {time.time() - t0:.0f}s", flush=True)
    # pack in the items' order (so a unit's clips sit together)
    for f in os.listdir(a.out):
        if f.startswith("fa-") and (f.endswith(".mp3pack") or f == "fa-index.json"): os.remove(os.path.join(a.out, f))
    packs, clips, cur, curb, limit = [], {}, None, 0, int(a.pack_mb * 1024 * 1024)
    for it in uniq:
        p = paths.get(it["id"])
        if not p: continue
        b = open(p, "rb").read()
        if cur is None or curb + len(b) > limit:
            if cur: cur.close()
            packs.append(f"fa-{len(packs) + 1}.mp3pack"); cur = open(os.path.join(a.out, packs[-1]), "wb"); curb = 0
        clips[it["id"]] = [len(packs) - 1, curb, len(b), mp3_ms(b)]
        cur.write(b); curb += len(b)
    if cur: cur.close()
    json.dump({"voice": f"piper fa_IR-{a.voice}-medium", "ls": a.ls, "packs": packs, "clips": clips}, open(os.path.join(a.out, "fa-index.json"), "w"), separators=(",", ":"))
    tot = sum(os.path.getsize(os.path.join(a.out, p)) for p in packs)
    print(json.dumps({"items": len(uniq), "clips": len(clips), "failed": len(fails), "packs": packs, "MB": round(tot / 1048576, 2), "secs": round(time.time() - t0)}))
    if fails: print("FAILS", fails[:10])

if __name__ == "__main__":
    main()
