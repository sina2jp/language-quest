// AI partner robustness (no real key needed): model auto-detect picks the newest haiku; a model-not-found error re-detects once.
// Run: node tests/ai.mjs   (esbuild bundles src/ai.js + store.js for node)
import * as esbuild from 'esbuild';
import fs from 'fs';
await esbuild.build({ entryPoints: ['src/ai.js'], bundle: true, format: 'esm', platform: 'neutral', outfile: '/tmp/lq_ai_test.mjs', loader: { '.js': 'jsx' }, logLevel: 'error' });
globalThis.window = globalThis; globalThis.location = { origin: 'https://x', protocol: 'https:' };
const store = {}; globalThis.localStorage = { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: (k) => { delete store[k]; } };
store['familyApps.anthropicKey.v1'] = 'sk-test';
const { detectModel, aiMessage } = await import('/tmp/lq_ai_test.mjs');
const models = { data: [{ id: 'claude-sonnet-9', created_at: '2026-10-01T00:00:00Z' }, { id: 'claude-haiku-4-5', created_at: '2025-10-01T00:00:00Z' }, { id: 'claude-haiku-5-5', created_at: '2026-09-01T00:00:00Z' }] };
let calls = [];
const res = (status, body) => ({ ok: status < 300, status, json: async () => body });
let fail = 0; const okc = (name, cond) => { console.log((cond ? 'PASS ' : 'FAIL ') + name); if (!cond) fail++; };
globalThis.fetch = async (url, opt = {}) => {
  calls.push([url, opt.headers && opt.headers['anthropic-dangerous-direct-browser-access'], opt.body ? JSON.parse(opt.body).model : null]);
  if (/\/v1\/models/.test(url)) return res(200, models);
  const m = JSON.parse(opt.body).model;
  if (m === 'claude-haiku-old') return res(404, { type: 'error', error: { type: 'not_found_error', message: 'model: claude-haiku-old' } });
  return res(200, { content: [{ text: 'hola' }], usage: { input_tokens: 3, output_tokens: 2 } });
};
okc('detectModel picks the newest haiku', (await detectModel('sk-test')) === 'claude-haiku-5-5');
okc('models call sends the direct-browser header', calls[0][1] === 'true');
calls = []; let picked = null;
const j = await aiMessage({ body: { max_tokens: 10, messages: [{ role: 'user', content: 'hi' }] }, model: 'claude-haiku-old', onModel: (m) => { picked = m; } });
okc('model-not-found re-detects once and retries', j.content[0].text === 'hola' && picked === 'claude-haiku-5-5' && calls.length === 3 && calls[2][2] === 'claude-haiku-5-5');
calls = []; picked = null;
await aiMessage({ body: { max_tokens: 10, messages: [] }, model: null, onModel: (m) => { picked = m; } });
okc('first use without a stored model detects first', calls[0][0].includes('/v1/models') && picked === 'claude-haiku-5-5');
fs.rmSync('/tmp/lq_ai_test.mjs', { force: true });
process.exit(fail ? 1 : 0);
