// family-wallet.js 1.2 (anti-farming) + its merge in family-sync.js 1.1 (several laptops).
// Run: node tests/wallet12.mjs   (Node 20+, no dependencies)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const here = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const ROOT = path.join(here, '..');
const { loadCodeGs } = require(path.join(ROOT, 'server', 'gas-shim.js'));
const CODE = fs.readFileSync(path.join(ROOT, 'server', 'Code.gs'), 'utf8');
const FSmod = require(path.join(ROOT, 'family-sync.js'));
const FWpath = path.join(ROOT, 'vendor', 'family-wallet.js');
let pass = 0, fail = 0; const results = [];
async function test(name, fn) { try { await fn(); pass++; results.push('ok   ' + name); } catch (e) { fail++; results.push('FAIL ' + name + '\n     ' + (e && e.stack ? e.stack.split('\n').slice(0, 3).join('\n     ') : e)); } }
const eq = (a, b, m) => { const A = JSON.stringify(a), B = JSON.stringify(b); if (A !== B) throw new Error((m || 'not equal') + ': ' + A.slice(0, 300) + ' !== ' + B.slice(0, 300)); };
const ok = (v, m) => { if (!v) throw new Error(m || 'expected truthy'); };
const DAY = 86400000;
function memStore() { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k), map: m }; }
function wallet(store, clock) { delete require.cache[require.resolve(FWpath)]; const FW = require(FWpath); FW.configure({ storage: store, now: clock ? () => clock.t : null, resetMemory: true }); return FW; }
const onceEvents = (FW, app) => FW.events({ limit: 1000, app }).filter((e) => e.tag === 'once' || e.tag === 'onceBank');
const sumAmt = (list) => list.reduce((n, e) => n + e.amount, 0);

await test('earnOnce: pays the first time, a repeat pays 0 (reason "repeat", counted, not in the ledger)', () => {
  const FW = wallet(memStore());
  eq(FW.MODULE_VERSION, '1.2.0');
  eq(FW.earnOnce('language', 'lesson:es-u1-l1:pass', 2, 'Greetings 1'), { paid: 2, banked: 0, reason: null });
  const before = FW.balance().language;
  for (let i = 0; i < 5; i++) eq(FW.earnOnce('language', 'lesson:es-u1-l1:pass', 2, 'Greetings 1'), { paid: 0, banked: 0, reason: 'repeat' });
  eq(FW.balance().language, before);
  eq(onceEvents(FW, 'language').length, 1);
  const d = Object.values(FW.daily())[0].language;
  eq(d.repeat, 5);
  eq(FW.earnOnce('math', 'lesson:es-u1-l1:pass', 2).paid, 2, 'onceIds are per app');
});
await test('earnOnce: daily cap 6 per app; the rest is banked and released on a later day (never lost, never sprinted)', () => {
  const clock = { t: new Date(2026, 10, 27, 10, 0).getTime() };
  const FW = wallet(memStore(), clock);
  const r = [1, 2, 3, 4].map((i) => FW.earnOnce('language', 'pass:' + i, 2, 'Lesson ' + i));
  eq(r.map((x) => x.paid), [2, 2, 2, 0]); eq(r[3], { paid: 0, banked: 2, reason: 'cap' });
  eq(FW.earnOnce('language', 'pass:5', 3).banked, 3);
  eq(FW.balance().language, 6); eq(FW.bankedNow().language, 5);
  eq(FW.earnOnce('code', 'pass:1', 2).paid, 2, 'the cap is per app');
  clock.t += 30 * 60000;
  eq(FW.releaseBanked('language'), 0, 'not on the same day');
  clock.t += DAY; // the next day: the first earning call in the app releases the bank first (oldest first), within the cap
  const n = FW.earnOnce('language', 'pass:6', 2);
  eq(n, { paid: 1, banked: 1, reason: 'cap' }, '5 released + 1 paid = 6 today; 1 banked again');
  eq(FW.bankedNow().language, 1);
  eq(FW.balance().language, 12);
  clock.t += DAY;
  FW.tickActive('language', 60000); // any earning call releases it
  eq(sumAmt(onceEvents(FW, 'language')), 13); eq(FW.bankedNow().language || 0, 0);
  const total = sumAmt(onceEvents(FW, 'language'));
  eq(total, 2 + 2 + 2 + 2 + 3 + 2, 'every shard of true learning was paid in the end');
});
await test('rupeesOnce: first correct answer on an item pays; repeats within 30 days pay 0; at most 5,000 ids per app', () => {
  const clock = { t: new Date(2026, 10, 27, 10, 0).getTime() };
  const FW = wallet(memStore(), clock);
  eq(FW.rupeesOnce('language', 'es:hola', 1), 1);
  eq(FW.rupeesOnce('language', 'es:hola', 1), 0);
  eq(FW.rupeesOnce('language', 'es:adios', 1), 1);
  eq(FW.balance().rupees, 2);
  eq(FW.events({ limit: 100 }).filter((e) => e.tag === 'rupeeOnce').length, 1, 'one growing ledger line per app per day');
  eq(Object.values(FW.daily())[0].language.repeatRupees, 1);
  clock.t += 31 * DAY;
  eq(FW.rupeesOnce('language', 'es:hola', 1), 1, 'after 30 days it counts again');
  for (let i = 0; i < 5100; i++) FW.rupeesOnce('math', 'q' + i, 1);
  eq(Object.keys(FW.load().seenRupee.math).length, 5000);
});
await test('review minutes count for the parent but earn no shards; the old calls still work (1.1 behaviour)', () => {
  const FW = wallet(memStore());
  for (let i = 0; i < 10; i++) FW.tickActive('music', 120000, { repeat: true });
  eq(FW.todayMinutes('music'), 20); eq(FW.balance().music, 0);
  for (let i = 0; i < 5; i++) FW.tickActive('music', 120000);
  eq(FW.balance().music, 1, '10 new-learning minutes = 1 shard');
  const old = FW.finishUnit('code', 'Old app lesson');
  ok(old.granted === 2 && FW.balance().code === 2, 'finishUnit unchanged');
  FW.finishUnit('code', 'Old app lesson');
  eq(FW.balance().code, 4, 'the old call still pays repeats (only earnOnce knows what is new)');
  ok(FW.answer('code', true, 'quiz-1') === 1 && FW.beatBoss('code', 'boss').granted === 3);
  const w = JSON.parse(FW.load ? JSON.stringify(FW.load()) : '{}');
  ok(w.totals.code.earned === 7, JSON.stringify(w.totals.code));
});
await test('the parent can turn the rule off (repeats pay, cap still holds) and change the cap', () => {
  const FW = wallet(memStore());
  FW.setSettings({ noRepeats: false, onceDailyCap: 3 });
  eq(FW.policy().noRepeats, false); eq(FW.policy().onceDailyCap, 3);
  eq(FW.earnOnce('math', 'x', 2).paid, 2);
  eq(FW.earnOnce('math', 'x', 2), { paid: 1, banked: 1, reason: 'cap' });
  eq(FW.rupeesOnce('math', 'q', 1) + FW.rupeesOnce('math', 'q', 1), 2);
  for (let i = 0; i < 5; i++) FW.tickActive('math', 120000, { repeat: true });
  eq(FW.balance().math, 3 + 1, 'review minutes earn shards when the rule is off');
});

// ---------------- with family-sync 1.1: several laptops ----------------
function backend() { const app = loadCodeGs(CODE); return { app, transport: (e, b) => Promise.resolve(app.handle(JSON.parse(JSON.stringify(b)))) }; }
async function family(clock) {
  const be = backend();
  const g = { store: memStore() }; g.fs = FSmod.__new();
  g.fs.configure({ storage: g.store, transport: be.transport, locks: null, win: null, channel: null, wallet: null, online: () => true, visible: () => true, now: clock ? () => clock.t : null });
  await g.fs.createFamily({ endpoint: 'http://127.0.0.1:9/exec' });
  return { be, g };
}
async function laptop(be, g, clock, flaky) {
  const d = { store: memStore() };
  d.FW = wallet(d.store, clock);
  d.fs = FSmod.__new();
  const tr = flaky ? (e, b) => (flaky.down ? Promise.reject(Object.assign(new Error('net'), { code: 'network' })) : be.transport(e, b)) : be.transport;
  d.fs.configure({ storage: d.store, transport: tr, locks: null, win: null, channel: null, wallet: d.FW, online: () => true, visible: () => true, now: clock ? () => clock.t : null });
  await d.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  return d;
}
const sync = async (...ls) => { for (let r = 0; r < 2; r++) for (const l of ls) await l.fs.syncNow(); };

await test('two laptops pay the same onceId offline -> paid once after they sync (union by event id + once set)', async () => {
  const { be, g } = await family();
  const net = { down: false };
  const A = await laptop(be, g, null, net), B = await laptop(be, g, null, net);
  net.down = true;
  eq(A.FW.earnOnce('math', 'codex:frac-number-line:mastered', 3, 'Fractions on a line').paid, 3);
  eq(B.FW.earnOnce('math', 'codex:frac-number-line:mastered', 3, 'Fractions on a line').paid, 3);
  net.down = false;
  await sync(A, B);
  eq(A.store.getItem('familyApps.wallet.v1'), B.store.getItem('familyApps.wallet.v1'), 'both laptops hold the same wallet');
  for (const L of [A, B]) {
    eq(L.FW.balance().math, 3); eq(onceEvents(L.FW, 'math').length, 1);
    eq(L.FW.earnOnce('math', 'codex:frac-number-line:mastered', 3).reason, 'repeat');
  }
});
await test('the daily cap holds across laptops: the excess is banked by the merge and released the next day', async () => {
  const clock = { t: new Date(2026, 10, 27, 10, 0).getTime() };
  const { be, g } = await family(clock);
  const net = { down: false };
  const A = await laptop(be, g, clock, net), B = await laptop(be, g, clock, net);
  net.down = true;
  [1, 2, 3].forEach((i) => A.FW.earnOnce('language', 'A' + i, 2));
  [1, 2, 3].forEach((i) => B.FW.earnOnce('language', 'B' + i, 2));
  net.down = false;
  await sync(A, B);
  for (const L of [A, B]) { eq(L.FW.balance().language, 6, 'capped at 6 today across both laptops'); eq(L.FW.bankedNow().language, 6, 'the other 6 are banked'); }
  clock.t += DAY;
  eq(B.FW.releaseBanked('language'), 6);
  await sync(B, A);
  for (const L of [A, B]) { eq(L.FW.balance().language, 12); eq(L.FW.bankedNow().language || 0, 0); }
  eq(A.FW.releaseBanked('language'), 0, 'released once, not again on the other laptop');
});
await test('banked on one laptop but paid in full on the other -> no double pay after the merge', async () => {
  const { be, g } = await family();
  const net = { down: false };
  const A = await laptop(be, g, null, net), B = await laptop(be, g, null, net);
  net.down = true;
  [1, 2, 3].forEach((i) => A.FW.earnOnce('code', 'pre' + i, 2)); // A is at the cap ...
  eq(A.FW.earnOnce('code', 'game:robot-1:built', 2).banked, 2); // ... so this one is banked on A
  eq(B.FW.earnOnce('code', 'game:robot-1:built', 2).paid, 2); // and paid on B
  net.down = false;
  await sync(A, B);
  for (const L of [A, B]) {
    const paid = sumAmt(onceEvents(L.FW, 'code').filter((x) => x.ref === 'game:robot-1:built'));
    const banked = (L.FW.load().bank || []).filter((x) => x.onceId === 'game:robot-1:built').reduce((n, x) => n + x.total - (x.released || 0), 0);
    eq(paid + banked, 2, 'that pass is worth 2 shards in total, paid or banked, once');
    eq(L.FW.balance().code, 6, 'the cap of 6 a day holds across the two laptops');
  }
  eq(A.store.getItem('familyApps.wallet.v1'), B.store.getItem('familyApps.wallet.v1'));
});
await test('review minutes merge like minutes (3-way, no double count); the Hub settings reach every laptop', async () => {
  const { be, g } = await family();
  const net = { down: false };
  const A = await laptop(be, g, null, net), B = await laptop(be, g, null, net);
  for (let i = 0; i < 3; i++) A.FW.tickActive('math', 120000, { repeat: true });
  await sync(A, B);
  net.down = true;
  for (let i = 0; i < 2; i++) A.FW.tickActive('math', 120000, { repeat: true });
  for (let i = 0; i < 4; i++) B.FW.tickActive('math', 120000, { repeat: true });
  net.down = false;
  await sync(A, B);
  const t = JSON.parse(A.store.getItem('familyApps.walletTime.v1'));
  const day = Object.keys(t.days)[0];
  eq(t.days[day].math, (3 + 2 + 4) * 120000); eq(t.days[day].rep.math, (3 + 2 + 4) * 120000);
  eq(A.FW.balance().math, 0, 'review minutes earned nothing');
  g.fs.setSetting('familyApps.rewards.v1', { version: 1, enabled: true, weeklyCap: 5, rewards: [{ id: 'r', emoji: '🎁', text: 'Movie' }], wallet: { noRepeats: false, onceDailyCap: 4 } });
  await g.fs.syncNow();
  await sync(A, B);
  await A.fs.applyParentRequests(); await B.fs.applyParentRequests();
  for (const L of [A, B]) { eq(L.FW.policy().noRepeats, false); eq(L.FW.policy().onceDailyCap, 4); }
});
await test('the language farming pattern (a 1-minute lesson every minute for 15 minutes) now pays once per lesson, capped', () => {
  const clock = { t: new Date(2026, 10, 27, 10, 32).getTime() };
  const FW = wallet(memStore(), clock);
  for (let m = 0; m < 15; m++) {
    const id = 'lesson:es-u1-l' + (m % 3 + 1) + ':pass'; // the same 3 easy lessons, over and over
    FW.earnOnce('language', id, 2, 'Easy lesson');
    for (let q = 0; q < 11; q++) FW.rupeesOnce('language', id + ':q' + q, 1);
    FW.tickActive('language', 60000, { repeat: m >= 3 });
    clock.t += 60000;
  }
  eq(FW.balance().language, 6, '3 lessons x 2 shards, then nothing for repeats (was about 30)');
  eq(FW.balance().rupees, 33, '33 new correct answers (was 165+)');
  eq(Object.values(FW.daily())[0].language.repeat, 12);
});

console.log(results.join('\n'));
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
