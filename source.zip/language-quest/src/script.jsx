import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useApp, Navi, PlayBtn, PersianKeyboard, ActionBar, Stars } from './ui.jsx';
import { say, sfx } from './audio.js';
import { shuffle, normFa } from './engine.js';

import { LETTERS, LESSONS, LT, learnedSet, canRead } from './scriptdata.js';
import { allItems } from './content.js';
import { Rich } from './ui.jsx';
export { LETTERS, LESSONS };
export const scriptWords = () => LESSONS.flatMap((l) => l.words);

export function forms(ch) {
  const l = LT[ch];
  if (!l) return [ch, ch, ch, ch];
  const Z = '\u200d';
  return l[4] ? [ch, ch + Z, Z + ch + Z, Z + ch] : [ch, ch, Z + ch, Z + ch];
}

// ---------- Tracing ----------
export function Trace({ glyph, onDone }) {
  const cv = useRef(null), guide = useRef(null), pts = useRef([]);
  const [score, setScore] = useState(null);
  const drawing = useRef(false);
  const S = 300;
  useEffect(() => {
    const c = cv.current, g = guide.current; const dpr = 1;
    [c, g].forEach((x) => { x.width = S * dpr; x.height = S * dpr; });
    const gx = g.getContext('2d');
    const paint = () => {
      gx.clearRect(0, 0, S, S); gx.fillStyle = 'rgba(255,255,255,0.18)'; gx.textAlign = 'center'; gx.textBaseline = 'middle';
      gx.font = '190px Vazirmatn, sans-serif'; gx.fillText(glyph, S / 2, S / 2 + 10);
      gx.setLineDash([4, 8]); gx.strokeStyle = 'rgba(244,201,93,.55)'; gx.lineWidth = 2; gx.strokeText(glyph, S / 2, S / 2 + 10);
    };
    paint(); (document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve()).then(paint);
    const cx = c.getContext('2d'); cx.clearRect(0, 0, S, S); pts.current = []; setScore(null);
  }, [glyph]);
  const pos = (e) => { const r = cv.current.getBoundingClientRect(); return [(e.clientX - r.left) * (S / r.width), (e.clientY - r.top) * (S / r.height)]; };
  const down = (e) => { drawing.current = true; cv.current.setPointerCapture && cv.current.setPointerCapture(e.pointerId); const p = pos(e); pts.current.push(p); line(p, p); };
  const move = (e) => { if (!drawing.current) return; const p = pos(e); const last = pts.current[pts.current.length - 1]; pts.current.push(p); line(last, p); };
  const up = () => { drawing.current = false; };
  const line = (a, b) => { const x = cv.current.getContext('2d'); x.strokeStyle = '#f4c95d'; x.lineWidth = 20; x.lineCap = 'round'; x.lineJoin = 'round'; x.beginPath(); x.moveTo(a[0], a[1]); x.lineTo(b[0], b[1]); x.stroke(); };
  const check = () => {
    const off = document.createElement('canvas'); off.width = S; off.height = S;
    const o = off.getContext('2d'); o.textAlign = 'center'; o.textBaseline = 'middle'; o.font = '190px Vazirmatn, sans-serif'; o.fillStyle = '#fff'; o.fillText(glyph, S / 2, S / 2 + 10);
    const gm = o.getImageData(0, 0, S, S).data;
    o.lineWidth = 30; o.strokeStyle = '#fff'; o.strokeText(glyph, S / 2, S / 2 + 10);
    const fat = o.getImageData(0, 0, S, S).data;
    const um = cv.current.getContext('2d').getImageData(0, 0, S, S).data;
    let g = 0, cov = 0, u = 0, inside = 0;
    for (let y = 0; y < S; y += 4) for (let x = 0; x < S; x += 4) {
      const i = (y * S + x) * 4 + 3;
      if (gm[i] > 128) { g++; if (um[i] > 0) cov++; }
      if (um[i] > 0) { u++; if (fat[i] > 0) inside++; }
    }
    const c = g ? cov / g : 0, p = u ? inside / u : 0;
    const st = c >= 0.6 && p >= 0.6 ? 3 : c >= 0.45 && p >= 0.5 ? 2 : 1;
    setScore({ st, c, p }); sfx(st >= 2 ? 'good' : 'try');
  };
  const clear = () => { cv.current.getContext('2d').clearRect(0, 0, S, S); pts.current = []; setScore(null); };
  return (
    <div className="center" style={{ display: 'grid', justifyItems: 'center', gap: 10 }} data-testid="trace">
      <div className="trace"><canvas ref={guide} /><canvas ref={cv} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerLeave={up} data-testid="trace-canvas" /></div>
      {score && <div className={`fb ${score.st >= 2 ? 'good' : 'try'}`}><Stars n={score.st} /> {score.st === 3 ? 'Beautiful tracing!' : score.st === 2 ? 'Nice! Try to stay on the letter.' : 'Trace over the whole letter, slowly.'}</div>}
      <div className="row c">
        <button className="btn sm" onClick={clear}>↺ Clear</button>
        {!score || score.st < 2 ? <button className="btn sm primary" onClick={check} data-testid="trace-check">Check</button> : <button className="btn sm good" onClick={() => onDone(score.st)} data-testid="trace-next">Next</button>}
        {score && score.st < 2 && <button className="btn sm" onClick={() => onDone(score.st)}>Next anyway</button>}
      </div>
    </div>
  );
}

// ---------- A script lesson (Meet → Trace → Read → Type) ----------
export function ScriptLesson({ idx, onDone, mini }) {
  const { S, set } = useApp();
  const les = LESSONS[Math.min(idx, LESSONS.length - 1)];
  const learned = useMemo(() => new Set(LESSONS.slice(0, idx + 1).flatMap((l) => l.letters)), [idx]);
  const phases = useMemo(() => {
    const p = les.letters.map((l) => ({ k: 'meet', l }));
    if (!les.marks) les.letters.forEach((l) => p.push({ k: 'trace', l }));
    shuffle(les.words).slice(0, 3).forEach((w) => p.push({ k: 'read', w }));
    p.push({ k: 'type', w: les.words[0] });
    return p;
  }, [idx]);
  const start = mini ? Math.min(S.fa.script.part || 0, phases.length - 1) : 0;
  const [i, setI] = useState(start);
  const end = mini ? Math.min(phases.length, start + 4) : phases.length;
  const next = () => {
    if (i + 1 < end) { setI(i + 1); return; }
    const finished = i + 1 >= phases.length;
    set((s) => { if (finished) { s.fa.script.step = Math.max(s.fa.script.step, idx + 1); s.fa.script.part = 0; s.fa.script.done[idx] = Date.now(); s.rupees += 5; } else s.fa.script.part = i + 1; });
    onDone({ finished });
  };
  const ph = phases[i];
  return (
    <div className="card pop" data-testid="script-lesson">
      <div className="row"><h3 className="grow">✍️ Script {idx + 1}: {les.title}</h3><span className="muted">{i + 1}/{phases.length}</span></div>
      {ph.k === 'meet' && <Meet l={ph.l} note={les.note} onNext={next} />}
      {ph.k === 'trace' && <><Navi small>{`Trace ${ph.l} with your finger or mouse. Start at the top, go right to left.`}</Navi><div className="muted small center">Tip: on a Mac, tracing is easier on the iPhone, or on paper with a pencil!</div><Trace glyph={ph.l} onDone={next} /></>}
      {ph.k === 'read' && <ReadWord w={ph.w} pool={LESSONS.slice(0, idx + 1).flatMap((l) => l.words)} onNext={next} />}
      {ph.k === 'type' && <TypeWord w={ph.w} learned={learned} onNext={next} />}
    </div>
  );
}

function Meet({ l, note, onNext }) {
  const [all4, setAll4] = useState(false);
  const L = LT[l];
  const f = forms(l);
  if (!L) { // vowel mark
    return (<>
      <Navi small>{note}</Navi>
      <div className="letterbig" lang="fa">ب{l}</div>
      <ActionBar><button className="btn primary wide" onClick={onNext} data-testid="next">Next</button></ActionBar>
    </>);
  }
  return (<>
    <Navi small>{note}</Navi>
    <div className="row c" style={{ margin: '8px 0' }}><div className="letterbig" lang="fa">{l}</div>
      <div><div className="big">{L[2]}</div><div className="muted">sound: <b>{L[3]}</b></div><PlayBtn lang="fa" text={L[1]} sm label="Letter name" /></div></div>
    <div className="forms" dir="rtl" style={all4 ? null : { gridTemplateColumns: '1fr 1fr' }}>
      {(all4 ? [['alone', 0], ['start', 1], ['middle', 2], ['end', 3]] : [['joined', 1], ['final', 3]]).map(([n, k]) => <div key={n}><div className="g" lang="fa">{f[k]}</div><div className="small muted">{n}</div></div>)}
    </div>
    {!all4 && <div className="center"><button className="linkbtn" onClick={() => setAll4(true)}>See all 4 shapes</button></div>}
    <div className="fb info" style={{ marginTop: 10 }}>{L[4] ? '🤝 This letter holds hands with the next letter.' : '🙅 This letter never holds hands with the letter after it.'}</div>
    <ActionBar><button className="btn primary wide" onClick={onNext} data-testid="next">Next</button></ActionBar>
  </>);
}

function ReadWord({ w, pool, onNext }) {
  const opts = useMemo(() => shuffle([w, ...shuffle(pool.filter((x) => x[0] !== w[0] && x[3] !== w[3])).slice(0, 2)]), [w]);
  const [sel, setSel] = useState(null);
  const ok = sel && sel[0] === w[0];
  return (<>
    <Navi small>Read this word. Which picture is it? (You know it by ear!)</Navi>
    <div className="letterbig" lang="fa" style={{ fontSize: '4rem' }}>{w[0]}</div>
    <div className="choices pics">{opts.map((o) => <button key={o[0]} className={`choice ${sel === o ? (o[0] === w[0] ? 'right' : 'wrong') : ''}`} onClick={() => { setSel(o); sfx(o[0] === w[0] ? 'good' : 'try'); if (o[0] === w[0]) say('fa', w[0]); }} data-ok={o[0] === w[0] ? '1' : '0'}><span className="pic emoji">{o[3]}</span></button>)}</div>
    {sel && !ok && <div className="fb try" style={{ marginTop: 10 }}>🔎 Sound out each letter, from right to left.</div>}
    {ok && <div className="fb good" style={{ marginTop: 10 }}>✨ <span className="fa" lang="fa">{w[0]}</span> = <span className="tr">{w[1]}</span> = {w[2]}</div>}
    <ActionBar><button className="btn primary wide" disabled={!ok} onClick={onNext} data-testid="next">Next</button></ActionBar>
  </>);
}

const KEYMAP = { a: 'ا', A: 'آ', b: 'ب', p: 'پ', t: 'ت', T: 'ط', s: 'س', S: 'ش', j: 'ج', c: 'چ', h: 'ه', H: 'ح', x: 'خ', d: 'د', z: 'ز', Z: 'ژ', r: 'ر', f: 'ف', q: 'ق', G: 'غ', k: 'ک', g: 'گ', l: 'ل', m: 'م', n: 'ن', v: 'و', w: 'و', u: 'و', o: 'و', y: 'ی', i: 'ی', e: 'ع', E: 'ع' };
function TypeWord({ w, learned, onNext }) {
  const [val, setVal] = useState('');
  useEffect(() => {
    const f = (e) => { if (e.metaKey || e.ctrlKey) return; if (e.key === 'Backspace') { e.preventDefault(); setVal((v) => v.slice(0, -1)); return; } const ch = KEYMAP[e.key]; if (ch) { e.preventDefault(); setVal((v) => v + ch); } };
    window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f);
  }, []);
  const ok = normFa(val) === normFa(w[0]);
  useEffect(() => { const t = setTimeout(() => say('fa', w[0]), 300); return () => clearTimeout(t); }, [w]);
  const nextKey = w[0][val.length];
  return (<>
    <Navi small>{`Type it: ${w[3]} ${w[1]}`}</Navi>
    <div className="muted small center">Use your Mac keys (b → ب, s → س, m → م …) or tap the letters below.</div>
    <div className="row c"><PlayBtn lang="fa" text={w[0]} sm /><div className="field fa" style={{ minHeight: 60, textAlign: 'center', fontSize: '2rem' }} lang="fa" data-testid="type-value" data-answer={globalThis.__LQ_TEST__ ? w[0] : undefined}>{val || ' '}</div></div>
    {ok && <div className="fb good" style={{ marginTop: 10 }}>✨ You wrote <span className="fa" lang="fa">{w[0]}</span>!</div>}
    <div style={{ marginTop: 10 }}><PersianKeyboard highlight={nextKey && !ok ? [nextKey] : []} onKey={(k) => { if (k === 'BACK') setVal(val.slice(0, -1)); else if (!ok) setVal(val + k); }} /></div>
    <ActionBar><button className="btn primary wide" disabled={!ok} onClick={onNext} data-testid="next">Next</button></ActionBar>
  </>);
}

// ---------- Script track home ----------
export function readableCount(step) { const set = learnedSet(step); return allItems('fa').filter((it) => it.kind === 'w' && canRead(it.t, set)).length; }
export function ScriptHome({ onLesson }) {
  const { S } = useApp();
  const step = S.fa.script.step || 0;
  const nread = useMemo(() => readableCount(step), [step]);
  return (
    <div className="card" data-testid="script-home">
      <h2>✍️ Persian letters</h2>
      <Navi small>{'Learn the letters family by family, then read words you already know by ear!'}</Navi>
      {step > 0 && <div className="fb good" style={{ marginTop: 8 }} data-testid="can-read">📖 You can read {nread} words!</div>}
      <div className="muted small" style={{ marginTop: 6 }}><Rich text="Spoken and written Farsi are BOTH right: people say خونه (khune), books write خانه (khâne)." /></div>
      <div className="plist" style={{ marginTop: 12 }}>
        {LESSONS.map((l, i) => (
          <button key={i} className="prow" style={{ opacity: i > step ? 0.5 : 1, textAlign: 'left' }} disabled={i > step} onClick={() => onLesson(i)}>
            <span><b>{i + 1}. {l.title}</b> <span className="fa" lang="fa">{l.letters.join(' ')}</span></span>
            <span>{i < step ? '⭐' : i === step ? '▶️' : '🔒'}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
