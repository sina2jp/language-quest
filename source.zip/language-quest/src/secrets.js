// The 18 Secret Treasures (Gold Skulltula tokens): 6 hidden things to find + 12 achievements (Spanish-weighted).
export const SECRETS = [
  { id: 'moon', kind: 'find', icon: '🌙', name: 'Moon Knock', hint: 'A moon on a bonus door likes to be knocked… three times.' },
  { id: 'navi', kind: 'find', icon: '🧚', name: 'Hiding Fairy', hint: 'A tiny fairy is hiding on your “I can” map.' },
  { id: 'owl', kind: 'find', icon: '🦉', name: 'Owl’s Whisper', hint: 'In an owl story, one line ends with a sparkle.' },
  { id: 'song', kind: 'find', icon: '🎵', name: 'Secret Song', hint: 'Some ocarina tunes open more than doors. Try an old song you know.' },
  { id: 'cow', kind: 'find', icon: '🐄', name: 'Ranch Friend', hint: 'Someone on the field map near the ranch says “moo” when tapped.' },
  { id: 'glint', kind: 'find', icon: '✨', name: 'Forest Glint', hint: 'Something glints in the forest at home. Watch for the twinkle.' },
  { id: 'speak20', kind: 'achieve', icon: '🗣️', name: 'Chatterbox', goal: 'Say 20 Spanish phrases aloud correctly', target: 20, value: (S) => (S.es.speak && S.es.speak.good) || 0 },
  { id: 'unit1', kind: 'achieve', icon: '🌱', name: 'First Steps', goal: 'Finish Spanish unit 1', target: 1, value: (S) => (S.es.units[1] && S.es.units[1].done ? 1 : 0) },
  { id: 'unit3', kind: 'achieve', icon: '🌿', name: 'Growing Strong', goal: 'Finish Spanish unit 3', target: 1, value: (S) => (S.es.units[3] && S.es.units[3].done ? 1 : 0) },
  { id: 'unit5', kind: 'achieve', icon: '🌳', name: 'Sprout Champion', goal: 'Finish Spanish unit 5', target: 1, value: (S) => (S.es.units[5] && S.es.units[5].done ? 1 : 0) },
  { id: 'nohint', kind: 'achieve', icon: '🛡️', name: 'Brave Hero', goal: 'Beat a boss without any hints', target: 1, value: (S) => (flag(S, 'nohint') ? 1 : 0) },
  { id: 'streak3', kind: 'achieve', icon: '🔥', name: 'Three in a Row', goal: 'Play 3 days in a row', target: 3, value: (S) => bestStreak(S) },
  { id: 'firststeps', kind: 'achieve', icon: '🏆', name: 'First Steps Champion', goal: 'Finish First Steps (Primeros pasos)', target: 1, value: (S) => (S.es.fs && S.es.fs.champion ? 1 : 0) },
  { id: 'words50', kind: 'achieve', icon: '📗', name: 'Word Collector', goal: 'Learn 50 Spanish words', target: 50, value: (S) => esWords(S) },
  { id: 'helpfinish', kind: 'achieve', icon: '🧚', name: 'Never Give Up', goal: 'Use Help and still finish a lesson', target: 1, value: (S) => (flag(S, 'helpfinish') ? 1 : 0) },
  { id: 'story', kind: 'achieve', icon: '📜', name: 'Story Keeper', goal: 'Finish an owl story', target: 1, value: (S) => (flag(S, 'story') ? 1 : 0) },
  { id: 'chant', kind: 'achieve', icon: '🥁', name: 'Dance Master', goal: 'Do a chant with the moves', target: 1, value: (S) => (flag(S, 'chant') ? 1 : 0) },
  { id: 'farsi', kind: 'achieve', icon: '🌙', name: 'Bonus Explorer', goal: 'Try the Farsi bonus quest', target: 1, value: (S) => ((S.fa.quests || 0) >= 1 ? 1 : 0) },
];
export const TOTAL = SECRETS.length;
// streaks count the longest run ever (kept in treasure.best, updated on actions)
export const bestStreak = (S) => Math.max((S.treasure && S.treasure.best) || 0, S.es.streak || 0, S.fa.streak || 0);
const flag = (S, k) => !!(S.treasure && S.treasure.flags && S.treasure.flags[k]);
function esWords(S) { let n = 0; for (const k of Object.keys(S.es.srs || {})) if (/^es\d+w\d+$/.test(k)) n++; return n; }
export const progress = (S, sec) => Math.min(sec.target, sec.value(S) || 0);
export const foundCount = (S) => Object.keys((S.treasure && S.treasure.found) || {}).filter((id) => SECRETS.some((x) => x.id === id)).length;
export function newlyAchieved(S) {
  const f = (S.treasure && S.treasure.found) || {};
  return SECRETS.filter((x) => x.kind === 'achieve' && !f[x.id] && progress(S, x) >= x.target).map((x) => x.id);
}
