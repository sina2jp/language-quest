// First Steps (Primeros pasos): the gentle start for Spanish beginners. 16 micro-lessons (~5 min, 3-4 new words or one
// chunk), FLES scope and sequence, pictures + audio + a gesture cue, "I do → we do → you do", help always one tap away.
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useApp, Navi, PlayBtn, ActionBar, Portrait, Stars, AccentBar } from './ui.jsx';
import { Pic } from './activities.jsx';
import { say, sfx, srAvailable, listenHandle } from './audio.js';
import { matchSpeech, introduce, shuffle } from './engine.js';
import { today } from './store.js';
import { emit } from './hooks.js';
import { partner, setLesson } from './wallet.js';
import { name } from './skin.js';

const W = (id, es, en, e, gesture, pic) => ({ id, es, en, e, gesture, pic, t: es, say: es });
export const FS_UNITS = [
  { id: 'hello', title: 'Hello!', es: '¡Hola!', ican: 'I can greet people, say please and thank you, and say how I feel.', lessons: [0, 1, 2, 3] },
  { id: 'count', title: 'Numbers', es: 'Los números', ican: 'I can count from 1 to 10.', lessons: [4, 5] },
  { id: 'colors', title: 'Colors', es: 'Los colores', ican: 'I can name 8 colors.', lessons: [6, 7] },
  { id: 'world', title: 'My world', es: 'Mi mundo', ican: 'I can name pets, my family, school things and food.', lessons: [8, 9, 10, 11] },
  { id: 'me', title: 'About me', es: 'Yo', ican: 'I can say what I like and how old I am.', lessons: [12, 13] },
  { id: 'champ', title: 'Champion', es: '¡Campeón!', ican: 'I can have a short conversation in Spanish.', lessons: [14, 15] },
];
// chat lines: m = mentor (Spanish), en = English, a = right answer, b = other choice ({nick} = the player's nickname)
export const FS_LESSONS = [
  { t: 'Hello and goodbye', sub: 'hola · adiós · buenos días', items: [W('es1w0', 'hola', 'hello', '👋', '👋 Wave hello'), W('es1w1', 'adiós', 'goodbye', '🙋', '🙋 Wave goodbye'), W('es1w2', 'buenos días', 'good morning', '🌞', '🌅 Stretch up like the morning sun')],
    build: { word: 'hola' }, chat: [{ m: '¡Hola!', en: 'Hello!', a: '¡Hola!', b: 'Adiós.' }, { m: '¡Adiós!', en: 'Goodbye!', a: '¡Adiós!', b: 'Buenos días.' }] },
  { t: 'Yes, no, please, thanks', sub: 'sí · no · por favor · gracias', items: [W('es1w10', 'sí', 'yes', '✅', '🙂 Nod your head'), W('es1w11', 'no', 'no', '❌', '🙃 Shake your head'), W('es1w5', 'por favor', 'please', '🙏', '🙏 Put your hands together'), W('es1w6', 'gracias', 'thank you', '😊', '🤲 Hand on your heart')],
    build: { word: 'gracias' }, chat: [{ m: '¿Agua? Por favor…', en: 'Water? Please…', a: 'Sí, gracias.', b: 'Adiós.' }, { m: '¡Gracias!', en: 'Thank you!', a: '¡Adiós!', b: 'No.' }] },
  { t: 'How are you?', sub: '¿Cómo estás? · bien · mal · así así', items: [W('es1p7', '¿Cómo estás?', 'How are you?', '🙂❓', '🫵 Point to a friend'), W('es1w13', 'bien', 'fine, good', '👍', '👍 Thumbs up'), W('es1w14', 'mal', 'bad', '👎', '👎 Thumbs down'), W('fs-asi', 'así así', 'so-so', '🤚', '🤚 Wobble your hand', 'es1w15')],
    build: { word: 'bien' }, chat: [{ m: '¡Hola! ¿Cómo estás?', en: 'Hi! How are you?', a: 'Bien, gracias.', b: 'Adiós.' }, { m: '¡Muy bien!', en: 'Very good!', a: '¡Adiós!', b: '¿Cómo estás?' }] },
  { t: 'What is your name?', sub: '¿Cómo te llamas? · Me llamo…', items: [W('es1p4', '¿Cómo te llamas?', 'What is your name?', '❓🏷️', '🫵 Point to a friend'), W('fs-mellamo', 'Me llamo…', 'My name is…', '🧒🏷️', '👆 Point to yourself', 'es1p5')],
    build: { bank: ['Me', 'llamo', '{nick}.'] }, chat: [{ m: 'Me llamo Navi. ¿Cómo te llamas?', en: 'My name is Navi. What is your name?', a: 'Me llamo {nick}.', b: '¿Cómo estás?' }, { m: '¡Hola, {nick}!', en: 'Hi, {nick}!', a: '¡Hola, Navi!', b: 'No.' }] },
  { t: 'Numbers 1 to 5', sub: 'uno · dos · tres · cuatro · cinco', items: [W('es2w1', 'uno', 'one', '1️⃣', '☝️ Show 1 finger'), W('es2w2', 'dos', 'two', '2️⃣', '✌️ Show 2 fingers'), W('es2w3', 'tres', 'three', '3️⃣', '🤟 Show 3 fingers'), W('es2w4', 'cuatro', 'four', '4️⃣', '🖖 Show 4 fingers'), W('es2w5', 'cinco', 'five', '5️⃣', '🖐️ Show 5 fingers')],
    count: true, build: { word: 'dos' }, chat: [{ m: '¿Uno, dos…?', en: 'One, two…?', a: '¡Tres!', b: 'Cinco.' }, { m: '¿Cuatro y…?', en: 'Four and…?', a: '¡Cinco!', b: 'Dos.' }] },
  { t: 'Numbers 6 to 10', sub: 'seis · siete · ocho · nueve · diez', items: [W('es2w6', 'seis', 'six', '6️⃣', '🖐️☝️ Show 6 fingers'), W('es2w7', 'siete', 'seven', '7️⃣', '🖐️✌️ Show 7 fingers'), W('es2w8', 'ocho', 'eight', '8️⃣', '🖐️🤟 Show 8 fingers'), W('es2w9', 'nueve', 'nine', '9️⃣', '🖐️🖖 Show 9 fingers'), W('es2w10', 'diez', 'ten', '🔟', '🙌 Show 10 fingers')],
    count: true, build: { word: 'diez' }, chat: [{ m: '¿Seis, siete…?', en: 'Six, seven…?', a: '¡Ocho!', b: 'Uno.' }, { m: '¿Nueve y…?', en: 'Nine and…?', a: '¡Diez!', b: 'Seis.' }] },
  { t: 'Colors 1', sub: 'rojo · azul · amarillo · verde', items: [W('es3w1', 'rojo', 'red', '🔴', '🍎 Point to something red'), W('es3w2', 'azul', 'blue', '🔵', '🌊 Make waves with your hands'), W('es3w3', 'amarillo', 'yellow', '🟡', '☀️ Make a big sun with your arms'), W('es3w4', 'verde', 'green', '🟢', '🌳 Be a tall tree')],
    build: { word: 'azul' }, chat: [{ m: '¿La manzana? 🍎', en: 'The apple?', a: 'Rojo.', b: 'Azul.' }, { m: '¿El sol? ☀️', en: 'The sun?', a: 'Amarillo.', b: 'Verde.' }] },
  { t: 'Colors 2', sub: 'blanco · negro · rosa · naranja', items: [W('es3w9', 'blanco', 'white', '⚪', '☁️ Float like a cloud'), W('es3w8', 'negro', 'black', '⚫', '🌑 Cover your eyes: dark!'), W('es3w7', 'rosa', 'pink', '🌸', '🌸 Smell a flower'), W('fs-naranja', 'naranja', 'orange', '🟠', '🍊 Peel an orange', 'es3w5')],
    build: { word: 'rosa' }, chat: [{ m: '¿La nieve? ❄️', en: 'The snow?', a: 'Blanco.', b: 'Negro.' }, { m: '¿La flor? 🌸', en: 'The flower?', a: 'Rosa.', b: 'Naranja.' }] },
  { t: 'Pets', sub: 'el perro · el gato · el pez · el pájaro', items: [W('es4w32', 'el perro', 'the dog', '🐶', '🐕 Pant like a puppy'), W('es4w33', 'el gato', 'the cat', '🐱', '🐈 Lick your paw like a cat'), W('es10w2', 'el pez', 'the fish', '🐟', '🐟 Swim with your hand'), W('es10w3', 'el pájaro', 'the bird', '🐦', '🐦 Flap your wings')],
    build: { word: 'gato' }, chat: [{ m: '¡Guau, guau! 🐶', en: 'Woof, woof!', a: 'El perro.', b: 'El gato.' }, { m: '¡Miau! 🐱', en: 'Meow!', a: 'El gato.', b: 'El pez.' }] },
  { t: 'My family', sub: 'mamá · papá · el hermano · la hermana', items: [W('fs-mama', 'mamá', 'mom', '👩', '🤗 Give a hug', 'es4w1'), W('fs-papa', 'papá', 'dad', '👨', '🙌 High five', 'es4w2'), W('es4w5', 'el hermano', 'the brother', '👦', '💪 Show your muscles'), W('es4w6', 'la hermana', 'the sister', '👧', '👋 Wave to her')],
    build: { word: 'mamá' }, chat: [{ m: '¿Quién es? 👩', en: 'Who is it?', a: 'Mamá.', b: 'Papá.' }, { m: '¿Y él? 👦', en: 'And him?', a: 'El hermano.', b: 'La hermana.' }] },
  { t: 'At school', sub: 'el libro · el lápiz · la mesa · la silla', items: [W('es5w8', 'el libro', 'the book', '📖', '📖 Open your hands like a book'), W('es5w10', 'el lápiz', 'the pencil', '✏️', '✏️ Write in the air'), W('es5w24', 'la mesa', 'the table', '🪵', '🖐️ Pat the table'), W('es5w25', 'la silla', 'the chair', '🪑', '🪑 Sit down, stand up')],
    build: { word: 'libro' }, chat: [{ m: '¿Un lápiz? ✏️', en: 'A pencil?', a: 'Sí, por favor.', b: 'Adiós.' }, { m: 'Aquí tienes.', en: 'Here you go.', a: '¡Gracias!', b: '¡Hola!' }] },
  { t: 'Food', sub: 'la manzana · el agua · la leche · el pan', items: [W('es8w6', 'la manzana', 'the apple', '🍎', '🍎 Take a big bite'), W('es8w0', 'el agua', 'the water', '💧', '🥤 Take a drink'), W('es8w2', 'la leche', 'the milk', '🥛', '🥛 Pour the milk'), W('es8w3', 'el pan', 'the bread', '🍞', '🍞 Cut a slice')],
    build: { word: 'pan' }, chat: [{ m: '¿Agua o leche?', en: 'Water or milk?', a: 'Leche, por favor.', b: 'Rojo.' }, { m: 'Aquí tienes. 🥛', en: 'Here you go.', a: '¡Gracias!', b: '¡Adiós!' }] },
  { t: 'I like it!', sub: 'Me gusta · No me gusta', items: [W('fs-mg1', 'Me gusta el perro.', 'I like the dog.', '👍🐶', '👍 Thumbs up'), W('fs-mg2', 'No me gusta el pan.', 'I don’t like the bread.', '👎🍞', '👎 Thumbs down'), W('fs-mg3', 'Me gusta la manzana.', 'I like the apple.', '👍🍎', '👍 Thumbs up')],
    build: { bank: ['Me', 'gusta', 'el', 'perro.'] }, chat: [{ m: '¿Te gusta el gato? 🐱', en: 'Do you like the cat?', a: 'Sí, me gusta el gato.', b: 'Tengo dos.' }, { m: '¿Te gusta la leche? 🥛', en: 'Do you like milk?', a: 'No me gusta la leche.', b: 'Adiós.' }] },
  { t: 'How old are you?', sub: 'Tengo ___ años', items: [W('fs-t9', 'Tengo nueve años.', 'I am nine years old.', '9️⃣🎂', '🖐️🖖 Show 9 fingers'), W('fs-t10', 'Tengo diez años.', 'I am ten years old.', '🔟🎂', '🙌 Show 10 fingers'), W('fs-t5', 'Tengo cinco años.', 'I am five years old.', '5️⃣🎂', '🖐️ Show 5 fingers')],
    build: { bank: ['Tengo', 'nueve', 'años.'] }, chat: [{ m: '¿Cuántos años tienes?', en: 'How old are you?', a: 'Tengo nueve años.', b: 'Me llamo Navi.' }, { m: '¡Qué bien!', en: 'How nice!', a: '¡Gracias!', b: 'Azul.' }] },
  { t: 'Review + chat', sub: 'a 4-line conversation', items: [], review: 4,
    chat: [{ m: '¡Hola! ¿Cómo te llamas?', en: 'Hi! What is your name?', a: 'Me llamo {nick}.', b: 'Tengo diez años.' }, { m: '¿Cómo estás, {nick}?', en: 'How are you, {nick}?', a: 'Bien, gracias.', b: 'El perro.' }, { m: '¿Cuántos años tienes?', en: 'How old are you?', a: 'Tengo nueve años.', b: 'Rojo.' }, { m: '¡Adiós, {nick}!', en: 'Goodbye, {nick}!', a: '¡Adiós!', b: 'Por favor.' }] },
  { t: 'First Steps champion', sub: 'celebrate!', items: [], champion: true },
];
export const FS_TOTAL = FS_LESSONS.length;
const nickOf = (S) => (S.nick || 'Link').replace(/[<>]/g, '').slice(0, 20);
const fill = (s, S) => String(s).split('{nick}').join(nickOf(S));
export function fsState(S) { const f = (S.es && S.es.fs) || {}; return { done: f.done || {}, skipped: !!f.skipped, champion: f.champion || 0, srs: f.srs || {}, help: f.help || 0 }; }
export const fsNext = (S) => { const d = fsState(S).done; for (let i = 0; i < FS_TOTAL; i++) if (!d[i]) return i; return FS_TOTAL; };
export const fsFinished = (S) => !!fsState(S).champion;
// the path is the Spanish home until First Steps is finished or skipped (a profile that already finished a Spanish unit
// before First Steps existed keeps its map; First Steps stays reachable from there)
export const fsActive = (S) => !!(S.es && S.es.placed) && !fsState(S).skipped && !fsState(S).champion && (!!S.es.fs || !Object.values(S.es.units || {}).some((u) => u && u.done));
const norm = (s) => String(s || '').toLowerCase().replace(/[¿?¡!.,…]/g, '').replace(/\s+/g, ' ').trim();
const noAcc = (s) => norm(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '');
const allItems = FS_LESSONS.flatMap((l) => l.items);

// ---------- start screen: "It's new to me" (default) or "Test me" ----------
export function FirstStepsStart() {
  const { set, go } = useApp();
  return (
    <div className="card pop center" data-testid="fs-start">
      <Portrait who="navi" size="lg" />
      <h2>Spanish · Español</h2>
      <Navi>Let's start with tiny, easy steps. Is Spanish new to you?</Navi>
      <div style={{ display: 'grid', gap: 12, marginTop: 14 }}>
        <button className="btn primary big wide" onClick={() => { sfx('tap'); set((s) => { s.es.placed = true; s.es.level = 'sprout'; s.es.fs = Object.assign({ done: {}, srs: {} }, s.es.fs || {}, { skipped: false }); }); go('lang', { lang: 'es' }); }} data-testid="fs-new">🌱 It's new to me <span className="muted small">(start First Steps)</span></button>
        <button className="btn wide" onClick={() => go('placement', { lang: 'es' })} data-testid="fs-test-start">🧭 Test me — I know some Spanish</button>
      </div>
    </div>
  );
}
// ---------- the learning path ----------
export function FirstStepsPath() {
  const { S, set, go } = useApp(); const st = fsState(S); const next = fsNext(S);
  useEffect(() => { const el = document.querySelector('.fsnode.now'); if (el && el.scrollIntoView) el.scrollIntoView({ block: 'center' }); }, []);
  return (
    <div className="fspath" data-testid="fs-path">
      <div className="card center"><h2>🌱 First Steps <span className="muted small">· Primeros pasos</span></h2>
        <Navi small>{next < FS_TOTAL ? 'Tiny lessons, about 5 minutes each. Tap the glowing step!' : 'You finished every step. ¡Felicidades!'}</Navi>
        <div className="bar" style={{ marginTop: 8 }}><i style={{ width: `${(Object.keys(st.done).length / FS_TOTAL) * 100}%` }} /></div>
        <div className="muted small">{Object.keys(st.done).length} of {FS_TOTAL} steps</div></div>
      {FS_UNITS.map((u) => (
        <div key={u.id} className="fsunit">
          <div className="fsunit-h"><b>{u.title}</b> <span lang="es" className="muted">· {u.es}</span><div className="small">🎯 {u.ican}</div></div>
          <div className="fsnodes">{u.lessons.map((i) => { const L = FS_LESSONS[i]; const done = st.done[i]; const now = i === next; const locked = i > next;
            return (
              <button key={i} className={`fsnode ${done ? 'done' : ''} ${now ? 'now' : ''} ${locked ? 'locked' : ''}`} disabled={locked} onClick={() => go('fslesson', { lang: 'es', fs: i })} data-testid={`fs-node-${i + 1}`} aria-label={`Step ${i + 1}: ${L.t}${now ? ' (you are here)' : ''}`}>
                <span className="fsdot">{done ? '★' : i + 1}</span>
                <span className="fslbl"><b>{L.t}</b><span className="muted small" lang="es">{L.sub}</span></span>
                {now && <span className="here">📍 You are here</span>}{done ? <Stars n={done} /> : null}
              </button>); })}</div>
        </div>))}
      <div className="center" style={{ display: 'grid', gap: 6 }}>
        <button className="linkbtn" onClick={() => go('placement', { lang: 'es' })} data-testid="fs-test">🧭 Already know some Spanish? Test me to skip ahead</button>
        <button className="linkbtn" onClick={() => { set((s) => { s.es.fs = Object.assign({ done: {}, srs: {} }, s.es.fs || {}, { skipped: true }); }); go('lang', { lang: 'es' }); }} data-testid="fs-skip">Skip First Steps and go to Hyrule Field</button>
      </div>
    </div>
  );
}
// ---------- help: always visible, a ladder ----------
function useHelp(stats, rungs) {
  const [lvl, setLvl] = useState(0); const [msg, setMsg] = useState('');
  const use = () => { const r = rungs[Math.min(lvl, rungs.length - 1)]; if (!r) return; stats.help++; setLvl(lvl + 1); setMsg(r.label); r.run(); sfx('tap'); };
  const ui = <div className="fshelp"><button className="btn help" onClick={use} data-testid="help-btn" aria-label="Help">🧚 Help</button>{msg && <span className="small muted" data-testid="help-msg">{msg}</span>}</div>;
  return { lvl, ui, reset: () => { setLvl(0); setMsg(''); } };
}
const Say = ({ text, slow }) => <span className="row" style={{ gap: 6 }}><PlayBtn lang="es" text={text} sm /><button className="btn sm ghost" onClick={() => say('es', text, { slow: true })} aria-label="slow" data-testid="slow">🐢</button></span>;
// ---------- steps ----------
function Meet({ item, onNext, count }) {
  useEffect(() => { const t = setTimeout(() => say('es', item.say), 350); return () => clearTimeout(t); }, [item.id]);
  return (
    <div className="card pop center" data-testid="fs-meet">
      <div className="muted small">Meet a new word</div>
      <div className="learn"><div className="pic emoji"><Pic item={item} e={item.e} /></div></div>
      <div className="huge" lang="es">{item.es}</div>
      <div className="row c"><Say text={item.say} /></div>
      <div className="muted">{item.en}</div>
      <div className="fb info" style={{ marginTop: 8 }}>🤸 Do it: {item.gesture}</div>
      <ActionBar><button className="btn primary wide" onClick={onNext} data-testid="next">Next</button></ActionBar>
    </div>
  );
}
function Tap({ target, pool, n, onDone, stats, title }) {
  const opts0 = useMemo(() => shuffle([target, ...shuffle(pool.filter((x) => x.id !== target.id && x.e !== target.e)).slice(0, n - 1)]), [target.id, n]);
  const [opts, setOpts] = useState(opts0); const [miss, setMiss] = useState(0); const [ok, setOk] = useState(false); const [shown, setShown] = useState(false); const [en, setEn] = useState(false); const [bad, setBad] = useState(null);
  useEffect(() => { const t = setTimeout(() => say('es', target.say), 300); return () => clearTimeout(t); }, [target.id]);
  const help = useHelp(stats, [
    { label: 'Listen again, slowly.', run: () => say('es', target.say, { slow: true }) },
    { label: 'Here it is in English.', run: () => setEn(true) },
    { label: 'One fewer choice.', run: () => setOpts((o) => { const w = o.find((x) => x.id !== target.id); return w ? o.filter((x) => x !== w) : o; }) },
    { label: 'Here is the answer. Tap it!', run: () => { setShown(true); stats.shown++; } },
  ]);
  const pick = (x) => { if (ok) return; emit('answer', { correct: x.id === target.id }); if (x.id === target.id) { setOk(true); sfx('good'); if (miss > 0) emit('comeback', { why: 'retry' }); setTimeout(() => onDone(miss === 0 && !shown), 650); } else { sfx('bad'); setBad(x.id); stats.miss++; const m = miss + 1; setMiss(m); if (m >= 2) { setShown(true); stats.shown++; } } };
  return (
    <div className="card pop center" data-testid="fs-tap">
      <div className="muted small">{title || 'Listen and tap the picture'}</div>
      <div className="row c" style={{ margin: '6px 0' }}><Say text={target.say} />{en && <span className="chip">{target.en}</span>}</div>
      <div className={`fschoices n${opts.length}`}>{opts.map((x) => <button key={x.id} className={`fspic ${ok && x.id === target.id ? 'right' : ''} ${bad === x.id && !ok ? 'wrong' : ''} ${shown && x.id === target.id ? 'hint' : ''}`} onClick={() => pick(x)} data-ok={x.id === target.id ? '1' : '0'} data-testid="fs-choice" aria-label={x.en}><span className="emoji"><Pic item={x} e={x.e} /></span>{(shown || en) && x.id === target.id ? <span className="small">{x.es}</span> : null}</button>)}</div>
      {miss === 1 && !ok && <div className="fb info small">Almost! Listen again and try another one.</div>}
      {shown && !ok && <div className="fb good small">Here it is: <b lang="es">{target.es}</b>. Tap it — that's good practice!</div>}
      {help.ui}
    </div>
  );
}
function Match({ items, onDone, stats }) {
  const pics = useMemo(() => shuffle(items), [items.map((x) => x.id).join()]);
  const [sel, setSel] = useState(null); const [done, setDone] = useState({}); const [miss, setMiss] = useState({}); const [shownFor, setShownFor] = useState(null); const [en, setEn] = useState(false); const [bad, setBad] = useState(null);
  const finish = (d) => { if (Object.keys(d).length === items.length) setTimeout(() => onDone(true), 600); };
  const help = useHelp(stats, [
    { label: 'Tap a word to hear it.', run: () => { const w = items.find((x) => !done[x.id]); if (w) { setSel(w.id); say('es', w.say, { slow: true }); } } },
    { label: 'English is showing now.', run: () => setEn(true) },
    { label: 'I matched one for you.', run: () => { const w = items.find((x) => !done[x.id]); if (w) { const d = { ...done, [w.id]: 1 }; setDone(d); finish(d); } } },
    { label: 'Look: the glowing picture goes with your word.', run: () => { const w = items.find((x) => x.id === sel && !done[x.id]) || items.find((x) => !done[x.id]); if (w) { setSel(w.id); setShownFor(w.id); stats.shown++; } } },
  ]);
  const tapPic = (p) => {
    if (!sel || done[p.id]) return;
    emit('answer', { correct: p.id === sel });
    if (p.id === sel) { sfx('good'); const d = { ...done, [p.id]: 1 }; setDone(d); setSel(null); setShownFor(null); finish(d); }
    else { sfx('bad'); setBad(p.id); stats.miss++; const m = (miss[sel] || 0) + 1; setMiss({ ...miss, [sel]: m }); if (m >= 2) { setShownFor(sel); stats.shown++; } }
  };
  return (
    <div className="card pop" data-testid="fs-match">
      <div className="muted small center">Match each word to its picture</div>
      <div className="fsmatch">
        <div className="col">{items.map((x) => <button key={x.id} className={`fsword ${sel === x.id ? 'sel' : ''} ${done[x.id] ? 'right' : ''}`} disabled={!!done[x.id]} onClick={() => { setSel(x.id); say('es', x.say); }} data-testid="fs-word" data-id={x.id} lang="es">{x.es}{en ? <span className="muted small"> · {x.en}</span> : null}</button>)}</div>
        <div className="col">{pics.map((p) => <button key={p.id} className={`fspic sm ${done[p.id] ? 'right' : ''} ${shownFor === p.id ? 'hint' : ''} ${bad === p.id ? 'wrong' : ''}`} disabled={!!done[p.id]} onClick={() => tapPic(p)} data-testid="fs-matchpic" data-id={p.id} aria-label={p.en}><span className="emoji"><Pic item={p} e={p.e} /></span></button>)}</div>
      </div>
      {help.ui}
    </div>
  );
}
function SayIt({ item, onDone, stats }) {
  const [res, setRes] = useState(null); const [tries, setTries] = useState(0); const [busy, setBusy] = useState(false);
  const mic = srAvailable('es');
  const go = async () => { setBusy(true); const r = await listenHandle('es', 6000).promise; setBusy(false); const m = matchSpeech('es', r.alts || [], [item.es]); const good = m.ok || m.score >= 0.55; setRes({ good, heard: m.heard }); setTries(tries + 1); if (good) { sfx('good'); emit('interaction'); setTimeout(() => onDone(true), 900); } else if (tries + 1 >= 2) { setTimeout(() => onDone(true), 1400); } };
  return (
    <div className="card pop center" data-testid="fs-say">
      <div className="muted small">Say it out loud (you can skip)</div>
      <div className="learn"><div className="pic emoji"><Pic item={item} e={item.e} /></div></div>
      <div className="huge" lang="es">{item.es}</div>
      <div className="row c"><Say text={item.say} /></div>
      {res && (res.good ? <div className="fb good">¡Muy bien! 🎉</div> : <div className="fb info">{tries >= 2 ? 'Great practice! Let’s keep going.' : `Nice try! I heard “${res.heard || '…'}”. Listen and try once more.`}</div>)}
      <ActionBar>
        <button className="btn" onClick={() => onDone(true)} data-testid="fs-skip-say">Skip</button>
        {mic ? <button className="btn primary wide mic" disabled={busy} onClick={go} data-testid="fs-mic">{busy ? '👂 Listening…' : '🎤 Say it'}</button> : <button className="btn primary wide" onClick={() => onDone(true)} data-testid="fs-said">I said it!</button>}
      </ActionBar>
    </div>
  );
}
function Build({ spec, S, onDone, stats }) {
  const target = fill(spec.word || spec.bank.join(' '), S);
  const bank = spec.bank ? spec.bank.map((w) => fill(w, S)) : null;
  const tiles0 = useMemo(() => bank ? shuffle(bank) : shuffle([...target.replace(/\s/g, '')].concat(shuffle([...'aeoslnr']).slice(0, 2))), [target]);
  const [mode, setMode] = useState('type'); const [val, setVal] = useState(''); const [used, setUsed] = useState([]); const [miss, setMiss] = useState(0); const [shown, setShown] = useState(false); const [en, setEn] = useState(false); const [ok, setOk] = useState(false); const [tip, setTip] = useState('');
  const choices = useMemo(() => shuffle([target, ...(bank ? [shuffle(bank).join(' '), [...bank].reverse().join(' ')] : [target.slice(0, -1) + (target.endsWith('a') ? 'o' : 'a'), target.length > 3 ? target[0] + target.slice(2) : target + 's'])].filter((v, i, a) => a.indexOf(v) === i)).slice(0, 3), [target]);
  const help = useHelp(stats, [
    { label: 'Listen again, slowly.', run: () => say('es', target, { slow: true }) },
    { label: 'In English it means: ' + (spec.en || ''), run: () => setEn(true) },
    { label: 'Here is the first ' + (bank ? 'word.' : 'letter.'), run: () => { if (bank) { setUsed([tiles0.indexOf(bank[0])]); setVal(bank[0]); } else setVal(target[0]); } },
    { label: mode === 'type' ? 'Now just choose.' : 'Now try typing.', run: () => setMode((m) => (m === 'type' ? 'choose' : 'type')) },
    { label: 'Here is the answer. Now try it yourself!', run: () => { setShown(true); stats.shown++; setVal(''); setUsed([]); } },
  ]);
  const check = (v) => {
    emit('answer', { correct: noAcc(v) === noAcc(target) });
    if (norm(v) === norm(target)) { setOk(true); sfx('good'); setTimeout(() => onDone(miss === 0), 800); return; }
    if (noAcc(v) === noAcc(target)) { setOk(true); setTip('Almost perfect — remember the accent: ' + target); sfx('good'); setTimeout(() => onDone(true), 1500); return; }
    sfx('bad'); stats.miss++; const m = miss + 1; setMiss(m); if (m >= 2) { setShown(true); stats.shown++; }
  };
  const addTile = (t, i) => { if (bank) { setUsed([...used, i]); setVal((v) => (v ? v + ' ' : '') + t); } else setVal((v) => v + t); };
  return (
    <div className="card pop center" data-testid="fs-build">
      <div className="muted small">Build it! {mode === 'type' ? 'Type it, or tap the tiles.' : 'Choose the right one.'}</div>
      <div className="row c" style={{ margin: '6px 0' }}><Say text={target} />{en && spec.en && <span className="chip">{spec.en}</span>}</div>
      {shown && !ok && <div className="fb good">The answer is <b lang="es">{target}</b>. Now you try!</div>}
      {mode === 'type' ? (<>
        <input className="field big" lang="es" data-answer={globalThis.__LQ_TEST__ ? target : undefined} value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') check(val); }} placeholder="type here" data-testid="fs-input" autoComplete="off" autoCapitalize="none" spellCheck={false} />
        <div className="fstiles">{tiles0.map((t, i) => <button key={i} className="tile" disabled={bank ? used.includes(i) : false} onClick={() => addTile(t, i)} data-testid="fs-tile">{t}</button>)}</div>
        {!bank && <AccentBar onInsert={(c) => setVal((v) => v + c)} />}
        <div className="row c"><button className="btn sm" onClick={() => { setVal(''); setUsed([]); }}>⌫ Clear</button><button className="btn sm ghost" onClick={() => setMode('choose')} data-testid="fs-choose-mode">👆 Choose instead</button></div>
      </>) : (<>
        <div className="fschoicetext">{choices.map((c) => <button key={c} className="btn wide" onClick={() => check(c)} data-ok={c === target ? '1' : '0'} data-testid="fs-build-choice" lang="es">{c}</button>)}</div>
        <button className="btn sm ghost" onClick={() => setMode('type')} data-testid="fs-type-mode">⌨️ Type instead</button>
      </>)}
      {miss === 1 && !ok && <div className="fb info small">Almost! Listen again, then try once more.</div>}
      {tip && <div className="fb info small">{tip}</div>}
      {help.ui}
      {mode === 'type' && <ActionBar><button className="btn primary wide" disabled={!val.trim() || ok} onClick={() => check(val)} data-testid="fs-check">Check</button></ActionBar>}
    </div>
  );
}
function Chat({ lines, S, onDone, stats }) {
  const mentor = partner() || 'navi'; const mentorName = name(mentor);
  const [k, setK] = useState(0); const [miss, setMiss] = useState(0); const [shown, setShown] = useState(false); const [en, setEn] = useState(false); const [said, setSaid] = useState([]);
  const L = lines[k]; const m = fill(L.m, S).replace('Me llamo Navi', 'Me llamo ' + mentorName).replace('¡Hola, Navi!', '¡Hola, ' + mentorName + '!'); const a = fill(L.a, S).replace('¡Hola, Navi!', '¡Hola, ' + mentorName + '!'); const b = fill(L.b, S).replace('Me llamo Navi', 'Me llamo ' + mentorName);
  const opts = useMemo(() => shuffle([a, b]), [k]);
  useEffect(() => { const t = setTimeout(() => say('es', m), 300); return () => clearTimeout(t); }, [k]);
  const help = useHelp(stats, [
    { label: 'Listen again, slowly.', run: () => say('es', m, { slow: true }) },
    { label: 'Here it is in English.', run: () => setEn(true) },
    { label: 'This one is right. Tap it!', run: () => { setShown(true); stats.shown++; } },
  ]);
  const pick = (o) => { emit('answer', { correct: o === a }); if (o === a) { sfx('good'); say('es', a); const s2 = [...said, [m, a]]; setSaid(s2); setMiss(0); setShown(false); setEn(false); help.reset(); if (k + 1 >= lines.length) setTimeout(() => onDone(true), 900); else setTimeout(() => setK(k + 1), 900); } else { sfx('bad'); stats.miss++; const mm = miss + 1; setMiss(mm); if (mm >= 2) { setShown(true); stats.shown++; } } };
  return (
    <div className="card pop" data-testid="fs-chat">
      <div className="muted small center">Mini chat with {mentorName}</div>
      <div className="fschat">{said.map(([q, r], i) => <React.Fragment key={i}><div className="bub npc" lang="es">{q}</div><div className="bub me" lang="es">{r}</div></React.Fragment>)}
        <div className="row"><Portrait who={mentor} size="sm" /><div className="bub npc big" lang="es">{m} <PlayBtn lang="es" text={m} sm /></div></div>
        {en && <div className="muted small">{fill(L.en, S)}</div>}</div>
      <div className="fschoicetext">{opts.map((o) => <button key={o} className={`btn wide ${shown && o === a ? 'hintbtn' : ''}`} onClick={() => pick(o)} data-ok={o === a ? '1' : '0'} data-testid="fs-chat-choice" lang="es">{o}</button>)}</div>
      {miss === 1 && !shown && <div className="fb info small">Hmm, listen again and try the other one.</div>}
      {help.ui}
    </div>
  );
}
function Win({ stars, idx, onNext }) {
  useEffect(() => { sfx('win'); }, []);
  return (
    <div className="card pop center" data-testid="fs-win">
      <div className="huge emoji">🎉</div><h2>Step {idx + 1} done!</h2><Stars n={stars} />
      <Navi small>{stars === 3 ? '¡Excelente! You did it all by yourself.' : 'Great work! Using help is how we learn.'}</Navi>
      <div className="muted small">These words come back for a quick review next time.</div>
      <ActionBar><button className="btn primary wide" onClick={onNext} data-testid="fs-continue">Continue</button></ActionBar>
    </div>
  );
}
function Champion({ onNext }) {
  const { S } = useApp();
  useEffect(() => { sfx('win'); }, []);
  return (
    <div className="card pop center cert" data-testid="fs-champion">
      <div className="huge emoji">🏆</div><h2>First Steps champion!</h2>
      <p><b>{nickOf(S)}</b> finished all of Primeros pasos and can:</p>
      <div style={{ textAlign: 'left', display: 'inline-grid', gap: 4 }}>{FS_UNITS.map((u) => <div key={u.id}>✅ {u.ican}</div>)}</div>
      <Navi small>Next stop: Hyrule Field! New places, new friends, and your first temple.</Navi>
      <ActionBar><button className="btn primary wide" onClick={onNext} data-testid="fs-continue">Enter Hyrule Field</button></ActionBar>
    </div>
  );
}
// ---------- a lesson: 2 quick review items, then I do → we do → you do (max ~10 items) ----------
export function FSLesson({ idx }) {
  const { S, set, go } = useApp();
  const L = FS_LESSONS[idx];
  const stats = useRef({ miss: 0, help: 0, shown: 0 }).current;
  const steps = useMemo(() => {
    if (L.champion) return [{ k: 'champion' }];
    const st = fsState(S); const prev = FS_LESSONS.slice(0, idx).flatMap((l) => l.items);
    const due = prev.slice().sort((a, b) => ((st.srs[a.id] || {}).d || 0) - ((st.srs[b.id] || {}).d || 0));
    const rev = due.slice(0, L.review || 2);
    const pool = [...L.items, ...prev];
    const out = rev.map((r) => ({ k: 'review', item: r, pool: prev.length >= 3 ? prev : allItems }));
    for (const it of L.items) out.push({ k: 'meet', item: it });
    const items = L.items.length ? L.items : rev;
    if (items.length) {
      const t1 = items[0], t2 = items[Math.min(1, items.length - 1)];
      out.push({ k: 'tap', item: t1, n: 2, pool }); out.push({ k: 'tap', item: t2, n: 3, pool });
      out.push({ k: 'match', items: items.slice(0, 4) });
      if (L.items.length) out.push({ k: 'say', item: L.items[L.items.length > 1 ? 1 : 0] });
      if (L.build) out.push({ k: 'build', spec: { ...L.build, en: L.build.word ? (L.items.find((x) => norm(x.es).endsWith(norm(L.build.word))) || {}).en : (L.items[0] || {}).en } });
    }
    if (L.chat) out.push({ k: 'chat' });
    out.push({ k: 'win' });
    return out;
  }, [idx]);
  const [i, setI] = useState(0);
  useEffect(() => { setLesson('firststeps-' + (idx + 1) + '-' + Date.now()); }, []);
  const next = () => setI((x) => Math.min(x + 1, steps.length - 1));
  const stars = stats.shown ? 1 : stats.help || stats.miss > 1 ? 2 : 3;
  const save = () => {
    set((s) => {
      const f = (s.es.fs = Object.assign({ done: {}, srs: {} }, s.es.fs || {}));
      f.done = f.done || {}; f.srs = f.srs || {};
      f.done[idx] = Math.max(f.done[idx] || 0, stars);
      const t = today();
      for (const it of L.items) { f.srs[it.id] = { b: 1, d: t + 1 }; if (/^es\d+[wp]\d+$/.test(it.id)) introduce(s.es, it.id); }
      for (const st of steps) if (st.k === 'review') { const r = f.srs[st.item.id] || { b: 1 }; const b = Math.min(5, (r.b || 1) + 1); f.srs[st.item.id] = { b, d: t + [1, 2, 3, 5, 8, 13][b] }; }
      if (stats.help) { f.help = (f.help || 0) + 1; s.treasure.flags.helpfinish = 1; }
      s.rupees += 5;
    });
    emit('lesson:done', { app: 'language', lesson: 'firststeps-' + (idx + 1) }); if (stats.help) emit('comeback', { why: 'help' });
  };
  const st = steps[i];
  const doneStep = () => next();
  let body = null;
  if (st.k === 'review') body = <Tap key={i} target={st.item} pool={st.pool} n={3} stats={stats} title="Quick review: listen and tap" onDone={doneStep} />;
  else if (st.k === 'meet') body = <Meet key={i} item={st.item} onNext={doneStep} />;
  else if (st.k === 'tap') body = <Tap key={i} target={st.item} pool={st.pool} n={st.n} stats={stats} onDone={doneStep} />;
  else if (st.k === 'match') body = <Match key={i} items={st.items} stats={stats} onDone={doneStep} />;
  else if (st.k === 'say') body = <SayIt key={i} item={st.item} stats={stats} onDone={doneStep} />;
  else if (st.k === 'build') body = <Build key={i} spec={st.spec} S={S} stats={stats} onDone={doneStep} />;
  else if (st.k === 'chat') body = <Chat key={i} lines={L.chat} S={S} stats={stats} onDone={doneStep} />;
  else if (st.k === 'win') body = <Win key={i} idx={idx} stars={stars} onNext={() => { save(); go('lang', { lang: 'es' }); }} />;
  else if (st.k === 'champion') body = <Champion key={i} onNext={() => { set((s) => { const f = (s.es.fs = Object.assign({ done: {}, srs: {} }, s.es.fs || {})); f.done[idx] = 3; f.champion = Date.now(); s.treasure.flags.firststeps = 1; s.rupees += 20; }); emit('lesson:done', { app: 'language', lesson: 'firststeps-champion' }); go('lang', { lang: 'es' }); }} />;
  return (
    <div className="main" data-card={i} data-testid="fs-lesson-wrap">
      <div className="fsprog" aria-label={`step ${i + 1} of ${steps.length}`}>{steps.map((_, k) => <span key={k} className={k < i ? 'd' : k === i ? 'c' : ''} />)}</div>
      {body}
    </div>
  );
}
