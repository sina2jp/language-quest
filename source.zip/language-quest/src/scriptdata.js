// Persian letters: [char, name in Persian, name, sound, connects to the next letter, shape family]
export const LETTERS = [
  ['ا', 'الف', 'alef', 'â / a', false, 'alef'], ['آ', 'آ', 'â (alef with a hat)', 'â', false, 'alef'],
  ['ب', 'به', 'be', 'b', true, 'be'], ['پ', 'په', 'pe', 'p', true, 'be'], ['ت', 'ته', 'te', 't', true, 'be'], ['ث', 'ثه', 'se', 's', true, 'be'],
  ['ج', 'جیم', 'jim', 'j', true, 'jim'], ['چ', 'چه', 'che', 'ch', true, 'jim'], ['ح', 'حه', 'he', 'h', true, 'jim'], ['خ', 'خه', 'khe', 'kh', true, 'jim'],
  ['د', 'دال', 'dâl', 'd', false, 'dal'], ['ذ', 'ذال', 'zâl', 'z', false, 'dal'],
  ['ر', 'ره', 're', 'r', false, 're'], ['ز', 'زه', 'ze', 'z', false, 're'], ['ژ', 'ژه', 'zhe', 'zh', false, 're'],
  ['س', 'سین', 'sin', 's', true, 'sin'], ['ش', 'شین', 'shin', 'sh', true, 'sin'],
  ['ص', 'صاد', 'sâd', 's', true, 'sad'], ['ض', 'ضاد', 'zâd', 'z', true, 'sad'], ['ط', 'طا', 'tâ', 't', true, 'ta'], ['ظ', 'ظا', 'zâ', 'z', true, 'ta'],
  ['ع', 'عین', 'eyn', 'a short stop', true, 'eyn'], ['غ', 'غین', 'gheyn', 'gh', true, 'eyn'],
  ['ف', 'فه', 'fe', 'f', true, 'fe'], ['ق', 'قاف', 'ghâf', 'gh', true, 'fe'], ['ک', 'کاف', 'kâf', 'k', true, 'kaf'], ['گ', 'گاف', 'gâf', 'g', true, 'kaf'],
  ['ل', 'لام', 'lâm', 'l', true, 'lam'], ['م', 'میم', 'mim', 'm', true, 'mim'], ['ن', 'نون', 'nun', 'n', true, 'nun'],
  ['و', 'واو', 'vâv', 'v, u or o', false, 'vav'], ['ه', 'هه', 'he', 'h, or e at the end', true, 'he'], ['ی', 'یه', 'ye', 'y or i', true, 'ye'],
];
export const LT = Object.fromEntries(LETTERS.map((l) => [l[0], l]));

// Lessons: letters grouped by shape family; reading words he already knows by ear.
export const LESSONS = [
  { title: 'Right to left! Alef and Be', letters: ['ا', 'آ', 'ب'], note: 'Farsi is written from RIGHT to LEFT. Alef (ا) never holds hands with the letter after it.', words: [['بابا', 'bâbâ', 'dad', '👨'], ['آب', 'âb', 'water', '💧']] },
  { title: 'Mim and Nun', letters: ['م', 'ن'], note: 'Nun (ن) has one dot on top. Mim (م) is a little round head.', words: [['مامان', 'mâmân', 'mom', '👩'], ['نان', 'nân', 'bread', '🍞'], ['بام', 'bâm', 'roof', '🏠']] },
  { title: 'The dots family: Pe, Te, Se, Ye', letters: ['پ', 'ت', 'ث', 'ی'], note: 'Same shape, different dots! Pe has 3 dots under, Te has 2 on top, Se has 3 on top.', words: [['پا', 'pâ', 'foot', '🦶'], ['تاب', 'tâb', 'swing', '🛝'], ['بینی', 'bini', 'nose', '👃'], ['نی', 'ni', 'straw', '🥤']] },
  { title: 'The lonely letters', letters: ['د', 'ر', 'ز', 'و', 'ذ', 'ژ'], note: 'These letters never hold hands with the letter AFTER them (just like alef).', words: [['در', 'dar', 'door', '🚪'], ['رود', 'rud', 'river', '🏞️'], ['ابر', 'abr', 'cloud', '☁️'], ['باران', 'bârân', 'rain', '🌧️'], ['دندان', 'dandân', 'tooth', '🦷'], ['زرد', 'zard', 'yellow', '💛'], ['توپ', 'tup', 'ball', '⚽'], ['روز', 'ruz', 'day', '🌞']] },
  { title: 'Sin and Shin: the teeth letters', letters: ['س', 'ش'], note: 'Sin (س) has three little teeth. Shin (ش) has teeth AND three dots.', words: [['سیب', 'sib', 'apple', '🍎'], ['دست', 'dast', 'hand', '✋'], ['سبز', 'sabz', 'green', '💚'], ['شب', 'shab', 'night', '🌙'], ['شیر', 'shir', 'milk / lion', '🥛'], ['دوست', 'dust', 'friend', '🤝']] },
  { title: 'The cup letters: Jim, Che, He, Khe', letters: ['ج', 'چ', 'ح', 'خ'], note: 'They look like a cup. The dots tell them apart.', words: [['چای', 'châi', 'tea', '🍵'], ['خرس', 'khers', 'bear', '🐻'], ['چشم', 'cheshm', 'eye', '👁️'], ['خواب', 'khâb', 'sleep', '😴'], ['جوراب', 'jurâb', 'sock', '🧦']] },
  { title: 'Kaf and Gaf', letters: ['ک', 'گ'], note: 'Gaf (گ) is Kaf (ک) with an extra line on top.', words: [['کتاب', 'ketâb', 'book', '📖'], ['سگ', 'sag', 'dog', '🐶'], ['کیک', 'keyk', 'cake', '🎂'], ['گوش', 'gush', 'ear', '👂'], ['کوچک', 'kuchek', 'small', '🐜']] },
  { title: 'Lam: the tall letter', letters: ['ل'], note: 'Lam (ل) is tall like a hook. Now you can read “salâm”!', words: [['سلام', 'salâm', 'hello', '👋'], ['گل', 'gol', 'flower', '🌸'], ['لب', 'lab', 'lip', '👄'], ['لباس', 'lebâs', 'clothes', '👕'], ['بلبل', 'bolbol', 'nightingale', '🐦']] },
  { title: 'He: the shape-changer', letters: ['ه'], note: 'He (ه) changes shape a lot. At the end of a word it often sounds like “e”.', words: [['خانه', 'khâne', 'house', '🏠'], ['گربه', 'gorbe', 'cat', '🐱'], ['ماه', 'mâh', 'moon', '🌙'], ['کوه', 'kuh', 'mountain', '⛰️'], ['سه', 'se', 'three', '3️⃣'], ['ده', 'dah', 'ten', '🔟']] },
  { title: 'Fe and Ghaf', letters: ['ف', 'ق'], note: 'Fe (ف) has one dot, Ghaf (ق) has two dots and a deeper bowl.', words: [['فیل', 'fil', 'elephant', '🐘'], ['قرمز', 'ghermez', 'red', '❤️'], ['برف', 'barf', 'snow', '❄️'], ['آفتاب', 'âftâb', 'sunshine', '☀️'], ['قاشق', 'ghâshogh', 'spoon', '🥄']] },
  { title: 'Eyn and Gheyn', letters: ['ع', 'غ'], note: 'Eyn (ع) and Gheyn (غ) look like a little open mouth.', words: [['عمو', 'amu', 'uncle (dad\u2019s brother)', '👨'], ['غذا', 'ghazâ', 'food', '🍲'], ['باغ', 'bâgh', 'garden', '🌳'], ['مرغ', 'morgh', 'chicken', '🐔'], ['عسل', 'asal', 'honey', '🍯']] },
  { title: 'Sad, Zad, Ta, Za', letters: ['ص', 'ض', 'ط', 'ظ'], note: 'These letters are rarer. They often come in words from Arabic.', words: [['صبح', 'sobh', 'morning', '🌅'], ['طوطی', 'tuti', 'parrot', '🦜'], ['ظهر', 'zohr', 'noon', '🕛'], ['صبحانه', 'sobhâne', 'breakfast', '🥣']] },
  { title: 'Short vowels (optional marks)', letters: ['َ', 'ِ', 'ُ'], marks: true, note: 'Short vowels are usually NOT written! Kids’ books add little marks: zebar (َ) = a, zir (ِ) = e, pish (ُ) = o.', words: [['گُل', 'gol', 'flower', '🌸'], ['دَست', 'dast', 'hand', '✋'], ['کِتاب', 'ketâb', 'book', '📖'], ['شُتُر', 'shotor', 'camel', '🐫']] },
];

// ---------- reading gate: script appears only for words made of letters the Letters track has covered ----------
const IGNORE = /[\s\u200c\u200d\u064B-\u0652\u0670\u0640؟?!.,،؛:«»()"'\-…0-9۰-۹]/g;
export function learnedSet(step) {
  const set = new Set();
  for (let i = 0; i < Math.min(step, LESSONS.length); i++) for (const l of LESSONS[i].letters) set.add(l);
  if (set.has('ا')) set.add('آ');
  if (step >= LESSONS.length) ['ء', 'ئ', 'أ', 'ؤ', 'ة', 'إ', 'ي', 'ك'].forEach((c) => set.add(c));
  return set;
}
export function canRead(text, set) {
  if (!text) return false;
  for (const ch of text.replace(IGNORE, '')) if (!set.has(ch)) return false;
  return true;
}

// ---------- short-vowel marks from the transliteration (heuristic aligner; null when unsure) ----------
const CONS = { b: 'ب', p: 'پ', t: 'تط', s: 'سصث', j: 'ج', ch: 'چ', h: 'هح', kh: 'خ', d: 'د', z: 'زذضظ', r: 'ر', zh: 'ژ', sh: 'ش', gh: 'غق', q: 'ق', f: 'ف', k: 'ک', g: 'گ', l: 'ل', m: 'م', n: 'ن', v: 'و', w: 'و', y: 'ی', x: 'خ', "'": 'عءئأؤ' };
const HAR = { a: '\u064E', e: '\u0650', o: '\u064F' };
function phonemes(t) {
  const s = t.toLowerCase().replace(/[^a-zâ' ]/g, '');
  const out = [];
  for (let i = 0; i < s.length;) {
    const two = s.slice(i, i + 2);
    if (['kh', 'gh', 'sh', 'ch', 'zh'].includes(two)) { out.push(two); i += 2; continue; }
    out.push(s[i]); i++;
  }
  return out;
}
function alignWord(f, t) {
  const L = [...f.replace(/[\u064B-\u0652]/g, '')]; const zw = new Set();
  const S = []; L.forEach((c) => { if (c === '\u200c') zw.add(S.length - 1); else S.push(c); });
  const P = phonemes(t.replace(/-/g, ''));
  const ezafe = /-y?e$/.test(t) && !/[هی]$/.test(f) ? true : false;
  const P2 = ezafe ? P.slice(0, P[P.length - 2] === 'y' ? -2 : -1) : P;
  const memo = new Map();
  const go = (i, j) => {
    const key = i * 1000 + j; if (memo.has(key)) return memo.get(key);
    let r = null;
    if (i === S.length && j === P2.length) r = [];
    else if (j < P2.length) {
      const p = P2[j], c = S[i];
      const tryT = (ni, nj, emit) => { if (r) return; const rest = go(ni, nj); if (rest) r = [...emit, ...rest]; };
      if ('aeo'.includes(p)) {
        if (i === 0 && (c === 'ا' || c === 'ع')) tryT(1, j + 1, [[0, HAR[p]]]);
        if (p === 'e' && c === 'ه' && i === S.length - 1 && j === P2.length - 1) tryT(i + 1, j + 1, i > 0 ? [[i - 1, HAR.e]] : []);
        if (p === 'o' && c === 'و') tryT(i + 1, j + 1, []);
        if (i > 0 && P2[j + 1] !== 'y') tryT(i, j + 1, [[i - 1, HAR[p]]]);
        if (i > 0 && P2[j + 1] === 'y') tryT(i, j + 1, []);
      } else if (p === 'â') {
        if (c === 'ا' || c === 'آ') tryT(i + 1, j + 1, []);
        if (c === 'و' && S[i + 1] === 'ا' && i > 0 && S[i - 1] === 'خ') tryT(i + 2, j + 1, []);
      } else if (p === 'u') {
        if (c === 'و') tryT(i + 1, j + 1, []);
        if (i === 0 && c === 'ا' && S[1] === 'و') tryT(2, j + 1, []);
      } else if (p === 'i') {
        if (c === 'ی') tryT(i + 1, j + 1, []);
        if (i === 0 && c === 'ا' && S[1] === 'ی') tryT(2, j + 1, []);
      } else if (CONS[p] && c && CONS[p].includes(c)) {
        if (P2[j + 1] === p) tryT(i + 1, j + 2, [[i, '\u0651']]);
        tryT(i + 1, j + 1, []);
      }
    }
    memo.set(key, r); return r;
  };
  const marks = go(0, 0);
  if (!marks) return null;
  const add = {}; marks.forEach(([k, h]) => { add[k] = (add[k] || '') + h; });
  if (ezafe) add[S.length - 1] = (add[S.length - 1] || '') + HAR.e;
  let out = '';
  S.forEach((c, k) => { out += c + (add[k] || ''); if (zw.has(k)) out += '\u200c'; });
  return out;
}
const vcache = new Map();
export function vowelize(f, t) {
  if (!f || !t) return null;
  const key = f + '|' + t; if (vcache.has(key)) return vcache.get(key);
  const fw = f.trim().split(/\s+/), tw = t.trim().replace(/[.,!?؟،]/g, '').split(/\s+/);
  let res = null;
  if (fw.length === tw.length) {
    const parts = fw.map((w, k) => { const m = w.match(/^([^\u0600-\u06FF]*)(.*?)([^\u0600-\u06FF\u200c]*)$/); const a = alignWord(m[2], tw[k]); return a == null ? null : m[1] + a + m[3]; });
    if (parts.every((x) => x != null)) res = parts.join(' ');
  }
  vcache.set(key, res); return res;
}
