# Spanish content review: summary (units 1–20)

The corrections file is `/tmp/lq/review/es_corrections.json`. It holds 458 entries: **56 errors** and **402 improvements**. The JSON loads, and every `old` value was checked against the unit files.

All 20 units got two independent passes: a full line-by-line pass, then a second pass that looked only for problems the first had missed. Automated checks also covered answer-index bounds, whether each `fill/a` appears in its `opts`, missing ¿/¡, Spain-only words in the default text, missing accents, and gender vs article. No `a` or `wa` index was out of range.

Conventions in the file:
- `"old": null` means the key does not exist yet (for example a new `esp` or `exEsp`).
- `"new": null` means delete the key. This is used once, for a leftover internal `flag` note in u07 `words/24`.
- A few entries replace a whole word object (`words/N`) to add `esp` and `exEsp` together.

## Most common problems (approximate; paired es/en fixes counted separately)
| Type | ~Count |
|---|---|
| English glosses that don't match the Spanish or are unnatural (exEn, en, song translations) | 115 |
| Unnatural or incorrect Spanish in word examples and phrases (missing articles or personal *a*, "sorprendido mucho", "la puerta lenta", "Hay cero rupias") | 66 |
| Grammar items, mistake types, build tiles and culture: broken blanks ("Es es la una", "¿Al al río?", "la ropa la ropa", "Hoy es hoy lunes"), identical options (u12 qué/qué), invalid `mt: "number"` | 65 |
| Why-lists where more than one reason is true (marked `why-convention:`, see below) | 46 |
| Song lines that are ungrammatical or mistranslated ("cielo raso" = ceiling, "ceno tampoco", "leo y contento") | 44 |
| Role or boss answers that don't answer the question (u03 five sides → hexágono should be pentágono) | 39 |
| Spain variants missing or wrong (manejar→conducir, piso→suelo, chile→guindilla not pimiento, fontanero, dormitorio…) | 34 |
| Learner-facing English fields left in Spanish (titleEn in u01, 08, 09, 10, 11, 14, 20; ican, goals and prompts in u08, 11, 14) | 24 |
| Ambiguous items with 2+ correct options (hay viento, ¿Dónde te duele?, usted forms Le/Puede/Tiene, Fuimos) | 18 |
| Grammar `explain` written in Spanish (u01, 06, 08, 11, 14, 17, 20), rewritten in English | 7 |

Other notable fixes:
- **Unit 11, "chaqueta":** in Mexico this is also vulgar slang. Replaced with "chamarra", with "chaqueta" moved to the Spain variant.
- **Unit 10, "el pollo":** glossed as "chick"; it means chicken. Changed to "el pollito".
- **Unit 10, monarch butterflies:** the culture note said they leave Mexico in winter; they migrate *to* Mexico.
- **Unit 15, title:** "ranchería" means a small rural settlement, not a ranch. Changed to "rancho".
- **Unit 15, culture:** the Spanish phrase "Necesito ayuda y mi ubicación" was garbled. Also clarified that 911 is Mexico's number and 112 is Spain's.

## Needs a decision / uncertain (not changed, or changed but optional)
1. **How "why" reasons are graded.** In most units, every reason in a why-list is a true statement about its own option (e.g. "Hay = there is" / "Tengo = I have"), and the schema's own example works the same way. If the app marks every reason except `wa` as wrong, a child who picks a true statement gets marked wrong.
   - Fixing it in the content means rewriting the other reasons as false statements. The 46 entries marked `why-convention:` do this, mostly in u01, 02, 04, 07, 09 and 10.
   - Other units still use the all-true style.
   - Either keep these entries and finish the rest, or drop them all and change the app's rule (grade the reason that explains the correct answer).
2. **Culture text is in Spanish in 19 of 20 units** (only u15 is in English), while the schema example is English. A beginner can't read it. Not changed.
3. **Answer position.** About 90% of `a` values are 0. If the app does not shuffle options, a child can always pick the first one. Not changed.
4. **Mexican vs neutral vocabulary, left as is:** piscina (Mexico: alberca), acera (banqueta), "las cuatro menos cuarto" (Mexico: "cuarto para las cuatro"), tortilla (in Spain an omelette), "almorzar" in Spain. Changes that were made: catarina for mariquita, lagartija for lagarto, patineta for monopatín, cuarto de lavado for lavandería (all marked improve).
5. **Wrong options that are silly or random** in some bosses (e.g. "Me llamo parque.", "Soy policía de helados.") go against the schema's "not silly-random" rule. Not rewritten.
6. **Topic overlap and repeats:** u16 reuses weather words from u11, and u05 and u07 share the school-uniform culture fact. Not changed.
7. **Emoji mismatches:** only a few were fixed (u09 table, u07 jeans, u10 donkey). Others, like the u11 beanie shown as a baseball cap, were left.
8. **Duplicate "number" mistake type:** singular/plural items were mapped to `mt: "gender"`, because the schema has no "number" type. Adding "number" to the schema may be better.
