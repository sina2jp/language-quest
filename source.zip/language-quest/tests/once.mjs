// v7.3 caps + banking through the app's payOnce() and the real family-wallet 1.2 (fake clock, no browser)
import * as esbuild from 'esbuild';
const mem = {}; globalThis.localStorage = { getItem: (k) => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: (k) => { delete mem[k]; }, key: (i) => Object.keys(mem)[i] || null, get length() { return Object.keys(mem).length; } };
globalThis.window = globalThis; globalThis.document = { addEventListener() {}, visibilityState: 'visible', hidden: false }; globalThis.location = { protocol: 'https:', origin: 'https://x', search: '' };
globalThis.CustomEvent = class { constructor(t, o) { this.type = t; this.detail = o && o.detail; } }; globalThis.dispatchEvent = () => true;
await esbuild.build({ stdin: { contents: "export * from './src/wallet.js'; export { emit } from './src/hooks.js';", resolveDir: process.cwd(), loader: 'js' }, bundle: true, format: 'esm', platform: 'neutral', outfile: '/tmp/lq_wb2.mjs', logLevel: 'error', loader: { '.js': 'jsx' }, mainFields: ['module', 'main'] });
const WB = await import('/tmp/lq_wb2.mjs'); const FW = WB.FW;
let fail = 0; const ok = (n, c, info = '') => { console.log((c ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); if (!c) fail++; };
let clock = Date.parse('2026-11-23T17:00:00Z'); // a Monday
FW.configure({ now: () => clock });
ok('family-wallet 1.2.0 with earnOnce / rupeesOnce / policy / bankedNow', FW.MODULE_VERSION === '1.2.0' && typeof FW.earnOnce === 'function' && typeof FW.bankedNow === 'function');
ok('policy defaults: no repeats on, 6 lesson shards per app per day', FW.policy().noRepeats === true && FW.policy().onceDailyCap === 6, JSON.stringify(FW.policy()));
// one heavy day: the 6 First Steps groups (2 each = 12) + 2 unit parts + a boss (3) = 17 requested
const ids = ['firststeps:group-hello:pass', 'firststeps:group-count:pass', 'firststeps:group-colors:pass', 'firststeps:group-world:pass', 'firststeps:group-me:pass', 'firststeps:group-champ:pass'];
const r = ids.map((id) => WB.payOnce(id, 2, id));
r.push(WB.payOnce('unit:es-u1:part1:pass', 1, 'u1 p1')); r.push(WB.payOnce('unit:es-u1:part2:pass', 1, 'u1 p2')); r.push(WB.payOnce('boss:es-u1', 3, 'boss'));
const paid1 = r.reduce((n, x) => n + x.paid, 0), banked1 = r.reduce((n, x) => n + x.banked, 0);
ok('daily cap: day 1 pays 6 shards, banks the other 11 (true learning is never lost)', paid1 === 6 && banked1 === 11 && FW.balance().language === 6 && FW.bankedNow().language === 11, JSON.stringify({ paid1, banked1, bal: FW.balance().language, bank: FW.bankedNow() }));
ok('a repeat of any of them pays 0 (reason "repeat"), even while banked', WB.payOnce(ids[0], 2, 'again').reason === 'repeat' && WB.payOnce('boss:es-u1', 3, 'again').paid === 0);
clock += 864e5; // day 2: releaseBanked at app start pays up to the cap
const rel = FW.releaseBanked('language');
ok('day 2: banked shards are released at start, within the day\'s cap (6), oldest first', FW.balance().language === 12 && FW.bankedNow().language === 5, JSON.stringify({ rel, bal: FW.balance().language, bank: FW.bankedNow() }));
const d2 = WB.payOnce('review:es:x:pass', 1, 'review'); // the cap is full today: banked
ok('day 2: a new pass after the released shards is banked (cap full)', d2.paid === 0 && d2.banked === 1, JSON.stringify(d2));
clock += 864e5; FW.releaseBanked('language');
ok('day 3: the rest is paid (5 + 1 = 6 = the cap), nothing lost, nothing doubled: 18 total', FW.balance().language === 18 && (FW.bankedNow().language || 0) === 0, JSON.stringify({ bal: FW.balance().language, bank: FW.bankedNow() }));
// rapid guessing: 'guessing' keeps the pass pending (onceId not used), paid on the next calm screen after the pause
clock += 864e5; for (let k = 0; k < 4; k++) FW.answer('language', false, 'g');
const g = WB.payOnce('firststeps:group-new:pass', 2, 'during the pause');
const pend1 = JSON.parse(localStorage.getItem('langQuest.oncePending') || '[]').length;
clock += 61000; const paidLater = WB.retryPending();
ok('rapid guessing: the pass is kept (pending) and paid after the 60 s pause by retryPending()', g.reason === 'guessing' && g.pending && pend1 === 1 && paidLater === 2 && !localStorage.getItem('langQuest.oncePending'), JSON.stringify({ g, pend1, paidLater }));
// time: repeat minutes count as minutes but earn no shards
WB.setReview(true); const t0 = FW.balance().language; FW.tickActive('language', 20 * 60000, { repeat: WB.isRepeat() }); WB.setReview(false);
ok('review minutes count but earn no time shards (isRepeat)', FW.balance().language === t0, String(FW.balance().language - t0));
// the grown-up turns "no repeats" off in the Hub: practice replays may pay again (module decides)
const st = JSON.parse(localStorage.getItem('familyApps.wallet.v1')); st.settings.noRepeats = false; localStorage.setItem('familyApps.wallet.v1', JSON.stringify(st));
WB.setRepeat(true); const off = WB.payOnce(ids[0], 2, 'practice with the rule off'); WB.setRepeat(false);
ok('with the Hub rule "no repeats" off, a practice pass goes to the module, which pays the repeat again', WB.noRepeats() === false && off.paid + off.banked === 2, JSON.stringify(off));
process.exit(fail ? 1 : 0);
