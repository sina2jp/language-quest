# Farsi content review — summary

Corrections file: `/tmp/lq/review/fa_corrections.json` (1,113 entries, valid JSON; every `old` was checked against the content files as of 02:26 PT).

| Severity | Count |
|---|---|
| error | 719 |
| improve | 394 |

Units 11–20 and all phrases were reviewed line by line first. Units 1–10 were reviewed in parallel by two helper reviewers, then merged and de-duplicated with the cross-unit bulk checks.

## Most common problem types
| Type | ≈ Count | Typical examples |
|---|---|---|
| Missing or wrong written form (w/wt) | 489 | Spoken items with no standard written form: میای/میام → می‌آیی/می‌آیم, رو → را, اون → آن/او, copula -e → است, -in → -id (رفتین → رفتید), تو → در, دیروز رفتم مدرسه → دیروز به مدرسه رفتم. Also: u14 words اون/اونجا had no w at all. |
| Transliteration vs scheme | 412 | oo → u (bekhoonam → bekhunam), q → gh (naqshe, Qeshm, Qom, somâq, musiqi), missing â (nahâr → nâhâr, tabestun → tâbestun, mikhabam, âmade, fal → fâl, dust dari → dust dâri), dost → dust (friend), châhârshanbe → chahârshanbe, gozashtim → gozâshtim, serkeh/sekeh/sofreh → serke/sekke/sofre, missing ezafe (u2 "mâmân man-e" → "mâmân-e man-e"), mi-rovim → miravim, stray typos (mikhori m, âm adam, nemigirīm). |
| Spoken spelling / TTS | 93 | Kasra used instead of the copula ه (چندِ، بلندِ، ایرانِ، منِه); یلدائه → یلداست; پیراهن → پیرهن (spoken pirhan); written یک/او in spoken lines → یه/اون (u19); خونس → خونه‌س. |
| Unnatural phrasing, wrong collocation, answer content | 59 | Hat with پوشیدن → کلاه سر کردن (u13). کارت دارین؟ means "do you have a card?", so it becomes کارتخون دارین؟ (u14). رشت تو کجاست؟ (u16). Answers that don't fit the question (e.g. "Okay, thanks!" to "Are you ready?"). A negative question answered with «نه، خوردیم» → «چرا، خوردیم». |
| Spanish `titleEn` | 20 | All 20 units have a Spanish `titleEn`; replaced with the English title. |
| Translation | 21 | senjed ≠ jujube (it is oleaster); mashgh is not an "old word"; a few en lines. |
| Quiz items with 2+ correct options | 17 | Usually a blank en lets two options work, e.g. پارک ___ مدرسه‌س (کنار/پشت), شب ___ می‌خوابم (زود/دیر), ro/râ items not marked "spoken", رفتیم دید و بازدید (also natural). Most were fixed by making the en specific; some by swapping the distractor. |
| Culture facts | 2 + 2 | Chahârshanbe Suri is the eve of the last Wednesday of the year, not "the night before" Nowruz (u17). The u13 headscarf note was softened to the school maghna'e. Place facts: Tabriz is in the northwest, not "the north"; Kerman is in the southeast. |

No Arabic ي/ك were found, and no missing ZWNJ in می‌/ها in written forms. All `a`/`wa` indexes point to the intended option/reason.

## Uncertain or not changed
- **Content files changed during the review.** u06, u11, u13, u17, u19 and u20 were modified around 02:17–02:18 PT, apparently by the author. `old` values were re-synced to the current files and fixes the author had already made (e.g. nâhâr) were dropped. If files change again, re-check `old` before applying.
- **Written forms not added for every short answer option, blank template, build tile or song line** (e.g. "زود میام.", "کیش یه جزیره‌س."). They were added for words, examples, phrases, speak/write models, NPC lines, many boss questions and some songs. A full pass over answer options would add roughly 150 more.
- **Spacing in transliteration is inconsistent** (mikhâham vs mi-âyam, miây vs miyâd, mi-re/mi-bine in u19, kheyli/kheili, televizyon/televizyun). Left alone except where it broke the scheme.
- **write.three models have only 1 sentence** in units 1, 4, 5, 8, 12, 14, 17 and 19 (2 in u7 and u13), although the prompt asks for 3. Only u12 got two added sentences (marked improve).
- **نو is written "now" in some places and "no" in others.** Not changed.
- **Lower-priority suggestions from the helper reviewers:** swap the donkey word khar for olâgh (khar is also an insult), marked improve. Test with the TTS voice whether «نه» (nine) is read as "na" (no).
- **Haft-sin list omits samanu**; sekke and sonbol are common add-ons. Not changed.
