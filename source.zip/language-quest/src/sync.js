// Family Sync bridge: family-sync.js (shared, copied byte-identical; never edited) + this app's hooks.
// Not connected = exactly today's app: the module makes no network calls and writes nothing; every call is a no-op.
import './family-sync.js';
export const FSY = globalThis.FamilySync || null;
export const APP = 'language';
export const STATE_KEY = 'langQuest.state';
export const MAX_SYNC = 300000; // characters per synced key (the family backend refuses more)
// our keys: progress (his laptop → family), localOnly (never synced). Family voice recordings live in IndexedDB
// ('langQuest.voices'), which the module never touches.
// first-connect merge: the copy with more learning wins (words met, quests, First Steps steps, units), not the longer string
function progressScore(parsed) {
  const s = parsed && parsed[STATE_KEY]; if (!s || typeof s !== 'object') return 0;
  // family-sync 1.1 suggestion: words learned (srs entries) + quests × 5 + units done × 10; plus First Steps steps × 3
  let n = 0;
  for (const l of ['es', 'fa']) { const L = s[l] || {}; n += Object.keys(L.srs || {}).length + (L.quests || 0) * 5 + Object.values(L.units || {}).filter((u) => u && u.done).length * 10; }
  n += Object.keys((s.es && s.es.fs && s.es.fs.done) || {}).length * 3;
  return n;
}
try { if (FSY) FSY.register(APP, { progress: [STATE_KEY], localOnly: ['langQuest.pin', 'langQuest.oncePending', 'langQuest.once'], score: progressScore }); } catch (e) {}
export const connected = () => { try { return !!(FSY && FSY.isConnected()); } catch (e) { return false; } };
export const connectedKid = () => { try { return !!(FSY && FSY.isConnected() && FSY.role() === 'kid'); } catch (e) { return false; } };
export const familyPinSet = () => { try { return !!(FSY && FSY.pinIsSet()); } catch (e) { return false; } };
export const familyCheckPin = (p) => { try { return FSY.checkPin(p); } catch (e) { return Promise.resolve(false); } };
// start after the first render; never waits on the network (no-op when not connected)
export function startSync(version) { try { if (FSY) FSY.start({ app: APP, version }); } catch (e) {} }
// family look ('hyrule' | 'grove' | null) → our look setting ('hyrule' | 'fallback')
export function familyLook() { try { const l = FSY && FSY.look(); return l === 'grove' ? 'fallback' : l === 'hyrule' ? 'hyrule' : null; } catch (e) { return null; } }
// the look in use: the family look (when set in the Hub) overrides ours; it is never written into his progress
export const effectiveSkin = (S) => familyLook() || (S && S.settings && S.settings.skinSel) || 'hyrule';
// our progress key is too big to sync (the module then skips it): the app keeps working here, the dot says "sync paused"
export function stateTooBig() {
  if (!connected()) return false;
  try {
    const raw = localStorage.getItem(STATE_KEY) || '';
    if (raw.length > MAX_SYNC) return true;
    const stt = FSY.status(); if (stt && Array.isArray(stt.tooBig) && stt.tooBig.includes(STATE_KEY)) return true;
    const st = JSON.parse(localStorage.getItem('familyApps.sync.state.v1') || 'null');
    return !!(st && st.tooBig && st.tooBig[STATE_KEY]);
  } catch (e) { return false; }
}
// local Sunday of this week, 'YYYY-MM-DD'
export function weekOf(t = Date.now()) { const d = new Date(t); const s = new Date(d.getFullYear(), d.getMonth(), d.getDate() - d.getDay()); return s.getFullYear() + '-' + String(s.getMonth() + 1).padStart(2, '0') + '-' + String(s.getDate()).padStart(2, '0'); }
const wordCount = (L) => Object.keys((L && L.srs) || {}).filter((k) => /^(es|fa)\d+w\d+$/.test(k)).length;
const tries = (S) => ((S.es.speak && S.es.speak.tries) || 0) + ((S.fa.speak && S.fa.speak.tries) || 0);
// weekly counters kept in our own save (tiny): lessons finished, words and speaking tries at the start of the week
export function weekOfState(s) {
  const w = weekOf();
  if (!s.wk || s.wk.w !== w) s.wk = { w, lessons: 0, words0: wordCount(s.es) + wordCount(s.fa), speak0: tries(s) };
  return s.wk;
}
const LEVEL = { sprout: 'Sprout', explorer: 'Explorer', core: 'Grade 4 core', stretch: 'Grade 4+ stretch' };
// weekly summary for the grown-up's dashboard (writes only on his connected laptop; deduplicated by the module)
export function writeSummary(S) {
  if (!connectedKid()) return false;
  try {
    const wk = S.wk && S.wk.w === weekOf() ? S.wk : { lessons: 0, words0: wordCount(S.es) + wordCount(S.fa), speak0: tries(S) };
    const es = wordCount(S.es), fa = wordCount(S.fa);
    const fs = S.es.fs || {};
    const level = S.es.placed && !fs.skipped && !fs.champion && !Object.values(S.es.units || {}).some((u) => u && u.done) ? 'First Steps' : LEVEL[S.es.level] || 'Not started';
    return FSY.writeSummary(APP, { week: { lessons: wk.lessons || 0, wordsLearned: Math.max(0, es + fa - (wk.words0 || 0)), speakingTries: Math.max(0, tries(S) - (wk.speak0 || 0)) },
      total: { wordsLearned: es + fa, words: { es, fa }, level, firstSteps: Object.keys(fs.done || {}).length } });
  } catch (e) { return false; }
}
export function mountStatus(el) { try { return FSY ? FSY.mountStatus(el) : null; } catch (e) { return null; } }
export function mountConnect(el, opts) { try { return FSY ? FSY.mountConnect(el, opts) : null; } catch (e) { return null; } }
export function mountPracticeBanner(el) { try { return FSY ? FSY.mountPracticeBanner(el) : null; } catch (e) { return null; } }
