// Language Quest build: content bundle, Farsi TTS item list, esbuild bundle, kit pack, fonts, PWA files, dist.
// node build.mjs [--items-only]
import * as esbuild from 'esbuild';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { execSync } from 'child_process';
import { LESSONS, LETTERS } from './src/scriptdata.js';
import { allFaRoutine, CHUNKS, makeChunk } from './src/routine.js';
import { UNIT_NOUNS, conceptOf } from './src/nouns.js';

const APP = path.dirname(new URL(import.meta.url).pathname);
const CONTENT_SRC = process.env.LQ_CONTENT || '/tmp/lq/content';
const KIT = process.env.LQ_KIT || '/tmp/lq/kit2/kit';
const AUDIO = process.env.LQ_AUDIO || '/tmp/lq/audio/fa';
const DIST = process.env.LQ_DIST || path.join(APP, 'dist');
const fnv = (s) => { const b = Buffer.from(s.trim().replace(/\s+/g, ' '), 'utf8'); let h = 0x811c9dc5; for (const x of b) { h ^= x; h = Math.imul(h, 0x01000193) >>> 0; } return 'f' + h.toString(36); };

// 1. content: copy generated units into app/content (source of truth for the repo), dedupe words across units
const content = { es: {}, fa: {} };
const stats = { es: { units: 0, words: 0, phrases: 0 }, fa: { units: 0, words: 0, phrases: 0 } };
for (const lang of ['es', 'fa']) {
  fs.mkdirSync(path.join(APP, 'content', lang), { recursive: true });
  const seen = new Set();
  for (let n = 1; n <= 20; n++) {
    const f = `u${String(n).padStart(2, '0')}.json`;
    const src = path.join(CONTENT_SRC, lang, f), dst = path.join(APP, 'content', lang, f);
    if (fs.existsSync(src)) fs.copyFileSync(src, dst);
    if (!fs.existsSync(dst)) continue;
    const u = JSON.parse(fs.readFileSync(dst, 'utf8'));
    u.n = n;
    const key = (w) => (lang === 'es' ? (w.es || '') : (w.f || '')).toLowerCase().replace(/^(el|la|los|las) /, '').trim();
    u.words = (u.words || []).filter((w) => w && (w.es || w.f) && !seen.has(key(w)) && (seen.add(key(w)) || true));
    u.phrases = (u.phrases || []).filter((p) => p && (p.es || p.f));
    content[lang][n] = u; stats[lang].units++; stats[lang].words += u.words.length; stats[lang].phrases += u.phrases.length;
  }
}
// owl stories (one per unit) + home missions
content.story = { es: {}, fa: {} };
for (const lang of ['es', 'fa']) for (let n = 1; n <= 20; n++) {
  const f = `s${String(n).padStart(2, '0')}.json`;
  const src = path.join(CONTENT_SRC, lang, f), dst = path.join(APP, 'content', lang, f);
  if (fs.existsSync(src)) fs.copyFileSync(src, dst);
  if (fs.existsSync(dst)) content.story[lang][n] = JSON.parse(fs.readFileSync(dst, 'utf8'));
}
// painted vocabulary pictures: keep a mapping only when the item's meaning matches the picture's concept
const VP = process.env.LQ_VOCABPICS || '/tmp/lq/vocabpics';
const vpm = fs.existsSync(path.join(VP, 'manifest_all.json')) ? JSON.parse(fs.readFileSync(path.join(VP, 'manifest_all.json'), 'utf8')) : null;
const vocab = { byId: {} }; let vpDrop = 0;
if (vpm) {
  const conceptOf = {}; for (const c of vpm.concepts) conceptOf[c.file] = c;
  const words = (s) => (s || '').toLowerCase().replace(/\(.*?\)/g, ' ').split(/[^a-z]+/).filter((w) => w.length > 2 && !['the', 'and', 'for', 'with'].includes(w));
  for (const lang of ['es', 'fa']) for (const [n, u] of Object.entries(content[lang])) {
    const all = [...(u.words || []).map((x, i) => [x, `${lang}${n}w${i}`]), ...(u.phrases || []).map((x, i) => [x, `${lang}${n}p${i}`])];
    for (const [x, id] of all) {
      const f = vpm.by_item_id[id]; if (!f) continue;
      const c = conceptOf[f]; const cw = new Set([...words(c.english), ...(c.glosses || []).flatMap(words)]);
      if (words(x.en).some((w) => cw.has(w) || cw.has(w.replace(/s$/, '')))) vocab.byId[id] = f; else vpDrop++;
    }
  }
}
if (!vpm && fs.existsSync(path.join(APP, 'src', 'vocabpics.gen.js'))) { const t = fs.readFileSync(path.join(APP, 'src', 'vocabpics.gen.js'), 'utf8'); vocab.byId = JSON.parse(t.slice(t.indexOf('{'), t.lastIndexOf('}') + 1)).byId || {}; console.log('vocab pictures: reusing src/vocabpics.gen.js (no manifest here)'); }
console.log('vocab pictures mapped', Object.keys(vocab.byId).length, 'dropped (meaning changed)', vpDrop);
fs.writeFileSync(path.join(APP, 'src', 'vocabpics.gen.js'), 'export default ' + JSON.stringify(vocab) + ';\n');
fs.writeFileSync(path.join(APP, 'src', 'content.gen.js'), 'export default ' + JSON.stringify(content) + ';\n');
console.log('content', JSON.stringify(stats));

// 2. every Farsi string the app can speak -> TTS item list
function collectFa(unitList) {
const items = new Map();
const addF = (x) => { if (!x) return; const t = typeof x === 'string' ? x : x.f; if (t && !/_{2,}/.test(t) && t.trim()) items.set(fnv(t), t.trim().replace(/\s+/g, ' ')); };
const fillF = (q, o) => q && o && q.f && o.f ? q.f.replace(/_{2,}/, o.f) : null;
for (const u of unitList) {
  addF(u.title);
  for (const w of u.words || []) { addF(w); addF(w.ex); }
  for (const p of u.phrases || []) addF(p);
  const g = u.grammar || {};
  (g.examples || []).forEach(addF);
  (g.practice || []).forEach((p) => { if (p.q && p.opts && p.opts[p.a]) addF(fillF(p.q, p.opts[p.a])); });
  ((u.speak || {}).model || []).forEach(addF);
  const w = u.write || {};
  (w.copy || []).forEach(addF);
  (w.fill || []).forEach((f) => addF(fillF(f.t, f.a)));
  (w.build || []).forEach((b) => addF((b.w || []).map((x) => x.f).join(' ')));
  if (w.one) addF(w.one.model);
  if (w.three) (w.three.model || []).forEach(addF);
  ((u.role || {}).lines || []).forEach((l) => { addF(l.npc); (l.opts || []).forEach(addF); });
  ((u.boss || {}).lines || []).forEach((l) => { addF(l.q); (l.opts || []).forEach(addF); });
  ((u.song || {}).lines || []).forEach(addF);
}
return { items, addF };
}
const { items, addF } = collectFa(Object.values(content.fa));
for (const lang of ['fa']) for (const st of Object.values(content.story.fa)) {
  addF(st.title);
  for (const p of st.parts || []) { (p.lines || []).forEach(addF); for (const q of p.qs || []) { addF(q.q); (q.opts || []).forEach(addF); } }
  for (const m of st.missions || []) addF(m.say);
}
for (const f of allFaRoutine()) addF(f);
// power phrases: every Farsi unit's whitelisted nouns (src/nouns.js) × every pattern
const faWord = {}; for (const u of Object.values(content.fa)) for (const w of u.words || []) if (!faWord[w.f]) faWord[w.f] = w;
const chunkTexts = new Set();
for (const list of Object.values(UNIT_NOUNS.fa)) for (const en of list) {
  const c = conceptOf(en); const w = faWord[c.fa]; if (!w) throw new Error('power-phrase noun not in the Farsi content: ' + c.fa);
  for (let k = 0; k < CHUNKS.fa.length; k++) { const x = makeChunk('fa', k, { t: w.f, tr: w.t, w: w.w, wt: w.wt, c }); chunkTexts.add(x.t); addF(x.t); }
}
console.log('power-phrase Farsi lines', chunkTexts.size);
for (const l of LESSONS) for (const w of l.words) addF(w[0]);
for (const l of LETTERS) addF(l[1]);
['بابا', 'نان', 'آب', 'آفرین!', 'عالیه!'].forEach(addF);
fs.mkdirSync('/tmp/lq/tts', { recursive: true });
fs.writeFileSync('/tmp/lq/tts/items_fa.json', JSON.stringify([...items].map(([id, text]) => ({ id, text })), null, 0));
console.log('farsi tts items', items.size);
if (process.argv.includes('--items-only')) process.exit(0);

// 3. bundle
fs.rmSync(DIST, { recursive: true, force: true });
fs.mkdirSync(path.join(DIST, 'kit'), { recursive: true }); fs.mkdirSync(path.join(DIST, 'audio'), { recursive: true }); fs.mkdirSync(path.join(DIST, 'icons'), { recursive: true });

// 4. kit pack: only the image sizes we use, one binary + index
const want = (p) => /img\/chars\/.*_512\.webp$/.test(p) || /img\/items\/.*_256\.webp$/.test(p) || /img\/places\/.*_16x9_1600\.webp$/.test(p) || /img\/places\/.*_9x16_800\.webp$/.test(p) || /^fallback\/.*\.svg$/.test(p);
const walk = (d) => fs.existsSync(d) ? fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]) : [];
const imgs = [...walk(path.join(KIT, 'img')), ...walk(path.join(KIT, 'fallback'))].map((f) => path.relative(KIT, f)).filter(want).sort();
// classic-script packs (window globals) so the dist also runs from file:// (fetch is blocked there).
// raw chunks of at most 2.5 MB -> base64 files of at most ~3.4 MB (publishing rule: every dist file <= 3.5 MB)
const LIMIT = 2.5 * 1024 * 1024;
const jsPack = (key, buf) => `(window.__lqPack=window.__lqPack||{})[${JSON.stringify(key)}]="${buf.toString('base64')}";\n`;
const idx = { packs: [], files: {} }; const chunks = []; let cur = []; let curLen = 0; let off = 0;
for (const p of imgs) {
  const b = fs.readFileSync(path.join(KIT, p));
  if (cur.length && curLen + b.length > LIMIT) { chunks.push(Buffer.concat(cur)); cur = []; curLen = 0; }
  idx.files[p] = [chunks.length, curLen, b.length, p.endsWith('.svg') ? 'image/svg+xml' : 'image/webp'];
  cur.push(b); curLen += b.length; off += b.length;
}
if (cur.length) chunks.push(Buffer.concat(cur));
chunks.forEach((c, i) => { const name = `kitpack-${i + 1}.js`; idx.packs.push(name); fs.writeFileSync(path.join(DIST, 'kit', name), jsPack(name, c)); });
console.log('kit pack', imgs.length, 'images', (off / 1048576).toFixed(2), 'MB');

// 5. fonts (from the kit, OFL)
const FONTS = ['nunito-latin-wght-normal.woff2', 'nunito-latin-ext-wght-normal.woff2', 'vazirmatn-arabic-wght-normal.woff2', 'cinzel-latin-700-normal.woff2'];
const fontCss = `@font-face{font-family:'Nunito';font-style:normal;font-display:swap;font-weight:200 1000;src:url(fonts/nunito-latin-wght-normal.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Nunito';font-style:normal;font-display:swap;font-weight:200 1000;src:url(fonts/nunito-latin-ext-wght-normal.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Vazirmatn';font-style:normal;font-display:swap;font-weight:100 900;src:url(fonts/vazirmatn-arabic-wght-normal.woff2) format('woff2');unicode-range:U+0600-06FF,U+0750-077F,U+0870-088E,U+0890-0891,U+0897-08E1,U+08E3-08FF,U+200C-200E,U+2010-2011,U+204F,U+2E41,U+FB50-FDFF,U+FE70-FE74,U+FE76-FEFC}
@font-face{font-family:'Cinzel';font-style:normal;font-display:swap;font-weight:700;src:url(fonts/cinzel-latin-700-normal.woff2) format('woff2')}
`;

// 6. audio packs
let audioFiles = [];
let faIndex = null;
if (fs.existsSync(path.join(AUDIO, 'fa-index.json'))) {
  // re-pack the clips into classic-script packs (window globals; work from file:// too), each file <= ~3.4 MB
  const srcIdx = JSON.parse(fs.readFileSync(path.join(AUDIO, 'fa-index.json'), 'utf8'));
  const bufs = srcIdx.packs.map((p) => fs.readFileSync(path.join(AUDIO, p)));
  faIndex = { voice: srcIdx.voice, ls: srcIdx.ls, packs: [], clips: {} };
  let cur = [], curLen = 0;
  const flush = () => { if (!cur.length) return; const name = `fa-${faIndex.packs.length + 1}.js`; faIndex.packs.push(name); fs.writeFileSync(path.join(DIST, 'audio', name), jsPack(name, Buffer.concat(cur))); audioFiles.push('audio/' + name); cur = []; curLen = 0; };
  for (const [id, [pi, off, len, dur]] of Object.entries(srcIdx.clips)) {
    if (cur.length && curLen + len > LIMIT) flush();
    faIndex.clips[id] = [faIndex.packs.length, curLen, len, dur]; cur.push(bufs[pi].subarray(off, off + len)); curLen += len;
  }
  flush();
}
fs.writeFileSync(path.join(APP, 'src', 'packs.gen.js'), 'export const KITIDX = ' + JSON.stringify(idx) + ';\nexport const FAIDX = ' + JSON.stringify(faIndex) + ';\n');
console.log('audio files', audioFiles.length);
await esbuild.build({ entryPoints: [path.join(APP, 'src', 'main.jsx')], bundle: true, minify: true, format: 'iife', target: ['es2020', 'safari15', 'chrome100'], outfile: path.join(DIST, 'app.js'), loader: { '.js': 'jsx' }, define: { 'process.env.NODE_ENV': '"production"' }, legalComments: 'none', logLevel: 'warning' });
const css = fs.readFileSync(path.join(DIST, 'app.css'), 'utf8');
let fcss = fontCss; for (const f of FONTS) fcss = fcss.split('url(fonts/' + f + ')').join('url(data:font/woff2;base64,' + fs.readFileSync(path.join(KIT, 'fonts', f)).toString('base64') + ')');
fs.writeFileSync(path.join(DIST, 'app.css'), fcss + css.replace(/'Fredoka',?\s*/g, ''));


// 6b. vocabulary picture packs (static <script> tags; each file < 2 MB)
fs.mkdirSync(path.join(DIST, 'vocabpics'), { recursive: true });
const vpPacks = (vpm ? vpm.packs : ['vocabpics_pack1.js', 'vocabpics_pack2.js', 'vocabpics_pack3.js']).filter((p) => fs.existsSync(path.join(VP, p)));
for (const p of vpPacks) fs.copyFileSync(path.join(VP, p), path.join(DIST, 'vocabpics', p));
// 7. icons
for (const f of fs.readdirSync(path.join(APP, 'assets', 'icons'))) fs.copyFileSync(path.join(APP, 'assets', 'icons', f), path.join(DIST, 'icons', f));

// 8. manifest, index.html (static poster first), sw.js
fs.writeFileSync(path.join(DIST, 'manifest.webmanifest'), JSON.stringify({
  name: 'Language Quest', short_name: 'LangQuest', description: 'A Spanish + Farsi learning adventure.', start_url: './', scope: './', display: 'standalone',
  background_color: '#0b1f15', theme_color: '#0f2a1d', orientation: 'any',
  icons: [{ src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' }, { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' }, { src: 'icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }],
}, null, 1));
// Inline guard, the FIRST script in <head>: records load/script errors into window.__lqDiag (shown in Parent corner -> Help).
// dist: kids never see an overlay; it logs to the console and shows an overlay only with ?debug=1.
// preview: a small corner badge "⚠ n" that expands on click. Also adds the web-app manifest link only on http(s).
const guardJs = (mode) => `(function(){var M=${JSON.stringify(mode)};if(M==='preview')window.__LQ_PREVIEW__=true;var D=window.__lqDiag=window.__lqDiag||[];
var dbg=/[?&]debug=1\\b/.test(location.search);
function el(){var b=document.getElementById('lq-diag');if(b)return b;b=document.createElement('div');b.id='lq-diag';b.setAttribute('role','status');
if(M==='preview'){b.style.cssText='position:fixed;left:8px;bottom:8px;z-index:99999;font:12px/1.4 system-ui,sans-serif;max-width:min(560px,92vw)';}
else{b.style.cssText='position:fixed;left:8px;right:8px;bottom:8px;z-index:99999;max-height:40vh;overflow:auto;background:#3a1208;color:#ffe3d6;border:2px solid #ff9f7a;border-radius:10px;padding:8px 10px;font:12px/1.4 monospace;white-space:pre-wrap';}
(document.body||document.documentElement).appendChild(b);return b;}
var open=false;function render(){try{if(M==='dist'&&!dbg)return;if(!D.length)return;var b=el();
if(M==='preview'){b.innerHTML='';var t=document.createElement('button');t.type='button';t.textContent='\\u26a0 '+D.length;t.setAttribute('aria-label',D.length+' problems recorded; click for details');
t.style.cssText='background:#3a1208;color:#ffe3d6;border:1px solid #ff9f7a;border-radius:999px;padding:3px 10px;cursor:pointer;font:inherit;opacity:.85';t.onclick=function(){open=!open;render();};b.appendChild(t);
if(open){var l=document.createElement('div');l.style.cssText='margin-top:6px;background:#3a1208;color:#ffe3d6;border:1px solid #ff9f7a;border-radius:10px;padding:8px 10px;max-height:40vh;overflow:auto;font:12px/1.4 monospace;white-space:pre-wrap';l.textContent=D.map(function(d){return '\\u26a0 '+d.m;}).join('\\n');b.appendChild(l);}}
else{b.textContent=D.map(function(d){return '\\u26a0 '+d.m;}).join('\\n');}}catch(e){}}
function add(m){try{m=String(m).slice(0,300);D.push({t:Date.now(),m:m});if(D.length>100)D.shift();if(window.console&&console.warn)console.warn('[LangQuest] '+m);render();}catch(e){}}
window.__lqDiagAdd=add;
window.addEventListener('error',function(e){var t=e.target;if(t&&t!==window&&(t.src||t.href)){add('Failed to load '+String(t.src||t.href).split('/').pop().split('?')[0]);return;}
add((e.message||'error')+(e.filename?' @ '+String(e.filename).split('/').pop()+':'+e.lineno:''));},true);
window.addEventListener('unhandledrejection',function(e){var r=e.reason;add('Unhandled: '+(r&&(r.message||r)));});
setTimeout(function(){var r=document.getElementById('root');if(!r||!r.firstChild)add('App not started after 15 s. Packs loaded: '+Object.keys(window.__lqPack||{}).join(', ')+'. app.js ran: '+(window.__lqBoot?'yes':'no'));},15000);
if(/^https?:$/.test(location.protocol)){var k=document.createElement('link');k.rel='manifest';k.href='manifest.webmanifest';document.head.appendChild(k);}
})();`;
const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<script>${guardJs('dist')}</script>
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Language Quest — Spanish + Farsi adventure</title>
<meta name="theme-color" content="#0f2a1d"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="LangQuest"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link rel="icon" href="icons/icon-192.png"><link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
<link rel="stylesheet" href="app.css">
</head><body>
<div id="poster" style="position:fixed;inset:0;display:grid;place-items:center;background:radial-gradient(ellipse at 50% 30%,#2d6238,#0b1f15 70%);color:#fbefc8;font-family:Georgia,serif;text-align:center;z-index:0">
<div><div style="width:84px;height:84px;margin:0 auto 18px;border-radius:50%;background:radial-gradient(circle,#fff 0 12%,#bfe9ff 30%,rgba(92,195,240,0) 70%)"></div>
<div style="font-size:34px;letter-spacing:.06em">LANGUAGE QUEST</div><div style="opacity:.8;margin-top:8px;font-family:system-ui,sans-serif">Spanish · فارسی · a Hyrule adventure</div>
<div style="opacity:.6;margin-top:22px;font-family:system-ui,sans-serif;font-size:14px">Loading…</div></div></div>
<div id="root"></div>
<noscript>Language Quest needs JavaScript.</noscript>
<script src="app.js" defer></script>
${vpPacks.map((p) => `<script src="vocabpics/${p}" async></script>`).join('\n')}
</body></html>
`;
fs.writeFileSync(path.join(DIST, 'index.html'), html);
const pre = ['./', 'index.html', 'app.js', 'app.css', 'manifest.webmanifest', ...vpPacks.map((p) => 'vocabpics/' + p), ...idx.packs.map((p) => 'kit/' + p), ...fs.readdirSync(path.join(DIST, 'icons')).map((f) => 'icons/' + f), ...audioFiles];
const ver = crypto.createHash('sha1').update(pre.filter((p) => p !== './').map((p) => fs.readFileSync(path.join(DIST, p))).reduce((a, b) => Buffer.concat([a, b.slice(0, 4096), Buffer.from(String(b.length))]), Buffer.alloc(0))).digest('hex').slice(0, 10);
fs.writeFileSync(path.join(DIST, 'sw.js'), `// Language Quest service worker: offline after the first load.
// Precache with fresh requests (never from the browser's HTTP cache); the page and the app code are network-first with a
// cache fallback, so an update can't get stuck on an old app.js; the big packs (kit, audio, vocabpics) are cache-first.
const CACHE = 'langQuest-v7-${ver}';
const PRE = ${JSON.stringify(pre)};
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(PRE.map((f) => new Request(f, { cache: 'reload' })))).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k.startsWith('langQuest-') && k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
const FRESH = /(\\/|\\/index\\.html|\\/app\\.js|\\/app\\.css)$/;
const net = (req) => (req.mode === 'navigate' ? fetch(req) : fetch(new Request(req.url, { cache: 'no-cache', credentials: 'same-origin' })));
const keep = (req, r) => { if (r && r.ok && r.type === 'basic') { const c = r.clone(); caches.open(CACHE).then((x) => x.put(req, c)); } return r; };
self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  if (e.request.mode === 'navigate' || FRESH.test(u.pathname)) {
    e.respondWith(net(e.request).then((r) => keep(e.request, r)).catch(() => caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || caches.match('index.html'))));
    return;
  }
  e.respondWith(caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || fetch(e.request).then((r) => keep(e.request, r)).catch(() => caches.match('index.html'))));
});
`);
fs.copyFileSync(path.join(APP, 'README.md'), path.join(DIST, 'README.md'));

// 8b. PREVIEW variant for the Meta artifact viewer (opaque-origin srcdoc frame that only loads STATIC references):
// packs as static <script data-lqpack> tags, fonts inlined into the CSS, an on-screen error overlay.
const PREV = process.env.LQ_PREVIEW || '/tmp/lq/preview';
fs.rmSync(PREV, { recursive: true, force: true });
for (const d of ['kit', 'audio', 'icons']) fs.mkdirSync(path.join(PREV, d), { recursive: true });
fs.writeFileSync(path.join(PREV, 'app-preview.css'), fs.readFileSync(path.join(DIST, 'app.css'), 'utf8'));
// light preview (the viewer can't take ~25 MB of script): smaller kit images, Farsi audio for units 1-2 only
// light preview kit: the SAME files the dist uses, each downscaled to half size (tools/make_preview_kit.py),
// so every image the app references is in the preview pack too
const PKIT = process.env.LQ_PKIT || '/tmp/lq/kitp/kit';
if (!fs.existsSync(PKIT)) execSync(`python3 ${path.join(APP, 'tools', 'make_preview_kit.py')} ${KIT} ${PKIT}`, { stdio: 'inherit' });
const pimgs = imgs.slice();
const missingP = pimgs.filter((p) => !fs.existsSync(path.join(PKIT, p)));
if (missingP.length) throw new Error('preview kit is missing ' + missingP.length + ' images, e.g. ' + missingP.slice(0, 3).join(', ') + ' (delete ' + PKIT + ' to regenerate)');
const pidx = { packs: ['kitpack-p1.js'], files: {} }; const pb = []; let poff = 0;
for (const p of pimgs) { const bb = fs.readFileSync(path.join(PKIT, p)); pidx.files[p] = [0, poff, bb.length, p.endsWith('.svg') ? 'image/svg+xml' : 'image/webp']; pb.push(bb); poff += bb.length; }
fs.writeFileSync(path.join(PREV, 'kit', 'kitpack-p1.js'), jsPack('kitpack-p1.js', Buffer.concat(pb)));
let pfa = null;
if (faIndex) {
  const sub = collectFa([content.fa[1]].filter(Boolean)).items;
  for (const l of LESSONS.slice(0, 1)) for (const w of l.words) sub.set(fnv(w[0]), w[0]);
  { const r = collectFa([]); for (const f of allFaRoutine().slice(0, 24)) r.addF(f); for (const [k, v] of r.items) sub.set(k, v); }
  pfa = { voice: faIndex.voice, packs: ['fa-p1.js'], clips: {} }; const ab = []; let aoff = 0;
  for (const id of sub.keys()) { const cf = '/tmp/lq/tts/cache/' + id + '.mp3'; if (!fs.existsSync(cf) || !faIndex.clips[id]) continue; const bb = fs.readFileSync(cf); pfa.clips[id] = [0, aoff, bb.length, faIndex.clips[id][3]]; ab.push(bb); aoff += bb.length; }
  fs.writeFileSync(path.join(PREV, 'audio', 'fa-p1.js'), jsPack('fa-p1.js', Buffer.concat(ab)));
  console.log('preview audio clips', Object.keys(pfa.clips).length, (aoff / 1048576).toFixed(2), 'MB');
}
console.log('preview kit', pimgs.length, 'images', (poff / 1048576).toFixed(2), 'MB');
const GEN = path.join(APP, 'src', 'packs.gen.js'); const genDist = fs.readFileSync(GEN, 'utf8');
fs.writeFileSync(GEN, 'export const KITIDX = ' + JSON.stringify(pidx) + ';\nexport const FAIDX = ' + JSON.stringify(pfa) + ';\n');
await esbuild.build({ entryPoints: [path.join(APP, 'src', 'main.jsx')], bundle: true, minify: true, format: 'iife', target: ['es2020', 'safari15', 'chrome100'], outfile: path.join(PREV, 'app.js'), loader: { '.js': 'jsx' }, define: { 'process.env.NODE_ENV': '"production"' }, legalComments: 'none', logLevel: 'warning' });
fs.writeFileSync(GEN, genDist);
if (fs.existsSync(path.join(PREV, 'app.css'))) fs.rmSync(path.join(PREV, 'app.css'));
const phtml = html.replace('<script>' + guardJs('dist') + '</script>', '<script>' + guardJs('preview') + '</script>').replace('<link rel="stylesheet" href="app.css">', '<link rel="stylesheet" href="app-preview.css">')
  .replace('<script src="app.js" defer></script>', '<script src="kit/kitpack-p1.js" data-lqpack="kitpack-p1.js" defer></script>\n<script src="app.js" defer></script>\n' + (pfa ? '<script src="audio/fa-p1.js" data-lqpack="fa-p1.js" async></script>' : ''));
if (!phtml.includes(guardJs('preview'))) throw new Error('preview guard not inlined');
const pPacks = [];
fs.mkdirSync(path.join(PREV, 'vocabpics'), { recursive: true });
for (const p of pPacks) fs.copyFileSync(path.join(VP, p), path.join(PREV, 'vocabpics', p));
fs.writeFileSync(path.join(PREV, 'index.html'), phtml.replace(/<script src="vocabpics\/[^"]+" async><\/script>\n?/g, '').replace('</body></html>', pPacks.map((p) => `<script src="vocabpics/${p}" async></script>`).join('\n') + '\n</body></html>'));
for (const f of ['manifest.webmanifest', 'README.md', ...fs.readdirSync(path.join(DIST, 'icons')).map((f) => 'icons/' + f)]) fs.copyFileSync(path.join(DIST, f), path.join(PREV, f));
console.log('preview files', walk(PREV).length, (walk(PREV).reduce((a, f) => a + fs.statSync(f).size, 0) / 1048576).toFixed(2), 'MB');

// 9. source.zip (full source, build script, tests, content, TTS + content tools)
const tmp = '/tmp/lq/srczip'; fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true });
execSync(`mkdir -p ${tmp}/language-quest && cd ${APP} && cp -r src content tests tools assets build.mjs package.json README.md ${tmp}/language-quest/ 2>/dev/null; mkdir -p ${tmp}/language-quest/tools && cp /tmp/lq/tts/build_audio.py /tmp/lq/tts/eval_voices.py /tmp/lq/tts/eval_mms.py /tmp/lq/tts/README.md /tmp/lq/fix/apply_review.py /tmp/lq/fix/apply_fix.py /tmp/lq/fix/apply_files.py ${APP}/tools/review_sheet.mjs ${tmp}/language-quest/tools/ 2>/dev/null; cp -r /tmp/lq/specs ${tmp}/language-quest/tools/specs; mkdir -p ${tmp}/language-quest/tools/review && cp /tmp/lq/review/es_corrections.json /tmp/lq/review/fa_corrections.json /tmp/lq/review/es_summary.md /tmp/lq/review/fa_summary.md ${tmp}/language-quest/tools/review/ 2>/dev/null; rm -f ${tmp}/language-quest/src/content.gen.js; rm -rf ${tmp}/language-quest/tests/wallet/shots; cd ${tmp} && zip -qr ${DIST}/source.zip language-quest`);
const files = walk(DIST);
const big = files.filter((f) => fs.statSync(f).size > 3.5 * 1024 * 1024);
if (big.length) console.log('WARNING files over 3.5 MB:', big.map((f) => path.relative(DIST, f) + ' ' + (fs.statSync(f).size / 1048576).toFixed(2)).join(', '));
console.log('dist files', files.length, (files.reduce((a, f) => a + fs.statSync(f).size, 0) / 1048576).toFixed(2), 'MB', 'version', ver);

// 10. packaging scrub: fail on internal hosts, tool names and paths in every text file of the dist, the preview and
// source.zip (the pattern is kept base64-encoded so this file passes its own scan; long base64 data blobs are skipped).
{
  const SCRUB = new RegExp(Buffer.from('aW50ZXJuYWxtZXRhfGludGVybmFsZmJ8ZmJ1cmx8bWV0YSBhcGV8YXBlXC5pbWFnZXxhcGVcLm1vZGVsfG5hbm8tYmFuYW5hfFZhdWx0IHBpcHxmd2Rwcm94eXx4MnB8TWV0YW1hdGV8YWdlbnRjbG91ZHx0d3N2Y3NjbQ==', 'base64').toString('utf8'), 'i');
  const TEXT = /\.(html|js|mjs|jsx|css|json|md|webmanifest|txt|py|sh|svg)$/i;
  const clean = (t) => t.replace(/[A-Za-z0-9+\/=]{200,}/g, ' ');
  const hits = [];
  const scanDir = (root, label) => { for (const f of walk(root)) { if (!TEXT.test(f)) continue; const m = clean(fs.readFileSync(f, 'utf8')).match(SCRUB); if (m) hits.push(`${label}/${path.relative(root, f)}: "${m[0]}"`); } };
  scanDir(DIST, 'dist'); scanDir(PREV, 'preview');
  const zdir = '/tmp/lq/scrubzip'; fs.rmSync(zdir, { recursive: true, force: true }); fs.mkdirSync(zdir, { recursive: true });
  execSync(`cd ${zdir} && unzip -q ${path.join(DIST, 'source.zip')}`); scanDir(zdir, 'source.zip');
  fs.rmSync(zdir, { recursive: true, force: true });
  if (hits.length) { console.error('SCRUB FAILED:\n  ' + hits.slice(0, 40).join('\n  ')); process.exit(3); }
  console.log('scrub: 0 hits (dist, preview, source.zip)');
}
