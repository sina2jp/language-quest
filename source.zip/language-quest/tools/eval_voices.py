#!/usr/bin/env python3
"""Evaluate Piper fa_IR voices: synthesize test items, transcribe with faster-whisper, report CER."""
import json, os, re, sys, time, wave, io
import numpy as np

TESTS = """سلام
خداحافظ
مرسی
خواهش می‌کنم
حالت چطوره؟
من خوبم.
خونه‌ی ما بزرگه.
می‌خوام برم پارک.
مامان‌بزرگ چای می‌خوره.
این سیب قرمزه.
گربه زیر میزه.
من نه سالمه.
امروز هوا سرده.
بابا داره غذا درست می‌کنه.
عمو
خاله
دایی
عمه
کتاب
مدرسه
آب
نون
پنیر
ته‌دیگ
یک، دو، سه، چهار، پنج
بیا بریم بازی کنیم!
دستت درد نکنه.
خسته نباشی.
نوروز مبارک!
شب یلدا
انار
هندونه
رستم و رخش
سیمرغ
دیروز رفتیم خونه‌ی خاله.
فردا مدرسه نمی‌رم.
چند سالته؟
اسمت چیه؟
من فارسی یاد می‌گیرم.
ببخشید، دستشویی کجاست؟""".strip().splitlines()

def norm(s):
    s = s.replace("ي", "ی").replace("ك", "ک").replace("\u200c", "")
    s = re.sub(r"[\u064B-\u0652\u0670]", "", s)
    s = re.sub(r"[^\u0600-\u06FF]", "", s)
    s = s.replace("أ", "ا").replace("إ", "ا").replace("ة", "ه")
    return s

def cer(a, b):
    a, b = norm(a), norm(b)
    if not a: return 1.0
    d = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        prev, d[0] = d[0], i
        for j, cb in enumerate(b, 1):
            cur = min(d[j] + 1, d[j - 1] + 1, prev + (ca != cb))
            prev, d[j] = d[j], cur
    return d[len(b)] / len(a)

def synth(voice, text, ls):
    from piper import SynthesisConfig
    cfg = SynthesisConfig(length_scale=ls)
    chunks = list(voice.synthesize(text, syn_config=cfg))
    audio = np.concatenate([c.audio_float_array for c in chunks]) if chunks else np.zeros(1, np.float32)
    return audio, chunks[0].sample_rate if chunks else 22050

if __name__ == "__main__":
    from piper import PiperVoice
    from faster_whisper import WhisperModel
    import soundfile as sf
    asr = WhisperModel("/tmp/lq/tts/whisper", device="cpu", compute_type="int8", cpu_threads=8)
    os.makedirs("/tmp/lq/tts/eval", exist_ok=True)
    res = {}
    for v in sys.argv[1:] or ["gyro", "amir", "ganji", "reza_ibrahim"]:
        voice = PiperVoice.load(f"/tmp/lq/tts/voices/fa_IR-{v}-medium.onnx")
        tot, n, t0, dur = 0, 0, time.time(), 0
        rows = []
        for i, t in enumerate(TESTS):
            a, sr = synth(voice, t, 1.1)
            dur += len(a) / sr
            p = f"/tmp/lq/tts/eval/{v}_{i:02d}.wav"
            sf.write(p, a, sr)
            a16 = np.interp(np.arange(0, len(a), sr/16000.0), np.arange(len(a)), a).astype(np.float32)
            segs, _ = asr.transcribe(a16, language="fa", beam_size=5, vad_filter=False)
            hyp = "".join(s.text for s in segs)
            c = cer(t, hyp); tot += c; n += 1
            rows.append((t, hyp.strip(), round(c, 2)))
        res[v] = {"cer": round(tot / n, 3), "synth_s": round(time.time() - t0, 1), "audio_s": round(dur, 1)}
        print(v, res[v], flush=True)
        json.dump(rows, open(f"/tmp/lq/tts/eval/{v}.json", "w"), ensure_ascii=False, indent=0)
    json.dump(res, open("/tmp/lq/tts/eval/summary.json", "w"), indent=1)
    print(json.dumps(res, indent=1))
