// Secret Treasures + shared reward keys (no browser): each secret unlocks once, ticket math, weekly cap across apps,
// shared keys with another app writing tickets and editing the list. Run: node tests/rewards.mjs
import * as esbuild from 'esbuild';
await esbuild.build({ entryPoints: ['src/treasure-core.js'], bundle: true, format: 'esm', platform: 'neutral', outfile: '/tmp/lq_tc.mjs', logLevel: 'error' });
await esbuild.build({ entryPoints: ['src/rewards.js'], bundle: true, format: 'esm', platform: 'neutral', outfile: '/tmp/lq_rw.mjs', logLevel: 'error' });
await esbuild.build({ entryPoints: ['src/secrets.js'], bundle: true, format: 'esm', platform: 'neutral', outfile: '/tmp/lq_sc.mjs', logLevel: 'error' });
const mem = {}; globalThis.localStorage = { getItem: (k) => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: (k) => { delete mem[k]; } };
const TC = await import('/tmp/lq_tc.mjs'); const RW = await import('/tmp/lq_rw.mjs'); const SC = await import('/tmp/lq_sc.mjs');
let fail = 0; const ok = (n, c, info = '') => { console.log((c ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); if (!c) fail++; };
const fresh = () => ({ es: { units: {}, srs: {}, speak: { good: 0 }, streak: 0, quests: 0 }, fa: { units: {}, srs: {}, streak: 0, quests: 0 }, treasure: { found: {}, tokens: 0, toChoose: 0, flags: {} } });
const reset = () => { for (const k of Object.keys(mem)) delete mem[k]; };
// defaults written only when missing
reset(); const c0 = RW.readConfig();
ok('defaults: ids youtube/switch/pet/treat/game, 3 per ticket, cap 5; reading writes nothing', c0.rewards.map((r) => r.id).join() === 'youtube,switch,pet,treat,game' && c0.tokensPerTicket === 3 && c0.weeklyCap === 5 && !(RW.REWARDS_KEY in mem) && c0.rewards[1].text === '20 minutes of Nintendo Switch');
const t0 = RW.addTicket(c0.rewards[1]);
ok('the first action writes the defaults; ticket id "language-<ms>-<random>", ISO earnedAt', !!mem[RW.REWARDS_KEY] && /^language-\d{13}-[a-z0-9]+$/.test(t0.id) && /^\d{4}-\d\d-\d\dT/.test(t0.earnedAt), t0.id + ' ' + t0.earnedAt);
RW.markUsed(t0.id); ok('usedAt is an ISO string', /^\d{4}-\d\d-\d\dT/.test(RW.readTickets()[0].usedAt));
mem[RW.REWARDS_KEY] = JSON.stringify({ version: 1, enabled: true, tokensPerTicket: 2, weeklyCap: 4, rewards: [{ id: 'a', emoji: '🚲', text: 'Bike ride' }], updatedAt: 1 });
ok('an existing list is never overwritten with defaults', RW.readConfig().rewards[0].text === 'Bike ride' && JSON.parse(mem[RW.REWARDS_KEY]).rewards.length === 1);
ok('at most 8 rewards', RW.writeConfig({ rewards: Array.from({ length: 12 }, (_, i) => ({ id: 'x' + i, emoji: '🎁', text: 'R' + i })) }).rewards.length === 8);
// each secret unlocks once; ticket math
reset(); let S = fresh();
ok('a secret unlocks once', TC.foundSecret(S, 'glint') === true && TC.foundSecret(S, 'glint') === false && S.treasure.tokens === 1);
ok('unknown secret ids are ignored', TC.foundSecret(S, 'nope') === false && S.treasure.tokens === 1);
TC.foundSecret(S, 'moon'); TC.foundSecret(S, 'navi');
ok('3 tokens → 1 ticket to choose, 0 tokens left', S.treasure.toChoose === 1 && S.treasure.tokens === 0);
TC.foundSecret(S, 'owl');
ok('a 4th token waits toward the next ticket', S.treasure.toChoose === 1 && S.treasure.tokens === 1);
RW.writeConfig({ tokensPerTicket: 1 }); TC.convertTokens(S);
ok('changing tokens per ticket (1) converts waiting tokens', S.treasure.toChoose === 2 && S.treasure.tokens === 0);
ok('18 secrets: 6 find + 12 achieve', SC.SECRETS.length === 18 && SC.SECRETS.filter((x) => x.kind === 'find').length === 6);
S.es.speak.good = 20; S.es.units[1] = { done: true }; S.fa.quests = 1;
ok('achievements: speak 20, unit 1, Farsi bonus detected once', JSON.stringify(SC.newlyAchieved(S).sort()) === JSON.stringify(['farsi', 'speak20', 'unit1']));
for (const id of SC.newlyAchieved(S)) TC.foundSecret(S, id);
ok('achievements do not unlock twice', SC.newlyAchieved(S).length === 0);
// weekly cap across all apps
reset(); RW.writeConfig({ tokensPerTicket: 1, weeklyCap: 2 });
const now = Date.now();
mem[RW.TICKETS_KEY] = JSON.stringify([{ id: 'math-' + (now - 1000) + '-k3j9x', app: 'math', rewardId: 'youtube', rewardText: '15 minutes of YouTube', emoji: '📺', earnedAt: new Date(now - 1000).toISOString(), status: 'earned' }]);
S = fresh(); TC.foundSecret(S, 'glint'); TC.foundSecret(S, 'moon');
ok('weekly cap 2 with 1 Math Arena ticket: 1 ticket now, the other token waits', S.treasure.toChoose === 1 && S.treasure.tokens === 1 && S.treasure.capped === true);
ok('next week the waiting token can become a ticket', RW.ticketsAvailable(1, 0, now + 7 * 86400000) === 1);
RW.writeConfig({ weeklyCap: 0 });
ok('weekly cap 0: no tickets at all', RW.ticketsAvailable(5, 0, now) === 0);
RW.writeConfig({ enabled: false, weeklyCap: 5 });
ok('rewards off: no tickets', RW.ticketsAvailable(5, 0, now) === 0);
// shared keys: another app writes tickets and edits the list between our reads
reset(); RW.writeConfig({ enabled: true });
const mine = RW.addTicket({ id: 'switch', emoji: '🎮', text: '20 minutes of Nintendo Switch' });
const other = JSON.parse(mem[RW.TICKETS_KEY]); other.push({ id: 'code-9', app: 'code', rewardId: 'pet', rewardText: 'Play time with our pet', emoji: '🐾', earnedAt: Date.now() + 5, status: 'earned' }); mem[RW.TICKETS_KEY] = JSON.stringify(other);
RW.addTicket({ id: 'treat', emoji: '🍦', text: 'Pick a special treat' }); RW.markUsed(mine.id);
const all = RW.readTickets();
ok('other apps\' tickets are kept (read-modify-write)', all.length === 3 && all.some((t) => t.id === 'code-9' && t.status === 'earned') && all.find((t) => t.id === mine.id).status === 'used' && all.every((t) => t.app));
const cfg = JSON.parse(mem[RW.REWARDS_KEY]); cfg.rewards.push({ id: 'zoo', emoji: '🦁', text: 'Zoo trip' }); mem[RW.REWARDS_KEY] = JSON.stringify(cfg);
ok('an edit by another app is seen on the next read', RW.readConfig().rewards.some((r) => r.text === 'Zoo trip'));
const big = Array.from({ length: 230 }, (_, i) => ({ id: 'math-' + i, app: 'math', rewardText: 'x', emoji: '📺', earnedAt: 1000 + i, status: 'used' })); mem[RW.TICKETS_KEY] = JSON.stringify(big);
RW.addTicket({ id: 'game', emoji: '🎲', text: 'Family game pick' });
const kept = RW.readTickets();
ok('only the newest 200 tickets are kept', kept.length === 200 && kept.some((t) => t.app === 'language') && !kept.some((t) => t.id === 'math-0'));
ok('ticket entries carry app "language" and the reward text', kept.find((t) => t.app === 'language').rewardText === 'Family game pick');
// cross-app: Math Arena-style tickets (ISO dates, "math-<ms>-<random>" ids) and an epoch-ms one all count toward the cap
reset(); RW.writeConfig({ weeklyCap: 3, tokensPerTicket: 1 });
const n2 = Date.now();
mem[RW.TICKETS_KEY] = JSON.stringify([
  { id: 'math-' + (n2 - 3000) + '-a1b2c3', app: 'math', rewardId: 'switch', rewardText: '20 minutes of Nintendo Switch', emoji: '🎮', earnedAt: new Date(n2 - 3000).toISOString(), status: 'earned' },
  { id: 'code-' + (n2 - 2000) + '-d4e5f6', app: 'code', rewardId: 'treat', rewardText: 'Pick a special treat', emoji: '🍦', earnedAt: n2 - 2000, status: 'used', usedAt: new Date(n2 - 1000).toISOString() },
  { id: 'math-' + (n2 - 9 * 86400000) + '-old000', app: 'math', rewardId: 'pet', rewardText: 'Play time with our pet', emoji: '🐾', earnedAt: new Date(n2 - 9 * 86400000).toISOString(), status: 'used' },
]);
ok('cross-app: ISO and epoch-ms tickets from this week count (2), last week\'s does not', RW.ticketsThisWeek(n2) === 2);
S = fresh(); TC.foundSecret(S, 'glint'); TC.foundSecret(S, 'moon');
ok('cross-app: with cap 3, only 1 more ticket this week; the next token waits', S.treasure.toChoose === 1 && S.treasure.tokens === 1 && S.treasure.capped === true);
process.exit(fail ? 1 : 0);
