import json, time, sys, numpy as np, torch, soundfile as sf
sys.path.insert(0, '/tmp/lq/tts')
from eval_voices import TESTS, cer
from transformers import VitsModel, AutoTokenizer
from faster_whisper import WhisperModel
torch.set_num_threads(8)
tok = AutoTokenizer.from_pretrained('/tmp/lq/tts/mms'); model = VitsModel.from_pretrained('/tmp/lq/tts/mms').eval()
asr = WhisperModel('/tmp/lq/tts/whisper', device='cpu', compute_type='int8', cpu_threads=8)
res = {}
for ls in [1.0, 1.15]:
    model.config.speaking_rate = 1.0 / ls
    model.speaking_rate = 1.0 / ls
    tot = 0; rows = []; t0 = time.time(); dur = 0
    for i, t in enumerate(TESTS):
        txt = t.replace('\u200c', '')
        inp = tok(txt, return_tensors='pt')
        torch.manual_seed(0)
        with torch.no_grad(): a = model(**inp).waveform[0].numpy()
        sr = model.config.sampling_rate; dur += len(a) / sr
        sf.write(f'/tmp/lq/tts/eval/mms{ls}_{i:02d}.wav', a, sr)
        segs, _ = asr.transcribe(a.astype(np.float32), language='fa', beam_size=5, vad_filter=False)
        h = ''.join(s.text for s in segs); c = cer(t, h); tot += c; rows.append((t, h.strip(), round(c, 2)))
    res[f'mms_{ls}'] = {'cer': round(tot / len(TESTS), 3), 'synth_s': round(time.time() - t0, 1), 'audio_s': round(dur, 1)}
    print(res, flush=True)
    json.dump(rows, open(f'/tmp/lq/tts/eval/mms_{ls}.json', 'w'), ensure_ascii=False, indent=0)
json.dump(res, open('/tmp/lq/tts/eval/summary_mms.json', 'w'), indent=1)
