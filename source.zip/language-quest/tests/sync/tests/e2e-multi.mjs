// End-to-end, several kid laptops (1.1) + the anti-farming wallet (1.2), in Chromium at 1440x900 and 390x844.
// Laptops A, B, C and the grown-up are separate browser contexts against the mock backend (real Code.gs 1.1) and the
// real static site. Run: node tests/e2e-multi.mjs   (ONLY=desktop|phone; PW_DIR, SITE as for tests/e2e.mjs)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const W = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const PW = process.env.PW_DIR || '/tmp/fs/pw';
const { launch } = await import(path.join(PW, 'launch.mjs'));
const { startMock, startStatic } = await import(path.join(W, 'tools', 'mock-server.mjs'));
const SITE = process.env.SITE || '/tmp/fs/site';
const SHOTS = process.env.SHOTS || path.join(W, 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
const LEGACY = fs.readFileSync(path.join(W, 'legacy', 'family-sync-1.0.0.js'), 'utf8');
const EF = path.join(PW, 'node_modules/@fontsource/noto-emoji/files');
const EMOJI_CSS = fs.existsSync(EF) ? [2, 4, 6, 7].map((n) => `@font-face{font-family:'Noto Emoji';src:url(data:font/woff2;base64,${fs.readFileSync(path.join(EF, `noto-emoji-${n}-400-normal.woff2`)).toString('base64')}) format('woff2')}`).join('') : '';
let pass = 0, fail = 0;
const log = [];
const check = (name, cond, detail) => { if (cond) pass++; else fail++; log.push(`${cond ? 'ok  ' : 'FAIL'} ${name}${!cond && detail ? ' :: ' + String(detail).slice(0, 300) : ''}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(fn, ms = 15000, step = 250) { const t = Date.now(); let v; while (Date.now() - t < ms) { try { v = await fn(); if (v) return v; } catch {} await sleep(step); } return v; }
const mock = await startMock({ port: 0 });
const site = await startStatic(SITE, 0);
const BASE = `http://127.0.0.1:${site.port}`;
const APPS = [['math', 'math-arena'], ['language', 'language-quest'], ['code', 'code-quest'], ['music', 'music-quest']];
const state = async () => (await fetch(`http://127.0.0.1:${mock.port}/__state`)).json();
const cloud = async (key) => { const r = (await state()).data.find((x) => x[0] === key); return r ? r.slice(8, 8 + Number(r[7])).map((p) => String(p).slice(1)).join('') : null; };

async function newCtx(browser, vp, name) {
  const ctx = await browser.newContext({ viewport: vp, deviceScaleFactor: 1, serviceWorkers: 'block', permissions: ['microphone'] });
  ctx.errors = [];
  if (EMOJI_CSS) await ctx.addInitScript((css) => { const add = () => { const s = document.createElement('style'); s.textContent = css; (document.head || document.documentElement).appendChild(s); }; if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', add); else add(); }, EMOJI_CSS);
  await ctx.addInitScript(() => { window.__fsUpdates = []; window.addEventListener('familysync:update', (e) => window.__fsUpdates.push(e.detail)); });
  await ctx.route(/^https?:\/\/(?!127\.0\.0\.1)/, (route) => route.abort());
  for (const [id, dir] of APPS) {
    await ctx.route(new RegExp(`^${BASE}/${dir}/(\\?.*)?$`), async (route) => {
      const res = await route.fetch();
      const legacy = /legacy=1/.test(route.request().url());
      let body = await res.text();
      body = body.replace(/<\/body>/i, (legacy ? `<script src="/__legacy/family-sync-1.0.0.js"></script>` : `<script src="/family/family-sync.js"></script>`) + `<script>FamilySync.start({app:'${id}'});</script></body>`);
      await route.fulfill({ response: res, body, headers: { ...res.headers(), 'content-type': 'text/html; charset=utf-8' } });
    });
  }
  await ctx.route(`${BASE}/__legacy/family-sync-1.0.0.js`, (route) => route.fulfill({ status: 200, contentType: 'text/javascript', body: LEGACY }));
  ctx.on('page', (p) => p.on('pageerror', (e) => ctx.errors.push(`${name}: ${e.message}`)));
  return ctx;
}
const shot = (page, name, full) => page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: !!full });
async function join(ctx, link, before) {
  const p = await ctx.newPage();
  if (before) { await p.goto(`${BASE}/family/`); await p.evaluate(before); }
  await p.goto(link.replace('https://sina2jp.github.io', BASE));
  await p.waitForSelector('text=All set!', { timeout: 30000 });
  return p;
}
const syncAll = async (...pages) => { for (let r = 0; r < 2; r++) for (const p of pages) await p.evaluate(() => FamilySync.syncNow()); };
const wallet = (p) => p.evaluate(() => JSON.parse(localStorage.getItem('familyApps.wallet.v1') || 'null'));

async function run(label, vp) {
  await fetch(`http://127.0.0.1:${mock.port}/__reset`, { method: 'POST' });
  const browser = await launch();
  const P = 'multi-' + label + '-';
  // ---- the grown-up sets up quickly (the full Hub setup is covered by tests/e2e.mjs) ----
  const G = await newCtx(browser, vp, 'grownup');
  const g = await G.newPage();
  await g.goto(`${BASE}/family/`);
  await g.fill('input[type=url]', mock.endpoint);
  await g.click('button:has-text("Set up our family")');
  await g.waitForSelector('#checklist');
  check(`${label}: step 6 says "Connect each laptop he uses"`, !!(await g.$('#step-connect >> text=Connect each laptop he uses')));
  await g.evaluate(async () => { await FamilySync.setPin('2468'); await FamilySync.syncNow(); });
  const link = await g.evaluate(() => FamilySync.joinLink('https://sina2jp.github.io/family/'));
  // ---- laptop A joins; laptop B already has some of today's play, then joins ----
  const A = await newCtx(browser, vp, 'kidA'), B = await newCtx(browser, vp, 'kidB');
  const a = await join(A, link);
  await a.evaluate(() => { FamilyWallet.finishUnit('math', 'A: first lesson'); localStorage.setItem('mathArena.v3.data.v1', JSON.stringify({ reports: [1, 2], progress: { seen: { a: 1 } } })); });
  await syncAll(a);
  const b = await join(B, link, () => { FamilyWallet.finishUnit('music', 'B: played before joining'); localStorage.setItem('musicQuest.v1', JSON.stringify({ lessons: ['m1'] })); });
  const wb = await wallet(b);
  check(`${label}: second laptop joining keeps its own play and gets A's (wallet union)`, wb.events.some((e) => e.reason === 'A: first lesson') && wb.events.some((e) => e.reason === 'B: played before joining'), JSON.stringify(wb.events.map((e) => e.reason)));
  await shot(b, P + '01-B-joined', true);
  await syncAll(b, a);
  check(`${label}: A gets B's pre-join play too`, (await wallet(a)).events.some((e) => e.reason === 'B: played before joining'));
  // ---- A -> B -> A: his progress follows him; the apps hear about their own keys (source "pull") ----
  const am = await A.newPage();
  await am.goto(`${BASE}/math-arena/`, { waitUntil: 'domcontentloaded' });
  await sleep(500);
  await am.evaluate(() => { localStorage.setItem('mathArena.v3.data.v1', JSON.stringify({ reports: [1, 2, 3, 4], progress: { seen: { a: 1, b: 1, c: 1 } } })); FamilyWallet.finishUnit('math', 'A: second lesson'); return FamilySync.syncNow(); });
  const bm = await B.newPage();
  await bm.goto(`${BASE}/math-arena/`, { waitUntil: 'domcontentloaded' });
  const gotB = await until(() => bm.evaluate(() => { const d = JSON.parse(localStorage.getItem('mathArena.v3.data.v1') || '{}'); return (d.reports || []).length === 4 && window.__fsUpdates.some((u) => u.source === 'pull' && u.keys.includes('mathArena.v3.data.v1')); }), 15000);
  check(`${label}: A -> B: B's Math Arena gets A's progress, with a "pull" update for its own key`, !!gotB, JSON.stringify(await bm.evaluate(() => window.__fsUpdates)));
  await bm.evaluate(() => { localStorage.setItem('mathArena.v3.data.v1', JSON.stringify({ reports: [1, 2, 3, 4, 5, 6], progress: { seen: { a: 1, b: 1, c: 1, d: 1 } } })); FamilyWallet.finishUnit('language', 'B: lesson'); return FamilySync.syncNow(); });
  await am.bringToFront();
  await am.evaluate(() => window.dispatchEvent(new Event('focus')));
  const gotA = await until(() => am.evaluate(() => (JSON.parse(localStorage.getItem('mathArena.v3.data.v1') || '{}').reports || []).length === 6 && FamilyWallet.balance().language >= 2), 15000);
  check(`${label}: B -> A: on focus, A gets B's progress back`, !!gotA);
  await syncAll(bm, am);
  await sleep(300); // let both tabs of each laptop see the latest storage
  const wa = await wallet(am), wbb2 = await wallet(bm);
  check(`${label}: no event is doubled after A -> B -> A`, new Set(wa.events.map((e) => e.id)).size === wa.events.length && wa.events.length === wbb2.events.length, JSON.stringify({ a: wa.events.map((e) => e.reason), b: wbb2.events.map((e) => e.reason) }));
  // ---- both laptops offline, then online ----
  await A.setOffline(true); await B.setOffline(true);
  await am.evaluate(() => { for (let i = 0; i < 5; i++) FamilyWallet.tickActive('code', 120000); FamilyWallet.finishUnit('code', 'A offline'); localStorage.setItem('codeQuest.progress.v1', JSON.stringify({ lessons: ['l1', 'l2', 'l3', 'l4'] })); });
  await bm.evaluate(() => { for (let i = 0; i < 4; i++) FamilyWallet.tickActive('code', 120000); FamilyWallet.finishUnit('music', 'B offline'); localStorage.setItem('codeQuest.progress.v1', JSON.stringify({ lessons: ['l1'] })); });
  const offA = await am.evaluate(() => FamilySync.syncNow().then(() => FamilySync.status()));
  check(`${label}: offline: the app keeps working and the change waits`, offA.state === 'offline' && offA.pending > 0, JSON.stringify(offA));
  await A.setOffline(false); await B.setOffline(false);
  await syncAll(am, bm, am);
  const mA = await wallet(a), mB = await wallet(b);
  const t = await a.evaluate(() => JSON.parse(localStorage.getItem('familyApps.walletTime.v1')));
  const codeMs = Object.values(t.days).reduce((n, d) => n + (d.code || 0), 0);
  check(`${label}: back online: both laptops' play is in both wallets`, ['A offline', 'B offline'].every((r) => mA.events.some((e) => e.reason === r) && mB.events.some((e) => e.reason === r)));
  check(`${label}: minutes from both laptops counted once each (10 + 8 min)`, codeMs === 18 * 60000, codeMs / 60000);
  check(`${label}: Code progress: the copy with more progress wins on both`, (await b.evaluate(() => JSON.parse(localStorage.getItem('codeQuest.progress.v1')).lessons.length)) === 4);
  const bk = JSON.parse((await cloud('familyApps.backup.code.v1')) || '{"entries":[]}');
  check(`${label}: the other Code copy is in the 30-day cloud backup`, bk.entries.some((e) => /"l1"\]/.test(e.items['codeQuest.progress.v1'] || '')), JSON.stringify(bk).slice(0, 200));
  check(`${label}: FS.log() lists the merge`, (await b.evaluate(() => FamilySync.log())).some((l) => l.kind === 'merge'));
  // ---- a legacy 1.0.0 tab left open on A cannot clobber B's newer progress ----
  const lt = await A.newPage();
  await lt.goto(`${BASE}/music-quest/?legacy=1`, { waitUntil: 'domcontentloaded' });
  await sleep(500);
  check(`${label}: the legacy tab runs family-sync 1.0.0`, (await lt.evaluate(() => FamilySync.VERSION)) === '1.0.0');
  await bm.evaluate(() => { localStorage.setItem('musicQuest.v1', JSON.stringify({ lessons: ['m1', 'm2', 'm3', 'm4', 'm5'] })); return FamilySync.syncNow(); });
  await lt.evaluate(() => { localStorage.setItem('musicQuest.v1', JSON.stringify({ lessons: ['m1', 'stale'] })); return FamilySync._t.cycle({ force: true }); });
  check(`${label}: the legacy tab could not overwrite B's newer Music progress`, JSON.parse(await cloud('musicQuest.v1')).lessons.length === 5);
  await lt.close();
  // ---- 1.2 anti-farming on his laptops (the Hub page on a kid laptop loads family-wallet.js 1.2) ----
  const fa = await A.newPage(); await fa.goto(`${BASE}/family/`); await fa.waitForSelector('text=All set ✔');
  const fb = await B.newPage(); await fb.goto(`${BASE}/family/`); await fb.waitForSelector('text=All set ✔');
  await A.setOffline(true); await B.setOffline(true);
  const ra = await fa.evaluate(() => { const r = [FamilyWallet.earnOnce('language', 'lesson:es-u1-l1:pass', 2, 'Greetings 1')]; for (let i = 0; i < 6; i++) r.push(FamilyWallet.earnOnce('language', 'lesson:es-u1-l1:pass', 2, 'Greetings 1')); r.push(FamilyWallet.rupeesOnce('language', 'es:hola', 1), FamilyWallet.rupeesOnce('language', 'es:hola', 1)); return r; });
  const rb = await fb.evaluate(() => FamilyWallet.earnOnce('language', 'lesson:es-u1-l1:pass', 2, 'Greetings 1'));
  check(`${label}: 1.2 earnOnce pays once, repeats pay 0, a repeated answer pays 0 rupees`, ra[0].paid === 2 && ra.slice(1, 7).every((x) => x.paid === 0 && x.reason === 'repeat') && ra[7] === 1 && ra[8] === 0, JSON.stringify(ra));
  check(`${label}: 1.2 the other laptop (offline) also paid it`, rb.paid === 2);
  await A.setOffline(false); await B.setOffline(false);
  await syncAll(fa, fb, fa);
  const once = await fa.evaluate(() => FamilyWallet.events({ limit: 1000 }).filter((e) => e.tag === 'once' && e.ref === 'lesson:es-u1-l1:pass').length);
  const onceB = await fb.evaluate(() => FamilyWallet.events({ limit: 1000 }).filter((e) => e.tag === 'once' && e.ref === 'lesson:es-u1-l1:pass').length);
  check(`${label}: 1.2 two laptops paying the same onceId -> paid once after sync`, once === 1 && onceB === 1, once + '/' + onceB);
  // ---- the grown-up: His laptops list, rename, remove; the policy toggle; the ledger summary row ----
  await until(async () => { await g.click('button:has-text("Sync now")'); await sleep(400); return (await g.$$('#devices ul.kids li')).length >= 2; }, 20000, 500);
  const kids = await g.$$('#devices ul.kids li');
  check(`${label}: Hub lists both of his laptops with last seen + last sync`, kids.length === 2 && /last sync from it/.test(await kids[0].innerText()), kids.length);
  const labels = await g.$$eval('#devices ul.kids input.devname', (els) => els.map((e) => e.value));
  check(`${label}: default names are Laptop 1 and Laptop 2`, JSON.stringify(labels) === JSON.stringify(['Laptop 1', 'Laptop 2']), JSON.stringify(labels));
  await g.fill('#devices ul.kids li:nth-child(1) input.devname', 'Kitchen Mac');
  await g.click('#devices ul.kids li:nth-child(1) button:has-text("Rename")');
  await until(() => g.$$eval('#devices input.devname', (els) => els.some((e) => e.value === 'Kitchen Mac')), 10000);
  await g.evaluate(() => FamilySync.syncNow());
  check(`${label}: rename saved as a family setting (familyApps.devices.v1)`, /Kitchen Mac/.test((await cloud('familyApps.devices.v1')) || ''));
  await shot(g, P + '02-his-laptops', true);
  g.once('dialog', (d) => d.accept());
  await g.click('#devices ul.kids li:nth-child(2) button:has-text("Remove")');
  await g.waitForSelector('#devices >> text=1 removed laptop is hidden');
  check(`${label}: Remove hides that laptop`, (await g.$$('#devices ul.kids li')).length === 1);
  check(`${label}: ledger shows one daily summary row for repeats`, !!(await g.$('#wallet tr.sumrow >> text=repeats — no reward')) || !!(await g.$('#wallet tr.sumrow')), await g.$eval('#wallet', (e) => e.innerText.slice(0, 400)));
  await g.evaluate(() => { window.__hub.ui.showSetup = true; window.__hub.ui.open = 'rewards'; window.__hub.route(); });
  await g.waitForSelector('#norepeats');
  check(`${label}: Rewards card has the no-repeats toggle (on by default) and the cap`, (await g.isChecked('#norepeats')) && (await g.inputValue('#oncecap')) === '6');
  await g.fill('#oncecap', '4');
  await g.click('#step-rewards button:has-text("Save rewards")');
  await g.evaluate(() => FamilySync.syncNow());
  await syncAll(fa);
  await fa.evaluate(() => FamilySync.applyParentRequests());
  check(`${label}: the cap reaches his laptop's wallet`, (await fa.evaluate(() => FamilyWallet.policy().onceDailyCap)) === 4);
  await shot(g, P + '03-rewards-policy');
  // ---- a second grown-up device keeps working ----
  const G2 = await newCtx(browser, vp, 'grownup2');
  const g2 = await G2.newPage();
  await g2.goto(`${BASE}/family/`);
  await g2.click('summary:has-text("Already set up")');
  await g2.fill('input[aria-label="Family link"]', link);
  await g2.click('button:has-text("Connect as a grown-up")');
  await g2.waitForSelector('#dashboard', { timeout: 20000 });
  await g2.click('button:has-text("Sync now")');
  const named = await until(() => g2.$$eval('#devices input.devname', (els) => els.some((e) => e.value === 'Kitchen Mac')), 15000);
  check(`${label}: second grown-up device sees the dashboard and the laptop names`, !!named);
  await shot(g2, P + '04-second-grownup', true);
  check(`${label}: no page errors`, [A, B, G, G2].every((c) => c.errors.length === 0), [A, B, G, G2].flatMap((c) => c.errors).join(' | '));
  await browser.close();
}
const ONLY = process.env.ONLY;
if (!ONLY || ONLY === 'desktop') await run('desktop', { width: 1440, height: 900 });
if (!ONLY || ONLY === 'phone') await run('phone', { width: 390, height: 844 });
await mock.close(); await site.close();
console.log(log.join('\n'));
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
