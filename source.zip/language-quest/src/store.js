// Storage: localStorage (prefix "langQuest.") with schema versions + migration, IndexedDB for family voices,
// backup/import. Save failures are reported to the UI.
import { familyPinSet, familyCheckPin } from './sync.js';
export const PREFIX = 'langQuest.';
export const SCHEMA = 3;
export const AI_KEY = 'familyApps.anthropicKey.v1';
const K_STATE = PREFIX + 'state';
let failCb = () => {};
export const onSaveFail = (cb) => { failCb = cb; };

// Storage that always works: real localStorage when allowed, else an in-memory stand-in (e.g. sandboxed preview iframes
// with an opaque origin, where touching localStorage throws). previewMode tells the UI that progress won't persist.
function memStore() {
  const m = new Map();
  return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => { m.set(k, String(v)); }, removeItem: (k) => { m.delete(k); },
    key: (i) => [...m.keys()][i] ?? null, get length() { return m.size; }, clear: () => m.clear() };
}
let _ls = null;
export let previewMode = false;
export function LS() {
  if (_ls) return _ls;
  try { const ls = window.localStorage; const t = '__langQuest_t'; ls.setItem(t, '1'); ls.removeItem(t); _ls = ls; }
  catch (e) { _ls = memStore(); previewMode = true; }
  return _ls;
}

export const today = () => { const d = new Date(); return Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / 86400000); };

export function langDefault() {
  return {
    level: null, placed: false, diff: 2, srs: {}, mistakes: {}, units: {}, quests: 0, lastDay: 0, streak: 0,
    script: { step: 0, done: {} }, speak: { tries: 0, good: 0 }, writing: [], win: [], minutes: 0, weekly: {}, songs: {}, comeback: [], mission: null, missionIdx: 0, firstDay: 0,
  };
}
export function defaults() {
  return {
    v: SCHEMA, created: Date.now(), nick: '', skin: 'hyrule', rupees: 0, hc: 0, chests: 0, lastBackup: 0, backupNag: 0,
    treasure: { found: {}, tokens: 0, toChoose: 0, flags: {}, capped: false },
    settings: {
      daily: 15, variety: 'es-MX', translit: 'fade', music: true, sfx: true, sr: 'auto', aiOn: false, aiCap: 20,
      aiModel: 'claude-haiku-4-5', voiceURI: '', rate: 0.9, mix: 'es', week: ['es', 'fa', 'es', 'fa', 'es', 'fa', 'es'], marks: 'auto',
    },
    es: langDefault(), fa: langDefault(), reports: [], ai: { day: 0, used: 0, tokens: 0 }, toys: { ocarina: false }, recQueue: [], setupDone: false, shop: { owned: [], tunic: 'green' }, secrets: {},
  };
}

// Migrations: v1 had a flat {progress} object; v2 lacked script/weekly/songs.
export function migrate(s) {
  if (!s || typeof s !== 'object') return defaults();
  if (!s.v || s.v < 2) {
    const d = defaults();
    if (s.nick) d.nick = s.nick;
    if (s.progress) for (const l of ['es', 'fa']) if (s.progress[l]) Object.assign(d[l], s.progress[l]);
    s = d;
  }
  if (s.v < 3) {
    for (const l of ['es', 'fa']) s[l] = Object.assign(langDefault(), s[l] || {});
    s.toys = s.toys || { ocarina: false };
    s.v = 3;
  }
  const d = defaults();
  for (const k of Object.keys(d)) if (s[k] === undefined || s[k] === null) s[k] = d[k];
  s.toys = Object.assign({ ocarina: false }, s.toys || {});
  s.settings = Object.assign(d.settings, s.settings || {});
  // Nov 2026: Spanish is the main language and Farsi the bonus; saves still on the old 'alternate days' default move over once
  if (!s.settings.mixV2) { if (s.settings.mix === 'alt') s.settings.mix = 'es'; s.settings.mixV2 = true; }
  for (const l of ['es', 'fa']) s[l] = Object.assign(langDefault(), s[l] || {});
  s.ai = Object.assign(d.ai, s.ai || {});
  s.treasure = Object.assign({ found: {}, tokens: 0, toChoose: 0, flags: {}, capped: false }, s.treasure || {});
  return s;
}

export function load() {
  try {
    const raw = LS().getItem(K_STATE);
    return migrate(raw ? unpackState(JSON.parse(raw)) : null);
  } catch (e) {
    console.warn('load failed', e);
    return defaults();
  }
}

// After Family Sync downloaded his cloud progress into this laptop (first connect), the page reloads at the next calm
// moment; until then the in-memory copy must not overwrite it.
let frozen = false;
export const freezeSaves = () => { frozen = true; };
export const unfreezeSaves = () => { frozen = false; };
export function save(s) {
  if (frozen) return true;
  try {
    LS().setItem(K_STATE, serializeState(s));
    return true;
  } catch (e) {
    if (!previewMode) failCb(e);
    return false;
  }
}

export function getRaw(k) { try { return LS().getItem(PREFIX + k); } catch { return null; } }
export function setRaw(k, v) { try { LS().setItem(PREFIX + k, v); return true; } catch (e) { if (!previewMode) failCb(e); return false; } }
export function getAIKey() {
  try {
    const v = (LS().getItem(AI_KEY) || '').trim();
    if (v.startsWith('{')) { try { const o = JSON.parse(v); return (o && (o.key || o.apiKey)) || ''; } catch { return ''; } }
    return v;
  } catch { return ''; }
}
export function setAIKey(v) { try { if (v) LS().setItem(AI_KEY, v); else LS().removeItem(AI_KEY); return true; } catch (e) { return false; } }

// PIN (hashed)
async function sha(s) {
  try {
    const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('lq-salt:' + s));
    return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
  } catch {
    let h = 5381; for (const c of s) h = (h * 33 + c.charCodeAt(0)) >>> 0; return 'h' + h;
  }
}
// When this laptop is connected to the family, the family PIN (set in the Family Hub) replaces the local PIN.
export const pinIsSet = () => familyPinSet() || !!getRaw('pin');
export async function setPin(p) { return setRaw('pin', await sha(p)); }
export async function checkPin(p) { if (familyPinSet()) return familyCheckPin(p); const h = getRaw('pin'); return h ? h === (await sha(p)) : p === '0000'; }

// IndexedDB — family voice recordings
let dbp = null;
const memVoices = new Map(); let idbOK = true;
export const voicesPersist = () => idbOK && !previewMode;
function db() {
  if (!dbp) dbp = new Promise((res, rej) => {
    try {
      if (!window.indexedDB) throw new Error('no idb');
      const r = window.indexedDB.open('langQuest.voices', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('voices');
      r.onsuccess = () => res(r.result);
      r.onerror = () => { idbOK = false; rej(r.error); };
    } catch (e) { idbOK = false; rej(e); }
  });
  return dbp;
}
async function tx(mode, fn) {
  const d = await db();
  return new Promise((res, rej) => {
    const t = d.transaction('voices', mode);
    const st = t.objectStore('voices');
    const out = fn(st);
    t.oncomplete = () => res(typeof IDBRequest !== 'undefined' && out instanceof IDBRequest ? out.result : out);
    t.onerror = () => rej(t.error);
  });
}
export async function voicePut(key, rec) { try { await tx('readwrite', (s) => s.put(rec, key)); return true; } catch (e) { memVoices.set(key, rec); return true; } }
export async function voiceDel(key) { memVoices.delete(key); try { await tx('readwrite', (s) => s.delete(key)); } catch {} }
export async function voiceGet(key) { if (memVoices.has(key)) return memVoices.get(key); try { const r = await tx('readonly', (s) => s.get(key)); return r || null; } catch { return null; } }
export async function voiceAll() {
  try {
    const d = await db();
    return await new Promise((res, rej) => {
      const out = []; const t = d.transaction('voices', 'readonly'); const c = t.objectStore('voices').openCursor();
      c.onsuccess = () => { const cur = c.result; if (cur) { out.push({ key: cur.key, ...cur.value }); cur.continue(); } };
      t.oncomplete = () => res(out); t.onerror = () => rej(t.error);
    });
  } catch { return [...memVoices].map(([key, v]) => ({ key, ...v })); }
}

const b2b64 = (blob) => new Promise((res) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.readAsDataURL(blob); });
const b642b = (b64, mime) => { const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new Blob([u], { type: mime }); };

export async function makeBackup() {
  const ls = {};
  const st = LS();
  for (let i = 0; i < st.length; i++) {
    const k = st.key(i);
    if (k && k.startsWith(PREFIX)) ls[k] = st.getItem(k);
  }
  const voices = [];
  for (const v of await voiceAll()) voices.push({ key: v.key, text: v.text, lang: v.lang, mime: v.mime, date: v.date, b64: await b2b64(v.blob) });
  return { app: 'langQuest', schema: SCHEMA, date: new Date().toISOString(), localStorage: ls, voices };
}
export function downloadBackup(obj) {
  const blob = new Blob([JSON.stringify(obj)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'language-quest-backup-' + new Date().toISOString().slice(0, 10) + '.json';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
export function parseBackup(text) {
  const o = JSON.parse(text);
  if (!o || o.app !== 'langQuest' || typeof o.localStorage !== 'object') throw new Error('This file is not a Language Quest backup.');
  if (o.schema > SCHEMA) throw new Error('This backup is from a newer version of the app.');
  return o;
}
export async function restoreBackup(o) {
  const keys = [];
  const st = LS();
  for (let i = 0; i < st.length; i++) { const k = st.key(i); if (k && k.startsWith(PREFIX)) keys.push(k); }
  keys.forEach((k) => st.removeItem(k));
  for (const [k, v] of Object.entries(o.localStorage)) if (k.startsWith(PREFIX)) st.setItem(k, v);
  for (const v of o.voices || []) await voicePut(v.key, { text: v.text, lang: v.lang, mime: v.mime, date: v.date, blob: b642b(v.b64, v.mime) });
  // run migration on the restored state
  const s = load(); save(s);
  return s;
}

export async function askPersist() { try { if (!previewMode && navigator.storage && navigator.storage.persist) return await navigator.storage.persist(); } catch {} return false; }

// ---------- keeping the save small (Family Sync caps a key at 300 KB; we stay well under 200 KB) ----------
// Spaced-repetition entries are stored as short arrays [box, due, right, wrong, start, lastWrong] and unpacked on load;
// in memory they stay objects. Logs and histories are capped. Old saves (object entries) load unchanged.
const packSrs = (srs) => { const o = {}; for (const k in srs || {}) { const r = srs[k]; if (!r || typeof r !== 'object' || Array.isArray(r)) { o[k] = r; continue; } const a = [r.b || 0, r.d || 0, r.r || 0, r.w || 0, r.s || 0]; if (r.lw) a.push(r.lw); o[k] = a; } return o; };
const unpackSrs = (srs) => { const o = {}; for (const k in srs || {}) { const a = srs[k]; if (Array.isArray(a)) { const r = { b: a[0] || 0, d: a[1] || 0, r: a[2] || 0, w: a[3] || 0, s: a[4] || 0 }; if (a[5]) r.lw = a[5]; o[k] = r; } else o[k] = a; } return o; };
const short = (t, n) => (typeof t === 'string' && t.length > n ? t.slice(0, n) : t);
// trims logs in place (the app reads only the newest of each); returns the same object
export function compactState(s) {
  if (!s || typeof s !== 'object') return s;
  if (Array.isArray(s.reports)) s.reports = s.reports.slice(0, 60).map((r, i) => {
    if (!r || typeof r !== 'object') return r;
    const x = { ...r, writing: (r.writing || []).slice(0, 3).map((w) => ({ kind: w.kind, text: short(w.text, 120) })) };
    if (i >= 30) { x.writing = []; x.mistakes = {}; delete x.boss; } // the Parent corner shows the newest 15 in full
    return x;
  });
  for (const l of ['es', 'fa']) {
    const L = s[l]; if (!L || typeof L !== 'object') continue;
    if (Array.isArray(L.writing)) L.writing = L.writing.slice(0, 20).map((w) => ({ ...w, text: short(w.text, 300), mts: (w.mts || []).slice(0, 6) }));
    if (Array.isArray(L.comeback)) L.comeback = L.comeback.slice(-30);
    if (Array.isArray(L.win)) L.win = L.win.slice(-12);
  }
  if (Array.isArray(s.recQueue)) s.recQueue = s.recQueue.slice(0, 200);
  return s;
}
export function serializeState(s) {
  compactState(s);
  const out = { ...s, srsPacked: 1 };
  for (const l of ['es', 'fa']) if (s[l]) { out[l] = { ...s[l], srs: packSrs(s[l].srs) }; if (s[l].fs && s[l].fs.srs) out[l].fs = { ...s[l].fs, srs: packSrs(s[l].fs.srs) }; }
  return JSON.stringify(out);
}
export function unpackState(o) {
  if (!o || typeof o !== 'object' || !o.srsPacked) return o;
  for (const l of ['es', 'fa']) if (o[l]) { o[l].srs = unpackSrs(o[l].srs); if (o[l].fs && o[l].fs.srs) o[l].fs.srs = unpackSrs(o[l].fs.srs); }
  delete o.srsPacked;
  return o;
}
