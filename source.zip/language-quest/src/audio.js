// Audio: Spanish browser voices, Farsi pre-generated packs, family voices (IndexedDB) first,
// speech recognition with record-and-compare fallback, small original SFX synth.
import { voiceGet } from './store.js';
import { fnv } from './engine.js';
import { getPack, FAIDX } from './packs.js';

let settings = { variety: 'es-MX', rate: 0.9, voiceURI: '', sfx: true, sr: 'auto' };
export const setAudioSettings = (s) => { settings = { ...settings, ...s }; };

// ---------- Spanish speech synthesis ----------
let voices = [];
const loadVoices = () => { try { voices = speechSynthesis.getVoices() || []; } catch { voices = []; } return voices; };
if (typeof speechSynthesis !== 'undefined') { loadVoices(); speechSynthesis.onvoiceschanged = loadVoices; }
export function spanishVoices() { return loadVoices().filter((v) => /^es/i.test(v.lang)); }
export function pickVoice(variety = settings.variety) {
  const vs = spanishVoices();
  if (settings.voiceURI) { const v = vs.find((x) => x.voiceURI === settings.voiceURI); if (v) return v; }
  const want = variety === 'es-ES' ? ['es-ES'] : ['es-MX', 'es-US', 'es-419'];
  const score = (v) => {
    const l = v.lang.replace('_', '-');
    let s = want.indexOf(l) >= 0 ? 10 - want.indexOf(l) : (variety !== 'es-ES' && l === 'es-ES' ? 2 : 1);
    if (/google/i.test(v.name)) s += 5;
    if (/(paulina|mónica|monica|juan|jorge|siri)/i.test(v.name)) s += 3;
    if (/eloquence|grandma|grandpa|shelley|rocko|sandy|flo|reed/i.test(v.name)) s -= 4;
    return s;
  };
  return vs.sort((a, b) => score(b) - score(a))[0] || null;
}
function sayTTS(text, lang) {
  return new Promise((res) => {
    if (typeof speechSynthesis === 'undefined') return res(false);
    try {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      const v = lang === 'fa' ? loadVoices().find((x) => /^fa/i.test(x.lang)) : pickVoice();
      if (lang === 'fa' && !v) return res(false);
      if (v) { u.voice = v; u.lang = v.lang; } else u.lang = settings.variety;
      u.rate = (settings.rate || 0.9) * (nextRate < 1 ? 0.7 : 1);
      let done = false; const fin = (ok) => { if (!done) { done = true; res(ok); } };
      u.onend = () => fin(true); u.onerror = () => fin(false);
      speechSynthesis.speak(u);
      setTimeout(() => fin(true), 1500 + text.length * 140);
    } catch { res(false); }
  });
}

// ---------- shared <audio> element (iOS friendly) ----------
let el = null; let curUrl = null;
function audioEl() { if (!el) { el = new Audio(); el.preload = 'auto'; } return el; }
export function unlockAudio() { try { const a = audioEl(); a.muted = true; a.play().catch(() => {}); a.pause(); a.muted = false; ctx(); } catch {} }
let nextRate = 1;
function playBlob(blob) {
  return new Promise((res) => {
    const a = audioEl();
    if (curUrl) URL.revokeObjectURL(curUrl);
    curUrl = URL.createObjectURL(blob);
    a.src = curUrl;
    try { a.playbackRate = nextRate; a.preservesPitch = true; } catch (e) {}
    let done = false; const fin = (ok) => { if (!done) { done = true; res(ok); } };
    a.onended = () => fin(true); a.onerror = () => fin(false);
    a.play().catch(() => fin(false));
    setTimeout(() => fin(true), 15000);
  });
}
export const stopAudio = () => { try { audioEl().pause(); speechSynthesis && speechSynthesis.cancel(); } catch {} };

// ---------- Farsi packs ----------
let faIndex = FAIDX ? { ...FAIDX, base: 'audio/' } : null;
export function loadFaIndex() { return Promise.resolve(faIndex); }
export const faHas = (text) => !!(faIndex && faIndex.clips && faIndex.clips[fnv(text)]);
export const faCoverage = () => (faIndex && faIndex.clips ? Object.keys(faIndex.clips).length : 0);
async function faClip(text) {
  await loadFaIndex();
  if (!faIndex) return null;
  const c = faIndex.clips[fnv(text)];
  if (!c) return null;
  const [pi, off, len] = c;
  const name = faIndex.packs[pi];
  const buf = await getPack(faIndex.base + name, faIndex.base + name.replace('.mp3pack', '.js'), name);
  return new Blob([buf.slice(off, off + len)], { type: 'audio/mpeg' });
}

// ---------- music ducking (kit music gets quiet while a voice plays or the mic listens) ----------
let duckDepth = 0, savedVol = null;
export function duck() { const M = globalThis.HyruleMusic; if (!M || !M.setMusicVolume) return; try { if (duckDepth++ === 0) { const v = M.getVolumes ? M.getVolumes() : null; savedVol = v && typeof v.music === 'number' ? v.music : null; M.setMusicVolume(0.06); } } catch (e) {} }
export function unduck() { const M = globalThis.HyruleMusic; if (!M || !M.setMusicVolume) return; try { duckDepth = Math.max(0, duckDepth - 1); if (duckDepth === 0 && savedVol != null) M.setMusicVolume(savedVol); } catch (e) {} }

// ---------- public: play any target-language text ----------
export const voiceKey = (lang, text) => lang + ':' + fnv(text);
export async function say(lang, text, opt = {}) {
  if (!text) return false;
  duck(); nextRate = opt.slow ? 0.7 : 1;
  try { return await sayInner(lang, text); } finally { unduck(); nextRate = 1; }
}
async function sayInner(lang, text) {
  stopAudio();
  const fam = await voiceGet(voiceKey(lang, text));
  if (fam && fam.blob) return playBlob(fam.blob);
  if (lang === 'fa') {
    const b = await faClip(text).catch(() => null);
    if (b) return playBlob(b);
    return sayTTS(text, 'fa');
  }
  return sayTTS(text, 'es');
}
export async function hasAudio(lang, text) {
  if (lang === 'es') return spanishVoices().length > 0;
  if (await voiceGet(voiceKey(lang, text))) return true;
  await loadFaIndex();
  return faHas(text) || loadVoices().some((x) => /^fa/i.test(x.lang));
}
export const playRecording = (blob) => playBlob(blob);

// ---------- speech recognition ----------
const SR = () => (typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition)) || null;
const broken = {};
export const srAvailable = (lang) => settings.sr !== 'off' && !!SR() && !broken[lang];
export function srLang(lang) { return lang === 'fa' ? 'fa-IR' : (settings.variety === 'es-ES' ? 'es-ES' : 'es-MX'); }
export function listen(lang, ms = 7000) { return listenHandle(lang, ms).promise; }
// Returns { promise, stop }: stop() ends listening early (hold-Space-to-talk releases the key).
export function listenHandle(lang, ms = 8000) {
  duck();
  let rec = null;
  const promise = new Promise((res) => {
    const C = SR();
    if (!C) return res({ error: 'unsupported', alts: [] });
    let r; try { r = new C(); } catch { broken[lang] = true; return res({ error: 'unsupported', alts: [] }); }
    rec = r;
    r.lang = srLang(lang); r.maxAlternatives = 5; r.interimResults = false; r.continuous = false;
    let done = false; const fin = (o) => { if (!done) { done = true; try { r.abort(); } catch {} res(o); } };
    r.onresult = (e) => { const alts = []; const x = e.results[0]; for (let i = 0; i < x.length; i++) alts.push(x[i].transcript); fin({ alts }); };
    r.onerror = (e) => {
      const err = (e && e.error) || 'error';
      if (['language-not-supported', 'not-allowed', 'service-not-allowed', 'audio-capture', 'network'].includes(err)) broken[lang] = true;
      fin({ error: err, alts: [] });
    };
    r.onend = () => fin({ alts: [], error: 'no-speech' });
    try { r.start(); } catch { broken[lang] = true; fin({ error: 'start', alts: [] }); }
    setTimeout(() => fin({ alts: [], error: 'timeout' }), ms);
  }).finally(unduck);
  return { promise, stop: () => { try { rec && rec.stop(); } catch (e) {} } };
}

// ---------- microphone permission (asked during parent setup) ----------
export async function micPermission() {
  try { if (navigator.permissions && navigator.permissions.query) { const q = await navigator.permissions.query({ name: 'microphone' }); return q.state; } } catch (e) {}
  return 'unknown';
}
export async function askMic() {
  try { const st = await navigator.mediaDevices.getUserMedia({ audio: true }); st.getTracks().forEach((t) => t.stop()); return true; } catch (e) { return false; }
}
// ---------- recorder (fallback + family voices) ----------
export const recAvailable = () => !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);
export async function startRecording() {
  duck();
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); } catch (e) { unduck(); throw e; }
  const types = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm', 'audio/ogg'];
  const mime = types.find((t) => MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t)) || '';
  const mr = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
  const chunks = [];
  mr.ondataavailable = (e) => e.data && e.data.size && chunks.push(e.data);
  mr.start();
  return {
    stop: () => new Promise((res) => {
      mr.onstop = () => { stream.getTracks().forEach((t) => t.stop()); unduck(); res(new Blob(chunks, { type: mr.mimeType || mime || 'audio/webm' })); };
      try { mr.stop(); } catch { unduck(); res(null); }
    }),
  };
}

// One-tap recording: starts now, stops by itself after the speaker goes quiet (or after maxMs).
export async function recordAuto(maxMs = 6000) {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const types = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm'];
  const mime = types.find((t) => window.MediaRecorder && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t)) || '';
  const mr = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
  const chunks = []; mr.ondataavailable = (e) => e.data && e.data.size && chunks.push(e.data);
  const c = ctx(); let an = null, buf = null;
  if (c) { try { const src = c.createMediaStreamSource(stream); an = c.createAnalyser(); an.fftSize = 1024; src.connect(an); buf = new Float32Array(an.fftSize); } catch (e) { an = null; } }
  duck(); mr.start();
  return new Promise((res) => {
    const t0 = Date.now(); let heard = false, quietSince = 0;
    const stop = () => { clearInterval(iv); try { mr.stop(); } catch (e) {} };
    mr.onstop = () => { stream.getTracks().forEach((t) => t.stop()); unduck(); res(new Blob(chunks, { type: mr.mimeType || mime || 'audio/webm' })); };
    const iv = setInterval(() => {
      const el = Date.now() - t0;
      if (an) { an.getFloatTimeDomainData(buf); let s = 0; for (let i = 0; i < buf.length; i++) s += buf[i] * buf[i]; const rms = Math.sqrt(s / buf.length);
        if (rms > 0.03) { heard = true; quietSince = 0; } else if (heard) { quietSince = quietSince || Date.now(); if (Date.now() - quietSince > 900) stop(); } }
      if (el > maxMs || (!an && el > 3000)) stop();
    }, 100);
  });
}
// ---------- SFX + ambient (original, synthesized) ----------
let ac = null;
function ctx() { if (!ac) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch { ac = null; } } if (ac && ac.state === 'suspended') ac.resume().catch(() => {}); return ac; }
export function tone(freq, t0, dur, type = 'triangle', vol = 0.12) {
  const c = ctx(); if (!c) return;
  const o = c.createOscillator(), g = c.createGain();
  o.type = type; o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, c.currentTime + t0);
  g.gain.exponentialRampToValueAtTime(vol, c.currentTime + t0 + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + t0 + dur);
  o.connect(g).connect(c.destination); o.start(c.currentTime + t0); o.stop(c.currentTime + t0 + dur + 0.05);
}
const N = (m) => 440 * Math.pow(2, (m - 69) / 12);
const KIT_SFX = { good: 'correct', try: 'wrong', tap: 'tap', rupee: 'rupee', chest: 'chest', boss: 'unlock', win: 'levelup', heart: 'heart', item: 'item' };
export function sfx(kind) {
  if (!settings.sfx) return;
  const M = globalThis.HyruleMusic;
  if (M && KIT_SFX[kind]) { try { if (M.sfx(KIT_SFX[kind]) !== false) return; } catch (e) {} }
  const seq = {
    good: [[76, 0, 0.18], [83, 0.09, 0.3]],
    try: [[64, 0, 0.16], [62, 0.12, 0.22]],
    tap: [[88, 0, 0.06]],
    rupee: [[84, 0, 0.08], [88, 0.06, 0.08], [91, 0.12, 0.16]],
    chest: [[67, 0, 0.18], [71, 0.15, 0.18], [74, 0.3, 0.18], [79, 0.45, 0.5], [83, 0.6, 0.6]],
    boss: [[45, 0, 0.5, 'sawtooth', 0.05], [44, 0.4, 0.6, 'sawtooth', 0.05]],
    win: [[72, 0, 0.15], [76, 0.12, 0.15], [79, 0.24, 0.15], [84, 0.36, 0.5], [79, 0.6, 0.15], [84, 0.72, 0.7]],
  }[kind] || [];
  seq.forEach(([m, t, d, type, v]) => tone(N(m), t, d, type || 'triangle', v || 0.12));
}
export function ocarinaNote(m) { const c = ctx(); if (!c) return; tone(N(m), 0, 0.7, 'sine', 0.2); tone(N(m) * 2, 0, 0.5, 'sine', 0.03); }
