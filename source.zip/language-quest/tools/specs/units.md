# Language Quest — shared unit map (both languages travel the same Hyrule)

Levels: Sprout (K-2) = units 1-5, Explorer (grade 3) = 6-10, Grade 4 core = 11-16, Grade 4+ stretch = 17-20.
Even units end with a temple boss and give a spiritual stone / medallion. Odd units end with a mini-boss.

| n | place | teacher (role-play partner) | boss |
|---|---|---|---|
| 1 | Kokiri Forest | Saria | Mad Scrub |
| 2 | Inside the Deku Tree | the Great Deku Tree | Queen Gohma (Kokiri's Emerald) |
| 3 | Hyrule Field | Kaepora Gaebora (owl) | Big Poe |
| 4 | Goron City | Darunia | King Dodongo (Goron's Ruby) |
| 5 | Zora's Domain | Ruto | Big Octo |
| 6 | Jabu-Jabu's Belly | Ruto | Barinade (Zora's Sapphire) |
| 7 | Hyrule Castle | Zelda | Stalfos |
| 8 | Forest Temple | Saria | Phantom Ganon (Forest Medallion) |
| 9 | Kakariko Village | Kakariko villagers | Lizalfos |
| 10 | Fire Temple | Darunia | Volvagia (Fire Medallion) |
| 11 | Lon Lon Ranch | Malon | Big Deku Baba |
| 12 | Water Temple | Ruto | Morpha (Water Medallion) |
| 13 | Lake Hylia | Kaepora Gaebora | Flare Dancer |
| 14 | Shadow Temple | Impa | Bongo Bongo (Shadow Medallion) |
| 15 | Lon Lon Ranch barn | Talon | Skull Kid |
| 16 | Spirit Temple | Impa | Twinrova (Spirit Medallion) |
| 17 | Kakariko at night | Kakariko villagers | Poe Sisters |
| 18 | Temple of Time | Zelda | Dark Link (Light Medallion) |
| 19 | Castle Town market | Talon | Iron Knuckle |
| 20 | Ganon's Castle | Zelda | Ganondorf (final; Triforce) |

Bosses are kid-friendly: the player beats a boss by speaking and understanding (no violence; the boss calms down, laughs, or turns friendly).

## Spanish units (theme — "I can" goal — grammar idea)
1. Greetings & feelings — I can greet people and say how I feel. — estoy + feeling (¿Cómo estás? Estoy feliz)
2. Numbers 0-100 — I can count to 100 and say my age. — hay + number, ¿cuántos?, tengo ___ años (chunk)
3. Colors & shapes — I can name colors and shapes. — gender & articles (el/la, un/una)
4. Family — I can introduce my family. — plurals (-s/-es, los/las)
5. School — I can talk about my classroom. — adjective agreement (la mochila roja, los lápices rojos)
6. Body — I can name body parts and say what hurts. — ser vs estar basics (+ me duele chunk)
7. Clothes — I can say what I wear. — present tense regular -ar verbs, singular (llevo, llevas, lleva)
8. Food & ordering — I can order food politely. — tener expressions (tengo hambre/sed) + quiero/quisiera chunk
9. Home — I can describe my home. — present tense -er/-ir verbs, singular (como, vivo, leo, escribe)
10. Animals — I can say which animals I like. — gustar (me gusta / me gustan / te gusta / le gusta)
11. Weather & seasons — I can talk about the weather. — hace + weather (hacer), llueve, nieva, está nublado
12. Calendar & time — I can say the day, date and time. — question words (qué, cuándo, a qué hora, cuántos, dónde, quién)
13. Hobbies & sports — I can talk about what I like to do. — ir a + infinitive (voy a jugar)
14. Town & directions — I can ask and give simple directions. — ir (voy, vas, va) + a/al; estar for location (¿Dónde está?)
15. Community helpers — I can talk about jobs and ask for help. — poder (puedo, puedes, puede) + infinitive
16. Nature — I can describe nature and say what I want to do. — querer (quiero, quieres, quiere) and hacer (hago, haces, hace)
17. Daily routines (stretch) — I can describe my daily routine. — reflexive verbs (me levanto, me lavo, me visto)
18. Celebrations (stretch) — I can talk about a holiday and what I did. — a few preterite forms (fui, comí, jugué, vi)
19. Spanish-speaking countries (stretch) — I can compare places in the Spanish-speaking world. — comparatives (más ... que, menos ... que, mejor, mayor)
20. Stories (stretch) — I can retell a short story. — preterite in stories (había una vez, fue, vio, dijo, encontró)

## Farsi units (theme — "I can" goal — grammar idea)
1. Greetings & polite phrases (simple ta'arof) — I can greet people politely. — pronouns (man, to, u, mâ, shomâ, unâ) and polite shomâ
2. Family (amu, amme, khâle, dâyi...) — I can introduce my family. — "is": spoken -e / written ast, hast
3. Feelings — I can say how I feel. — "to be" personal endings (khoshhâlam, khaste-i?, khoshhâl-e)
4. Numbers & Persian digits — I can count to 100 and read Persian digits. — number + tâ + singular noun (se tâ sib)
5. Colors — I can name colors and describe things. — SOV word order (man ye tup-e ghermez dâram)
6. Persian food — I can talk about food I eat. — present tense with mi- + personal endings (mikhoram, mikhori, mikhore)
7. Home — I can describe my home. — negation (nemikhâm, nadâram, nist)
8. School — I can talk about my school. — ezafe (ketâb-e man, kelâs-e chahârom)
9. Animals — I can talk about animals. — plurals -hâ / -ân (spoken -â)
10. Body — I can name body parts and say what hurts. — possessive endings (dastam, cheshmet, sar-esh)
11. Days & time — I can say the day and the time. — question words (key, chand, kojâ, chi, ki, cherâ, chetor)
12. Weather & seasons — I can talk about the weather. — hast/nist and mi- verbs for weather (bârun miyâd)
13. Clothes — I can say what I wear. — ezafe + adjective (pirhan-e sefid) and mipusham
14. Town & bazaar — I can ask for things in a shop. — khâstan: mikhâm (spoken) / mikhâham (written) + polite requests
15. Hobbies & games — I can talk about what I like to do. — dust dâshtan + verb (dust dâram futbâl bâzi konam) as chunks
16. Places in Iran — I can talk about cities and places in Iran. — kojâ + prepositions (tu, ru, kenâr) and comparatives -tar
17. Nowruz (stretch) — I can talk about Nowruz and what we did. — simple past (raftim, didim, khordim)
18. Yalda & other celebrations (stretch) — I can talk about Yalda and other celebrations. — simple past: negative and questions
19. Shahnameh stories for kids (stretch) — I can retell a Shahnameh story. — past narrative (Rostam raft, Simorgh did)
20. My day (stretch) — I can describe yesterday and today. — past vs present (diruz raftam, emruz miram)
