// Farsi review sheet for a native speaker: Sprout words + phrases, every boss line, the first owl story.
// node tools/review_sheet.mjs > farsi-review.html
import fs from 'fs';
import C from '../src/content.gen.js';
const font = fs.readFileSync(process.env.LQ_FONT || '/tmp/lq/kit2/kit/fonts/vazirmatn-arabic-wght-normal.woff2').toString('base64');
const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const rows = [];
const add = (sec, id, x, ex) => rows.push({ sec, id, en: x.en || '', f: x.f || '', t: x.t || '', w: x.w && x.w !== x.f ? x.w : '', wt: x.w && x.w !== x.f ? x.wt || '' : '', exf: ex ? ex.f || '' : '', ext: ex ? ex.t || '' : '', exw: ex && ex.w && ex.w !== ex.f ? ex.w : '', exwt: ex && ex.w && ex.w !== ex.f ? ex.wt || '' : '' });
for (let n = 1; n <= 5; n++) {
  const u = C.fa[n]; if (!u) continue;
  (u.words || []).forEach((w, i) => add(`Sprout · unit ${n} (${u.theme}) · words`, `fa${n}w${i}`, w, w.ex));
  (u.phrases || []).forEach((p, i) => add(`Sprout · unit ${n} (${u.theme}) · phrases`, `fa${n}p${i}`, p, null));
}
for (let n = 1; n <= 20; n++) {
  const u = C.fa[n]; if (!u || !u.boss) continue;
  (u.boss.lines || []).forEach((l, i) => { const a = l.opts[l.a]; add(`Boss lines · unit ${n} (${u.theme}) — question | correct answer in the example columns`, `fa${n}boss${i}`, { ...l.q, en: (l.q.en || '') + (a && a.en ? '  →  ' + a.en : '') }, a); });
}
const st = C.story && C.story.fa && C.story.fa[1];
if (st) st.parts.forEach((p, k) => (p.lines || []).forEach((l, i) => add('Owl story · unit 1 (first story)', `fa1story${k}.${i}`, l, null)));
const sections = [...new Set(rows.map((r) => r.sec))];
const body = sections.map((sec) => `<tr class="sec"><th colspan="9">${esc(sec)}</th></tr>` + rows.filter((r) => r.sec === sec).map((r) => `<tr data-id="${r.id}">
<td class="ck"><input type="checkbox" aria-label="flag"></td>
<td class="en">${esc(r.en)}</td>
<td class="fa">${esc(r.f)}</td>
<td class="tr">${esc(r.t)}</td>
<td class="fa">${esc(r.w)}${r.wt ? `<div class="tr">${esc(r.wt)}</div>` : ''}</td>
<td class="fa">${esc(r.exf)}${r.ext ? `<div class="tr">${esc(r.ext)}</div>` : ''}</td>
<td class="fa">${esc(r.exw)}${r.exwt ? `<div class="tr">${esc(r.exwt)}</div>` : ''}</td>
<td class="note"><input type="text" placeholder="note"></td>
<td class="id">${r.id}</td></tr>`).join('\n')).join('\n');
const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Language Quest — Farsi review sheet</title>
<style>
@font-face{font-family:'Vazirmatn';font-weight:100 900;src:url(data:font/woff2;base64,${font}) format('woff2')}
body{font-family:system-ui,-apple-system,'Segoe UI',sans-serif;margin:16px;background:#fbf8ef;color:#1b1a17}
h1{font-size:22px;margin:0 0 6px} .intro{max-width:900px;line-height:1.5}
.bar{position:sticky;top:0;background:#fbf8ef;padding:8px 0;z-index:2;display:flex;gap:10px;align-items:center;flex-wrap:wrap;border-bottom:1px solid #ddd}
button{font:inherit;padding:8px 14px;border-radius:8px;border:1px solid #9a7224;background:#f0d58a;cursor:pointer;font-weight:700}
table{border-collapse:collapse;width:100%;margin-top:10px} th,td{border:1px solid #e3d7b9;padding:6px 8px;vertical-align:top}
thead th{background:#eedfba;position:sticky;top:52px;z-index:1;font-size:13px}
tr.sec th{background:#1f4a2e;color:#fbefc8;text-align:left;font-size:14px}
td.fa{font-family:'Vazirmatn',sans-serif;font-size:22px;direction:rtl;text-align:right;unicode-bidi:isolate;line-height:1.6}
td.fa .tr{font-family:system-ui,sans-serif;font-size:13px;direction:ltr;text-align:left;color:#6b6152;font-style:italic}
td.tr{font-style:italic;color:#3a352c} td.en{max-width:260px} td.id{font-size:11px;color:#999} td.ck{text-align:center}
td.note input{width:180px;font:inherit;padding:4px} tr.flag td{background:#fff3d6}
textarea{width:100%;height:160px;font-family:monospace}
</style></head><body>
<h1>Language Quest — Farsi review sheet</h1>
<div class="intro">${rows.length} rows: every Sprout-level (units 1–5) word and phrase, every boss line (question, with the correct answer in the example columns) and the first owl story. <b>Spoken</b> = everyday Tehrani as the app says it; <b>written</b> = the standard written form, shown only when it differs. Tick a row and/or type a note for anything that sounds wrong, then press <b>Export my notes</b> and paste the text into a message.</div>
<div class="bar"><button id="exp">Export my notes</button><span id="cnt">0 rows marked</span><span style="color:#6b6152">Notes stay on this page until you close it.</span></div>
<textarea id="out" style="display:none" readonly></textarea>
<table><thead><tr><th>✔</th><th>English</th><th>Spoken (script)</th><th>Spoken transliteration</th><th>Written (where different)</th><th>Example — spoken</th><th>Example — written</th><th>Note</th><th>id</th></tr></thead>
<tbody>${body}</tbody></table>
<script>
const K='langQuest.reviewNotes';let saved={};try{saved=JSON.parse(localStorage.getItem(K)||'{}')}catch(e){}
const rows=[...document.querySelectorAll('tr[data-id]')];
function count(){const n=rows.filter(r=>r.querySelector('input[type=checkbox]').checked||r.querySelector('td.note input').value.trim()).length;document.getElementById('cnt').textContent=n+' rows marked';}
function persist(){const o={};rows.forEach(r=>{const c=r.querySelector('input[type=checkbox]').checked,v=r.querySelector('td.note input').value;if(c||v)o[r.dataset.id]={c,v};});try{localStorage.setItem(K,JSON.stringify(o))}catch(e){}}
rows.forEach(r=>{const s=saved[r.dataset.id];const cb=r.querySelector('input[type=checkbox]'),nt=r.querySelector('td.note input');if(s){cb.checked=!!s.c;nt.value=s.v||'';r.classList.toggle('flag',cb.checked);}
cb.addEventListener('change',()=>{r.classList.toggle('flag',cb.checked);count();persist();});nt.addEventListener('input',()=>{count();persist();});});
count();
document.getElementById('exp').onclick=async()=>{const lines=rows.filter(r=>r.querySelector('input[type=checkbox]').checked||r.querySelector('td.note input').value.trim()).map(r=>{const t=[...r.children].map(c=>c.innerText.trim());return '['+r.dataset.id+'] '+t[1]+' | '+t[2]+' ('+t[3]+')'+(t[4]?' | written: '+t[4].replace(/\\n/g,' '):'')+' — NOTE: '+(r.querySelector('td.note input').value.trim()||'(flagged)');});
const txt='Language Quest — Farsi review notes ('+lines.length+')\\n'+lines.join('\\n');const ta=document.getElementById('out');ta.style.display='block';ta.value=txt;ta.select();
try{await navigator.clipboard.writeText(txt);document.getElementById('exp').textContent='Copied! ('+lines.length+')';}catch(e){try{document.execCommand('copy');document.getElementById('exp').textContent='Copied! ('+lines.length+')';}catch(e2){document.getElementById('exp').textContent='Select the text below and copy it';}}};
</script></body></html>`;
process.stdout.write(html);
console.error('rows', rows.length);
