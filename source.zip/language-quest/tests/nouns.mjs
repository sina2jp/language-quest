// Power phrases: every phrase must use a whitelisted, concrete, inanimate noun; Spanish articles per pattern; plural agreement.
// Run after `node build.mjs`: node tests/nouns.mjs
import C from '../src/content.gen.js';
import { WHITELIST, UNIT_NOUNS, conceptOf } from '../src/nouns.js';
import { CHUNKS, makeChunk, esForms } from '../src/routine.js';
const fails = []; let checked = 0;
const fail = (m) => fails.push(m);
const BLOCK = /\b(red|blue|green|yellow|white|black|brown|purple|orange color|pink|gray|grey|golden|silver|color|day|night|week|month|year|hour|minute|morning|noon|monday|tuesday|wednesday|thursday|friday|saturday|sunday|weather|rain|snow|wind|storm|fog|cloud|sun|moon|sky|season|spring|summer|winter|fall|game|soccer|swimming|running|dance|mom|dad|mother|father|sister|brother|friend|teacher|student|doctor|baby|boy|girl|man|woman|person|dog|cat|bird|fish|horse|cow|animal|mouse|bear|lion|tiger)\b/;
const esWords = new Map(), faWords = new Map();
for (const u of Object.values(C.es)) for (const w of u.words || []) esWords.set(w.es, w);
for (const u of Object.values(C.fa)) for (const w of u.words || []) faWords.set(w.f, w);
for (const w of WHITELIST) {
  if (BLOCK.test(w.en)) fail(`excluded category in whitelist: ${w.en}`);
  if (!esWords.has(w.es)) fail(`Spanish noun missing from content: ${w.es}`);
  if (!faWords.has(w.fa)) fail(`Farsi noun missing from content: ${w.fa}`);
  if (!/^(el|la|los|las) /.test(w.es)) fail(`Spanish noun without article: ${w.es}`);
}
const allowed = new Set(WHITELIST.map((w) => w.en));
for (const lang of ['es', 'fa']) for (let n = 1; n <= 20; n++) {
  const list = UNIT_NOUNS[lang][n] || [];
  if (list.length < 6 || list.length > 10) fail(`${lang} unit ${n}: ${list.length} nouns (want 6-10)`);
  for (const en of list) {
    if (!allowed.has(en)) { fail(`${lang} unit ${n}: ${en} is not whitelisted`); continue; }
    const c = conceptOf(en);
    const noun = lang === 'es' ? { t: c.es, c } : (() => { const w = faWords.get(c.fa); return { t: w.f, tr: w.t, w: w.w, wt: w.wt, c }; })();
    CHUNKS[lang].forEach((pat, k) => {
      const x = makeChunk(lang, k, noun); checked++;
      if (!x.t || !x.en || /___|undefined/.test(x.t + x.en)) fail(`${lang} ${en} #${k}: bad phrase "${x.t}" / "${x.en}"`);
      if (lang === 'fa') { if (!x.t.includes(noun.t)) fail(`fa ${en} #${k}: noun missing in "${x.t}"`); return; }
      const F = esForms(c.es, c);
      const want = pat.art === 'i' ? F.indef : F.def;
      if (!x.t.includes(' ' + want + (/[?!.]$/.test(x.t) ? '' : '')) && !x.t.includes(want)) fail(`es ${en} #${k}: expected "${want}" in "${x.t}"`);
      if (pat.art === 'i' && !c.mass && !F.pl && !/\b(un|una) /.test(x.t)) fail(`es ${en} #${k}: indefinite article missing in "${x.t}"`);
      if (pat.art === 'i' && (c.mass || F.pl) && /\b(un|una|unos|unas) /.test(x.t)) fail(`es ${en} #${k}: mass/plural noun should have no article in "${x.t}"`);
      if (pat.art === 'd' && !/\b(el|la|los|las) /.test(x.t)) fail(`es ${en} #${k}: definite article missing in "${x.t}"`);
      if (F.pl && /\b(gusta|está|encanta)\b/.test(x.t)) fail(`es ${en} #${k}: plural agreement in "${x.t}"`);
      if (!F.pl && /\b(gustan|están|encantan)\b/.test(x.t)) fail(`es ${en} #${k}: singular agreement in "${x.t}"`);
    });
  }
}
console.log(`power phrases: ${WHITELIST.length} whitelisted nouns, ${checked} phrases checked, ${fails.length} problems`);
fails.slice(0, 30).forEach((f) => console.log('  FAIL ' + f));
process.exit(fails.length ? 1 : 0);
