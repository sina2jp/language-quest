#!/usr/bin/env node
// Packaging scrub: fails (exit 1) if any file under the given folders (zip entries included as text) matches the
// blocked-words pattern. The pattern is stored base64-encoded so this file passes its own check.
import fs from 'node:fs';
import path from 'node:path';
const PATTERN = new RegExp(Buffer.from('aW50ZXJuYWxtZXRhfGludGVybmFsZmJ8ZmJ1cmx8bWV0YSBhcGV8YXBlLmltYWdlfGFwZS5tb2RlbHxuYW5vLWJhbmFuYXxWYXVsdCBwaXB8ZndkcHJveHl8eDJwfE1ldGFtYXRlfGFnZW50Y2xvdWR8dHdzdmNzY218ZmFhcw==', 'base64').toString('utf8'), 'i');
const roots = process.argv.slice(2);
if (!roots.length) { console.error('usage: node tools/scrub.mjs <dir|file> ...'); process.exit(2); }
let hits = 0, files = 0;
function walk(p) {
  const s = fs.statSync(p);
  if (s.isDirectory()) { for (const n of fs.readdirSync(p)) if (n !== 'node_modules' && n !== '.git') walk(path.join(p, n)); return; }
  files++;
  const text = fs.readFileSync(p).toString('latin1');
  const m = PATTERN.exec(text);
  if (m) { hits++; console.log(`HIT ${p}: ...${text.slice(Math.max(0, m.index - 40), m.index + 40).replace(/\s+/g, ' ')}...`); }
}
roots.forEach(walk);
console.log(`scrub: ${files} files, ${hits} hits`);
process.exit(hits ? 1 : 0);
