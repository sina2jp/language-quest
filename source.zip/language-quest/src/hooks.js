// App events for shared family features (the Family Wallet and similar): a tiny event bus.
// Types: 'learning' {on:true|false, screen}, 'lesson:done', 'quest:done', 'mission:done', 'boss:won', 'story:done',
// 'comeback' {why:'retry'|'help'}, 'streak' {days}, 'secret' {id}, 'interaction'.
const subs = new Set();
export function emit(type, detail = {}) {
  for (const fn of subs) { try { fn(type, detail); } catch (e) { /* a listener must never break the app */ } }
  try { window.dispatchEvent(new CustomEvent('lq-event', { detail: { type, ...detail } })); } catch (e) {}
}
export function on(fn) { subs.add(fn); return () => subs.delete(fn); }
