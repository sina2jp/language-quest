#!/usr/bin/env python3
"""Light-preview kit: the SAME file names as the dist kit (so every image the app references is present),
each image downscaled to half size. Usage: python3 tools/make_preview_kit.py <kit dir> <out dir>"""
import os, sys, shutil
from PIL import Image
src, out = sys.argv[1], sys.argv[2]
shutil.rmtree(out, ignore_errors=True)
n = tot = 0
for root, _, files in os.walk(src):
    for f in files:
        p = os.path.join(root, f); rel = os.path.relpath(p, src)
        if rel.startswith('fonts'): continue
        q = os.path.join(out, rel); os.makedirs(os.path.dirname(q), exist_ok=True)
        if f.endswith('.webp'):
            im = Image.open(p); w, h = im.size
            im = im.resize((max(1, w // 2), max(1, h // 2)), Image.LANCZOS)
            im.save(q, 'WEBP', quality=60 if '/places/' in p else 72, method=6)
        else:
            shutil.copyfile(p, q)
        n += 1; tot += os.path.getsize(q)
print('preview kit files', n, round(tot / 1048576, 2), 'MB')
