# Family Sync 1.0.0 (early drop)

- `family-sync.js`: the shared module. Copy it byte-identical into all 4 apps and the Hub. sha256 `bffc6790b089709d115dcdafbcfb19063ee253331976b72e58d187b14c085659`
- `INTEGRATION.md`: exactly what each app registers and changes (PIN, look, panels, summary, status dot, Connect panel, update events).
- `server/Code.gs`: the Apps Script backend (protocol v1, chunked rows, salted-hash auth, rate limits, pairing codes).
- `server/gas-shim.js`: in-memory Apps Script services, so the real Code.gs runs in Node and in a browser.
- `tools/mock-server.mjs`: a local backend that runs the real Code.gs. It answers with an Apps Script-style 302, counts CORS preflights (there must be 0), and can also serve the site: `node tools/mock-server.mjs --static <site-root>`.
- `tools/scrub.mjs`: the packaging scrub (pattern stored base64): `node tools/scrub.mjs <dir>`.
- `tests/unit.mjs`: chunking, protocol rules, merge rules, crypto, and two-device sync with the real family-wallet.js: `node tests/unit.mjs` (Node 20+, no deps).
- `vendor/family-wallet.js`: the unchanged 1.1 module the tests use.
