import json, os, sys
lang = sys.argv[1]
R = '/tmp/lq/content'
C = json.load(open(sys.argv[2] if len(sys.argv) > 2 else f'/tmp/lq/review/{lang}_corrections.json'))
cache = {}
def unit(n):
    if n not in cache: cache[n] = json.load(open(f'{R}/{lang}/u{n:02d}.json'))
    return cache[n]
ok = skip = 0; skipped = []
for c in C:
    try:
        d = unit(int(c['unit']))
        parts = [p for p in str(c['path']).split('/') if p != '']
        cur = d
        for p in parts[:-1]:
            if isinstance(cur, list): cur = cur[int(p)]
            else:
                if p not in cur or cur[p] is None: cur[p] = {}
                cur = cur[p]
        last = parts[-1]
        if isinstance(cur, list):
            i = int(last); val = cur[i] if i < len(cur) else None
        else:
            val = cur.get(last)
        old = c.get('old')
        if old is None and val not in (None, ''):
            if val == c['new']: ok += 1; continue
            skip += 1; skipped.append((c['unit'], c['path'], 'exists', val)); continue
        if old is not None and val != old:
            if val == c['new']: ok += 1; continue
            skip += 1; skipped.append((c['unit'], c['path'], 'mismatch', val, old)); continue
        if isinstance(cur, list): cur[int(last)] = c['new']
        else: cur[last] = c['new']
        ok += 1
    except Exception as e:
        skip += 1; skipped.append((c.get('unit'), c.get('path'), 'error', repr(e)))
for n, d in cache.items():
    p = f'{R}/{lang}/u{n:02d}.json'; json.dump(d, open(p + '.tmp', 'w'), ensure_ascii=False, indent=1); os.replace(p + '.tmp', p)
print(lang, 'applied', ok, 'skipped', skip)
for s in skipped[:15]: print('  SKIP', s)
json.dump(skipped, open(f'/tmp/lq/review/{lang}_skipped_fix.json', 'w'), ensure_ascii=False, indent=1)
