import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useApp, Navi, Modal, PlayBtn } from './ui.jsx';
import { detectModel } from './ai.js';
import { ParentRewards } from './treasure.jsx';
import { FW } from './wallet.js';
import { connectedKid, familyPinSet, mountStatus, mountConnect, stateTooBig } from './sync.js';
import { ParentWallet } from './walletui.jsx';
import { isBonus } from './engine.js';
import { checkPin, setPin, pinIsSet, makeBackup, downloadBackup, parseBackup, restoreBackup, voicePut, voiceDel, voiceAll, voiceGet, getAIKey, setAIKey } from './store.js';
import { spanishVoices, recAvailable, startRecording, playRecording, voiceKey, faCoverage, loadFaIndex, askMic, micPermission, recordAuto, say, faHas } from './audio.js';
import { LEVELS, MT, mastered } from './engine.js';
import { getUnits, unitItems, LANG, getUnit, T } from './content.js';


function PinPad({ title, onSubmit, sub }) {
  const [v, setV] = useState('');
  const [err, setErr] = useState('');
  const press = async (d) => {
    const nv = (v + d).slice(0, 4); setV(nv); setErr('');
    if (nv.length === 4) { const r = await onSubmit(nv); if (r !== true) { setErr(r || 'Wrong PIN'); setV(''); } }
  };
  return (
    <div className="card center" data-testid="pinpad">
      <h2>🔒 {title}</h2>
      {sub && <div className="muted" style={{ marginBottom: 10 }}>{sub}</div>}
      <div className="pin-dots">{[0, 1, 2, 3].map((i) => <span key={i}>{i < v.length ? '●' : '○'}</span>)}</div>
      {err && <div className="fb try" style={{ margin: '8px 0' }}>{err}</div>}
      <div className="pin-pad" style={{ marginTop: 12 }}>
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, '⌫'].map((d, i) => d === '' ? <span key={i} /> : <button key={i} onClick={() => d === '⌫' ? setV(v.slice(0, -1)) : press(String(d))} data-testid={`pin-${d}`}>{d}</button>)}
      </div>
    </div>
  );
}

function Setup({ onDone }) {
  const { S, set } = useApp();
  const [mic, setMic] = useState(null);
  return (
    <div className="card" data-testid="setup">
      <h2>👋 Quick setup</h2>
      <div className="plist">
        <div className="prow"><span>🎤 <b>Microphone</b>: your child answers by talking. Allow it once now.</span>
          <button className="btn sm primary" onClick={async () => setMic(await askMic())} data-testid="allow-mic">{mic === true ? '✓ Allowed' : mic === false ? 'Blocked: see Help' : 'Allow microphone'}</button></div>
        <label className="prow"><span>📅 <b>Which language when?</b></span>
          <select className="field" style={{ width: 'auto' }} value={S.settings.mix} onChange={(e) => set((s) => { s.settings.mix = e.target.value; })} data-testid="setup-mix">
            <option value="es">Spanish every day + Farsi bonus (recommended)</option><option value="alt">Alternate days (Spanish, then Farsi)</option><option value="fa">Farsi every day + Spanish bonus</option><option value="custom">Choose per weekday (Settings)</option></select></label>
        <label className="prow"><span>⏱️ <b>Daily quest</b></span>
          <select className="field" style={{ width: 'auto' }} value={S.settings.daily} onChange={(e) => set((s) => { s.settings.daily = +e.target.value; })}><option value={10}>10 minutes</option><option value={15}>15 minutes</option><option value={20}>20 minutes</option></select></label>
      </div>
      <div className="muted small" style={{ marginTop: 8 }}>You can change all of this later in Settings.</div>
      <div className="row" style={{ marginTop: 12 }}><button className="btn primary wide" onClick={() => { set((s) => { s.setupDone = true; }); onDone(); }} data-testid="setup-done">Done</button></div>
    </div>
  );
}
export function ParentGate({ children }) {
  const { S } = useApp();
  const [stage, setStage] = useState(() => (globalThis.__LQ_TEST__ && globalThis.__LQ_TEST__.unlock ? 'ok' : 'enter')); // enter | new1 | new2 | setup | ok (tests can open it directly)
  const [first, setFirst] = useState('');
  const isDefault = !pinIsSet();
  if (stage === 'ok' && !S.setupDone) return <Setup onDone={() => setStage('ok')} />;
  if (stage === 'ok') return children;
  if (stage === 'enter') return <PinPad title="Parent corner" sub={familyPinSet() ? 'Enter the family PIN.' : isDefault ? 'First visit: the starting PIN is 0000. You will choose your own PIN next.' : 'Enter your parent PIN.'}
    onSubmit={async (p) => { if (await checkPin(p)) { setStage(isDefault ? 'new1' : 'ok'); return true; } return 'Wrong PIN. Try again.'; }} />;
  if (stage === 'new1') return <PinPad key="n1" title="Choose a new PIN" sub="Pick 4 digits a child won't guess (not 0000 or 1234)." onSubmit={async (p) => { if (['0000', '1234', '1111'].includes(p)) return 'Please choose a less obvious PIN.'; setFirst(p); setStage('new2'); return true; }} />;
  return <PinPad key="n2" title="Type the new PIN again" onSubmit={async (p) => { if (p !== first) { setStage('new1'); return 'The PINs did not match. Start again.'; } await setPin(p); setStage('ok'); return true; }} />;
}

// "Set in the Family Hub" line for panels that are read-only on his connected laptop
function HubLine({ what }) {
  return <div className="card soft" data-testid="hub-line"><b>☁ {what}</b><div>Set in the Family Hub on the grown-up's laptop.</div><div className="muted small">Approving a reward ticket with the PIN still works here, in the Treasure Wallet.</div></div>;
}
// the tiny "☁ synced" status (nothing when not connected); "sync paused" when his save is too big to sync
function SyncDot() {
  const ref = useRef(null); const [big, setBig] = useState(stateTooBig());
  useEffect(() => { const m = mountStatus(ref.current); const t = setInterval(() => setBig(stateTooBig()), 3000); const h = () => setBig(stateTooBig()); window.addEventListener('familysync:update', h); return () => { clearInterval(t); window.removeEventListener('familysync:update', h); try { m && m.destroy && m.destroy(); } catch (e) {} }; }, []);
  return <span className="syncdot" data-testid="sync-dot"><span ref={ref} style={big ? { display: 'none' } : null} />{big && <span className="fs-paused" data-testid="sync-paused" title="His progress is too big to sync right now. Everything is saved on this laptop.">☁ sync paused</span>}</span>;
}
// Family sync card: connect this laptop with the 6-character code from the Family Hub (behind the PIN)
function FamilySyncCard() {
  const ref = useRef(null);
  useEffect(() => { const m = mountConnect(ref.current, { onConnected: () => {} }); return () => { try { m && m.destroy && m.destroy(); } catch (e) {} }; }, []);
  return <div className="card soft" data-testid="family-sync"><b>☁ Family sync</b><div className="muted small">Set things up once in the Family Hub on the grown-up's laptop; this laptop then gets the PIN, rewards and look, and sends his progress.</div><div ref={ref} style={{ marginTop: 8 }} /></div>;
}
export function ParentCorner({ onClose }) {
  const [tab, setTab] = useState('week');
  return (
    <ParentGate>
      <div className="card" data-testid="parent">
        <div className="row"><h2 className="grow">👪 Parent corner</h2><SyncDot /><button className="btn sm" onClick={onClose} data-testid="parent-close">Close</button></div>
        <div className="tabs" style={{ margin: '8px 0 14px' }}>
          {[['week', '🗓️ This week'], ['report', '📊 Full reports'], ['settings', '⚙️ Settings'], ['voices', '🎙️ Family voices'], ['backup', '💾 Backup'], ['rewards', '🎟️ Rewards'], ['ai', '🤖 AI partner'], ['help', '📱 Install & help']].map(([k, l]) => <button key={k} className={tab === k ? 'sel' : ''} onClick={() => setTab(k)} data-testid={`tab-${k}`}>{l}</button>)}
        </div>
        {tab === 'week' && <WeekCard />}
        {tab === 'report' && <Reports />}
        {tab === 'settings' && <Settings />}
        {tab === 'voices' && <FamilyVoices />}
        {tab === 'backup' && <Backup />}
        {tab === 'ai' && <AISettings />}
        {tab === 'rewards' && (connectedKid() ? <HubLine what="Rewards, costs and the weekly cap" /> : FW ? <ParentWallet /> : <ParentRewards />)}
        {tab === 'help' && <Help />}
      </div>
    </ParentGate>
  );
}

function WeekCard() {
  const { S } = useApp();
  const [clip, setClip] = useState(null);
  useEffect(() => { voiceGet('clip:latest').then(setClip); }, []);
  const wk = Date.now() - 7 * 86400000;
  const rs = (S.reports || []).filter((r) => r.date >= wk);
  const mins = Math.round(rs.reduce((a, r) => a + (r.mins || 0), 0));
  const spoke = rs.reduce((a, r) => a + ((r.speak && r.speak.tries) || 0), 0);
  const goals = [];
  for (const l of ['es', 'fa']) for (const [n, u] of Object.entries(S[l].units)) if (u.done) { const un = getUnits(l)[n - 1]; if (un) goals.push({ at: u.doneAt || 0, l, t: un.ican }); }
  goals.sort((a, b) => b.at - a.at);
  const m = S.fa.mission || S.es.mission;
  return (
    <div className="card soft" data-testid="week-card">
      <h3>This week</h3>
      <div className="plist">
        <div className="prow"><span>⏱️ Minutes of practice</span><b>{mins}</b></div>
        <div className="prow"><span>🗣️ Times spoken out loud</span><b>{spoke}</b></div>
        <div className="prow"><span>🎯 Newest “I can” goals</span><span>{goals.slice(0, 3).map((g, i) => <div key={i} className="small">{g.l === 'es' ? '☀️' : '🌙'} {g.t}</div>)}{!goals.length && <span className="muted small">The first one comes when a boss is beaten.</span>}</span></div>
        <div className="prow"><span>🎙️ Your child's voice</span>{clip ? <button className="btn sm" onClick={() => playRecording(clip.blob)}>▶️ “{clip.text}”</button> : <span className="muted small">A clip appears after he answers out loud.</span>}</div>
        {m && <div className="prow"><span>🍽️ Use at dinner</span><span><b lang={m.say && m.say.f ? 'fa' : 'es'}>{m.say ? (m.say.f || m.say) : ''}</b> <span className="muted small">{m.say && m.say.t ? m.say.t + ' · ' : ''}{m.en}</span></span></div>}
      </div>
      <div className="muted small" style={{ marginTop: 8 }}>Full details are in “Full reports”.</div>
    </div>
  );
}
function Reports() {
  const { S } = useApp();
  const units = { es: getUnits('es'), fa: getUnits('fa') };
  return (
    <div style={{ display: 'grid', gap: 14 }}>
      {['es', 'fa'].map((l) => {
        const L = S[l];
        const intro = Object.keys(L.srs).length;
        const goals = Object.entries(L.units).filter(([, u]) => u.done).map(([n]) => units[l][n - 1] && units[l][n - 1].ican).filter(Boolean);
        const mts = Object.entries(L.mistakes).sort((a, b) => b[1] - a[1]);
        const maxm = Math.max(1, ...mts.map((m) => m[1]));
        return (
          <div key={l} className="card soft" data-testid={`report-${l}`}>
            <h3>{LANG[l].name}{isBonus(S, l) ? ' (Bonus)' : ''} — {L.level ? LEVELS.find((x) => x.id === L.level).name : 'not placed yet'}</h3>
            <div className="plist">
              <div className="prow"><span>Words & phrases met</span><b>{intro}</b></div>
              <div className="prow"><span>Mastered (seen correctly 3+ times, spaced)</span><b>{mastered(L)}</b></div>
              <div className="prow"><span>Quests finished · minutes</span><b>{L.quests} · {Math.round(L.minutes || 0)}</b></div>
              <div className="prow"><span>Speaking attempts (good)</span><b>{L.speak.tries} ({L.speak.good})</b></div>
              {l === 'fa' && <div className="prow"><span>Script lessons finished</span><b>{L.script.step} / 13</b></div>}
            </div>
            <h3 style={{ marginTop: 12 }}>“I can” goals reached</h3>
            {goals.length ? <ul>{goals.map((g, i) => <li key={i}>{g}</li>)}</ul> : <div className="muted">None yet: each boss defeated adds one.</div>}
            <h3>Mistake types</h3>
            {mts.length ? mts.map(([k, v]) => <div key={k} className="row" style={{ marginBottom: 4 }}><span style={{ width: 150 }}>{MT[k] || k}</span><div className="bar grow"><i style={{ width: `${(v / maxm) * 100}%` }} /></div><b>{v}</b></div>) : <div className="muted">No mistakes recorded yet.</div>}
            <h3 style={{ marginTop: 12 }}>Writing samples</h3>
            {(L.writing || []).slice(0, 8).map((w, i) => <div key={i} className="prow small"><span lang={l} className={l === 'fa' ? 'fa' : ''}>{w.text}</span><span className="muted">unit {w.unit} · {w.kind}{w.mts && w.mts.length ? ' · ' + w.mts.map((m) => MT[m]).join(', ') : ''}</span></div>)}
            {!(L.writing || []).length && <div className="muted">No writing yet.</div>}
          </div>
        );
      })}
      <div className="card soft">
        <h3>Session reports</h3>
        {(S.reports || []).slice(0, 15).map((r, i) => (
          <div key={i} className="prow small" data-testid="session-report">
            <span>{new Date(r.date).toLocaleString()} · <b>{LANG[r.lang].name}</b> unit {r.unit}</span>
            <span>{Math.round(r.mins)} min · {r.correct}/{r.total} first-try · {r.newItems} new · 🗣 {r.speak.tries} · ✍️ {r.writing.length}{Object.keys(r.mistakes).length ? ' · ' + Object.entries(r.mistakes).map(([k, v]) => `${MT[k]} ${v}`).join(', ') : ''}{r.boss ? ' · ' + r.boss : ''}</span>
          </div>
        ))}
        {!(S.reports || []).length && <div className="muted">A report appears here after each quest.</div>}
      </div>
    </div>
  );
}

function Settings() {
  const { S, set, refreshAudio } = useApp();
  const st = S.settings;
  const [voices, setVoices] = useState(spanishVoices());
  useEffect(() => { const t = setTimeout(() => setVoices(spanishVoices()), 600); return () => clearTimeout(t); }, []);
  const upd = (k, v) => { set((s) => { s.settings[k] = v; }); refreshAudio && refreshAudio(); };
  const Sel = ({ label, k, opts }) => (
    <label className="prow"><span>{label}</span>
      <select className="field" style={{ width: 'auto' }} value={st[k]} onChange={(e) => upd(k, isNaN(+e.target.value) || e.target.value === '' ? e.target.value : +e.target.value)} data-testid={`set-${k}`}>{opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
  );
  return (
    <div className="plist">
      {['es', 'fa'].map((l) => (
        <label key={l} className="prow"><span>{LANG[l].name} level</span>
          <select className="field" style={{ width: 'auto' }} value={S[l].level || ''} onChange={(e) => set((s) => { s[l].level = e.target.value || null; s[l].placed = !!e.target.value; const lv = LEVELS.find((x) => x.id === e.target.value); if (lv) s[l].diff = lv.diff; })} data-testid={`set-level-${l}`}>
            <option value="">Not placed (run placement)</option>{LEVELS.map((lv) => <option key={lv.id} value={lv.id}>{lv.name} ({lv.grade})</option>)}</select></label>
      ))}
      <Sel label="Daily quest length" k="daily" opts={[[10, '10 minutes'], [15, '15 minutes'], [20, '20 minutes']]} />
      <Sel label="Language of the day" k="mix" opts={[['es', 'Spanish every day + Farsi bonus'], ['alt', 'Alternate days'], ['fa', 'Farsi every day + Spanish bonus'], ['custom', 'Choose per weekday']]} />
      {st.mix === 'custom' && <div className="prow"><span>Week</span><span className="row">{['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d, i) => { const wk = st.week || ['es', 'fa', 'es', 'fa', 'es', 'fa', 'es']; return <button key={d} className="btn sm" onClick={() => set((s) => { const w = (s.settings.week || ['es', 'fa', 'es', 'fa', 'es', 'fa', 'es']).slice(); w[i] = w[i] === 'es' ? 'fa' : 'es'; s.settings.week = w; })}>{d}: {wk[i] === 'es' ? '☀️ ES' : '🌙 FA'}</button>; })}</span></div>}
      <Sel label="Farsi short-vowel marks" k="marks" opts={[['auto', 'On while learning letters, then off'], ['on', 'Always on'], ['off', 'Off']]} />
      <Sel label="Spanish variety" k="variety" opts={[['es-MX', 'Latin America (default)'], ['es-ES', 'Spain']]} />
      <label className="prow"><span>Spanish voice</span>
        <select className="field" style={{ width: 'auto', maxWidth: 260 }} value={st.voiceURI} onChange={(e) => upd('voiceURI', e.target.value)}><option value="">Automatic (best {st.variety})</option>{voices.map((v) => <option key={v.voiceURI} value={v.voiceURI}>{v.name} ({v.lang})</option>)}</select></label>
      <Sel label="Speaking speed" k="rate" opts={[[0.75, 'Slow'], [0.9, 'Calm (default)'], [1, 'Normal']]} />
      <Sel label="Farsi transliteration" k="translit" opts={[['fade', 'Fade out as words are learned'], ['on', 'Always on'], ['off', 'Off']]} />
      <Sel label="Speech recognition" k="sr" opts={[['auto', 'Use when available'], ['off', 'Off (record and self-check)']]} />
      {connectedKid() ? <div className="prow" data-testid="look-hub"><span>Look</span><span className="muted small">Set in the Family Hub on the grown-up's laptop.</span></div> : <Sel label="Look" k="skinSel" opts={[['hyrule', 'Hyrule (Ocarina of Time fan art)'], ['fallback', 'Starlit Grove (original look)']]} />}
      <label className="prow"><span>Music</span><input type="checkbox" checked={!!st.music} onChange={(e) => upd('music', e.target.checked)} /></label>
      <label className="prow"><span>Sound effects</span><input type="checkbox" checked={!!st.sfx} onChange={(e) => upd('sfx', e.target.checked)} /></label>
      <label className="prow"><span>Player nickname</span><input className="field" style={{ width: 200 }} value={S.nick} onChange={(e) => set((s) => { s.nick = e.target.value.slice(0, 20); })} /></label>
      {familyPinSet() ? <div className="prow" data-testid="pin-hub"><span>Parent PIN</span><span className="muted small">The PIN is set in the Family Hub.</span></div> : <div className="prow"><span>Change parent PIN</span><ChangePin /></div>}
      <FamilySyncCard />
    </div>
  );
}
function ChangePin() {
  const [open, setOpen] = useState(false);
  const [v, setV] = useState('');
  const [msg, setMsg] = useState('');
  if (!open) return <button className="btn sm" onClick={() => setOpen(true)}>Change</button>;
  return <span className="row"><input className="field" style={{ width: 110 }} inputMode="numeric" maxLength={4} value={v} onChange={(e) => setV(e.target.value.replace(/\D/g, ''))} placeholder="4 digits" /><button className="btn sm" disabled={v.length !== 4} onClick={async () => { await setPin(v); setMsg('Saved'); setOpen(false); }}>Save</button>{msg}</span>;
}

// The ~300 most-used Farsi lines: Sprout words, phrases of units 1-3, boss questions and answers of units 1-5.
function topLines(S) {
  const out = []; const seen = new Set();
  const add = (x, en) => { if (!x || !x.t || seen.has(x.t)) return; seen.add(x.t); out.push({ t: x.t, tr: x.tr || '', en: en || x.en || '' }); };
  for (let n = 1; n <= 5; n++) unitItems('fa', n).filter((i) => i.kind === 'w').forEach((i) => add(i));
  for (let n = 1; n <= 3; n++) unitItems('fa', n).filter((i) => i.kind === 'p').forEach((i) => add(i));
  for (let n = 1; n <= 5; n++) { const u = getUnit('fa', n); ((u && u.boss && u.boss.lines) || []).forEach((l) => { add(T('fa', l.q)); add(T('fa', l.opts[l.a])); }); }
  return [...(S.recQueue || []).map((t) => ({ t, tr: '', en: '(you marked this clip)' })), ...out].slice(0, 320);
}
function RecordQueue({ onClose }) {
  const { S, set } = useApp();
  const [list, setList] = useState(null);
  const [i, setI] = useState(0);
  const [busy, setBusy] = useState(false);
  const [last, setLast] = useState(null);
  useEffect(() => { (async () => { const all = topLines(S); const todo = []; for (const x of all) { if (!(await voiceGet(voiceKey('fa', x.t)))) todo.push(x); if (todo.length >= 20) break; } setList(todo); })(); }, []);
  if (!list) return <div className="muted">Preparing…</div>;
  if (!list.length || i >= list.length) return <div className="fb good" data-testid="queue-done">✓ Batch done! {list.length} lines recorded. <button className="btn sm" onClick={onClose}>Close</button></div>;
  const x = list[i];
  const rec = async () => {
    setBusy(true);
    try { const blob = await recordAuto(); await voicePut(voiceKey('fa', x.t), { text: x.t, lang: 'fa', mime: blob.type, date: Date.now(), blob }); setLast(blob); set((s) => { s.recQueue = (s.recQueue || []).filter((t) => t !== x.t); }); setI(i + 1); }
    catch (e) { alert('The microphone is not available. See Help.'); }
    setBusy(false);
  };
  return (
    <div className="card soft" data-testid="rec-queue">
      <div className="row"><b className="grow">Recording {i + 1} of {list.length}</b><button className="btn sm ghost" onClick={onClose}>Stop</button></div>
      <div className="center" style={{ margin: '12px 0' }}><div className="fa big" lang="fa">{x.t}</div><div className="tr">{x.tr}</div><div className="muted">{x.en}</div></div>
      <div className="row c"><button className="btn primary" disabled={busy} onClick={rec} data-testid="rec-one">{busy ? '🔴 Recording… (stops when you pause)' : '🎙️ Tap and say it'}</button>
        <button className="btn sm" onClick={() => say('fa', x.t)}>🔈 Computer voice</button>
        {last && <button className="btn sm" onClick={() => playRecording(last)}>▶️ Last</button>}
        {last && i > 0 && <button className="btn sm" onClick={() => setI(i - 1)}>↺ Redo last</button>}
        <button className="btn sm ghost" onClick={() => setI(i + 1)}>Skip</button></div>
    </div>
  );
}
function EarCheck({ onClose }) {
  const { S, set } = useApp();
  const clips = useMemo(() => { const all = []; for (let n = 1; n <= 20; n++) unitItems('fa', n).forEach((it) => { if (faHas(it.say)) all.push(it); }); return all.sort(() => Math.random() - 0.5).slice(0, 30); }, []);
  const [i, setI] = useState(0); const [down, setDown] = useState(0);
  useEffect(() => { if (clips[i]) say('fa', clips[i].say); }, [i]);
  if (i >= clips.length) return <div className="fb good">✓ Ear check done. {down} clips went to your recording queue. <button className="btn sm" onClick={onClose}>Close</button></div>;
  const x = clips[i];
  const vote = (ok) => { if (!ok) { setDown(down + 1); set((s) => { s.recQueue = [x.say, ...(s.recQueue || []).filter((t) => t !== x.say)]; }); } setI(i + 1); };
  return (
    <div className="card soft" data-testid="ear-check">
      <div className="row"><b className="grow">Ear check {i + 1} / {clips.length}</b><button className="btn sm ghost" onClick={onClose}>Stop</button></div>
      <div className="center" style={{ margin: '12px 0' }}><div className="fa big" lang="fa">{x.t}</div><div className="tr">{x.tr}</div><div className="muted">{x.en}</div></div>
      <div className="row c"><button className="btn sm" onClick={() => say('fa', x.say)}>🔈 Again</button><button className="btn" onClick={() => vote(true)}>👍 Sounds right</button><button className="btn" onClick={() => vote(false)} data-testid="thumbs-down">👎 Record it myself</button></div>
    </div>
  );
}
function FamilyVoices() {
  const { S } = useApp();
  const [lang, setLang] = useState('fa');
  const [unit, setUnit] = useState(1);
  const [recs, setRecs] = useState([]);
  const [recording, setRecording] = useState(null);
  const [custom, setCustom] = useState('');
  const [tool, setTool] = useState(null);
  const recRef = useRef(null);
  const reload = async () => setRecs(await voiceAll());
  useEffect(() => { reload(); }, []);
  const items = unitItems(lang, unit, S.settings.variety).slice(0, 60);
  const has = (t) => recs.find((r) => r.key === voiceKey(lang, t));
  const rec = async (text) => {
    if (recording === text) {
      const blob = await recRef.current.stop(); setRecording(null);
      if (blob) { await voicePut(voiceKey(lang, text), { text, lang, mime: blob.type, date: Date.now(), blob }); reload(); }
      return;
    }
    try { recRef.current = await startRecording(); setRecording(text); } catch { alert('The microphone is not available. Check the browser permission.'); }
  };
  return (
    <div data-testid="voices">
      <Navi small>Record your own voice for any word or phrase. Your recording plays instead of the computer voice, and it is saved in backups.</Navi>
      <div className="row" style={{ margin: '10px 0' }}><button className="btn sm primary" onClick={() => setTool('queue')} data-testid="open-queue">🎙️ Record the most-used Farsi lines (20 at a time)</button><button className="btn sm" onClick={() => setTool('ear')} data-testid="open-ear">👂 Ear check (30 clips)</button></div>
      {tool === 'queue' && <RecordQueue onClose={() => { setTool(null); reload(); }} />}
      {tool === 'ear' && <EarCheck onClose={() => setTool(null)} />}
      {!recAvailable() && <div className="fb try">Recording is not supported in this browser.</div>}
      <div className="row" style={{ margin: '10px 0' }}>
        <select className="field" style={{ width: 'auto' }} value={lang} onChange={(e) => setLang(e.target.value)}><option value="fa">Farsi</option><option value="es">Spanish</option></select>
        <select className="field" style={{ width: 'auto' }} value={unit} onChange={(e) => setUnit(+e.target.value)}>{getUnits(lang).map((u, i) => <option key={i} value={i + 1}>{i + 1}. {u ? u.theme : '(coming soon)'}</option>)}</select>
      </div>
      <div className="row" style={{ marginBottom: 10 }}><input className="field grow" style={{ fontSize: '1rem' }} placeholder="Or type any phrase to record" value={custom} onChange={(e) => setCustom(e.target.value)} lang={lang} dir="auto" />{custom && <button className="btn sm" onClick={() => rec(custom)}>{recording === custom ? '⏹ Stop' : '🎙️ Record'}</button>}</div>
      <div className="plist">
        {items.map((it) => (
          <div key={it.id} className="prow">
            <span><span className="emoji">{it.e}</span> <span lang={lang} className={lang === 'fa' ? 'fa' : ''}>{it.t}</span> <span className="muted small">{it.tr ? it.tr + ' · ' : ''}{it.en}</span></span>
            <span className="row">
              {has(it.t) && <button className="btn sm" onClick={() => playRecording(has(it.t).blob)}>▶️</button>}
              {has(it.t) && <button className="btn sm" onClick={async () => { await voiceDel(voiceKey(lang, it.t)); reload(); }}>🗑</button>}
              <button className={`btn sm ${recording === it.t ? 'good' : ''}`} onClick={() => rec(it.t)}>{recording === it.t ? '⏹ Stop' : '🎙️'}</button>
            </span>
          </div>
        ))}
      </div>
      <div className="muted" style={{ marginTop: 10 }}>{recs.length} family recordings saved.</div>
    </div>
  );
}

function Backup() {
  const { S, set, toast } = useApp();
  const [pending, setPending] = useState(null);
  const [err, setErr] = useState('');
  const fileRef = useRef(null);
  const days = S.lastBackup ? Math.floor((Date.now() - S.lastBackup) / 86400000) : null;
  return (
    <div className="plist" data-testid="backup">
      <div className="prow"><span>Last backup</span><b>{days == null ? 'never' : days === 0 ? 'today' : `${days} days ago`}</b></div>
      {(days == null || days >= 7) && <div className="fb try">Reminder: download a backup every week. Browsers (especially Safari) can clear saved data.</div>}
      <button className="btn primary" data-testid="download-backup" onClick={async () => { const b = await makeBackup(); downloadBackup(b); set((s) => { s.lastBackup = Date.now(); }); toast('Backup downloaded', true); }}>⬇️ Download backup</button>
      <button className="btn" onClick={() => fileRef.current.click()} data-testid="import-backup">⬆️ Import a backup…</button>
      <input ref={fileRef} type="file" accept="application/json,.json" style={{ display: 'none' }} data-testid="import-file" onChange={async (e) => {
        const f = e.target.files[0]; if (!f) return; setErr('');
        try { const o = parseBackup(await f.text()); setPending(o); } catch (x) { setErr(x.message || 'Could not read that file.'); }
        e.target.value = '';
      }} />
      {err && <div className="fb try">{err}</div>}
      {pending && (
        <Modal onClose={() => setPending(null)}>
          <h2>Replace progress?</h2>
          <p>This backup is from <b>{new Date(pending.date).toLocaleString()}</b> with {Object.keys(pending.localStorage).length} saved items and {(pending.voices || []).length} family recordings.</p>
          <p>Importing <b>replaces</b> all progress on this device.</p>
          <div className="row"><button className="btn" onClick={() => setPending(null)}>Cancel</button><button className="btn primary" data-testid="confirm-import" onClick={async () => { await restoreBackup(pending); setPending(null); toast('Backup restored', true); setTimeout(() => location.reload(), 600); }}>Yes, import</button></div>
        </Modal>
      )}
    </div>
  );
}

function AISettings() {
  const { S, set } = useApp();
  const [key, setKey] = useState(getAIKey());
  const [msg, setMsg] = useState('');
  const kidSync = connectedKid();
  const st = S.settings;
  // pick the newest available haiku (fast) model for this key and show it
  const test = (k, ok) => { if (!k) { setMsg('Add a key first.'); return; } setMsg('Checking the key…'); detectModel(k).then((m) => { set((s) => { s.settings.aiModel = m; s.settings.aiDetected = true; }); setMsg(`✓ ${ok} Model: ${m}`); }).catch((e) => setMsg('The key check failed: ' + String(e.message || e).slice(0, 120))); };
  return (
    <div className="plist" data-testid="ai-settings">
      <Navi small>Optional: a villager can chat with your child in Spanish or Farsi, using words already learned. Off by default; everything else works without it.</Navi>
      <label className="prow"><span>AI partner</span><input type="checkbox" checked={!!st.aiOn} onChange={(e) => set((s) => { s.settings.aiOn = e.target.checked; })} data-testid="ai-on" /></label>
{!kidSync &&       <label className="prow"><span>Anthropic API key (shared family key)</span><input className="field" type="password" style={{ width: 240, fontSize: '.95rem' }} value={key} onChange={(e) => setKey(e.target.value)} placeholder="sk-ant-…" /></label>}
      {kidSync ? <div className="row"><button className="btn sm" onClick={() => test(getAIKey(), 'Key works.')} data-testid="ai-test">Test key</button><span className="muted small">The key is set in the Family Hub on the grown-up's laptop.</span></div>
        : <div className="row"><button className="btn sm primary" onClick={() => { const k = key.trim(); setAIKey(k); if (k) test(k, 'Key saved.'); else setMsg('Key removed.'); }} data-testid="ai-save">Save key</button><button className="btn sm" onClick={() => test(key.trim() || getAIKey(), 'Key works.')} data-testid="ai-test">Test key</button><button className="btn sm" onClick={() => { setAIKey(''); setKey(''); setMsg('Key removed.'); }}>Remove key</button></div>}
      {msg && <div className={`fb ${/✓/.test(msg) ? 'good' : 'info'} small`} data-testid="ai-msg">{msg}</div>}
      <label className="prow"><span>Daily message cap</span><input className="field" type="number" min="1" max="200" style={{ width: 100 }} value={st.aiCap} onChange={(e) => set((s) => { s.settings.aiCap = Math.max(1, +e.target.value || 20); })} /></label>
      <label className="prow"><span>Model {st.aiDetected ? '(picked automatically)' : ''}</span><input className="field" style={{ width: 220, fontSize: '.95rem' }} value={st.aiModel} onChange={(e) => set((s) => { s.settings.aiModel = e.target.value; s.settings.aiDetected = !!e.target.value; })} data-testid="ai-model" /></label>
      <div className="prow"><span>Usage today</span><b>{S.ai.day === Math.floor(Date.now() / 86400000) ? S.ai.used : 0} / {st.aiCap} messages · {S.ai.tokens} tokens total</b></div>
      <div className="muted small">The key is stored only in this browser (localStorage key familyApps.anthropicKey.v1), is never included in backups, and calls go straight from this device to Anthropic.</div>
    </div>
  );
}

function MicHelp() {
  const [st, setSt] = useState('unknown');
  useEffect(() => { micPermission().then(setSt); }, []);
  return (
    <div className="card soft" data-testid="mic-help"><h3>🎤 Microphone {st === 'granted' ? '✓ allowed' : st === 'denied' ? '— blocked' : ''}</h3>
      {st === 'denied' ? <p>The microphone is blocked, so your child taps answers instead. To fix it in Chrome: click the icon left of the address bar → <b>Site settings</b> → <b>Microphone: Allow</b>, then reload. On iPhone: Settings → Safari → Microphone → Allow.</p>
        : <p>Your child answers by talking (Chrome speech recognition). <button className="btn sm" onClick={async () => { await askMic(); setSt(await micPermission()); }}>Test / allow microphone</button></p>}
    </div>
  );
}
// Diagnostics: problems the page recorded (missing files, script errors). Kids never see these; ?debug=1 shows an overlay.
function Diagnostics() {
  const [, setT] = useState(0);
  const list = (globalThis.__lqDiag || []).slice(-30).reverse();
  const packs = Object.keys(globalThis.__lqPack || {});
  return (
    <div className="card soft" data-testid="diagnostics">
      <div className="row"><b className="grow">🩺 Diagnostics</b><button className="btn sm" onClick={() => setT((t) => t + 1)}>Refresh</button></div>
      {list.length ? <ol className="small" style={{ margin: '6px 0 0', paddingLeft: 18 }}>{list.map((d, i) => <li key={i}><span className="muted">{new Date(d.t).toLocaleTimeString()}</span> {d.m}</li>)}</ol> : <div className="muted small">No problems recorded on this visit.</div>}
      <div className="muted small" style={{ marginTop: 6 }}>Opened from: {location.protocol === 'file:' ? 'a file on this computer' : location.host || 'preview'} · packs loaded: {packs.length ? packs.join(', ') : 'none yet'}</div>
    </div>
  );
}
function Help() {
  const [cov, setCov] = useState(0);
  useEffect(() => { loadFaIndex().then(() => setCov(faCoverage())); }, []);
  return (
    <div className="plist" data-testid="help">
      <Diagnostics />
      <div className="card soft"><h3>📱 iPhone (Safari)</h3><ol><li>Open the app in Safari.</li><li>Tap the Share button (square with an arrow).</li><li>Choose <b>Add to Home Screen</b>, then <b>Add</b>.</li><li>Open it from the new icon. It works offline after the first visit, and installed apps keep their saved data.</li></ol></div>
      <div className="card soft"><h3>💻 Mac (Chrome)</h3><ol><li>Open the app in Chrome.</li><li>Click the install icon at the right end of the address bar (or ⋮ menu → <b>Cast, save and share → Install page as app</b>).</li><li>Click <b>Install</b>. It opens in its own window and works offline.</li></ol></div>
      <MicHelp />
      <div className="card soft"><h3>🔊 Audio</h3><p>Spanish uses the browser's built-in voices (Chrome on Mac: the “Google español de Estados Unidos” voice is best; iPhone: Paulina or Mónica). Farsi uses pre-made recordings ({cov} clips loaded) because Macs and iPhones have no Farsi voice. Family recordings always play first.</p><p>Speaking practice uses Chrome's speech recognition when available; otherwise the app records and lets your child compare with the model.</p></div>
      <div className="card soft"><h3>🎨 Credits</h3><p>Fan art inspired by The Legend of Zelda: Ocarina of Time. Not affiliated with or endorsed by Nintendo. Art, music and the ocarina come from the team's Hyrule kit; all music is original. Fonts: Nunito, Cinzel, Vazirmatn (SIL Open Font License). Farsi voice: Piper fa_IR "ganji".</p></div>
      <div className="card soft"><h3>🔒 Privacy</h3><p>All progress stays on this device (browser storage). Nothing is sent anywhere, except AI partner messages if you turn that on.</p></div>
    </div>
  );
}
