// Unit tests: chunking (Code.gs on gas-shim), protocol rules, merge rules, crypto, and family-sync between two devices.
// Run: node tests/unit.mjs      (Node 20+, no dependencies)
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const here = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const ROOT = path.join(here, '..');
const { loadCodeGs, sha256, utf8Bytes } = require(path.join(ROOT, 'server', 'gas-shim.js'));
const CODE = fs.readFileSync(path.join(ROOT, 'server', 'Code.gs'), 'utf8');
const FSmod = require(path.join(ROOT, 'family-sync.js'));
const FWpath = path.join(ROOT, 'vendor', 'family-wallet.js');

let pass = 0, fail = 0;
const results = [];
async function test(name, fn) {
  try { await fn(); pass++; results.push('ok   ' + name); }
  catch (e) { fail++; results.push('FAIL ' + name + '\n     ' + (e && e.stack ? e.stack.split('\n').slice(0, 3).join('\n     ') : e)); }
}
function eq(a, b, msg) { const A = JSON.stringify(a), B = JSON.stringify(b); if (A !== B) throw new Error((msg || 'not equal') + ': ' + A.slice(0, 300) + ' !== ' + B.slice(0, 300)); }
function ok(v, msg) { if (!v) throw new Error(msg || 'expected truthy'); }

function memStore() {
  const m = new Map();
  const s = { writes: 0, getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => { s.writes++; m.set(k, String(v)); }, removeItem: (k) => { s.writes++; m.delete(k); }, key: (i) => [...m.keys()][i] ?? null, get length() { return m.size; }, map: m };
  return s;
}
function backend(opts) {
  const app = loadCodeGs(CODE, opts);
  const calls = [];
  const transport = (endpoint, body) => { calls.push(body.op); return Promise.resolve(app.handle(JSON.parse(JSON.stringify(body)))); };
  return { app, transport, calls };
}
function device(be, extra) {
  const store = memStore();
  const fs = FSmod.__new();
  fs.configure({ storage: store, transport: be.transport, locks: null, win: null, channel: null, wallet: null, online: () => true, visible: () => true, ...(extra || {}) });
  return { fs, store };
}
function freshWallet(store) {
  delete require.cache[require.resolve(FWpath)];
  const FW = require(FWpath);
  FW.configure({ storage: store, resetMemory: true });
  return FW;
}
const ENDPOINT = 'http://127.0.0.1:9/exec';
const AKFY = 'https://script.google.com/macros/s/AKfycbTESTdeploymentIdForUnitTests0123456789/exec';

// ---------------- crypto + hashing ----------------
await test('gas-shim SHA-256 matches node:crypto (ascii, unicode, long)', () => {
  for (const s of ['', 'abc', 'salt:token', 'فارسی 🐾 ñ', 'x'.repeat(100000)]) {
    const mine = Buffer.from(sha256(utf8Bytes(s))).toString('hex');
    eq(mine, crypto.createHash('sha256').update(s, 'utf8').digest('hex'), s.slice(0, 10));
  }
});
await test('HKDF auth token is deterministic per secret and differs between secrets', async () => {
  const t = FSmod._t;
  const s1 = t.b64u(crypto.randomBytes(16)), s2 = t.b64u(crypto.randomBytes(16));
  const a1 = (await t.familyKeys(s1)).auth, a1b = (await FSmod.__new()._t.familyKeys(s1)).auth, a2 = (await t.familyKeys(s2)).auth;
  eq(a1, a1b); ok(a1 !== a2); ok(/^[A-Za-z0-9_-]{43}$/.test(a1)); ok(a1 !== s1);
});
await test('AES-GCM round trip; tamper, wrong secret and wrong key name all fail', async () => {
  const t = FSmod._t;
  const s = t.b64u(crypto.randomBytes(16)), s2 = t.b64u(crypto.randomBytes(16));
  const plain = 'sk-ant-api03-EXAMPLE-not-a-real-key';
  const c = await t.aesEncrypt(s, 'famX', 'familyApps.anthropicKey.v1', plain);
  ok(/^fsenc1:/.test(c) && c.indexOf('EXAMPLE') < 0, 'ciphertext must not contain the key');
  eq(await t.aesDecrypt(s, 'famX', 'familyApps.anthropicKey.v1', c), plain);
  const c2 = await t.aesEncrypt(s, 'famX', 'familyApps.anthropicKey.v1', plain); ok(c !== c2, 'fresh IV each time');
  const bad = c.slice(0, -3) + (c.slice(-3) === 'AAA' ? 'BBB' : 'AAA');
  for (const [sec, fam, key, val] of [[s, 'famX', 'familyApps.anthropicKey.v1', bad], [s2, 'famX', 'familyApps.anthropicKey.v1', c], [s, 'famX', 'familyApps.other.v1', c], [s, 'famY', 'familyApps.anthropicKey.v1', c]]) {
    let threw = false; try { await t.aesDecrypt(sec, fam, key, val); } catch { threw = true; } ok(threw, 'should fail');
  }
});
await test('family PIN: salted PBKDF2 record, right PIN passes, wrong fails, salt differs', async () => {
  const { fs } = device(backend());
  const r1 = await fs.makePinRecord('2580'), r2 = await fs.makePinRecord('2580');
  ok(r1.salt !== r2.salt && r1.hash !== r2.hash); ok(JSON.stringify(r1).indexOf('2580') < 0, 'no plain PIN in the record');
  let threw = false; try { await fs.makePinRecord('12a4'); } catch { threw = true; } ok(threw);
});

// ---------------- chunking + Sheet rules (real Code.gs) ----------------
await test('chunking: values split into <=45,000-char cells and join back exactly', () => {
  const { app } = backend();
  for (const n of [0, 1, 44999, 45000, 45001, 90000, 135001, 299999, 300000]) {
    const v = 'é'.repeat(Math.min(n, 3)) + 'x'.repeat(Math.max(0, n - 3));
    const parts = app._splitValue(v);
    ok(parts.every((p) => p.length <= 45001), 'cell too big');
    ok(parts.length === Math.max(1, Math.ceil(n / 45000)), 'parts ' + n);
    const row = ['k', '', 1, '', '', n, 'kid', parts.length].concat(parts, Array(8 - parts.length).fill(''));
    eq(app._joinValue(row), v, 'join ' + n);
  }
  eq(app._joinValue(['k', '', 1, '', '', 0, 'kid', 0, '', '', '', '', '', '', '', '']), null, 'deleted');
});
await test('protocol round-trip keeps tricky values exact (numbers, TRUE, formulas, dates, Farsi, emoji, 300 KB)', async () => {
  const be = backend();
  const { fs } = device(be);
  await fs.createFamily({ endpoint: ENDPOINT });
  const vals = { 'familyApps.look.v1': '12345', 'familyApps.rewards.v1': 'TRUE', 'familyApps.pin.v1': '=SUM(A1:A9)', 'familyApps.walletAdjust.v1': '2026-11-27', 'familyApps.ticketApprovals.v1': 'سلام 🐾 ' + 'ب'.repeat(1000), 'musicQuest.myLessons.v1': 'y'.repeat(300000) };
  for (const [k, v] of Object.entries(vals)) ok(fs.setSetting(k, v), 'setSetting ' + k);
  await fs.syncNow();
  const res = be.app.handle({ v: 1, op: 'get', familyId: fs.config().familyId, auth: 'A'.repeat(43) });
  ok(!res.ok && res.error === 'auth', 'a made-up auth is refused');
  // read back through the real protocol with the right auth
  const st = JSON.parse(be.app.shim.props.FAMILY);
  ok(st.hash && st.salt && !st.secret, 'only a salted hash is stored');
  const rows = be.app.shim.sheetRows('data').slice(1);
  for (const r of rows) for (const c of r.slice(8)) ok(typeof c === 'string' && c.length <= 45001, 'cell <= 45,001');
  ok(be.app.shim.stats.coerced === 0, 'no Sheets coercion happened');
  const back = {};
  for (const r of rows) back[r[0]] = be.app._joinValue(r);
  for (const [k, v] of Object.entries(vals)) eq(back[k], v, k);
  const big = rows.find((r) => r[0] === 'musicQuest.myLessons.v1');
  eq(big[1], 'music'); eq(Number(big[7]), 7); eq(Number(big[5]), 300000);
});
await test('a value over 300,000 characters is refused (too-large), others still saved', async () => {
  const be = backend();
  const { fs, store } = device(be);
  await fs.createFamily({ endpoint: ENDPOINT });
  fs.setSetting('familyApps.look.v1', JSON.stringify({ v: 1, skin: 'grove' }));
  store.setItem('musicQuest.myLessons.v1', 'z'.repeat(300001));
  await fs.syncNow();
  const keys = be.app.shim.sheetRows('data').slice(1).map((r) => r[0]);
  ok(keys.includes('familyApps.look.v1')); ok(!keys.includes('musicQuest.myLessons.v1'));
  ok(fs.status().tooBig.includes('musicQuest.myLessons.v1'), 'status reports the too-big key');
});

// ---------------- protocol rules ----------------
await test('create once; second create is refused; wrong secret refused on every op', async () => {
  const be = backend();
  const g = device(be);
  await g.fs.createFamily({ endpoint: ENDPOINT });
  const other = device(be);
  let e1; try { await other.fs.createFamily({ endpoint: ENDPOINT }); } catch (e) { e1 = e; }
  eq(e1 && e1.code, 'exists');
  const link = g.fs.joinLink('https://example.test/family/');
  const j = FSmod.parseJoin(link);
  const badSecret = (j.secret[0] === 'A' ? 'B' : 'A') + j.secret.slice(1);
  const k = device(be);
  let e2; try { await k.fs.connect({ ...j, secret: badSecret }); } catch (e) { e2 = e; }
  eq(e2 && e2.code, 'auth'); ok(!k.fs.isConnected(), 'nothing saved'); eq(k.store.map.has('familyApps.sync.v1'), false);
});
await test('get filters: keys, sinceRev, writer role; unchanged put keeps its rev', async () => {
  const be = backend();
  const g = device(be);
  await g.fs.createFamily({ endpoint: ENDPOINT });
  g.fs.setSetting('familyApps.look.v1', '{"v":1,"skin":"hyrule"}');
  await g.fs.syncNow();
  const c = JSON.parse(g.store.getItem('familyApps.sync.v1'));
  const auth = (await FSmod._t.familyKeys(c.secret)).auth;
  const base = { v: 1, familyId: c.familyId, auth, device: { id: c.deviceId, role: 'grownup' } };
  const r1 = be.app.handle({ ...base, op: 'put', items: [{ key: 'familyApps.rewards.v1', value: '{"a":1}' }] });
  const r2 = be.app.handle({ ...base, op: 'put', items: [{ key: 'familyApps.rewards.v1', value: '{"a":1}' }] });
  eq(r2.revs['familyApps.rewards.v1'], r1.revs['familyApps.rewards.v1'], 'same value, same rev');
  const all = be.app.handle({ ...base, op: 'get' });
  eq(all.items.length, 2);
  eq(be.app.handle({ ...base, op: 'get', keys: ['familyApps.look.v1'] }).items.map((i) => i.key), ['familyApps.look.v1']);
  eq(be.app.handle({ ...base, op: 'get', sinceRev: r1.rev - 1 }).items.map((i) => i.key), ['familyApps.rewards.v1']);
  eq(be.app.handle({ ...base, op: 'get', role: 'kid' }).items.length, 0);
  const kidPut = be.app.handle({ ...base, device: { id: 'd-kid1', role: 'kid' }, op: 'put', items: [{ key: 'familyApps.look.v1', value: 'x' }] });
  eq(kidPut.refused['familyApps.look.v1'], 'wrong-role', 'a kid device can never overwrite a grown-up key');
});
await test('one kid writer: a second kid device is refused until it claims', async () => {
  const be = backend();
  const g = device(be);
  await g.fs.createFamily({ endpoint: ENDPOINT });
  const c = JSON.parse(g.store.getItem('familyApps.sync.v1'));
  const auth = (await FSmod._t.familyKeys(c.secret)).auth;
  const base = { v: 1, familyId: c.familyId, auth, op: 'put' };
  ok(be.app.handle({ ...base, device: { id: 'd-kidA', role: 'kid' }, items: [{ key: 'familyApps.wallet.v1', value: '1' }] }).ok);
  eq(be.app.handle({ ...base, device: { id: 'd-kidB', role: 'kid' }, items: [{ key: 'familyApps.wallet.v1', value: '2' }] }).error, 'not-writer');
  ok(be.app.handle({ ...base, device: { id: 'd-kidB', role: 'kid' }, claim: true, items: [{ key: 'familyApps.wallet.v1', value: '2' }] }).ok);
  eq(be.app.handle({ ...base, device: { id: 'd-kidA', role: 'kid' }, items: [{ key: 'familyApps.wallet.v1', value: '3' }] }).error, 'not-writer');
});
await test('pairing: 6-character code, one use, expires after 10 minutes, tries are limited', async () => {
  let clock = Date.now();
  const be = backend({ now: () => clock });
  const g = device(be);
  await g.fs.createFamily({ endpoint: ENDPOINT });
  const p = await g.fs.pairCreate();
  ok(/^[A-HJ-NP-Z2-9]{6}$/.test(p.code), 'code ' + p.code);
  const r = be.app.handle({ v: 1, op: 'pairRedeem', code: p.code.toLowerCase() });
  ok(r.ok && r.familyId === g.fs.config().familyId && /^[A-Za-z0-9_-]{22}$/.test(r.secret));
  eq(be.app.handle({ v: 1, op: 'pairRedeem', code: p.code }).error, 'not-found', 'one use');
  const p2 = await g.fs.pairCreate();
  clock += 601000;
  eq(be.app.handle({ v: 1, op: 'pairRedeem', code: p2.code }).error, 'not-found', 'expired');
  let limited = false;
  for (let i = 0; i < 12; i++) if (be.app.handle({ v: 1, op: 'pairRedeem', code: 'ZZZZZZ' }).error === 'rate-limited') limited = true;
  ok(limited, 'rate limited');
});
await test('auth failures are rate limited', async () => {
  const be = backend();
  const g = device(be);
  await g.fs.createFamily({ endpoint: ENDPOINT });
  const fid = g.fs.config().familyId;
  let last;
  for (let i = 0; i < 25; i++) last = be.app.handle({ v: 1, op: 'get', familyId: fid, auth: 'x'.repeat(43) });
  eq(last.error, 'rate-limited');
});

// ---------------- merge rules ----------------
await test('merge rules: cloud empty -> local; local empty -> cloud; same -> same; more progress wins', () => {
  const t = FSmod._t;
  const W = (shards, rupees) => JSON.stringify({ totals: { math: { earned: shards, spent: 0 }, rupees: { earned: rupees, spent: 0 } } });
  const keys = ['familyApps.wallet.v1', 'familyApps.tickets.v1'];
  eq(t.decideMerge('family', keys, { 'familyApps.wallet.v1': W(3, 10) }, {}).use, 'local');
  eq(t.decideMerge('family', keys, {}, { 'familyApps.wallet.v1': W(3, 10) }).use, 'cloud');
  eq(t.decideMerge('family', keys, { 'familyApps.wallet.v1': W(3, 10) }, { 'familyApps.wallet.v1': W(3, 10) }).use, 'same');
  eq(t.decideMerge('family', keys, { 'familyApps.wallet.v1': W(9, 10) }, { 'familyApps.wallet.v1': W(3, 50) }).use, 'local', '9 shards beat 3 shards + 40 rupees');
  eq(t.decideMerge('family', keys, { 'familyApps.wallet.v1': W(1, 0) }, { 'familyApps.wallet.v1': W(2, 0), 'familyApps.tickets.v1': '[]' }).use, 'cloud');
  eq(t.decideMerge('math', ['mathArena.v3.data.v1'], { 'mathArena.v3.data.v1': '{"a":1}' }, { 'mathArena.v3.data.v1': '{"a":1,"b":[1,2,3]}' }).use, 'cloud', 'default: more data wins');
  eq(t.decideMerge('x', ['k'], {}, {}).use, 'none');
});
await test('keepLocal: school sync "done" marks stay on his laptop; drift hash ignores them', () => {
  const t = FSmod._t;
  const remote = JSON.stringify({ v: 1, programs: [{ id: 'p1' }], weeks: [] });
  const local = JSON.stringify({ v: 1, programs: [], weeks: [], done: { 'b-0': { doneAt: 5 } } });
  eq(JSON.parse(t.keepLocalMerge(remote, local, ['done'])), { v: 1, programs: [{ id: 'p1' }], weeks: [], done: { 'b-0': { doneAt: 5 } } });
  eq(JSON.parse(t.keepLocalMerge(remote, null, ['done'])), JSON.parse(remote));
  const rule = { keepLocal: ['done'] };
  eq(t.stripLocal(t.keepLocalMerge(remote, local, ['done']), rule), remote);
});

// ---------------- family-sync between two devices ----------------
async function family() {
  const be = backend();
  const g = device(be);
  await g.fs.createFamily({ endpoint: ENDPOINT });
  return { be, g };
}
await test('not connected: start() makes no network calls and writes nothing', async () => {
  const be = backend();
  const d = device(be);
  d.store.setItem('mathArena.v3.data.v1', '{"x":1}'); d.store.writes = 0;
  d.fs.start({ app: 'math' });
  ok(d.fs.writeSummary('math', { week: { lessons: 1 } }) === false);
  await d.fs.applyParentRequests();
  await d.fs.syncNow();
  eq(d.store.writes, 0, 'writes'); eq(be.calls.length, 0, 'network'); eq(d.fs.status().state, 'off');
  d.fs.stop();
});
await test('Hub setup -> kid joins -> settings + decrypted AI key land; ciphertext only in the Sheet', async () => {
  const { be, g } = await family();
  const pin = await g.fs.setPin('1357');
  g.fs.setSetting('familyApps.rewards.v1', { version: 1, enabled: true, tokensPerTicket: 3, weeklyCap: 4, rewards: [{ id: 'pet', emoji: '🐾', text: 'Walk with the dog' }], wallet: { appsInSet: ['math', 'music'], costs: { pet: 2 } } });
  g.fs.setSetting('familyApps.look.v1', { v: 1, skin: 'grove' });
  g.fs.setSetting('familyApps.anthropicKey.v1', 'sk-ant-test-123');
  g.fs.setSetting('mathArena.v3.schoolSync.v1', { v: 1, programs: [{ id: 'p', label: 'Class', day: 'Sat', time: '9:00' }], weeks: [], books: [], focus: [], methods: [], importedAt: 1 });
  await g.fs.syncNow();
  const rows = be.app.shim.sheetRows('data').slice(1);
  const keyRow = rows.find((r) => r[0] === 'familyApps.anthropicKey.v1');
  ok(keyRow && String(keyRow[8]).indexOf('sk-ant') < 0 && /^~fsenc1:/.test(keyRow[8]), 'encrypted at rest');
  const kid = device(be);
  const FW = freshWallet(kid.store);
  kid.fs.configure({ wallet: FW });
  kid.store.setItem('mathArena.v3.schoolSync.v1', JSON.stringify({ v: 1, programs: [], done: { 'x-0': { doneAt: 1 } } }));
  const rep = await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  eq(kid.fs.role(), 'kid');
  eq(kid.store.getItem('familyApps.anthropicKey.v1'), 'sk-ant-test-123', 'plain string for the apps');
  eq(JSON.parse(kid.store.getItem('familyApps.look.v1')).skin, 'grove'); eq(kid.store.getItem('hyruleKit.skin'), 'grove');
  ok(kid.fs.pinIsSet() && (await kid.fs.checkPin('1357')) && !(await kid.fs.checkPin('0000')), 'family PIN works on his laptop');
  eq(JSON.parse(kid.store.getItem('mathArena.v3.schoolSync.v1')).done, { 'x-0': { doneAt: 1 } }, 'done marks kept');
  eq(FW.settings().appsInSet, ['math', 'music'], 'wallet settings applied through FamilyWallet');
  eq(FW.settings().costs, { pet: 2 });
  ok(rep.settings.includes('familyApps.pin.v1')); void pin;
});
await test('kid progress reaches the grown-up mirror; summary written only on the kid device', async () => {
  const { be, g } = await family();
  const kid = device(be);
  const FW = freshWallet(kid.store);
  kid.fs.configure({ wallet: FW });
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  FW.finishUnit('math', 'lesson'); FW.beatBoss('music', 'boss');
  ok(kid.fs.writeSummary('math', { week: { lessons: 3, mastered: 2, readAccuracy: 87.5 }, total: { mastered: 9 } }));
  ok(!g.fs.writeSummary('math', { week: { lessons: 1 } }), 'grown-up never writes a summary');
  await kid.fs.syncNow();
  await g.fs.syncNow();
  const m = g.fs.mirror();
  eq(m.items['familyApps.wallet.v1'].value.totals.math.earned, 2);
  eq(m.items['familyApps.summary.math.v1'].value.week.readAccuracy, 87.5);
  ok(m.devices.some((d) => d.role === 'kid' && d.kidWriter), 'device list shows his laptop');
  ok(!g.store.getItem('familyApps.wallet.v1'), 'his wallet is not written into the grown-up practice copy');
});
await test('approval + adjust are applied exactly once (repeat calls, a second device instance, re-pull)', async () => {
  const { be, g } = await family();
  const kid = device(be);
  const FW = freshWallet(kid.store);
  kid.fs.configure({ wallet: FW });
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  for (let i = 0; i < 4; i++) FW.finishUnit('math', 'l' + i);
  for (const a of ['language', 'code', 'music']) for (let i = 0; i < 2; i++) FW.finishUnit(a, 'l' + i);
  const claim = FW.claim('youtube', 'math');
  ok(claim && claim.ok !== false, 'claimed a ticket');
  const ticket = FW.tickets()[0];
  await kid.fs.syncNow(); await g.fs.syncNow();
  const tk = g.fs.mirror().items['familyApps.tickets.v1'].value;
  eq(tk[0].status, 'earned');
  const before = FW.balance().math;
  g.fs.request('approve', { ticketId: ticket.id });
  g.fs.request('adjust', { app: 'math', amount: 2, reason: 'Great week' });
  g.fs.request('adjust', { app: 'rupees', amount: 25, reason: 'Helped at home' });
  await g.fs.syncNow();
  await kid.fs.syncNow();
  await kid.fs.applyParentRequests(); await kid.fs.applyParentRequests();
  const twin = FSmod.__new(); twin.configure({ storage: kid.store, transport: be.transport, locks: null, win: null, channel: null, wallet: FW, online: () => true, visible: () => true });
  await twin.applyParentRequests(); await twin.syncNow(); await kid.fs.syncNow();
  eq(FW.balance().math, before + 2, 'adjust once');
  eq(FW.events({ limit: 100 }).filter((e) => e.kind === 'rupee' && e.reason === 'Helped at home').length, 1, 'rupees once');
  eq(FW.tickets().find((t) => t.id === ticket.id).status, 'used');
  await g.fs.syncNow();
  const done = g.fs.mirror().items['familyApps.requestsDone.v1'].value.done;
  eq(Object.keys(done).length, 3); ok(Object.values(done).every((d) => d.ok));
});
await test('first connect: cloud empty -> uploads his local progress', async () => {
  const { be, g } = await family();
  const kid = device(be);
  const FW = freshWallet(kid.store);
  FW.finishUnit('code', 'x');
  kid.store.setItem('codeQuest.progress.v1', '{"lessons":5}');
  kid.fs.configure({ wallet: FW });
  const rep = await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  ok(rep.uploaded.includes('family') && rep.uploaded.includes('code'));
  const keys = be.app.shim.sheetRows('data').slice(1).map((r) => r[0]);
  ok(keys.includes('familyApps.wallet.v1') && keys.includes('codeQuest.progress.v1'));
});
await test('first connect: both exist -> more progress wins, the other is kept in the backup key', async () => {
  const { be, g } = await family();
  const k1 = device(be);
  const FW1 = freshWallet(k1.store);
  for (let i = 0; i < 5; i++) FW1.finishUnit('math', 'a' + i);
  k1.store.setItem('mathArena.v3.data.v1', JSON.stringify({ progress: { solved: Array(50).fill(1) } }));
  k1.fs.configure({ wallet: FW1 });
  await k1.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  // his laptop again, after a browser reset: a little local progress, the cloud has more
  const k2 = device(be);
  const FW2 = freshWallet(k2.store);
  FW2.finishUnit('math', 'only-one');
  k2.store.setItem('mathArena.v3.data.v1', JSON.stringify({ progress: { solved: [1] } }));
  k2.fs.configure({ wallet: FW2 });
  const rep = await k2.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  ok(rep.downloaded.includes('family') && rep.downloaded.includes('math'), JSON.stringify(rep));
  eq(JSON.parse(k2.store.getItem('familyApps.wallet.v1')).totals.math.earned, 10);
  const bk = JSON.parse(k2.store.getItem('familyApps.sync.backup.v1'));
  ok(bk.entries.some((e) => e.group === 'family' && e.side === 'local' && JSON.parse(e.items['familyApps.wallet.v1']).totals.math.earned === 2));
  // a third time, with MORE local progress than the cloud: local wins and the cloud copy is backed up
  const k3 = device(be);
  const FW3 = freshWallet(k3.store);
  for (let i = 0; i < 9; i++) FW3.finishUnit('math', 'b' + i);
  k3.fs.configure({ wallet: FW3 });
  const rep3 = await k3.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  ok(rep3.uploaded.includes('family'));
  await g.fs.syncNow();
  eq(g.fs.mirror().items['familyApps.wallet.v1'].value.totals.math.earned, 18);
  ok(JSON.parse(k3.store.getItem('familyApps.sync.backup.v1')).entries.some((e) => e.side === 'cloud'));
});
await test('single writer: a kid device never pushes settings, a grown-up never pushes progress', async () => {
  const { be, g } = await family();
  const kid = device(be);
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  kid.store.setItem('familyApps.look.v1', '{"v":1,"skin":"grove"}');
  g.store.setItem('familyApps.wallet.v1', '{"totals":{}}');
  await kid.fs.syncNow(); await g.fs.syncNow();
  const rows = be.app.shim.sheetRows('data').slice(1);
  ok(!rows.some((r) => r[0] === 'familyApps.look.v1'), 'kid did not push a setting');
  ok(!rows.some((r) => r[0] === 'familyApps.wallet.v1'), 'grown-up did not push progress');
});
await test('drift repair: a local edit of a family setting on his laptop is put back on the next start', async () => {
  const { be, g } = await family();
  g.fs.setSetting('familyApps.look.v1', { v: 1, skin: 'hyrule' });
  await g.fs.syncNow();
  const kid = device(be);
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  kid.store.setItem('familyApps.look.v1', '{"v":1,"skin":"grove"}');
  const again = FSmod.__new(); again.configure({ storage: kid.store, transport: be.transport, locks: null, win: null, channel: null, wallet: null, online: () => true, visible: () => true });
  await again._t.cycle({ first: true });
  eq(JSON.parse(kid.store.getItem('familyApps.look.v1')).skin, 'hyrule');
});
await test('offline: changes queue up and go out when the backend is back (backoff, no loss)', async () => {
  const { be, g } = await family();
  let down = false;
  const flaky = (e, b) => (down ? Promise.reject(Object.assign(new Error('net'), { code: 'network' })) : be.transport(e, b));
  const kid = device(be, { transport: flaky });
  const FW = freshWallet(kid.store);
  kid.fs.configure({ wallet: FW });
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  down = true;
  FW.finishUnit('language', 'offline lesson');
  await kid.fs.syncNow();
  eq(kid.fs.status().state, 'offline'); ok(kid.fs.status().pending > 0);
  down = false;
  await kid.fs.syncNow();
  eq(kid.fs.status().pending, 0);
  await g.fs.syncNow();
  eq(g.fs.mirror().items['familyApps.wallet.v1'].value.totals.language.earned, 2);
});
await test('Apps Script URL: family id = deployment id; the join link has just id.secret', async () => {
  const be = backend();
  const g = device(be);
  await g.fs.createFamily({ endpoint: AKFY });
  const link = g.fs.joinLink('https://sina2jp.github.io/family/');
  ok(/^https:\/\/sina2jp\.github\.io\/family\/#join=AKfycbTEST[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{22}$/.test(link), link);
  eq(FSmod.parseJoin(link).endpoint, AKFY);
  ok(link.length < 120, 'short enough for a QR code: ' + link.length);
});
await test('lease fallback (no navigator.locks) serialises two tabs; requests still applied once', async () => {
  const { be, g } = await family();
  const kid = device(be);
  const FW = freshWallet(kid.store);
  kid.fs.configure({ wallet: FW });
  await kid.fs.connect(FSmod.parseJoin(g.fs.joinLink()));
  FW.finishUnit('math', 'x');
  g.fs.request('adjust', { app: 'math', amount: 3, reason: 'Bonus' });
  await g.fs.syncNow();
  const tab2 = FSmod.__new(); tab2.configure({ storage: kid.store, transport: be.transport, locks: null, win: null, channel: null, wallet: FW, online: () => true, visible: () => true });
  await Promise.all([kid.fs.syncNow(), tab2.syncNow()]);
  await Promise.all([kid.fs.applyParentRequests(), tab2.applyParentRequests()]);
  eq(FW.events({ limit: 50 }).filter((e) => e.kind === 'adjust').length, 1);
});

console.log(results.join('\n'));
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
