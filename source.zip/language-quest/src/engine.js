// Learning engine: normalization, similarity, mistake typing, spaced repetition, adaptivity, quest plans.
import { today } from './store.js';

export const MT = {
  gender: 'Gender (el / la)', verb: 'Verb ending', order: 'Word order', spelling: 'Spelling / accent',
  word: 'Wrong word', listening: 'Listening', pron: 'Pronunciation',
};

// ---------- text ----------
export const stripAcc = (s) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
export const normEs = (s) => (s || '').toLowerCase().replace(/[¿¡!?.,;:"“”«»()…—–\-']/g, ' ').replace(/\s+/g, ' ').trim();
export const normFa = (s) => (s || '').replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/[\u064B-\u0652\u0670\u0640]/g, '')
  .replace(/\u200c/g, '').replace(/[؟?!.,،؛:"«»()…\-]/g, ' ').replace(/[ۀ]/g, 'ه').replace(/\s+/g, ' ').trim();
export const normTr = (s) => stripAcc((s || '').toLowerCase()).replace(/[^a-z' ]/g, ' ').replace(/'/g, '').replace(/\s+/g, ' ').trim();
export const isFaScript = (s) => /[\u0600-\u06FF]/.test(s || '');
export function lev(a, b) {
  if (a === b) return 0; if (!a.length) return b.length; if (!b.length) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i];
    for (let j = 1; j <= b.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    prev = cur;
  }
  return prev[b.length];
}
export const sim = (a, b) => { const m = Math.max(a.length, b.length); return m ? 1 - lev(a, b) / m : 1; };
export function shuffle(a, seed) {
  const r = a.slice(); let s = seed || Math.floor(Math.random() * 1e9);
  const rnd = () => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff; };
  for (let i = r.length - 1; i > 0; i--) { const j = Math.floor((seed ? rnd() : Math.random()) * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; }
  return r;
}
export const pick = (a, n) => shuffle(a).slice(0, n);
export function fnv(s) {
  const b = new TextEncoder().encode(s.trim().replace(/\s+/g, ' '));
  let h = 0x811c9dc5;
  for (const x of b) { h ^= x; h = Math.imul(h, 0x01000193) >>> 0; }
  return 'f' + h.toString(36);
}

// ---------- mistake typing (never reveals the answer; points to the part to check) ----------
const ARTS = ['el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas'];
export function classifyEs(exp, got) {
  const a = normEs(exp), b = normEs(got);
  if (a === b) return null;
  if (stripAcc(a) === stripAcc(b)) {
    const A = a.split(' '), B = b.split(' ');
    const i = A.findIndex((w, k) => w !== B[k]);
    return { mt: 'spelling', i, msg: 'Almost! Check the accent marks.' };
  }
  const A = a.split(' '), B = b.split(' ');
  if (A.length === B.length && A.slice().sort().join(' ') === B.slice().sort().join(' ')) return { mt: 'order', i: A.findIndex((w, k) => w !== B[k]), msg: 'All the right words! Check the order.' };
  if (A.length === B.length) {
    const d = A.map((w, i) => [w, B[i], i]).filter(([x, y]) => x !== y);
    if (d.length === 1) {
      const [x, y, i] = d[0];
      if (ARTS.includes(x) && ARTS.includes(y)) return { mt: 'gender', i, msg: 'Check the little word before the noun: is the noun masculine or feminine?' };
      if (stripAcc(x) === stripAcc(y)) return { mt: 'spelling', i, msg: 'Check the accent marks in this word.' };
      if (x.slice(0, 3) === y.slice(0, 3) && Math.abs(x.length - y.length) <= 3) {
        if (/[oa]s?$/.test(x) && /[oa]s?$/.test(y) && x.replace(/[oa](s?)$/, '$1') === y.replace(/[oa](s?)$/, '$1')) return { mt: 'gender', i, msg: 'Check the ending: does it match a masculine or feminine noun?' };
        return { mt: 'verb', i, msg: 'Check the ending of this word: who is doing it?' };
      }
      if (lev(x, y) <= 2) return { mt: 'spelling', i, msg: 'Check the spelling of this word.' };
      return { mt: 'word', i, msg: 'Check this word: is it the one you need?' };
    }
  }
  if (sim(stripAcc(a), stripAcc(b)) > 0.82) return { mt: 'spelling', i: -1, msg: 'Very close! Check your spelling.' };
  return { mt: 'word', i: -1, msg: 'Check the words you used. Listen to the example again.' };
}
export function classifyFa(exp, got, expTr) {
  const script = isFaScript(got);
  const a = script ? normFa(exp) : normTr(expTr || ''), b = script ? normFa(got) : normTr(got);
  if (a === b || a.replace(/ /g, '') === b.replace(/ /g, '')) return null;
  const A = a.split(' '), B = b.split(' ');
  if (A.length === B.length && A.slice().sort().join(' ') === B.slice().sort().join(' ')) {
    const verbMoved = A[A.length - 1] !== B[B.length - 1];
    return { mt: 'order', i: A.findIndex((w, k) => w !== B[k]), msg: verbMoved ? 'Right words! In Farsi the verb goes at the END.' : 'Right words! Check the order.' };
  }
  if (A.length === B.length) {
    const d = A.map((w, i) => [w, B[i], i]).filter(([x, y]) => x !== y);
    if (d.length === 1) {
      const [x, y, i] = d[0];
      if (x.slice(0, 2) === y.slice(0, 2) && Math.abs(x.length - y.length) <= 3 && i === A.length - 1) return { mt: 'verb', i, msg: 'Check the ending of the verb: who is doing it?' };
      if (lev(x, y) <= 2) return { mt: 'spelling', i, msg: 'Check the letters in this word.' };
      return { mt: 'word', i, msg: 'Check this word: is it the one you need?' };
    }
  }
  if (sim(a, b) > 0.8) return { mt: 'spelling', i: -1, msg: 'Very close! Check the letters.' };
  return { mt: 'word', i: -1, msg: 'Check the words you used. Listen to the example again.' };
}

// Free writing (one sentence / three sentences): lenient checks that name mistake types.
const EN_COMMON = new Set('the and is are i you my a an it this that to of in we he she they have has with on for was what like am do'.split(' '));
export function checkFree(lang, text, ctx) {
  const t = (text || '').trim();
  const sentences = t.split(/[.!?؟\n]+/).map((x) => x.trim()).filter((x) => x.split(/\s+/).length >= 2);
  const out = { ok: false, notes: [], mts: [], used: [] };
  const words = (lang === 'es' ? normEs(t) : (isFaScript(t) ? normFa(t) : normTr(t))).split(' ').filter(Boolean);
  if (words.length < (ctx.need === 3 ? 6 : 3)) { out.notes.push(ctx.need === 3 ? 'Write 3 short sentences (at least 2 words each).' : 'Write a whole sentence: at least 3 words.'); return out; }
  const en = words.filter((w) => EN_COMMON.has(w)).length;
  if (lang === 'es' && en >= Math.max(2, words.length * 0.4)) { out.notes.push('That looks like English. Try it in Spanish!'); out.mts.push('word'); return out; }
  if (lang === 'es') {
    const known = ctx.known || {}; // stripped -> correct
    for (const w of words) {
      const k = known[stripAcc(w)];
      if (k && k !== w) { out.notes.push(`Check the accent: ${k}`); out.mts.push('spelling'); }
    }
    const genders = ctx.genders || {};
    for (let i = 0; i < words.length - 1; i++) {
      const art = words[i], n = stripAcc(words[i + 1]);
      if (ARTS.includes(art) && genders[n]) {
        const fem = /^(la|las|una|unas)$/.test(art);
        if ((genders[n] === 'f') !== fem) { out.notes.push(`Check the gender: ${art} ${words[i + 1]}`); out.mts.push('gender'); }
      }
    }
  }
  for (const k of ctx.keys || []) {
    const kk = lang === 'es' ? normEs(k) : normFa(typeof k === 'string' ? k : k.f || '');
    const kt = lang === 'fa' && typeof k === 'object' ? normTr(k.t || '') : '';
    const hay = lang === 'es' ? stripAcc(words.join(' ')) : words.join(' ');
    if ((kk && hay.includes(lang === 'es' ? stripAcc(kk) : kk)) || (kt && hay.includes(kt))) out.used.push(typeof k === 'string' ? k : k.t);
  }
  if (ctx.need === 3 && sentences.length < 3 && words.length < 9) out.notes.push('Can you make it 3 sentences?');
  out.ok = out.notes.length === 0 || (out.mts.length === 0 && !(ctx.need === 3 && sentences.length < 3 && words.length < 9));
  return out;
}

// ---------- spaced repetition ----------
export const INTERVALS = [0, 1, 2, 4, 7, 14, 30];
export function grade(L, id, res) { // res: 'first' | 'retry' | 'wrong'
  const t = today();
  const r = L.srs[id] || { b: 0, d: t, r: 0, w: 0, s: t };
  if (res === 'first') { r.b = Math.min(6, (r.b || 0) + 1); r.r++; }
  else if (res === 'retry') { r.b = Math.max(1, r.b || 1); r.r++; }
  else { r.b = 1; r.w++; r.lw = t; }
  r.d = t + INTERVALS[r.b];
  L.srs[id] = r;
}
export function introduce(L, id) { if (!L.srs[id]) L.srs[id] = { b: 0, d: today(), r: 0, w: 0, s: today() }; }
export const known = (L, id) => !!L.srs[id];
export const dueItems = (L, items) => { const t = today(); return items.filter((it) => L.srs[it.id] && L.srs[it.id].d <= t); };
export const mastered = (L) => Object.values(L.srs).filter((r) => r.b >= 3).length;

// ---------- adaptivity (moves both ways: no ratchet) ----------
export function record(L, ok) {
  L.win = (L.win || []).concat(ok ? 1 : 0).slice(-12);
  if (L.win.length >= 8) {
    const acc = L.win.reduce((a, b) => a + b, 0) / L.win.length;
    if (acc >= 0.9 && L.diff < 5) { L.diff++; L.win = []; }
    else if (acc <= 0.6 && L.diff > 1) { L.diff--; L.win = []; }
  }
}
export const nOptions = (L) => [3, 3, 4, 4, 5, 5][L.diff] || 4;

// ---------- levels / units ----------
export const LEVELS = [
  { id: 'sprout', name: 'Sprout', grade: 'K-2', from: 1, to: 5, diff: 1 },
  { id: 'explorer', name: 'Explorer', grade: 'Grade 3', from: 6, to: 10, diff: 2 },
  { id: 'core', name: 'Grade 4 core', grade: 'Grade 4', from: 11, to: 16, diff: 3 },
  { id: 'stretch', name: 'Grade 4+ stretch', grade: 'Grade 4+', from: 17, to: 20, diff: 4 },
];
export const levelOf = (n) => LEVELS.find((l) => n >= l.from && n <= l.to) || LEVELS[0];
export function unitState(L, n) { if (!L.units[n]) L.units[n] = { hp: 3, done: false, spk: 0, wrt: 0, wstep: 0, bossSeen: 0, days: 0 }; return L.units[n]; }
export function currentUnit(L, units) {
  const start = (LEVELS.find((l) => l.id === L.level) || LEVELS[0]).from;
  for (let n = start; n <= 20; n++) { if (!units[n - 1]) return n; if (!unitState(L, n).done) return n; }
  for (let n = 1; n < start; n++) if (units[n - 1] && !unitState(L, n).done) return n;
  return 20;
}
export function unitStars(L, unit, items) {
  const u = unitState(L, unit.n);
  const wl = items.filter((it) => L.srs[it.id] && L.srs[it.id].b >= 2).length;
  return { w: items.length > 0 && wl / items.length >= 0.8, s: u.spk >= 2 && u.wrt >= 2, b: u.done };
}

// ---------- lenient speech matching ----------
const ES_U = ['cero', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve', 'diez', 'once', 'doce', 'trece', 'catorce', 'quince', 'dieciseis', 'diecisiete', 'dieciocho', 'diecinueve', 'veinte', 'veintiuno', 'veintidos', 'veintitres', 'veinticuatro', 'veinticinco', 'veintiseis', 'veintisiete', 'veintiocho', 'veintinueve'];
const ES_T = { 30: 'treinta', 40: 'cuarenta', 50: 'cincuenta', 60: 'sesenta', 70: 'setenta', 80: 'ochenta', 90: 'noventa' };
export const esNum = (n) => (n < 30 ? ES_U[n] : n === 100 ? 'cien' : n > 100 ? String(n) : ES_T[Math.floor(n / 10) * 10] + (n % 10 ? ' y ' + ES_U[n % 10] : ''));
const FA_U = ['صفر', 'یک', 'دو', 'سه', 'چهار', 'پنج', 'شش', 'هفت', 'هشت', 'نه', 'ده', 'یازده', 'دوازده', 'سیزده', 'چهارده', 'پانزده', 'شانزده', 'هفده', 'هجده', 'نوزده'];
const FA_T = { 20: 'بیست', 30: 'سی', 40: 'چهل', 50: 'پنجاه', 60: 'شصت', 70: 'هفتاد', 80: 'هشتاد', 90: 'نود' };
const faNum = (n) => (n < 20 ? FA_U[n] : n === 100 ? 'صد' : n > 100 ? String(n) : FA_T[Math.floor(n / 10) * 10] + (n % 10 ? ' و ' + FA_U[n % 10] : ''));
const ES_ART = /^(el|la|los|las|un|una|unos|unas)\s+/;
export function normSpeechEs(s) {
  s = (s || '').toLowerCase().replace(/\d+/g, (d) => esNum(+d));
  return stripAcc(s).replace(/[¿¡?!.,;:"“”«»()…—–\-']/g, ' ').replace(/\s+/g, ' ').trim();
}
const FA_SPOKEN = { 'یه': 'یک', 'پونزده': 'پانزده', 'شونزده': 'شانزده', 'اره': 'اره' };
export function normSpeechFa(s) {
  s = (s || '').replace(/[۰-۹]/g, (c) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g, (c) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
  s = s.replace(/\d+/g, (d) => ' ' + faNum(+d) + ' ');
  s = normFa(s).replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ی');
  return s.split(' ').map((w) => FA_SPOKEN[w] || w).join(' ').trim();
}
const YES = { es: ['si', 'claro', 'si senor'], fa: ['اره', 'بله', 'اری', 'بلی'] };
const NO = { es: ['no'], fa: ['نه', 'نخیر', 'نچ'] };
function variants(lang, t) {
  const n = lang === 'es' ? normSpeechEs(t) : normSpeechFa(t);
  const out = [n];
  if (YES[lang].includes(n.replace(/\s/g, ' '))) out.push(...YES[lang]);
  if (NO[lang].includes(n)) out.push(...NO[lang]);
  if (lang === 'es' && ES_ART.test(n)) out.push(n.replace(ES_ART, ''));
  return out;
}
// Kind matching: any alternative Chrome returns, any accepted target (spoken or written form), contains or close enough.
export function matchSpeech(lang, alts, targets) {
  const T = [...new Set(targets.filter(Boolean).flatMap((t) => variants(lang, t)))];
  let best = { score: 0, heard: (alts && alts[0]) || '' };
  for (const a of alts || []) {
    const h = lang === 'es' ? normSpeechEs(a) : normSpeechFa(a);
    const hz = h.replace(/\s/g, '');
    for (const t of T) {
      const tz = t.replace(/\s/g, '');
      if (!tz) continue;
      let sc = 0;
      if (hz === tz) sc = 1;
      else if (tz.length >= 3 && hz.includes(tz)) sc = 0.95;
      else if (lang === 'es' && t.split(' ').length > 1 && t.split(' ').every((w) => h.split(' ').includes(w))) sc = 0.92;
      else if (tz.length >= 4) sc = sim(tz, hz);
      if (sc > best.score) best = { score: sc, heard: a };
    }
  }
  return { ok: best.score >= 0.7, score: best.score, heard: best.heard };
}

// ---------- look-alike emoji never share a choice set ----------
const EMO_GROUPS = ['😀😃😄😁😆😊🙂☺😺😸', '😢😭😿😥', '😠😡👿', '😮😯😲😱', '😴😪🥱', '👦🧒👧👨👩🧑👶🙋🙎🙍💁🙆🙅', '👵👴🧓', '🐱🐈', '🐶🐕🐩', '🐦🐤🐥🐣🐧', '🐟🐠🐡', '🌳🌲🌴🌿', '☀🌞🌅', '🌙🌛🌜🌝', '⭐🌟✨💫', '❤💖💗💕💓💞', '📖📚📕📗📘📙📓📔', '✏🖊🖋🖍', '🏠🏡🏘', '🚗🚙🚕', '🍎🍏', '🎵🎶', '👟👞', '👕👚', '🌧☔🌦', '❄☃⛄'];
const EMO_MAP = new Map(); EMO_GROUPS.forEach((g, i) => [...g].forEach((ch) => { if (ch.codePointAt(0) > 0x2000) EMO_MAP.set(ch, 'g' + i); }));
export function emojiClass(e) { const ch = [...(e || '').replace(/[\uFE0F\u200D]/g, '')][0] || ''; return EMO_MAP.get(ch) || ch; }

// ---------- language of the day (one language a day, the other is a bonus) ----------
// Spanish is the main language; Farsi is the Bonus (unless the parent picked Farsi every day)
export const isBonus = (S, l) => l === ((S.settings && S.settings.mix) === 'fa' ? 'es' : 'fa');
export function todayLang(S) {
  const st = S.settings; const d = new Date();
  if (st.mix === 'es' || st.mix === 'fa') return st.mix;
  if (st.mix === 'custom' && Array.isArray(st.week)) return st.week[d.getDay()] === 'fa' ? 'fa' : 'es';
  return Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / 86400000) % 2 === 0 ? 'es' : 'fa';
}

// ---------- writing by level ----------
export function writeKinds(n) { return n <= 5 ? ['copy', 'fill'] : n <= 10 ? ['copy', 'fill', 'build'] : ['fill', 'build', 'one', 'three']; }

// ---------- quest plan ----------
// greeting → review (≤12) → story → new words → sword training → grammar / letters / writing → boss → chest
const PER = { 10: { rev: 8, neu: 5 }, 15: { rev: 12, neu: 7 }, 20: { rev: 12, neu: 9 } };
export function planQuest(S, lang, unit, items, allItems, opts = {}) {
  const L = S[lang];
  const per = PER[S.settings.daily] || PER[15];
  const steps = [{ type: 'greeting' }];
  const t = today();
  const due = dueItems(L, allItems).sort((a, b) => (L.srs[b.id].w || 0) - (L.srs[a.id].w || 0) || (L.srs[b.id].lw || 0) - (L.srs[a.id].lw || 0) || L.srs[a.id].d - L.srs[b.id].d);
  const rev = due.slice(0, per.rev - 1); // one slot goes to the power phrase
  if (rev.length) steps.push({ type: 'review', items: rev, rolled: due.length - rev.length });
  steps.push({ type: 'story' });
  const heavy = Math.floor(rev.length / 4);
  const fresh = items.filter((it) => !L.srs[it.id] && !(opts.storyIds || []).includes(it.id));
  const w = fresh.filter((i) => i.kind === 'w'), p = fresh.filter((i) => i.kind === 'p');
  // Spanish: at most 4 new words in a quest (easier start)
  const want = Math.min(lang === 'es' ? 4 : 99, Math.max(3, per.neu - heavy - (opts.storyIds || []).length));
  const neu = [];
  while (neu.length < want && (w.length || p.length)) {
    for (let k = 0; k < 3 && w.length && neu.length < want; k++) neu.push(w.shift());
    if (p.length && neu.length < want) neu.push(p.shift());
  }
  if (neu.length) steps.push({ type: 'learn', items: neu });
  steps.push({ type: 'tpr' });
  const rot = lang === 'fa' ? ['grammar', 'script', 'write'] : ['grammar', 'write'];
  // Spanish Sprout units (1-5): no grammar terms yet, teach chunks (writing instead)
  const kind = lang === 'es' && unit.n <= 5 ? 'write' : rot[(L.quests || 0) % rot.length];
  const u = unitState(L, unit.n);
  if (kind === 'grammar') steps.push({ type: 'grammar', first: !u.gseen, optional: true });
  else if (kind === 'script') steps.push({ type: 'script', optional: true });
  else { const ks = writeKinds(unit.n); steps.push({ type: 'write', kind: ks[(u.wstep || 0) % ks.length], optional: true }); }
  steps.push({ type: 'boss' });
  return steps;
}
