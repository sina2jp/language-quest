// Playwright checks for the Family Wallet UI. Run: node ui-test.mjs  (add --stub to use the in-memory stub instead of core)
// Needs playwright-core and @sparticuz/chromium installed in ../pw (or set PW_DIR).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));
const pw = process.env.PW_DIR || path.join(dir, '..', 'pw');
const { chromium } = await import(pathToFileURL(path.join(pw, 'node_modules/playwright-core/index.mjs')).href);
const Chromium = (await import(pathToFileURL(path.join(pw, 'node_modules/@sparticuz/chromium/build/index.js')).href)).default;
const shots = path.join(dir, 'shots');
fs.mkdirSync(shots, { recursive: true });
const STUB = process.argv.includes('--stub');
const base = pathToFileURL(path.join(dir, 'ui-harness.html')).href + (STUB ? '?stub=1' : '?stub=0');

const results = [];
function check(ok, msg) { results.push({ ok: !!ok, msg }); if (!ok) console.log('  FAIL', msg); }

const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox'] });

const configs = [
  { name: 'mac', viewport: { width: 1440, height: 900 }, hasTouch: false, isMobile: false },
  { name: 'phone', viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 }
];

for (const cfg of configs) {
  console.log(`== ${cfg.name} (${STUB ? 'stub' : 'core'})`);
  const ctx = await browser.newContext({ viewport: cfg.viewport, hasTouch: cfg.hasTouch, isMobile: cfg.isMobile, deviceScaleFactor: cfg.deviceScaleFactor || 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push(String(e)));
  const tap = async (loc) => { await loc.scrollIntoViewIfNeeded(); if (cfg.hasTouch) await loc.tap(); else await loc.click(); };
  const shot = async (name) => page.screenshot({ path: path.join(shots, `${cfg.name}-${name}.png`), fullPage: true });
  const P = (s, o) => page.locator('#page ' + s, o);

  async function generic(label) {
    const r = await page.evaluate(() => {
      const out = { badClass: [], small: [], styles: document.querySelectorAll('#fw-style').length, overflow: document.documentElement.scrollWidth - innerWidth };
      document.querySelectorAll('.fw-root, .fw-root *').forEach((el) => {
        if (el instanceof SVGElement) return;
        el.classList.forEach((c) => { if (!c.startsWith('fw-')) out.badClass.push(c); });
      });
      document.querySelectorAll('.fw-root button, .fw-root a.fw-btn, .fw-root select, .fw-root input:not([type=checkbox]), .fw-root label.fw-check').forEach((el) => {
        const b = el.getBoundingClientRect();
        if (b.width === 0 && b.height === 0) return;
        if (b.height < 44 || b.width < 44) out.small.push(`${el.tagName}:${(el.textContent || el.getAttribute('aria-label') || '').trim().slice(0, 24)} ${Math.round(b.width)}x${Math.round(b.height)}`);
      });
      return out;
    });
    check(r.styles === 1, `${label}: exactly one #fw-style (${r.styles})`);
    check(r.badClass.length === 0, `${label}: all classes start with fw- ${r.badClass.slice(0, 5).join(',')}`);
    check(r.small.length === 0, `${label}: tap targets >= 44px ${r.small.slice(0, 5).join(' | ')}`);
    check(r.overflow <= 0, `${label}: no horizontal page overflow (${r.overflow}px)`);
  }

  await page.goto(base);
  await page.waitForFunction(() => window.H && window.H.ready);
  await page.evaluate(() => window.H.seed(false));
  await page.waitForTimeout(50);

  // ---- Wallet ----
  const triLabel = await P('.fw-tri-label').textContent();
  check(/Wisdom 2\/3/.test(triLabel) && /Power 3\/3/.test(triLabel) && /Courage 0\/3/.test(triLabel) && /Song 0\/3/.test(triLabel), `wallet: piece labels "${triLabel}"`);
  check(await P('svg.fw-tri ellipse').count() >= 1, 'wallet: ocarina note piece drawn for music');
  check(await P('svg.fw-tri polygon').count() >= 3, 'wallet: Triforce triangles drawn');
  const newCards = await P('.fw-new').allTextContents();
  check(newCards.some((t) => /New: .*(Language|Music) Quest!/.test(t)), `wallet: New card shown (${newCards.join(' / ').slice(0, 80)})`);
  const hrefs = await P('a.fw-btn').evaluateAll((as) => as.map((a) => a.getAttribute('href')));
  check(hrefs.includes('../music-quest/') && hrefs.includes('../code-quest/') && !hrefs.includes('../math-arena/'), `wallet: other-app links ${[...new Set(hrefs)].join(',')}`);
  check(await P('.fw-today-col').count() === 4, 'wallet: Today lists all 4 apps');
  const claimBtn = P('button[data-fw-key=claim]');
  check(await claimBtn.isDisabled(), 'wallet: claim disabled when short');
  check(/need/i.test(await P('.fw-wallet .fw-line').first().textContent()), 'wallet: gentle line when short');
  check(await page.locator('#counter button.fw-counter').getAttribute('aria-label').then((l) => /Wisdom 2, Courage 0, Power 3, Song 0, 120 rupees/.test(l)), 'counter: aria-label has full numbers');
  check(!(await page.locator('#counter .fw-ready').count()), 'counter: no ring when not affordable');
  await generic('wallet');
  await shot('wallet-short');

  // Secrets tab
  await tap(P('[data-fw-key=tab-secrets]'));
  check(await P('.host-secrets').count() === 1, 'wallet: secrets tab renders host content');
  await shot('wallet-secrets');
  await tap(P('[data-fw-key=tab-wallet]'));

  // Make a reward affordable (other tab-like change through the core) and claim it
  await page.evaluate(() => { const FW = window.H.FW; FW.APPS.forEach((a) => FW.adjust(a, 3, 'Test')); });
  await page.waitForTimeout(30);
  check(!(await claimBtn.isDisabled()), 'wallet: claim enabled after onChange re-render');
  check(await page.locator('#counter .fw-ready').count() === 1, 'counter: ring when a reward is affordable');
  await shot('wallet-ready');
  await tap(claimBtn);
  const firstReward = P('button.fw-reward:not([disabled])').first();
  check(/Triforce/.test(await firstReward.textContent()), 'claim: reward card shows cost in Triforces');
  await shot('claim-pick');
  await tap(firstReward);
  const ticketText = await P('.fw-ticket-big').textContent();
  check(/earned in Math Arena/.test(ticketText) && /Show a grown-up!/.test(ticketText), `claim: ticket card "${ticketText.trim().slice(0, 90)}"`);
  await shot('claim-ticket');
  // PIN says no first
  await page.evaluate(() => { window.H.pinAnswer = false; });
  await tap(P('.fw-ticket-big button', { hasText: 'Grown-up: approve' }).first());
  await page.waitForTimeout(30);
  check(await P('.fw-ticket-big').textContent().then((t) => !/Approved/.test(t)), 'claim: wrong PIN does not approve');
  await page.evaluate(() => { window.H.pinAnswer = true; });
  await tap(P('.fw-ticket-big button').first());
  await page.waitForTimeout(30);
  check(/Approved\. Have fun!/.test(await P('.fw-ticket-big').textContent()), 'claim: approved after PIN');
  check(await page.evaluate(() => window.H.FW.tickets()[0].status === 'used'), 'claim: ticket marked used in core');
  await shot('claim-approved');
  await tap(P('[data-fw-key=done]'));
  check(await P('h2', { hasText: 'My tickets' }).count() === 1, 'wallet: back to main, My tickets shown');

  // Wallet without renderSecrets hides the tab
  await page.evaluate(() => window.H.show('wallet', { renderSecrets: null }));
  check(await P('[data-fw-key=tab-secrets]').count() === 0, 'wallet: secrets tab hidden without renderSecrets');

  // Any mode
  await page.evaluate(() => window.H.FW.setSettings({ mode: 'any' }));
  await page.waitForTimeout(30);
  const anyLabel = await P('.fw-tri-label').textContent();
  check(/\/12/.test(anyLabel), `wallet any-mode: total/anyCost label "${anyLabel}"`);
  await shot('wallet-any');
  await page.evaluate(() => window.H.FW.setSettings({ mode: 'balanced' }));

  // ---- Market ----
  await page.evaluate(() => window.H.show('market'));
  await page.evaluate(() => window.H.FW.adjustRupees(200, 'Test'));
  await page.waitForTimeout(30);
  check(await P('.fw-item-featured').count() === 1, 'market: weekly item card first');
  check(/You can afford/.test(await P('.fw-note').first().textContent()), 'market: affordable line');
  const chips = P('.fw-chips .fw-chip');
  check(await chips.count() >= 3, 'market: category chips');
  await generic('market');
  await shot('market');
  // filter
  await tap(chips.nth(1));
  const cats = await P('.fw-grid .fw-item .fw-item-cat').allTextContents();
  check(cats.length > 0 && new Set(cats).size === 1, `market: chip filters to one category (${new Set(cats).size})`);
  await shot('market-filtered');
  await tap(chips.first());
  // short item shows "x more"
  check(await P('.fw-grid button[disabled]', { hasText: 'more' }).count() > 0, 'market: unaffordable items show "x more" disabled');
  // buy flow: Not now, then Yes
  const buyItem = await P('.fw-grid .fw-item').filter({ has: page.locator('button', { hasText: /^Buy$/ }) }).evaluateAll((els) => els.map((e) => e.getAttribute('data-item')));
  const equipFirst = await page.evaluate((ids) => { const FW = window.H.FW; const c = FW.catalog(window.H.app); return ids.find((id) => { const it = c.find((x) => x.id === id); return it && it.slot && ['background', 'buddy', 'naviColor'].includes(it.slot); }) || ids[0]; }, buyItem);
  const card = P(`.fw-item[data-item="${equipFirst}"]`);
  await tap(card.locator('button', { hasText: /^Buy$/ }));
  check(/^Buy .+ for \d+ rupees\?$/.test((await card.locator('.fw-confirm p').textContent()).trim()), 'market: buy asks once inline');
  await shot('market-confirm');
  await tap(card.locator('button', { hasText: 'Not now' }));
  check(await card.locator('.fw-confirm').count() === 0, 'market: Not now cancels');
  // pin as goal
  await tap(card.locator('button', { hasText: 'Save for this' }));
  check(await card.locator('button', { hasText: 'Saving for this' }).count() === 1, 'market: Save for this -> Saving for this');
  check(await page.locator('#goal .fw-goal').count() === 1, 'goal bar: shows pinned goal');
  check(await page.locator('#goal .fw-bar').count() === 1, 'goal bar: has progress bar');
  await page.screenshot({ path: path.join(shots, `${cfg.name}-goal-bar.png`), clip: { x: 0, y: 0, width: cfg.viewport.width, height: 160 } });
  await tap(card.locator('button', { hasText: /^Buy$/ }));
  const logBefore = await page.evaluate(() => window.H.equippedLog.length);
  await tap(card.locator('button', { hasText: 'Yes' }));
  await page.waitForTimeout(30);
  check(await page.evaluate((id) => window.H.FW.inventory().owned.includes(id), equipFirst), 'market: Yes buys the item');
  check(/It is yours/.test(await P('.fw-note').first().textContent()), 'market: success line');
  const eqBtn = card.locator('button', { hasText: /^Equip$/ });
  if (await eqBtn.count()) {
    await tap(eqBtn);
    await page.waitForTimeout(30);
    check(await card.locator('button', { hasText: 'Equipped' }).count() === 1, 'market: Equip -> Equipped');
    check(await page.evaluate((n) => window.H.equippedLog.length > n, logBefore), 'applyEquipped: handler called on equip');
  } else check(true, 'market: bought item not equippable (skipped equip)');
  await shot('market-bought');
  // Room
  await tap(P('[data-fw-key=tab-room]'));
  check(await P('.fw-shelf .fw-item').count() >= 1, 'room: owned item on the shelf');
  check(await P('.fw-shelf .fw-badge', { hasText: 'Equipped' }).count() >= 1, 'room: equipped item marked');
  await generic('room');
  await shot('room');

  // ---- Parent ----
  await page.evaluate(() => window.H.show('parent'));
  await generic('parent');
  await shot('parent');
  check(await P('label.fw-check').count() === 4, 'parent: Apps in the set checkboxes (4)');
  // uncheck music, change minutes per shard, save
  await tap(P('label.fw-check[data-app=music] input'));
  const mps = P('input[name=minutesPerShard]');
  await mps.fill('12');
  await tap(P('[data-fw-key=save-settings]'));
  const s1 = await page.evaluate(() => window.H.FW.settings());
  check(s1.minutesPerShard === 12 && s1.appsInSet.join() === 'math,language,code', `parent: settings saved (${s1.minutesPerShard}, ${s1.appsInSet})`);
  // cannot uncheck the last app
  await tap(P('label.fw-check[data-app=language] input'));
  await tap(P('label.fw-check[data-app=code] input'));
  check(await P('label.fw-check[data-app=math] input').isDisabled(), 'parent: last checked app cannot be unchecked');
  await page.evaluate(() => window.H.show('parent'));
  // any mode: read-only cost
  await tap(P('[data-fw-key=mode-any]'));
  check(await P('input[name=anyCost]').count() === 0 && /9/.test(await P('.fw-any-cost').textContent()), 'parent: any-mode cost read-only (3 x apps in set)');
  await tap(P('[data-fw-key=mode-balanced]'));
  // rewards add/remove/save
  const rows0 = await P('.fw-rw-row').count();
  await tap(P('[data-fw-key=rw-add]'));
  await P(`.fw-rw-row[data-row="${rows0}"] input[aria-label=Reward]`).fill('Bake cookies together');
  await P(`.fw-rw-row[data-row="${rows0}"] select`).selectOption('2');
  await tap(P('[data-fw-key=rw-save]'));
  const rw = await page.evaluate(() => window.H.FW.rewards());
  check(rw.list.some((r) => r.text === 'Bake cookies together'), 'parent: reward added and saved');
  await tap(P('.fw-rw-row').first().locator('button', { hasText: 'Remove' }));
  await tap(P('[data-fw-key=rw-save]'));
  check(await page.evaluate((n) => window.H.FW.rewards().list.length === n, rw.list.length - 1), 'parent: reward removed and saved');
  // ledger filter
  await tap(P('[data-fw-key=lg-code]'));
  const evApps = await P('.fw-ev').allTextContents();
  check(evApps.length > 0 && evApps.every((t) => /Code Quest/.test(t)), 'parent: ledger filter by app');
  check(await P('[data-sec=ledger] .fw-chip').count() === 5, 'parent: ledger chips All + 4 apps');
  // weekly
  check(await P('.fw-table tbody tr').count() === 4, 'parent: weekly report one row per app');
  await tap(P('[data-fw-key=wk-1]'));
  check(await P('[data-fw-key=wk-1][aria-pressed=true]').count() === 1, 'parent: Last week toggle');
  // adjust: reason required
  await P('input[name=adj-amount]').fill('5');
  await tap(P('[data-fw-key=adj-apply]'));
  check(/reason/i.test(await P('[data-sec=adjust] .fw-err').textContent()), 'parent: adjust needs a reason');
  await P('input[name=adj-amount]').fill('5');
  await P('input[name=adj-reason]').fill('Helped at home');
  await tap(P('[data-fw-key=adj-apply]'));
  check(await page.evaluate(() => window.H.FW.events({ limit: 1 })[0].reason === 'Helped at home'), 'parent: adjust applied');
  check(/on this browser/.test(await P('.fw-shared-note').textContent()), 'parent: shared note');
  // tickets: claim one more and mark as used from parent
  await page.evaluate(() => { const FW = window.H.FW; FW.APPS.forEach((a) => FW.adjust(a, 6, 'Test')); FW.claim(FW.rewards().list[0].id, 'code'); });
  await page.waitForTimeout(30);
  const mu = P('[data-sec=tickets] button', { hasText: 'Mark as used' }).first();
  check(await mu.count() === 1, 'parent: ticket with Mark as used');
  await tap(mu);
  check(await page.evaluate(() => window.H.FW.tickets()[0].status === 'used'), 'parent: Mark as used works');
  await generic('parent-after');
  await shot('parent-after');

  // ---- Grove skin, counter, destroy, reduced motion ----
  const groveOk = await page.evaluate(() => {
    const FW = window.H.FW; const el = document.createElement('div'); document.body.appendChild(el);
    const m = FW.mountMarket(el, { app: 'math', skin: 'grove' });
    const t = el.textContent; m.destroy(); const empty = el.childNodes.length === 0; el.remove();
    return { grove: /Grove Market/.test(t) && /Treehouse/.test(t), empty };
  });
  check(groveOk.grove, 'skin: grove names used');
  check(groveOk.empty, 'destroy: removes DOM');
  if (STUB) {
    const leak = await page.evaluate(() => {
      const FW = window.H.FW; const before = FW.__listenerCount(); const el = document.createElement('div');
      const ms = [FW.mountWallet(el, { app: 'math' }), FW.mountMarket(el, { app: 'math' }), FW.mountParent(el, { app: 'math' }), FW.mountGoal(el, { app: 'math' }), FW.mountCounter(el, { app: 'math' })];
      const off = FW.applyEquipped({}); const mid = FW.__listenerCount(); ms.forEach((m) => m.destroy()); off();
      return { before, mid, after: FW.__listenerCount() };
    });
    check(leak.mid === leak.before + 6 && leak.after === leak.before, `destroy: onChange listeners cleaned (${leak.before}->${leak.mid}->${leak.after})`);
  }
  // cross-tab: a storage event from another tab re-renders
  if (!STUB) {
    const p2 = await ctx.newPage();
    await p2.goto(base + '&page=wallet');
    await p2.waitForFunction(() => window.H && window.H.ready);
    const before = await page.locator('#counter button').getAttribute('aria-label');
    await p2.evaluate(() => window.H.FW.adjustRupees(7, 'Other tab'));
    await page.waitForTimeout(150);
    const after = await page.locator('#counter button').getAttribute('aria-label');
    check(before !== after, 'cross-tab: counter re-renders on a change in another tab');
    await p2.close();
  }
  await page.emulateMedia({ reducedMotion: 'reduce' });
  const td = await page.evaluate(() => getComputedStyle(document.querySelector('.fw-root .fw-btn')).transitionDuration);
  check(/^0s/.test(td), `reduced motion: no transitions (${td})`);
  await page.locator('#counter').screenshot({ path: path.join(shots, `${cfg.name}-counter.png`) });

  check(errors.length === 0, `zero console errors ${errors.slice(0, 3).join(' | ')}`);
  await ctx.close();
}
await browser.close();
const fails = results.filter((r) => !r.ok);
console.log(`\n${results.length - fails.length}/${results.length} checks passed (${STUB ? 'stub' : 'core'})`);
fs.writeFileSync(path.join(shots, `results-${STUB ? 'stub' : 'core'}.json`), JSON.stringify(results, null, 1));
process.exit(fails.length ? 1 : 0);
