import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';
import { load, save, onSaveFail, askPersist, today, getAIKey, previewMode, LS, setPin } from './store.js';
import { AppCtx, useApp, Navi, Portrait, PlayBtn, TT, ActionBar, Modal, Stars, Dots, Motes, AccentBar, insertAt, PersianKeyboard, Icon, SafeImg } from './ui.jsx';
import { aiMessage } from './ai.js';
import { TokenChip, TreasurePage, TicketFlow, ToastHost, TreasureWatch, SecretTap, useFind, noteAction } from './treasure.jsx';
import { FirstStepsStart, FirstStepsPath, FSLesson, fsActive } from './firststeps.jsx';
import { emit } from './hooks.js';
import { FW, APP, wireWallet, migrateOnce, legacyItems, imageFor, partner } from './wallet.js';
import { WalletCounter, WalletScreen, MarketScreen, GoalBar, useEquipped } from './walletui.jsx';
try { if (FW) FW.registerItems(legacyItems(SHOP)); } catch (e) {}
wireWallet();
const LEARNING = ['quest', 'fslesson', 'script', 'songs', 'weekly', 'ai', 'placement'];
import { setAudioSettings, say, sfx, unlockAudio, loadFaIndex, srAvailable, listen, ocarinaNote, tone, stopAudio } from './audio.js';
import { planQuest, introduce, grade, record, unitState, currentUnit, unitStars, LEVELS, levelOf, shuffle, normEs, normFa, sim, stripAcc } from './engine.js';
import { LANG, T, getUnits, getUnit, unitItems, allItems, triplets } from './content.js';
import { PLACES, name, cap, placeName, rewardName, rewardIcon, setSkin, getSkin, sceneArt, mapArt, REWARDS, pinPos, mapTall, musicFor, credit, kitSkin, kitIcon, rewardImg, rewardNameK } from './skin.js';
import { loadKitPack, HM } from './kitload.js';
import { LearnCard, Pick, SayIt, SpellIt, SpeedRound, Triplets, GrammarStep, WriteStep, RolePlay, PicDescribe, tally, showTr } from './activities.jsx';
import { ScriptLesson, ScriptHome, LESSONS } from './script.jsx';
import { Placement } from './placement.jsx';
import { ParentCorner } from './parent.jsx';
import { Quest } from './quest.jsx';
import { todayLang, isBonus } from './engine.js';
import { SECRET_SONGS, SHOP } from './routine.js';
import { VoiceAnswer } from './voice.jsx';

const weekKey = () => { const d = new Date(); const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); const day = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - day); const y = new Date(Date.UTC(t.getUTCFullYear(), 0, 1)); return t.getUTCFullYear() + '-W' + Math.ceil(((t - y) / 86400000 + 1) / 7); };

// ---------- ambient music (original, gentle; replaced by the kit's tracks when present) ----------
let musicTimer = null;
function startMusic(kind, track) {
  stopMusic();
  const M = HM(); if (M) { try { M.play(track || (kind === 'boss' ? 'boss' : 'forest'), { fade: true }); } catch (e) {} return; }
  const scales = { home: [62, 66, 69, 73, 74, 78, 81], quest: [57, 60, 64, 67, 69, 72, 76], boss: [50, 53, 57, 58, 62, 65] };
  const sc = scales[kind] || scales.home; let i = 0;
  musicTimer = setInterval(() => {
    const n = sc[(i * 3 + (i >> 2)) % sc.length]; const f = 440 * Math.pow(2, (n - 69) / 12);
    tone(f, 0, 1.6, 'sine', 0.025); if (i % 4 === 0) tone(f / 2, 0, 2.4, 'triangle', 0.018); i++;
  }, kind === 'boss' ? 420 : 620);
}
function stopMusic() { if (musicTimer) clearInterval(musicTimer); musicTimer = null; const M = HM(); if (M) { try { M.stop(0.6); } catch (e) {} } }

function App() {
  const [S] = useState(() => load());
  const [, setTick] = useState(0);
  const equipped = useEquipped();
  const [route, setRoute] = useState({ s: 'home' });
  const [toastMsg, setToast] = useState(null);
  const [kitReady, setKitReady] = useState(false);
  const [bgOverride, setBg] = useState(null);
  const set = useCallback((fn) => { noteAction(); fn(S); save(S); setTick((t) => t + 1); }, [S]);
  const toast = useCallback((msg, ok) => { setToast({ msg, ok }); setTimeout(() => setToast(null), 3500); }, []);
  const refreshAudio = () => setAudioSettings(S.settings);
  useEffect(() => {
    onSaveFail(() => toast('⚠️ Could not save progress! Ask a grown-up to download a backup (Parent corner).'));
    setAudioSettings(S.settings); loadFaIndex(); askPersist();
    loadKitPack().then((ok) => { kitSkin(S.settings.skinSel || 'hyrule'); setKitReady(ok); });
    const unlock = () => { unlockAudio(); window.removeEventListener('pointerdown', unlock); };
    window.addEventListener('pointerdown', unlock);
  }, []);
  setSkin(S.settings.skinSel || 'hyrule');
  useEffect(() => { const b = document.body; if (!FW) { b.dataset.navi = (S.shop && S.shop.navi) || ''; b.dataset.tunic = (S.shop && S.shop.tunic) || ''; } });
  useEffect(() => { const h = equipped.naviColor && equipped.naviColor.hue; document.body.style.setProperty('--navi-hue', h != null ? h + 'deg' : '0deg'); document.body.dataset.naviHue = h != null ? '1' : ''; }, [equipped.naviColor]);
  useEffect(() => { kitSkin(S.settings.skinSel || 'hyrule'); setTick((t) => t + 1); }, [S.settings.skinSel]);
  useEffect(() => {
    if (!S.settings.music) { stopMusic(); return; }
    const kind = route.s === 'quest' ? 'quest' : ['home', 'lang', 'ican'].includes(route.s) ? 'home' : null;
    const track = route.s === 'quest' ? musicFor((PLACES[route.unit] || PLACES[1]).bg) : route.s === 'lang' ? 'field' : (equipped.music && equipped.music.track) || 'forest';
    if (kind && (kind !== 'quest' || HM())) { const t = setTimeout(() => startMusic(kind, track), 600); return () => clearTimeout(t); } stopMusic();
  }, [route.s, route.unit, S.settings.music, kitReady]);
  const go = (s, p = {}) => { noteAction(); stopAudio(); setRoute({ s, ...p }); window.scrollTo(0, 0); };
  if (globalThis.__LQ_TEST__) globalThis.__lqTest = { go, set, get: () => S, setPin };
  // Family Wallet: one-time migration of local rupees/tokens/items; active-time tracking on learning screens only
  const routeRef = useRef(route.s); routeRef.current = route.s;
  useEffect(() => { if (!FW) return undefined; if (S.nick) migrateOnce(S); let tr = null; try { tr = FW.startTracker(APP, { isLearning: () => LEARNING.includes(routeRef.current) }); } catch (e) {} return () => { try { tr && tr.stop(); } catch (e) {} }; }, []);
  // learning-screen signal (start/stop) for shared time tracking, plus a throttled interaction ping
  useEffect(() => { const on = LEARNING.includes(route.s); emit('learning', { on, screen: route.s }); return () => { if (on) emit('learning', { on: false, screen: route.s }); }; }, [route.s]);
  useEffect(() => { let last = 0; const ping = () => { const t = Date.now(); if (t - last > 5000) { last = t; emit('interaction'); } }; window.addEventListener('pointerdown', ping, true); window.addEventListener('keydown', ping, true); return () => { window.removeEventListener('pointerdown', ping, true); window.removeEventListener('keydown', ping, true); }; }, []);
  const ctx = { S, set, go, toast, route, refreshAudio, kitReady, setBg, equipped };
  const lang = route.lang;
  const eqBg = equipped.background && equipped.background.image ? imageFor(equipped.background.image) : null;
  const bg = bgOverride && route.s === 'quest' ? bgOverride : route.s === 'quest' || route.s === 'boss' ? (PLACES[route.unit] || PLACES[1]).bg : route.s === 'lang' ? (PLACES[currentUnit(S[lang], getUnits(lang))] || PLACES[1]).bg : 'home';
  return (
    <AppCtx.Provider value={ctx}>
      <TreasureWatch route={route} /><ToastHost />
      <div className="scene" style={{ backgroundImage: bg === 'home' && eqBg ? `url("${eqBg}")` : sceneArt(bg) }}><div className="rays" /><Motes /></div>
      {toastMsg && <div className={`toast ${toastMsg.ok ? 'ok' : ''}`} role="alert">{toastMsg.msg}</div>}
      <div className="app">
        {route.s === 'home' && <Home />}
        {route.s === 'lang' && (lang === 'es' && fsActive(S) ? <Shell title="Spanish · First Steps" back={() => go('home')}><FirstStepsPath /></Shell> : <LangHome lang={lang} />)}
        {route.s === 'fspath' && <Shell title="Spanish · First Steps" back={() => go('lang', { lang: 'es' })}><FirstStepsPath /></Shell>}
        {route.s === 'fsstart' && <Shell title="Spanish" back={() => go('home')}><FirstStepsStart /></Shell>}
        {route.s === 'fslesson' && <Shell title={`First Steps · step ${(route.fs || 0) + 1}`} back={() => go('lang', { lang: 'es' })}><FSLesson key={route.fs} idx={route.fs || 0} /></Shell>}
        {route.s === 'placement' && <Shell title="Placement" back={() => go('home')}><Placement lang={lang} onDone={() => { if (lang === 'es') set((s) => { if (s.es.level && s.es.level !== 'sprout') s.es.fs = Object.assign({ done: {}, srs: {} }, s.es.fs || {}, { skipped: true }); }); go('lang', { lang }); }} /></Shell>}
        {route.s === 'quest' && <Quest lang={lang} unitN={route.unit} />}
        {route.s === 'ican' && <Shell title={`My “I can” map · ${LANG[lang].name}${isBonus(S, lang) ? ' (Bonus)' : ''}`} back={() => go('lang', { lang })}><ICanMap lang={lang} /></Shell>}
        {route.s === 'script' && <Shell title="Persian letters" back={() => go('lang', { lang: 'fa' })}>{route.lesson != null ? <ScriptLesson idx={route.lesson} onDone={() => go('script', { lang: 'fa' })} /> : <ScriptHome onLesson={(i) => go('script', { lang: 'fa', lesson: i })} />}</Shell>}
        {route.s === 'songs' && <Shell title="Songbook" back={() => go('lang', { lang })}><Songs lang={lang} /></Shell>}
        {route.s === 'shop' && <Shell title="Rupee shop" back={() => go('lang', { lang })}><Shop lang={lang} /></Shell>}
        {route.s === 'ocarina' && <Shell title="Ocarina" back={() => go(route.from || 'home', { lang })}><Ocarina /></Shell>}
        {route.s === 'weekly' && <Shell title="Show your family" back={() => go('lang', { lang })}><Weekly lang={lang} /></Shell>}
        {route.s === 'ai' && <Shell title="Talk with a villager" back={() => go('lang', { lang })}><AIChat lang={lang} /></Shell>}
        {route.s === 'treasure' && <Shell title="House of Skulltula" back={() => go('home')}><TreasurePage /></Shell>}
        {route.s === 'wallet' && <Shell title="Treasure Wallet" back={() => go('home')}><WalletScreen renderSecretsInto={() => <TreasurePage />} /></Shell>}
        {route.s === 'market' && <Shell title="Hyrule Market" back={() => go(lang ? 'lang' : 'home', { lang })}><div style={{ display: 'grid', gap: 12 }}><MarketScreen /><div className="center"><button className="btn" onClick={() => go('shop', { lang: lang || 'es' })} data-testid="talon-shop">🗣️ Talon's shop: say it in Spanish to buy</button></div></div></Shell>}
        {route.s === 'cert' && <Shell title="Certificate" back={() => go('ican', { lang })}><Certificate lang={lang} level={route.level} /></Shell>}
        {route.s === 'parent' && <Shell title="Parent corner" back={() => go('home')}><ParentCorner onClose={() => go('home')} /></Shell>}
      </div>
    </AppCtx.Provider>
  );
}

function Shell({ title, back, children, right }) {
  return (<>
    <div className="top"><button className="iconbtn" onClick={back} aria-label="Back" data-testid="back"><Icon n="back" /></button><div className="title">{title}</div>{right || <span style={{ width: 44 }} />}</div>
    <div className="main">{children}</div>
  </>);
}

function TopChips() {
  const { S } = useApp();
  const ru = kitIcon('rupee'), he = kitIcon('heart');
  return <div className="row">{!FW && <span className="chip" title="Rupees"><SafeImg src={ru} width={20} height={20} fallback="💎" /> {S.rupees}</span>}<span className="chip" title="Heart containers"><SafeImg src={he} width={20} height={20} fallback="❤️" /> {3 + (S.hc || 0)}</span>{FW ? <WalletCounter /> : <TokenChip />}</div>;
}

// Seasonal quests: Shab-e Yalda (Dec 21) and Nowruz (around Mar 20) open their Farsi unit as a special quest
function season() {
  const d = new Date(); const m = d.getMonth() + 1, day = d.getDate();
  if ((m === 12 && day >= 7 && day <= 22)) return { name: 'Shab-e Yalda', icon: '🍉', unit: 18 };
  if ((m === 3 && day >= 6 && day <= 21) || (m === 2 && day >= 28)) return { name: 'Nowruz', icon: '🌱', unit: 17 };
  return null;
}
// ---------- Home: two doors ----------
function Home() {
  const { S, set, go, equipped: eq = {} } = useApp();
  const [nick, setNick] = useState('');
  if (!S.nick) {
    return (
      <div className="main" style={{ justifyContent: 'center', minHeight: '90vh' }}>
        <div className="card pop center" data-testid="welcome">
          <Portrait who="navi" size="lg" />
          <h1>Hey! Listen!</h1>
          <Navi>I'm {name('navi')}, your fairy guide! I speak Spanish and Farsi. What should I call you, hero?</Navi>
          <input className="field" style={{ marginTop: 14, textAlign: 'center' }} maxLength={20} placeholder="Your hero nickname" value={nick} onChange={(e) => setNick(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && nick.trim()) set((s) => { s.nick = nick.trim(); }); }} data-testid="nick" />
          <div className="muted small" style={{ marginTop: 6 }}>Use a nickname, not your real name.</div>
          {previewMode && <div className="fb info small" style={{ marginTop: 8 }} data-testid="preview-note">Preview mode: progress won’t be saved here.</div>}
          <ActionBar><button className="btn primary wide" disabled={!nick.trim()} onClick={() => { sfx('chest'); set((s) => { s.nick = nick.trim(); }); }} data-testid="nick-ok">Let's go!</button></ActionBar>
        </div>
      </div>
    );
  }
  const tl = todayLang(S); const other = tl === 'es' ? 'fa' : 'es';
  const open = (l) => { sfx('tap'); go(S[l].placed ? 'lang' : l === 'es' ? 'fsstart' : 'placement', { lang: l }); };
  const L = S[tl]; const n = currentUnit(L, getUnits(tl));
  return (<>
    <div className="top"><TopChips /><div className="title" /><button className="iconbtn" onClick={() => go('parent')} aria-label="Parent corner" title="Parent corner" data-testid="parent-btn"><Icon n="gear" /></button></div>
    <div className="main">
      <div className="center" style={{ position: 'relative' }}><h1>Language Quest</h1>{eq.title && <div className="chip" data-testid="fw-title">🏷️ {(eq.title.name && (eq.title.name.hyrule || eq.title.name.classic)) || eq.title.emoji}</div>}<SecretTap id="glint" className="glint" label="a glint in the forest" /></div>
      <div className="row c" style={{ alignItems: 'flex-end' }}><SafeImg className="hero" src={kitIcon('heroHappy')} fallback={null} style={{ height: 120 }} />{eq.buddy && <SafeImg className="buddy" src={imageFor(eq.buddy.image || eq.buddy.portrait)} fallback={<span className="emoji" style={{ fontSize: '2.4rem' }}>{eq.buddy.emoji}</span>} style={{ height: 84, borderRadius: '50%' }} />}{S.shop && (S.shop.owned || []).includes('shield') && <span className="emoji" style={{ fontSize: '2.2rem' }} title="Hylian shield">🛡️</span>}<Navi>{`Welcome back, ${S.nick}! Today is a ${LANG[tl].name} day.`}</Navi></div>
      {season() && <button className="card soft row" style={{ textAlign: 'left' }} onClick={() => go(S.fa.placed ? 'quest' : 'placement', { lang: 'fa', unit: season().unit })} data-testid="season"><span className="big">{season().icon}</span><span className="grow"><b>{season().name}</b> is coming! Play the {season().name} quest.</span></button>}
      <button className={`door big ${tl}`} onClick={() => open(tl)} data-testid={`door-${tl}`}>
        <div className="glyph emoji">{tl === 'fa' ? <SecretTap id="moon" taps={3} label="moon">{LANG[tl].glyph}</SecretTap> : LANG[tl].glyph}</div>
        <div className="lbl">{LANG[tl].name}</div>
        <div className="sub"><span lang={tl} className={tl === 'fa' ? 'fa' : ''}>{LANG[tl].native}</span> · {L.placed ? placeName(n) : 'Find your start'}</div>
      </button>
      <button className={`door bonus ${other}`} onClick={() => open(other)} data-testid={`door-${other}`}>
        <span className="glyph emoji">{other === 'fa' ? <SecretTap id="moon" taps={3} label="moon">{LANG[other].glyph}</SecretTap> : LANG[other].glyph}</span>
        <span className="lbl">Bonus: {LANG[other].name}</span>
        <span className="sub"><span lang={other} className={other === 'fa' ? 'fa' : ''}>{LANG[other].native}</span>{S[other].placed ? '' : ' · find your start'}</span>
      </button>
      {FW && <GoalBar />}
      {previewMode && <div className="fb info small center" data-testid="preview-note">Preview mode: progress won’t be saved here.</div>}
      <div className="muted small center" style={{ marginTop: 18, opacity: 0.8 }}>{credit()}</div>
    </div>
  </>);
}

// ---------- Language home: Hyrule Field map + one main action ----------
function LangHome({ lang }) {
  const { S, set, go } = useApp();
  const L = S[lang];
  const units = getUnits(lang);
  const n = currentUnit(L, units);
  const unit = units[n - 1];
  const place = PLACES[n];
  const did = L.lastDay === today();
  const wk = !L.weekly[weekKey()] && L.quests >= 2;
  const ai = S.settings.aiOn && getAIKey();
  return (<>
    <div className="top"><button className="iconbtn" onClick={() => go('home')} aria-label="Home" data-testid="back"><Icon n="back" /></button><div className="title">{LANG[lang].name}{isBonus(S, lang) ? ' (Bonus)' : ''} · Hyrule Field</div><TopChips /></div>
    <div className="main">
      <div className={`map ${mapTall() ? 'tall' : ''}`} data-testid="map">
        <div className="mapart" style={{ backgroundImage: mapArt() }} />
        {PLACES.slice(1).map((p, i) => {
          const k = i + 1; const u = L.units[k]; const done = u && u.done; const now = k === n; const lv = LEVELS.find((x) => x.id === L.level) || LEVELS[0];
          const pp = pinPos(k); return <div key={k} className={`pin ${done ? 'done' : now ? 'now' : k < lv.from ? '' : 'lock'}`} style={{ left: pp.x + '%', top: pp.y + '%' }} title={`${k}. ${placeName(k)}`}>{done ? '★' : k}</div>;
        })}
        {(() => { const pp = pinPos(3); return <SecretTap id="cow" className="critter" label="a cow" style={{ left: Math.min(94, pp.x + 5) + '%', top: Math.min(94, pp.y + 6) + '%' }}>🐄</SecretTap>; })()}
      </div>
      <div className="card center">
        <div className="row c"><Portrait who={place.teacher} size="sm" /><div style={{ textAlign: 'left' }}><div className="muted small">Place {n} · {levelOf(n).name}</div><h2 style={{ margin: 0 }}>{placeName(n)}</h2></div></div>
        {unit ? <div style={{ marginTop: 8 }}>🎯 <b>{unit.ican}</b></div> : <div className="muted">This place is still being built. Check back soon!</div>}
        {did && <div className="fb good" style={{ marginTop: 10 }}>✅ Today's quest is done! Come back tomorrow, or play again for extra practice.</div>}
      </div>
      {wk && <button className="card soft row" style={{ textAlign: 'left' }} onClick={() => go('weekly', { lang })} data-testid="weekly-btn"><span className="big">⭐</span><span className="grow"><b>Weekly challenge:</b> show your family what you can say!</span><span></span></button>}
      <div className="row c">
        <button className="btn sm" onClick={() => go('ican', { lang })} data-testid="ican-btn">🗺️ I can map</button>
        {lang === 'es' && <button className="btn sm" onClick={() => { set((s) => { s.es.fs = Object.assign({ done: {}, srs: {} }, s.es.fs || {}, { skipped: false, champion: (s.es.fs && s.es.fs.champion) || 0 }); }); go('fspath'); }} data-testid="fs-open">🌱 First Steps</button>}
        {lang === 'fa' && <button className="btn sm" onClick={() => go('script', { lang })} data-testid="script-btn">✍️ Letters</button>}
        {L.quests > 0 && <button className="btn sm" onClick={() => go('songs', { lang })} data-testid="songs-btn">🎵 Songbook</button>}
        {S.toys.ocarina && <button className="btn sm" onClick={() => go('ocarina', { lang, from: 'lang' })}>🎵 Ocarina</button>}
        {L.quests > 0 && <button className="btn sm" onClick={() => go(FW ? 'market' : 'shop', { lang })} data-testid="shop-btn">🛒 Shop</button>}
        {ai && <button className="btn sm" onClick={() => go('ai', { lang })}>💬 Talk</button>}
      </div>
    </div>
    <ActionBar><button className="btn primary wide" disabled={!unit} onClick={() => { sfx('tap'); go('quest', { lang, unit: n }); }} data-testid="start-quest">{did ? '⚔️ Extra practice quest' : '⚔️ Start today’s quest'}</button></ActionBar>
  </>);
}

// ---------- I can map ----------
function ICanMap({ lang }) {
  const { S, go } = useApp();
  const units = getUnits(lang);
  return (
    <div style={{ display: 'grid', gap: 14, position: 'relative' }} data-testid="ican">
      <SecretTap id="navi" className="hidnavi" label="a tiny fairy">🧚</SecretTap>
      {LEVELS.map((lv) => {
        const ns = Array.from({ length: lv.to - lv.from + 1 }, (_, k) => lv.from + k);
        const done = ns.every((n) => S[lang].units[n] && S[lang].units[n].done);
        return (
          <div key={lv.id} className="card">
            <div className="row"><h3 className="grow">{lv.name} <span className="muted small">({lv.grade})</span></h3>{done ? <button className="btn sm primary" onClick={() => go('cert', { lang, level: lv.id })}>🏅 Certificate</button> : <span className="muted small">🏅 at the end</span>}</div>
            <div className="plist">
              {ns.map((n) => {
                const u = units[n - 1]; if (!u) return <div key={n} className="prow muted"><span>{n}. {placeName(n)}</span><span>coming soon</span></div>;
                const st = unitStars(S[lang], u, unitItems(lang, n, S.settings.variety));
                const cnt = (st.w ? 1 : 0) + (st.s ? 1 : 0) + (st.b ? 1 : 0);
                return <div key={n} className="prow"><span><b>{n}.</b> {u.ican} <span className="muted small">· {placeName(n)}</span>{PLACES[n].reward ? <SafeImg src={(rewardImg(PLACES[n].reward) || {}).url} label={rewardNameK(PLACES[n].reward)} fallback={rewardIcon(PLACES[n].reward)} width={26} height={26} style={{ verticalAlign: 'middle', marginLeft: 6, opacity: st.b ? 1 : 0.35 }} /> : ''}</span><Stars n={cnt} /></div>;
              })}
            </div>
          </div>
        );
      })}
      <div className="muted small center">⭐ words learned · ⭐ speaking + writing tasks · ⭐ boss challenge</div>
    </div>
  );
}

function Certificate({ lang, level }) {
  const { S } = useApp();
  const lv = LEVELS.find((x) => x.id === level) || LEVELS[0];
  const units = getUnits(lang);
  return (
    <div className="card" data-testid="cert">
      <div className="cert">
        <div style={{ fontSize: '3rem' }}>🏅</div>
        <h1>Certificate of Courage</h1>
        <p>This certifies that hero</p>
        <h2 style={{ fontSize: '2rem' }}>{S.nick}</h2>
        <p>completed the <b>{lv.name}</b> level of <b>{LANG[lang].name}</b> in Language Quest and can say:</p>
        <ul style={{ textAlign: 'left', display: 'inline-block' }}>{Array.from({ length: lv.to - lv.from + 1 }, (_, k) => units[lv.from + k - 1]).filter(Boolean).map((u) => <li key={u.n}>{u.ican}</li>)}</ul>
        <p className="small">{new Date().toLocaleDateString()} · signed by {name('navi')} ✨</p>
      </div>
      <ActionBar><button className="btn primary wide" onClick={() => window.print()}>🖨️ Print</button></ActionBar>
    </div>
  );
}

// ---------- Chants: call and response with a strong beat, a gap to repeat, one gesture per line ----------
const GESTURES = [['👏', 'clap'], ['🦶', 'stomp'], ['👋', 'wave'], ['👉', 'point'], ['🙌', 'hands up'], ['🌀', 'spin'], ['🤸', 'jump'], ['🫶', 'hug yourself']];
// ---------- Ocarina songbook: each unit's key phrase has its own ORIGINAL 5-8 note tune ----------
const NOTE_IC = { D4: 'A', F4: '▼', A4: '▶', B4: '◀', D5: '▲' };
export function tuneFor(text) {
  const N = ['D4', 'F4', 'A4', 'B4', 'D5'];
  let h = 2166136261; for (const ch of text) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619) >>> 0; }
  for (let tries = 0; tries < 50; tries++) {
    const len = 5 + (h % 4); const out = []; let x = h;
    for (let i = 0; i < len; i++) { x = (Math.imul(x, 1103515245) + 12345) >>> 0; let n = N[(x >>> 8) % 5]; if (out.length >= 2 && out[out.length - 1] === n && out[out.length - 2] === n) n = N[((x >>> 8) + 1) % 5]; out.push(n); }
    const str = out.join(',');
    if (!SECRET_SONGS.some((sg) => str.includes(sg.notes.join(',')) || str.includes(sg.notes.slice(0, 5).join(',')))) return out;
    h = (Math.imul(h, 31) + 7) >>> 0;
  }
  return ['D4', 'A4', 'F4', 'D5', 'B4'];
}
function SongDoor({ lang, unit, onBack }) {
  const { S, set } = useApp();
  const ph = unit.phrases && unit.phrases[0] ? T(lang, unit.phrases[0], S.settings.variety) : T(lang, unit.song.lines[0]);
  const tune = useMemo(() => tuneFor(ph.t), [ph.t]);
  const [pos, setPos] = useState(0);
  const [phase, setPhase] = useState('tune');
  const [lit, setLit] = useState(-1);
  const ref = useRef(null); const posRef = useRef(0);
  useEffect(() => {
    if (phase !== 'tune') return;
    const O = globalThis.HyruleOcarina; if (!O || !ref.current) return;
    let h; try { h = O.mount(ref.current, { keys: true, title: 'Play the tune', size: 'small', onNote: (nm) => { if (nm === tune[posRef.current]) { posRef.current++; setPos(posRef.current); if (posRef.current >= tune.length) setTimeout(() => setPhase('line'), 600); } else { posRef.current = nm === tune[0] ? 1 : 0; setPos(posRef.current); } } }); } catch (e) { return; }
    return () => { try { h.destroy(); } catch (e) {} };
  }, [phase]);
  const words = ph.t.split(/\s+/);
  const karaoke = async () => { let k = 0; setLit(0); const iv = setInterval(() => { k++; setLit(k); if (k >= words.length) clearInterval(iv); }, 420); await say(lang, ph.say); clearInterval(iv); setLit(words.length); };
  useEffect(() => { if (phase === 'line') karaoke(); }, [phase]);
  if (phase === 'done') return <div className="card center" data-testid="door-open"><div className="reward"><div className="item emoji">🚪✨</div></div><h2>The temple door opens!</h2><Navi>{'You played the tune and said the words!'}</Navi><ActionBar><button className="btn primary wide" onClick={onBack} data-testid="next">Back to the songbook</button></ActionBar></div>;
  if (phase === 'line') return <VoiceAnswer lang={lang} sayText={ph.say} targets={[ph.t, ph.w].filter(Boolean)} opts={[{ x: ph, ok: true }]} praise="🚪✨" label="Sing or say it"
    prompt={<><h3>🎶 Now sing or say the words</h3><div className={`karaoke ${lang === 'fa' ? 'fa' : ''}`} dir={lang === 'fa' ? 'rtl' : 'ltr'} lang={lang}>{words.map((w, i) => <span key={i} className={i < lit ? 'on' : ''}>{w} </span>)}</div>{lang === 'fa' && <div className="tr center">{ph.tr}</div>}<div className="muted center">{ph.en}</div><div className="center"><button className="linkbtn" onClick={karaoke}>🔁 Hear it again</button></div></>}
    onDone={() => { sfx('chest'); set((s) => { s[lang].songs = s[lang].songs || {}; if (!s[lang].songs[unit.n]) s.rupees += 10; s[lang].songs[unit.n] = true; }); setPhase('done'); }} />;
  return (
    <div className="card center" data-testid="songbook-tune">
      <h3>🎵 {placeName(unit.n)}: the song of “{lang === 'fa' ? ph.tr : ph.t}”</h3>
      <div className="tune">{tune.map((n, i) => <span key={i} className={`tn ${i < pos ? 'done' : i === pos ? 'now' : ''}`}>{NOTE_IC[n]}</span>)}</div>
      <div className="muted small">Play the notes on the ocarina: tap the buttons or use keys A ▼ ▶ ◀ ▲ (1–5).</div>
      <div ref={ref} style={{ margin: '10px auto', maxWidth: 560 }} />
      {!globalThis.HyruleOcarina && <div className="ocarina">{Object.entries(NOTE_IC).map(([n, ic]) => <button key={n} onClick={() => { ocarinaNote({ D4: 62, F4: 65, A4: 69, B4: 71, D5: 74 }[n]); if (n === tune[posRef.current]) { posRef.current++; setPos(posRef.current); if (posRef.current >= tune.length) setTimeout(() => setPhase('line'), 600); } else { posRef.current = 0; setPos(0); } }}>{ic}</button>)}</div>}
      <ActionBar><button className="btn ghost" onClick={onBack}>Back</button><button className="btn wide" onClick={() => setPhase('line')} data-testid="skip-tune">Skip the tune</button></ActionBar>
    </div>
  );
}
function Songs({ lang }) {
  const { S, set } = useApp();
  const [door, setDoor] = useState(null);
  const units = getUnits(lang).filter((u, i) => u && u.song && (S[lang].units[i + 1] || i + 1 === currentUnit(S[lang], getUnits(lang))));
  const [sel, setSel] = useState(null);
  const [line, setLine] = useState(-1);
  const [turn, setTurn] = useState(false);
  const playing = useRef(false);
  const beat = (n) => { for (let b = 0; b < n; b++) { const M = HM(); if (M && M.note) { try { M.note('drums', 'kick', { when: b * 0.5 }); } catch (e) { tone(70, b * 0.5, 0.15, 'sine', 0.2); } } else tone(70, b * 0.5, 0.15, 'sine', 0.2); } };
  const play = async (u) => {
    playing.current = true;
    const lines = u.song.lines.map((l) => T(lang, l));
    for (let k = 0; k < lines.length && playing.current; k++) {
      setLine(k); setTurn(false); beat(2);
      await new Promise((r) => setTimeout(r, 900));
      const t0 = Date.now(); await say(lang, lines[k].say); const dur = Date.now() - t0;
      if (!playing.current) break;
      setTurn(true); beat(Math.max(2, Math.round((dur + 800) / 500)));
      await new Promise((r) => setTimeout(r, Math.max(1600, dur + 900)));
    }
    if (playing.current) set((s) => { s.treasure.flags.chant = 1; }); // whole chant done with the moves
    setLine(-1); setTurn(false); playing.current = false;
  };
  useEffect(() => () => { playing.current = false; stopAudio(); }, []);
  if (door) return <SongDoor lang={lang} unit={door} onBack={() => setDoor(null)} />;
  if (sel) {
    const lines = sel.song.lines.map((l) => T(lang, l));
    const title = T(lang, sel.song.title);
    return (
      <div className="card" data-testid="song">
        <h2>🥁 {title.tr ? title.tr : title.t}</h2>
        <Navi small>{'Navi sings a line, then it is your turn: say it back and do the move!'}</Navi>
        <div style={{ display: 'grid', gap: 6, marginTop: 10 }}>{lines.map((l, k) => <div key={k} className={`lyric ${k === line ? 'on' : ''}`}><span className="emoji" style={{ fontSize: '1.6rem', marginRight: 8 }}>{GESTURES[k % GESTURES.length][0]}</span><TT lang={lang} x={l} showTr={lang === 'fa'} /><div className="muted small">{l.en} · {GESTURES[k % GESTURES.length][1]}{k === line && turn ? <b> · Your turn!</b> : null}</div></div>)}</div>
        <ActionBar><button className="btn" onClick={() => { playing.current = false; stopAudio(); setSel(null); }}>Back</button><button className="btn primary wide" onClick={() => play(sel)} data-testid="sing">▶️ Start the chant</button></ActionBar>
      </div>
    );
  }
  return <div className="card" data-testid="songbook"><h2>🎵 Ocarina songbook</h2><Navi small>{'Play each place\'s tune, then sing its words to open the temple door. Or do the chant!'}</Navi>
    <div className="plist" style={{ marginTop: 10 }}>{units.map((u) => <div key={u.n} className="prow"><span>{(S[lang].songs || {})[u.n] ? '🚪✨' : '🎵'} {u.n}. {placeName(u.n)}</span><span className="row"><button className="btn sm primary" onClick={() => setDoor(u)} data-testid="song-door">Play the tune</button><button className="btn sm" onClick={() => setSel(u)}>🥁 Chant</button></span></div>)}</div>{!units.length && <div className="muted">Songs appear as you visit places.</div>}</div>;
}

// ---------- Ocarina toy (5 notes; free play) ----------
function Ocarina() {
  const { S, set } = useApp();
  const findT = useFind();
  const ref = useRef(null);
  const [msg, setMsg] = useState(null);
  const lang = todayLang(S);
  const hist = useRef([]);
  const fallbackNotes = [[62, 'D4', 'A'], [65, 'F4', '▼'], [69, 'A4', '▶'], [71, 'B4', '◀'], [74, 'D5', '▲']];
  const onNote = (nm) => {
    hist.current = [...hist.current, nm].slice(-6);
    const h = hist.current.join(',');
    const sg = SECRET_SONGS.find((x) => x.notes.join(',') === h);
    if (sg) {
      hist.current = [];
      const x = lang === 'es' ? { t: sg.es, say: sg.es } : T('fa', sg.fa);
      const first = !(S.secrets || {})[sg.id];
      set((s) => { s.secrets = s.secrets || {}; if (!s.secrets[sg.id]) { s.secrets[sg.id] = Date.now(); s.hp4 = (s.hp4 || 0) + 1; if (s.hp4 >= 4) { s.hp4 = 0; s.hc = (s.hc || 0) + 1; } } });
      setMsg({ x, first }); setTimeout(() => say(lang, x.say), 700); sfx('chest'); findT('song');
    }
  };
  useEffect(() => {
    const O = globalThis.HyruleOcarina;
    if (!O || !ref.current) return;
    let h; try { h = O.mount(ref.current, { keys: true, title: 'Ocarina', onNote }); } catch (e) { return; }
    return () => { try { h.destroy(); } catch (e) {} };
  }, []);
  const has = !!globalThis.HyruleOcarina;
  return (
    <div className="card center" data-testid="ocarina">
      <h2>🎵 Your ocarina</h2>
      <Navi small>{'Make up your own melodies! Maybe you know a secret song?'}</Navi>
      <div ref={ref} style={{ margin: '14px auto', maxWidth: 560 }} />
      {!has && <div className="ocarina" style={{ margin: '18px 0' }}>{fallbackNotes.map((n, k) => <button key={k} onClick={() => { ocarinaNote(n[0]); onNote(n[1]); }} aria-label={`Note ${k + 1}`}>{n[2]}</button>)}</div>}
      {msg && <div className="fb good" data-testid="secret-song"><TT lang={lang} x={msg.x} showTr={lang === 'fa'} showW={false} /> {msg.first ? <div>🫀 You found a heart piece!</div> : null}</div>}
    </div>
  );
}

// ---------- Rupee shop (inside the map screen): the keeper speaks only the target language ----------
function Shop({ lang }) {
  const { S, set } = useApp();
  const [pick, setPick] = useState(null);
  const [said, setSaid] = useState(null);
  const owned = [...((S.shop && S.shop.owned) || []), ...(FW ? SHOP.items.filter((x) => { try { return FW.owns('language.' + x.id); } catch (e) { return false; } }).map((x) => x.id) : [])];
  const hello = lang === 'es' ? { ...SHOP.hello.es, say: SHOP.hello.es.t } : T('fa', SHOP.hello.fa);
  useEffect(() => { const t = setTimeout(() => say(lang, hello.say), 400); return () => clearTimeout(t); }, []);
  if (pick) {
    const it = pick;
    const phrase = lang === 'es' ? { t: it.es[1], say: it.es[1] } : T('fa', it.fa[1]);
    const wrong = lang === 'es' ? SHOP.wrong.es(it.es[0]).map((w) => ({ x: { t: w }, ok: false })) : SHOP.wrong.fa(it.fa[0]).map((w) => ({ x: T('fa', w), ok: false }));
    const bal = FW ? ((FW.balance() || {}).rupees || 0) : S.rupees;
    const enough = bal >= it.price;
    if (!enough) { const m = lang === 'es' ? { ...SHOP.more.es, say: SHOP.more.es.t } : T('fa', SHOP.more.fa); return <div className="card center"><Portrait who="talon" size="lg" /><div className="big row c"><PlayBtn lang={lang} text={m.say} sm auto /><TT lang={lang} x={m} showW={false} /></div><ActionBar><button className="btn primary wide" onClick={() => setPick(null)}>OK</button></ActionBar></div>; }
    if (said) { const th = lang === 'es' ? { ...SHOP.thanks.es, say: SHOP.thanks.es.t } : T('fa', SHOP.thanks.fa); return <div className="card center" data-testid="shop-bought"><Portrait who="talon" size="lg" /><div className="reward"><div className="item emoji">{it.icon}</div></div><div className="big row c"><PlayBtn lang={lang} text={th.say} sm auto /><TT lang={lang} x={th} showW={false} /></div><div>{it.en} is yours!</div><ActionBar><button className="btn primary wide" onClick={() => { setPick(null); setSaid(null); }} data-testid="next">Back to the shop</button></ActionBar></div>; }
    return <VoiceAnswer lang={lang} sayText={phrase.say} targets={[phrase.t, phrase.w].filter(Boolean)} opts={[{ x: phrase, ok: true }, ...wrong]} praise="🛒"
      prompt={<><div className="row c"><Portrait who="talon" size="sm" /><div className="huge emoji">{it.icon}</div></div><Navi small>{'Ask for it in ' + LANG[lang].name + '! (Tap 🔈 to hear how.)'}</Navi><div className="row c"><PlayBtn lang={lang} text={phrase.say} sm /><span className="muted">{lang === 'es' ? '' : ''}{it.en} · {it.price} 💎</span></div></>}
      onDone={(r) => { if (r.ok || r.close) { sfx('rupee'); if (FW) { try { const b = FW.buy('language.' + it.id); if (b.ok || b.why === 'owned') { const sl = it.id.startsWith('tunic') ? 'language.tunic' : it.id.startsWith('navi') ? 'language.navi' : 'language.shield'; FW.equip(sl, 'language.' + it.id); } } catch (e) {} } set((s) => { if (!FW) s.rupees -= it.price; s.shop = s.shop || { owned: [] }; s.shop.owned = [...new Set([...(s.shop.owned || []), it.id])]; if (it.id.startsWith('tunic')) s.shop.tunic = it.id; if (it.id.startsWith('navi')) s.shop.navi = it.id; }); setSaid(true); } else setPick(null); }} />;
  }
  return (
    <div className="card" data-testid="shop">
      <div className="row"><Portrait who="talon" size="sm" /><div className="grow"><div className="big row"><PlayBtn lang={lang} text={hello.say} sm /><TT lang={lang} x={hello} showW={false} /></div><div className="muted small">The shopkeeper only speaks {LANG[lang].name}!</div></div><span className="chip">💎 {FW ? ((FW.balance() || {}).rupees || 0) : S.rupees}</span></div>
      <div className="choices" style={{ marginTop: 12 }}>
        {SHOP.items.map((it) => <button key={it.id} className={`choice ${owned.includes(it.id) ? 'right' : ''}`} onClick={() => !owned.includes(it.id) && setPick(it)} data-testid={`shop-${it.id}`}><span className="pic emoji">{it.icon}</span><span>{it.en}</span><span className="sub">{owned.includes(it.id) ? 'yours ✓' : it.price + ' 💎'}</span></button>)}
      </div>
    </div>
  );
}

// ---------- Weekly "show your family" speaking task ----------
function Weekly({ lang }) {
  const { S, set, go } = useApp();
  const units = getUnits(lang);
  const n = currentUnit(S[lang], units);
  const u = units[n - 1] || units.find(Boolean);
  const model = ((u && u.speak && u.speak.model) || []).map((m) => T(lang, m, S.settings.variety)).slice(0, 3);
  const [done, setDone] = useState(false);
  return (
    <div className="card center" data-testid="weekly">
      <h2>⭐ Show your family!</h2>
      <Navi>{'Practice these sentences, then say them to your family. A video call with a relative counts too!'}</Navi>
      <div style={{ display: 'grid', gap: 8, margin: '12px 0' }}>{model.map((m, k) => <div key={k} className="ex row"><PlayBtn lang={lang} text={m.say} sm /><div style={{ textAlign: 'left' }}><TT lang={lang} x={m} showTr={lang === 'fa'} /><div className="muted small">{m.en}</div></div></div>)}</div>
      {done ? <div className="reward"><div className="item emoji">❤️</div><h3>+1 heart container!</h3></div> : null}
      <ActionBar>{done ? <button className="btn primary wide" onClick={() => go('lang', { lang })}>Back</button> : <button className="btn primary wide" onClick={() => { sfx('win'); setDone(true); set((s) => { s[lang].weekly[weekKey()] = true; s.hc = (s.hc || 0) + 1; }); }} data-testid="weekly-done">👪 I showed my family!</button>}</ActionBar>
    </div>
  );
}

// ---------- Optional AI villager chat ----------
function AIChat({ lang }) {
  const { S, set } = useApp();
  const n = currentUnit(S[lang], getUnits(lang));
  const who = PLACES[n].teacher;
  const [msgs, setMsgs] = useState([]);
  const [val, setVal] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const ref = useRef(null);
  const day = Math.floor(Date.now() / 86400000);
  const used = S.ai.day === day ? S.ai.used : 0;
  const learned = allItems(lang, S.settings.variety).filter((it) => S[lang].srs[it.id]).slice(-120).map((it) => it.t + ' (' + it.en + ')').join(', ');
  const system = `You are ${name(who)}, a friendly character in a kids' language-learning adventure game. You chat with a 9-year-old learner in ${lang === 'es' ? 'Latin American Spanish' : 'everyday spoken Tehrani Persian (Farsi), written in Persian script with a transliteration in parentheses'}. Rules: keep every reply to 1-3 very short sentences. Use mostly these words the learner knows: ${learned || 'basic greetings'}; add at most 1-2 new words and give their English meaning in brackets. If the learner makes a mistake, gently show the correct version first ("Tip: ..."), then continue. Always be kind, encouraging and age-appropriate. Never ask for or repeat personal information (real names, address, school, phone, photos). Avoid scary, violent, romantic or adult topics; steer back to the game world (forest, ranch, village, animals, food, school, family). If asked for something unsafe, kindly change the subject.`;
  const send = async () => {
    const text = val.trim(); if (!text || busy) return;
    if (used >= S.settings.aiCap) { setErr('That’s all the chat for today. See you tomorrow!'); return; }
    const key = getAIKey(); if (!key) { setErr('Ask a grown-up to add the AI key in the Parent corner.'); return; }
    const nm = [...msgs, { role: 'user', content: text }]; setMsgs(nm); setVal(''); setBusy(true); setErr('');
    try {
      const j = await aiMessage({ body: { max_tokens: 250, system, messages: nm.slice(-12) }, model: S.settings.aiDetected ? S.settings.aiModel : null, onModel: (m) => set((s) => { s.settings.aiModel = m; s.settings.aiDetected = true; }) });
      const out = (j.content || []).map((c) => c.text || '').join('').trim();
      setMsgs([...nm, { role: 'assistant', content: out }]);
      set((s) => { if (s.ai.day !== day) { s.ai.day = day; s.ai.used = 0; } s.ai.used++; s.ai.tokens += ((j.usage && j.usage.input_tokens) || 0) + ((j.usage && j.usage.output_tokens) || 0); });
    } catch (e) { setErr('The villager could not answer right now. (' + String(e.message || e).slice(0, 80) + ')'); }
    setBusy(false);
  };
  return (
    <div className="card" data-testid="ai-chat">
      <div className="row"><Portrait who={who} size="sm" /><h3 className="grow">Chat with {name(who)}</h3><span className="chip">💬 {Math.max(0, S.settings.aiCap - used)} left today</span></div>
      <div style={{ display: 'grid', gap: 8, margin: '12px 0', maxHeight: '50vh', overflow: 'auto' }}>
        {msgs.map((m, k) => <div key={k} className={`fb ${m.role === 'user' ? 'info' : 'good'}`} dir="auto" lang={lang}>{m.role === 'assistant' && <PlayBtn lang={lang} text={m.content.replace(/\(.*?\)|\[.*?\]/g, '')} sm />} {m.content}</div>)}
        {!msgs.length && <Navi small>Say hi to {name(who)}! Write in {LANG[lang].name}.</Navi>}
      </div>
      {err && <div className="fb try">{err}</div>}
      <input ref={ref} className="field" dir="auto" value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} placeholder="Type a message" />
      {lang === 'es' && <div style={{ marginTop: 8 }}><AccentBar onInsert={(c) => insertAt(ref, val, setVal, c)} /></div>}
      <ActionBar><button className="btn primary wide" disabled={busy || !val.trim()} onClick={send}>{busy ? '…' : 'Send'}</button></ActionBar>
    </div>
  );
}

// ---------- boot ----------
window.__lqBoot = true;
LS();
createRoot(document.getElementById('root')).render(<App />);
const poster = document.getElementById('poster'); if (poster) poster.remove();
try {
  // service worker only on http(s) (never from file:// or the sandboxed preview)
  if (!previewMode && /^https?:$/.test(location.protocol) && 'serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
} catch (e) { /* opaque origin (sandboxed preview): no service worker */ }
