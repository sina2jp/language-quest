# Farsi unit file schema — /tmp/lq/content/fa/uNN.json (NN = 01..20)

The learner is a 9-year-old who UNDERSTANDS SOME Farsi from home, speaks little and cannot read yet.
Listening/speaking come first in the everyday spoken TEHRANI register; reading/writing use the standard written forms.
So every Farsi text is an "F-object":

  {"f": "<spoken Tehrani form in Persian script>", "t": "<transliteration of the spoken form>",
   "w": "<standard written form>", "wt": "<transliteration of the written form>", "en": "<English>"}

  "w"/"wt" appear ONLY when the written form differs from the spoken one (mikhâm / mikhâham, khune / khâne, nun / nân,
  bozorg-e / bozorg ast). For most nouns they are identical: omit w/wt.

One JSON object per file, UTF-8, no comments. Validate each file after writing:
  python3 -c "import json,sys; d=json.load(open(sys.argv[1])); print(d['n'], len(d['words']), len(d['phrases']))" /tmp/lq/content/fa/u01.json

Example (shortened — real files need the full counts listed below):
{
 "n": 1,
 "theme": "Greetings & polite phrases",
 "title": {"f": "سلام!", "t": "salâm!", "en": "Hello!"},
 "ican": "I can greet people politely.",
 "goals": ["I can say hello and goodbye.", "I can say thank you and you're welcome.", "I can ask how someone is."],
 "grammar": {
  "name": "Pronouns: man, to, u ...",
  "explain": "man = I, to = you (a friend), shomâ = you (polite, or many people). Use shomâ with grown-ups you don't know well.",
  "examples": [{"f": "من خوبم.", "t": "man khubam.", "w": "من خوب هستم.", "wt": "man khub hastam.", "en": "I am fine."}],
  "practice": [
   {"q": {"f": "___ خوبم.", "t": "___ khubam.", "en": "I am fine."},
    "opts": [{"f": "من", "t": "man"}, {"f": "تو", "t": "to"}], "a": 0,
    "why": ["khubam ends in -am, so it is 'I'", "to always comes first"], "wa": 0, "mt": "verb"}
  ]
 },
 "words": [
  {"f": "سلام", "t": "salâm", "en": "hello", "e": "👋",
   "ex": {"f": "سلام مامان!", "t": "salâm mâmân!", "en": "Hello Mom!"}},
  {"f": "خونه", "t": "khune", "w": "خانه", "wt": "khâne", "en": "house, home", "e": "🏠",
   "ex": {"f": "خونه‌ی ما بزرگه.", "t": "khune-ye mâ bozorg-e.", "w": "خانه‌ی ما بزرگ است.", "wt": "khâne-ye mâ bozorg ast.", "en": "Our house is big."}}
 ],
 "phrases": [
  {"f": "حالت چطوره؟", "t": "hâlet chetore?", "w": "حالت چطور است؟", "wt": "hâlat chetor ast?", "en": "How are you?", "e": "🙂"}
 ],
 "speak": {"task": "Greet Saria, say you are fine, and thank her.", "pic": "🧚🌳😀",
           "model": [{"f": "سلام ساریا!", "t": "salâm Sâriyâ!", "en": "Hello Saria!"}]},
 "write": {
  "copy": [{"f": "سلام", "t": "salâm", "en": "hello"}],
  "fill": [{"t": {"f": "من ___ م.", "t": "man ___-am.", "en": "I am fine."}, "a": {"f": "خوب", "t": "khub"},
            "opts": [{"f": "خوب", "t": "khub"}, {"f": "سلام", "t": "salâm"}, {"f": "مرسی", "t": "mersi"}], "mt": "word"}],
  "build": [{"w": [{"f": "من", "t": "man"}, {"f": "خوبم", "t": "khubam"}], "en": "I am fine."}],
  "one": {"prompt": "Write how you are today.", "model": {"f": "من خوبم.", "t": "man khubam.", "en": "I am fine."},
          "keys": [{"f": "خوبم", "t": "khubam"}]},
  "three": {"pic": "🧒👋👵☕", "prompt": "Write 3 sentences: you visit your grandma.",
            "model": [{"f": "سلام مامان‌بزرگ!", "t": "salâm mâmân-bozorg!", "en": "Hi Grandma!"}],
            "keys": [{"f": "سلام", "t": "salâm"}]}
 },
 "culture": {"title": "Ta'arof", "text": "Iranians love polite back-and-forth called ta'arof. A host offers tea again and again; guests often say 'no, thank you' at first."},
 "role": {"who": "Saria", "lines": [
   {"npc": {"f": "سلام! حالت چطوره؟", "t": "salâm! hâlet chetore?", "en": "Hi! How are you?"},
    "opts": [{"f": "خوبم، مرسی!", "t": "khubam, mersi!", "en": "I'm fine, thanks!"}, {"f": "خداحافظ!", "t": "khodâhâfez!", "en": "Goodbye!"}], "a": 0}]},
 "boss": {"intro": "A Mad Scrub pops out of the grass! Answer him in Farsi to calm him down.",
          "win": "The Mad Scrub smiles: he only wanted someone to be polite to him!",
          "lines": [{"q": {"f": "حالت چطوره؟", "t": "hâlet chetore?", "en": "How are you?"},
                     "opts": [{"f": "خوبم، مرسی.", "t": "khubam, mersi."}, {"f": "سیب قرمزه.", "t": "sib ghermez-e."}, {"f": "سه تا.", "t": "se tâ."}], "a": 0}]},
 "song": {"title": {"f": "آهنگ سلام", "t": "âhang-e salâm", "en": "The hello song"},
          "lines": [{"f": "سلام سلام، حالت چطوره؟", "t": "salâm salâm, hâlet chetore?", "en": "Hello hello, how are you?"}]}
}

## Required counts per unit
- words: 35 (at least 30) in TEACHING ORDER (most essential first; the first ~12 must suit a K-2 "Sprout" learner).
  Each word: "e" = 1 emoji (max 2) picturing it; "ex" = F-object example sentence (3-8 words, mostly known words).
- phrases: 12-13 (at least 10) F-objects + "e" emoji.
- grammar.examples 3-4 F-objects; grammar.practice 8 items (2-3 opts each, one correct; "why" = 2-3 short English reasons,
  exactly one true (index "wa"); "mt" = verb | order | spelling | word).
- write.copy 2, write.fill 4, write.build 4 (tiles in correct SPOKEN order, 2-6 tiles), write.one 1, write.three 1.
- role.lines 4-5 with the unit's teacher (see units.md); boss.lines 6 (3 opts, one correct); song.lines 4-8 ORIGINAL,
  simple, rhythmic, singable lines that repeat the unit's words (never lyrics of any existing song).
- culture: 1-3 sentences in English, real Iranian culture (Nowruz, Yalda, ta'arof, food, places...).

## Language rules
- Iranian Persian. Spoken = natural everyday Tehrani speech; written = standard modern written Persian.
- Persian letters only: ی and ک (never Arabic ي ك), ZWNJ (U+200C) where standard (می‌خواهم, کتاب‌ها, خانه‌ی).
  For spoken forms use the common informal spelling (می‌خوام, خونه, نون, بزرگه).
- Persian digits ۰۱۲۳۴۵۶۷۸۹ inside Persian text (numbers unit: give the digit with each number word, e.g. "e": "5️⃣" and add "d": "۵").
- Transliteration (kid-friendly, consistent): â = long "aa" as in father (آ / ا); a = short a as in cat; e = as in bed;
  o = as in go (short); u = "oo" as in moon; i = "ee" as in see; kh = خ; gh = غ and ق; sh, ch, zh (ژ), j, y;
  ' only where a stop is clearly heard (sâ'at). Ezafe = "-e" (ketâb-e man), after a vowel "-ye" (khune-ye mâ).
  Spoken copula "-e" after a consonant (bozorg-e). Capitalize nothing except names.
- Family words to include in the family unit: mâmân, bâbâ, mâdar, pedar, khâhar, barâdar, amu, amme, khâle, dâyi,
  mâmân-bozorg, bâbâ-bozorg, pesar-amu/dokhtar-khâle (cousins), etc.
- Every string must be correct and natural. If you are unsure of anything, add "flag": "<why>" on that item.
  An independent reviewer will check everything.
- Kid-safe, warm, funny where possible. Examples mostly about the player's real life (family, home, food, school);
  sometimes use Hyrule characters: Link لینک, Navi ناوی, Saria ساریا, Zelda زلدا, Impa ایمپا, Darunia دارونیا, Ruto روتو, Malon مالون.
- Never write any real child's name. Refer to the learner as "the player".
- Avoid putting a word in your unit if it clearly belongs to another unit's theme (see units.md).
- Shahnameh content stays kid-friendly (Rostam and Rakhsh, Zal and the Simorgh, Kaveh; no tragedies, no gore).
