// Loads the team's Hyrule kit (skin contract + music + ocarina) and its image pack (one binary file + index).
import './kit/skin.js';
import './kit/music.js';
import './kit/ocarina.js';
import { getPack, KITIDX } from './packs.js';
import { setKitOn } from './skin.js';

export async function loadKitPack(base = 'kit/') {
  const H = globalThis.HyruleKit; if (!H) return false;
  H.setBase(base);
  try {
    const idx = KITIDX;
    const bufs = await Promise.all(idx.packs.map((pk) => getPack(base + pk, base + pk.replace('.bin', '.js'), pk)));
    const urls = {};
    for (const [p, [pi, off, len, type]] of Object.entries(idx.files)) urls[p] = URL.createObjectURL(new Blob([bufs[pi].slice(off, off + len)], { type }));
    const orig = H.url.bind(H);
    // a kit image that is not in the pack resolves to '' (never to a file that does not exist)
    H.url = (p) => urls[p] || (/\.(webp|png|jpg|svg)$/i.test(p || '') && !/^(https?:|data:|blob:)/.test(p || '') ? '' : orig(p));
    const prune = (o) => {
      if (!o || typeof o !== 'object') return;
      for (const k of Object.keys(o)) {
        const v = o[k];
        if (typeof v === 'string' && /\.(webp|png|jpg|svg)$/.test(v) && !urls[v] && /^(\d+|wide|tall|src|img|icon)$/.test(k)) delete o[k];
        else if (v && typeof v === 'object') { prune(v); if (!Array.isArray(v) && Object.keys(v).length === 0) delete o[k]; }
      }
    };
    prune(H.skins);
    // HyruleKit.src falls back to ANY available size of the same picture (never an empty answer when one exists)
    const src0 = H.src.bind(H);
    H.src = function (ref, px) {
      let u = ''; try { u = src0(ref, px); } catch (e) { u = ''; }
      if (u) return u;
      if (ref && typeof ref === 'object') for (const v of Object.values(ref)) if (typeof v === 'string' && urls[v]) return urls[v];
      return '';
    };
    setKitOn(true);
    return true;
  } catch (e) { console.info('kit pack not loaded', e && e.message); return false; }
}
export const HM = () => globalThis.HyruleMusic || null;
