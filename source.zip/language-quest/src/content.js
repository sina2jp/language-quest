// Content model: normalizes the generated unit JSON (content.gen.js) into items and tasks.
import RAW from './content.gen.js';
import VOC from './vocabpics.gen.js';
// painted vocabulary pictures (static script packs fill window.VOCABPICS); emoji stay the fallback
globalThis.__lqIcon = (item) => { const f = item && VOC.byId[item.id]; const P = globalThis.VOCABPICS; return f && P && P[f] ? P[f] : null; };
globalThis.__lqPicKey = (item) => { const f = item && VOC.byId[item.id]; return f ? 'pic:' + f : null; };
import { fnv, stripAcc } from './engine.js';

export const LANG = {
  es: { id: 'es', name: 'Spanish', native: 'Español', glyph: '☀️', door: 'es' },
  fa: { id: 'fa', name: 'Farsi', native: 'فارسی', glyph: '🌙', door: 'fa' },
};

// Unified text: { t: target (spoken), tr: transliteration, w/wt: written form (Farsi), en, say: text for audio }
export function T(lang, x, variety, en) {
  if (x == null) return { t: '', en: en || '', say: '' };
  if (lang === 'es') {
    if (typeof x === 'string') return { t: x, say: x, en: en || '' };
    if (Array.isArray(x)) return { t: x[0], say: x[0], en: x[1] || '' };
    const t = variety === 'es-ES' && x.esp ? x.esp : x.es || x.t || '';
    return { t, say: t, en: x.en || en || '' };
  }
  if (typeof x === 'string') return { t: x, say: x, en: en || '' };
  return { t: x.f || '', tr: x.t || '', w: x.w || '', wt: x.wt || '', en: x.en || en || '', say: x.f || '' };
}
export const fill = (q, o) => ({ ...q, t: (q.t || '').replace(/_{2,}/, o.t || ''), say: (q.say || q.t || '').replace(/_{2,}/, o.t || ''),
  tr: q.tr ? q.tr.replace(/_{2,}/, o.tr || '') : q.tr, w: q.w ? q.w.replace(/_{2,}/, o.w || o.t || '') : q.w });

const units = { es: [], fa: [] };
for (const lang of ['es', 'fa']) for (let n = 1; n <= 20; n++) units[lang][n - 1] = (RAW[lang] && RAW[lang][n]) || null;
export const getUnits = (lang) => units[lang];
export const getUnit = (lang, n) => units[lang][n - 1];

const memo = {};
export function unitItems(lang, n, variety = 'es-MX') {
  const k = lang + n + variety;
  if (memo[k]) return memo[k];
  const u = getUnit(lang, n);
  if (!u) return (memo[k] = []);
  const mk = (x, i, kind) => {
    const base = T(lang, x, variety);
    let ex;
    if (lang === 'es') ex = { t: (variety === 'es-ES' && x.exEsp) || x.ex || '', en: x.exEn || '' };
    else ex = x.ex ? T('fa', x.ex) : { t: '', en: '' };
    ex.say = ex.t;
    return { id: `${lang}${n}${kind}${i}`, lang, n, kind, ...base, b: lang === 'es' ? x.es || '' : x.f || '', e: x.e || '✨', g: x.g || '', fem: x.fem || '', d: x.d || '', ex, flag: x.flag || '' };
  };
  return (memo[k] = [...(u.words || []).map((x, i) => mk(x, i, 'w')), ...(u.phrases || []).map((x, i) => mk(x, i, 'p'))]);
}
export function allItems(lang, variety) { const out = []; for (let n = 1; n <= 20; n++) out.push(...unitItems(lang, n, variety)); return out; }
export const itemById = (lang, id, variety) => allItems(lang, variety).find((x) => x.id === id);

// Spanish helpers for writing feedback: accent map and noun genders from the word list
let esKnown = null;
export function esLexicon() {
  if (esKnown) return esKnown;
  const known = {}, genders = {};
  for (const it of allItems('es')) {
    if (it.kind !== 'w') continue;
    const parts = it.t.toLowerCase().split(' ');
    const w = parts.length > 1 && /^(el|la|los|las)$/.test(parts[0]) ? parts.slice(1).join(' ') : it.t.toLowerCase();
    if (w.indexOf(' ') < 0) { if (stripAcc(w) !== w) known[stripAcc(w)] = w; if (it.g) genders[stripAcc(w)] = it.g; }
    if (it.fem && stripAcc(it.fem) !== it.fem) known[stripAcc(it.fem)] = it.fem;
  }
  return (esKnown = { known, genders });
}

// Spanish–Farsi–English triplets (matched by English meaning)
export function triplets(variety) {
  const key = (s) => (s || '').toLowerCase().replace(/\(.*?\)/g, '').replace(/^to /, '').split(/[,;/]/)[0].trim();
  const fa = {};
  for (const it of allItems('fa')) if (it.kind === 'w') { const k = key(it.en); if (k && !fa[k]) fa[k] = it; }
  const out = [];
  for (const it of allItems('es', variety)) if (it.kind === 'w') { const k = key(it.en); if (k && fa[k]) out.push({ en: k, es: it, fa: fa[k], e: it.e }); }
  return out;
}

// Owl stories: one per unit, parts reference target words by their text
export const getStory = (lang, n) => (RAW.story && RAW.story[lang] && RAW.story[lang][n]) || null;
const nt = (lang, s) => (lang === 'es' ? stripAcc((s || '').toLowerCase()).replace(/^(el|la|los|las|un|una) /, '').trim() : (s || '').replace(/[\u200c\s]/g, '').replace(/ي/g, 'ی').replace(/ك/g, 'ک').trim());
export function storyTargets(lang, n, k, variety) {
  const st = getStory(lang, n); if (!st || !st.targets || !st.targets[k]) return [];
  const its = unitItems(lang, n, variety).filter((i) => i.kind === 'w');
  return st.targets[k].map((w) => its.find((i) => nt(lang, i.t) === nt(lang, w) || (lang === 'es' && nt(lang, i.t) === nt(lang, w)))).filter(Boolean);
}
// Every Farsi string the app can speak (for the TTS build)
export const faSay = (s) => fnv(s);
