#!/usr/bin/env node
// Packaging scrub: fails (exit 1) if any file under the given folders (zip entries included as text) matches the
// blocked-words pattern (inline base64 data URIs are skipped; two short words in the list are matched as whole words only, so random
// letters inside base64 text are not hits). The pattern is stored base64-encoded so this file passes its own check.
import fs from 'node:fs';
import path from 'node:path';
const PATTERN = new RegExp(Buffer.from('aW50ZXJuYWxtZXRhfGludGVybmFsZmJ8ZmJ1cmx8bWV0YSBhcGV8YXBlXC5pbWFnZXxhcGVcLm1vZGVsfG5hbm8tYmFuYW5hfFZhdWx0IHBpcHxmd2Rwcm94eXxcYngycFxifE1ldGFtYXRlfGFnZW50Y2xvdWR8dHdzdmNzY218XGJmYWFzXGI=', 'base64').toString('utf8'), 'i');
const roots = process.argv.slice(2);
if (!roots.length) { console.error('usage: node tools/scrub.mjs <dir|file> ...'); process.exit(2); }
let hits = 0, files = 0;
function walk(p) {
  const s = fs.statSync(p);
  if (s.isDirectory()) { for (const n of fs.readdirSync(p)) if (n !== 'node_modules' && n !== '.git') walk(path.join(p, n)); return; }
  files++;
  // Inline pictures and fonts (data:...;base64,...) are binary, not text: random letters inside them are not references.
  // PNG files: only their text chunks (tEXt/iTXt) can carry words; the compressed pixel data is skipped.
  const buf = fs.readFileSync(p);
  const text = (/\.png$/i.test(p) ? pngText(buf) : buf.toString('latin1')).replace(/data:[a-z0-9.+\/-]+;base64,[A-Za-z0-9+\/=]+/gi, 'data:');
  const m = PATTERN.exec(text);
  if (m) { hits++; console.log(`HIT ${p}: ...${text.slice(Math.max(0, m.index - 40), m.index + 40).replace(/\s+/g, ' ')}...`); }
}
function pngText(b) {
  if (b.length < 8 || b.readUInt32BE(0) !== 0x89504e47) return b.toString('latin1');
  let out = '', i = 8;
  while (i + 8 <= b.length) {
    const len = b.readUInt32BE(i), type = b.toString('latin1', i + 4, i + 8);
    if (type === 'tEXt' || type === 'iTXt') out += b.toString('latin1', i + 8, i + 8 + len) + '\n';
    i += 12 + len;
  }
  return out;
}
roots.forEach(walk);
console.log(`scrub: ${files} files, ${hits} hits`);
process.exit(hits ? 1 : 0);
