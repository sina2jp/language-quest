// Family Sync caps a key at 300 KB: our progress key (langQuest.state) must stay well under 200 KB after ~6 months of
// heavy daily use. Simulates 180 days × 3 sessions with every Spanish and Farsi word and phrase learned, then checks the
// exact string the app saves (store.js serializeState) and that it loads back to the same progress.
import * as esbuild from 'esbuild';
const mem = {}; globalThis.localStorage = { getItem: (k) => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: (k) => { delete mem[k]; }, key: (i) => Object.keys(mem)[i] || null, get length() { return Object.keys(mem).length; } };
globalThis.window = globalThis;
await esbuild.build({ stdin: { contents: "export { serializeState, unpackState, compactState, migrate, defaults, save, load } from './src/store.js'; export { default as C } from './src/content.gen.js';", resolveDir: process.cwd(), loader: 'js' }, bundle: true, format: 'esm', platform: 'neutral', outfile: '/tmp/lq_size.mjs', logLevel: 'error', loader: { '.js': 'jsx' } });
const M = await import('/tmp/lq_size.mjs');
let fail = 0; const ok = (n, c, info = '') => { console.log((c ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); if (!c) fail++; };
let seed = 7; const rnd = (n) => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed % n; };
const T0 = 20400; const words = (n) => Array.from({ length: n }, () => 'palabra'.slice(0, 3 + rnd(5))).join(' ');
const S = M.migrate(null); S.nick = 'Hero';
let items = 0;
for (const l of ['es', 'fa']) {
  const L = S[l]; L.placed = true; L.level = 'stretch';
  for (const [n, u] of Object.entries(M.C[l])) {
    (u.words || []).forEach((_, i) => { const r = { b: rnd(7), d: T0 + 180 + rnd(30), r: rnd(90), w: rnd(16), s: T0 + rnd(180) }; if (r.w) r.lw = T0 + rnd(180); L.srs[`${l}${n}w${i}`] = r; items++; });
    (u.phrases || []).forEach((_, i) => { const r = { b: rnd(7), d: T0 + 180 + rnd(30), r: rnd(90), w: rnd(16), s: T0 + rnd(180) }; if (r.w) r.lw = T0 + rnd(180); L.srs[`${l}${n}p${i}`] = r; items++; });
    L.units[n] = { hp: 0, done: true, spk: 30 + rnd(20), wrt: 10 + rnd(10), wstep: 5, bossSeen: 3, days: 9, story: 8, gseen: 1, doneAt: Date.now() - rnd(1e9) };
  }
  L.mistakes = { gender: 40, verb: 33, order: 12, spelling: 80, wrong: 61, listening: 25, pron: 48 };
  L.speak = { tries: 2400, good: 2100 }; L.quests = 270; L.streak = 31; L.minutes = 2700; L.diff = 4;
  L.comeback = Array.from({ length: 80 }, () => ({ n: 1 + rnd(20), gi: rnd(6) }));
  for (let w = 0; w < 26; w++) L.weekly['2026-W' + w] = { done: true, at: Date.now() };
  for (let n = 1; n <= 20; n++) L.songs[n] = Date.now();
  L.script = { step: 30, done: Object.fromEntries(Array.from({ length: 30 }, (_, i) => [i, 3])) };
}
S.es.fs = { done: Object.fromEntries(Array.from({ length: 16 }, (_, i) => [i, 3])), champion: Date.now(), help: 12, srs: Object.fromEntries(Array.from({ length: 60 }, (_, i) => ['fs-' + i, { b: 3, d: T0 + 200 }])) };
S.treasure = { found: Object.fromEntries(['moon', 'navi', 'owl', 'song', 'cow', 'glint', 'speak20', 'unit1', 'unit3', 'unit5', 'nohint', 'streak3', 'firststeps', 'words50', 'helpfinish', 'story', 'chant', 'farsi'].map((k) => [k, Date.now()])), tokens: 0, toChoose: 0, flags: { story: 1, chant: 1, nohint: 1, helpfinish: 1, firststeps: 1 }, best: 31 };
S.recQueue = Array.from({ length: 320 }, (_, i) => 'یک جمله‌ی فارسی برای ضبط شماره ' + i);
S.secrets = { saria: Date.now(), zelda: Date.now(), epona: Date.now() }; S.hc = 12; S.rupees = 900;
S.wk = { w: '2026-11-22', lessons: 14, words0: 1500, speak0: 4000 };
// 180 days × 3 sessions: the app's own caps (reports 120, writing 40), then the save (which compacts)
let biggest = 0, raw = '';
for (let d = 0; d < 180; d++) for (let k = 0; k < 3; k++) {
  const l = k === 2 ? 'fa' : 'es';
  S.reports = [{ date: Date.now() - (180 - d) * 864e5, lang: l, unit: 1 + rnd(20), mins: 14 + rnd(8), total: 40, correct: 31, newItems: 4, reviewed: 12, mistakes: { spelling: rnd(4), gender: rnd(3), listening: rnd(2) }, speak: { tries: 12, good: 10 }, writing: [{ kind: 'one', text: words(18) }, { kind: 'three', text: words(40) }], boss: 'Queen Gohma', complete: true, rupees: 30 }, ...(S.reports || [])].slice(0, 120);
  S[l].writing = [{ d: Date.now(), unit: 1 + rnd(20), kind: 'three', text: words(70), mts: ['spelling', 'gender', 'verb'] }, ...(S[l].writing || [])].slice(0, 40);
  S[l].win = (S[l].win || []).concat([1, 0, 1]).slice(-12);
  raw = M.serializeState(S); biggest = Math.max(biggest, raw.length);
}
console.log(`  items learned: ${items}; saved state: ${(raw.length / 1024).toFixed(1)} KB (peak ${(biggest / 1024).toFixed(1)} KB)`);
ok('6 months of heavy daily use: langQuest.state stays under 200 KB (Family Sync cap: 300 KB)', biggest < 200000, `${biggest} chars`);
// the same progress loads back (srs entries, units, First Steps, treasure)
const back = M.migrate(M.unpackState(JSON.parse(raw)));
const sameSrs = Object.keys(S.es.srs).every((k) => JSON.stringify(back.es.srs[k]) === JSON.stringify(S.es.srs[k])) && Object.keys(S.fa.srs).every((k) => JSON.stringify(back.fa.srs[k]) === JSON.stringify(S.fa.srs[k]));
ok('the packed save loads back to the same spaced-repetition progress, units, First Steps and treasures', sameSrs && Object.keys(back.es.srs).length === Object.keys(S.es.srs).length && back.es.units[20].done && back.es.fs.done[15] === 3 && back.es.fs.srs['fs-3'].b === 3 && Object.keys(back.treasure.found).length === 18);
ok('the newest 15 reports keep their details for the Parent corner', back.reports.length <= 60 && back.reports.slice(0, 15).every((r) => r.writing && r.mistakes && r.speak));
// an old save (object entries, no packing) still loads
const old = M.migrate(M.unpackState(JSON.parse(JSON.stringify({ ...S, srsPacked: undefined }))));
ok('an old (unpacked) save still loads', Object.keys(old.es.srs).length === Object.keys(S.es.srs).length && old.es.srs['es1w0'].b === S.es.srs['es1w0'].b);
// save()/load() through localStorage
M.save(S); const L2 = M.load();
ok('save() then load() round trip through localStorage', JSON.stringify(L2.fa.srs['fa1w0']) === JSON.stringify(S.fa.srs['fa1w0']) && (mem['langQuest.state'] || '').length < 200000);
process.exit(fail ? 1 : 0);
