// Headless Chromium walkthrough "like a 9-year-old": placement, full quests (Spanish + Farsi), a boss win, speaking with and
// without recognition (mocked), the script track, parent corner (PIN, reports, settings, backup + restore), offline.
// Usage: node tests/e2e.mjs [distDir] [shotsDir]
import { chromium } from 'playwright-core';
import chromiumPkg from '@sparticuz/chromium';
import http from 'http';
import fs from 'fs';
import { WHITELIST } from '../src/nouns.js';
const chunkSeen = [];
import path from 'path';

const SPARTI = chromiumPkg.default || chromiumPkg;
const DIST = path.resolve(process.argv[2] || 'dist');
const PREVIEW = path.resolve(process.env.LQ_PREVIEW || '/tmp/lq/preview');
const PORT = +process.env.PORT || 8123;
const OUT = path.resolve(process.argv[3] || '/tmp/lq/shots');
fs.mkdirSync(OUT, { recursive: true });
const TYPES = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.woff2': 'font/woff2', '.webp': 'image/webp', '.md': 'text/plain' };
const srv = http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname); if (p.endsWith('/')) p += 'index.html';
  if (p.startsWith('/language-quest/')) p = p.slice('/language-quest'.length); // GitHub Pages project subpath
  // headless Chromium can't paint color (COLRv1) emoji, so screenshots use the monochrome Noto Emoji under the color font's name
  const EMO = path.join(path.dirname(new URL(import.meta.url).pathname), '../node_modules/@fontsource/noto-emoji');
  if (p.startsWith('/preview/')) { const pf = path.join(PREVIEW, p.slice(9)); if (fs.existsSync(pf) && fs.statSync(pf).isFile()) { res.writeHead(200, { 'content-type': TYPES[path.extname(pf)] || 'application/octet-stream', 'access-control-allow-origin': '*' }); fs.createReadStream(pf).pipe(res); return; } res.writeHead(404); res.end(); return; }
  if (p === '/viewer/x/__viewer.html') {
    // Emulates the Meta artifact viewer: an opaque-origin srcdoc iframe whose STATIC references were rewritten to absolute URLs;
    // relative URLs requested dynamically resolve under /viewer/x/ and 404.
    res.writeHead(200, { 'content-type': 'text/html' });
    res.end(`<!doctype html><body style="margin:0"><iframe id="f" sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-pointer-lock" style="width:100vw;height:100vh;border:0"></iframe>
<script>fetch('/preview/index.html').then(r=>r.text()).then(h=>{h=h.replace(/(src|href)="(?!https?:|data:|#)([^"]+)"/g,(m,a,u)=>a+'="http://localhost:${PORT}/preview/'+u+'"');document.getElementById('f').srcdoc=h;});</script></body>`);
    return;
  }
  if (p === '/__sandbox.html') { res.writeHead(200, { 'content-type': 'text/html' }); res.end('<!doctype html><title>sandbox</title><body style="margin:0"><iframe sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-pointer-lock" src="/index.html" style="width:100vw;height:100vh;border:0"></iframe></body>'); return; }
  if (p.startsWith('/__emoji/')) { const ef = path.join(EMO, p.slice(9)); if (fs.existsSync(ef)) { res.writeHead(200, { 'content-type': ef.endsWith('.css') ? 'text/css' : 'font/woff2', 'access-control-allow-origin': '*' }); if (ef.endsWith('.css')) res.end(fs.readFileSync(ef, 'utf8').replace(/font-family: 'Noto Emoji'/g, "font-family: 'Noto Color Emoji'")); else fs.createReadStream(ef).pipe(res); return; } }
  const f = path.join(DIST, p);
  if (!f.startsWith(DIST) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); res.end('not found'); return; }
  res.writeHead(200, { 'content-type': TYPES[path.extname(f)] || 'application/octet-stream', 'access-control-allow-origin': '*' }); fs.createReadStream(f).pipe(res);
}).listen(PORT);
const URL0 = `http://localhost:${PORT}/`;
const results = []; const errors = [];
const ok = (name, pass, info = '') => { results.push({ name, pass, info }); console.log((pass ? 'PASS ' : 'FAIL ') + name + (info ? ' — ' + info : '')); };

const exe = await SPARTI.executablePath();
// outside AWS Lambda the bundled shared libraries (libnspr4, libnss3…) are not unpacked automatically
const { inflate } = await import('@sparticuz/chromium/build/lambdafs.js').catch(() => import(path.join(path.dirname(new URL(import.meta.url).pathname), '../node_modules/@sparticuz/chromium/build/lambdafs.js')));
const binDir = path.join(path.dirname(new URL(import.meta.url).pathname), '../node_modules/@sparticuz/chromium/bin');
if (!fs.existsSync('/tmp/al2023/lib')) await inflate(path.join(binDir, 'al2023.tar.br'));
const LIBENV = { ...process.env, LD_LIBRARY_PATH: ['/tmp/al2023/lib', '/tmp', process.env.LD_LIBRARY_PATH || ''].filter(Boolean).join(':'), FONTCONFIG_PATH: '/tmp/fonts' };
const browser = await chromium.launch({ executablePath: exe, headless: true, env: LIBENV, args: [...SPARTI.args.filter((a) => a !== '--single-process'), '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox', '--ignore-gpu-blocklist', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--autoplay-policy=no-user-gesture-required'] });

async function newCtx(vp, sr) {
  const phone = vp === 'phone';
  const ctx = await browser.newContext(phone ? { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1', acceptDownloads: true } : { viewport: { width: 1440, height: 900 }, acceptDownloads: true });
  await ctx.grantPermissions(['microphone'], { origin: URL0 }).catch(() => {});
  await ctx.addInitScript(`window.__LQ_PORT__ = ${PORT};`);
  await ctx.addInitScript((srOn) => {
    window.__LQ_TEST__ = true; window.__LQ_NOAUTO__ = true;
    // reward tickets are off unless a test turns them on (seeded progress would otherwise open the ticket flow mid-test)
    try { if (!localStorage.getItem('familyApps.rewards.v1')) localStorage.setItem('familyApps.rewards.v1', JSON.stringify({ version: 1, enabled: false, tokensPerTicket: 3, weeklyCap: 5, rewards: [{ id: 'youtube', emoji: '📺', text: '15 minutes of YouTube' }], updatedAt: 1 })); } catch (e) {}
    // headless Chromium has no emoji font (Macs and iPhones do): load Noto Color Emoji for the screenshots only
    document.addEventListener('DOMContentLoaded', () => { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'http://localhost:' + (window.__LQ_PORT__ || location.port) + '/__emoji/index.css'; document.head.appendChild(l); });
    try {
      const fakeSynth = { speaking: false, pending: false, paused: false, getVoices: () => [], speak(u) { setTimeout(() => { u.onend && u.onend({}); }, 40); }, cancel() {}, pause() {}, resume() {}, onvoiceschanged: null, addEventListener() {}, removeEventListener() {} };
      Object.defineProperty(window, 'speechSynthesis', { value: fakeSynth, configurable: true });
    } catch (e) {}
    if (srOn) {
      class FakeSR {
        start() {
          setTimeout(() => {
            const el = document.querySelector('[data-say]');
            let t = (el && el.getAttribute('data-say')) || 'hola';
            if (window.__LQ_MISS__ > 0) { window.__LQ_MISS__--; t = 'zzz qqq'; }
            const r = [{ transcript: t }]; const ev = { results: [r] };
            this.onresult && this.onresult(ev); this.onend && this.onend();
          }, 150);
        }
        abort() {} stop() {}
      }
      window.SpeechRecognition = FakeSR; window.webkitSpeechRecognition = FakeSR;
    } else { try { delete window.SpeechRecognition; delete window.webkitSpeechRecognition; window.SpeechRecognition = undefined; window.webkitSpeechRecognition = undefined; } catch (e) {} }
    // faster audio element in tests
    const P = HTMLMediaElement.prototype.play;
    HTMLMediaElement.prototype.play = function () { const p = P.call(this); setTimeout(() => this.dispatchEvent(new Event('ended')), 60); return p.catch(() => {}); };
  }, sr);
  return ctx;
}
function watch(page, tag) {
  page.on('console', (m) => { if (m.type() === 'error') errors.push(`[${tag}] console: ${m.text()}`); });
  page.on('pageerror', (e) => { errors.push(`[${tag}] pageerror: ${e.message}`); console.log(`PAGEERROR [${tag}] ${e.message} ${(e.stack || '').split('\n').slice(0, 3).join(' | ')}`); });
}
const imgIssues = []; let imgScreens = 0;
async function checkImgs(page, name) {
  imgScreens++;
  for (const fr of page.frames()) {
    try {
      await fr.waitForFunction(() => [...document.images].every((i) => i.complete), null, { timeout: 4000 }).catch(() => {});
      const bad = await fr.evaluate(() => [...document.images].filter((i) => { const s = i.getAttribute('src'); return !s || !/\S/.test(s) || (i.complete && i.naturalWidth === 0); }).map((i) => (i.getAttribute('src') || '(no src)').slice(0, 50) + ' [' + (i.getAttribute('aria-label') || i.className || 'img') + ']'));
      for (const b of bad) imgIssues.push(`${name}: ${b}`);
    } catch (e) { /* frame navigated away */ }
  }
}
const imgSummary = (tag) => ok(`${tag}: no broken images (${imgScreens} screens checked; every <img> has a src and naturalWidth > 0, or is the fallback badge)`, imgIssues.length === 0, imgIssues.slice(0, 6).join(' | '));
const shot = async (page, name) => {
  const f = path.join(OUT, name + '.png');
  await checkImgs(page, name);
  try { await Promise.race([page.evaluate(() => document.fonts && document.fonts.ready), new Promise((r) => setTimeout(r, 2000))]); } catch (e) {}
  await page.waitForTimeout(120);
  for (let k = 0; k < 2; k++) { try { await page.screenshot({ path: f, fullPage: false, timeout: 15000 }); return f; } catch (e) { console.log('screenshot retry', name, e.message.split('\n')[0]); await page.waitForTimeout(1000); } }
  return f;
};
const tid = (page) => page.evaluate(() => { if (document.querySelector('[data-testid=map]')) return 'langhome'; const el = document.querySelector('.main .card[data-testid]'); return el ? el.getAttribute('data-testid') : null; });
const cardNo = (page) => page.evaluate(() => { const m = document.querySelector('.main[data-card]'); return m ? m.getAttribute('data-card') : null; });
async function waitChange(page, before, ms = 3000) { for (let t = 0; t < ms; t += 150) { await page.waitForTimeout(150); if ((await cardNo(page)) !== before || (await tid(page)) === 'langhome') return true; } return false; }
async function voice(page) {
  const before = await cardNo(page); const t0 = await page.evaluate(() => document.querySelector('[data-testid=voice]') && document.querySelector('[data-testid=voice]').innerText.slice(0, 60));
  if (await page.locator('[data-testid=mic]').count()) await click(page, '[data-testid=mic]');
  else await click(page, '.main [data-testid=voice] .choice[data-ok="1"]');
  for (let k = 0; k < 20; k++) {
    await page.waitForTimeout(200);
    if ((await cardNo(page)) !== before) return;
    const t1 = await page.evaluate(() => document.querySelector('[data-testid=voice]') && document.querySelector('[data-testid=voice]').innerText.slice(0, 60));
    if (t1 !== t0) return; // next question inside the same card
    const nb = page.locator('.actionbar [data-testid=next]:not([disabled])');
    if (await nb.count()) { await nb.first().click(); return; }
    if (await page.locator('[data-testid=compare]').count()) continue;
    if (await page.locator('.main [data-testid=voice] .choice[data-ok="1"]').count() && k > 6) { await page.locator('.main [data-testid=voice] .choice[data-ok="1"]').first().click(); }
  }
}
const click = async (page, sel, opt = {}) => { const el = page.locator(sel).first(); await el.waitFor({ state: 'visible', timeout: opt.timeout || 4000 }); await el.evaluate((e) => e.scrollIntoView({ block: 'center' })); await el.click({ timeout: 5000 }); };
const nextBtn = async (page) => { const b = page.locator('[data-testid=next]').first(); await b.waitFor({ timeout: 4000 }); for (let k = 0; k < 20 && !(await b.isEnabled()); k++) await page.waitForTimeout(150); await b.click({ timeout: 5000 }); };

async function sayIt(page) {
  if (await page.locator('[data-testid=mic]').count()) { await click(page, '[data-testid=mic]'); await page.waitForTimeout(500); }
  else if (await page.locator('[data-testid=rec]').count()) { await click(page, '[data-testid=rec]'); await page.waitForTimeout(700); await click(page, '[data-testid=rec]'); await page.waitForTimeout(400); await click(page, '[data-testid=self-yes]'); }
  else await click(page, '[data-testid=self-yes]');
  await nextBtn(page);
}
async function drawTrace(page) {
  const c = page.locator('[data-testid=trace-canvas]'); const b = await c.boundingBox();
  for (let row = 0; row < 9; row++) { // zig-zag over the middle of the box
    await page.mouse.move(b.x + b.width * 0.2, b.y + b.height * (0.15 + row * 0.08)); await page.mouse.down();
    await page.mouse.move(b.x + b.width * 0.8, b.y + b.height * (0.15 + row * 0.08), { steps: 8 }); await page.mouse.up();
  }
  await click(page, '[data-testid=trace-check]');
  await page.waitForTimeout(200);
  if (await page.locator('[data-testid=trace-next]').count()) await click(page, '[data-testid=trace-next]'); else await page.getByText('Next anyway').click();
}
async function typeFa(page, word) {
  for (const ch of [...word]) { if (ch === '\u200c') { await page.getByText('half-space').click(); continue; } await page.locator('.kbd button', { hasText: ch }).first().click(); }
}

async function playCards(page, tag, maxSteps = 160) {
  const seen = {}; let steps = 0; let unknown = 0; let nulls = 0;
  for (; steps < maxSteps; steps++) {
    await page.waitForTimeout(220);
    const t = await tid(page);
    if (!t) { nulls++; if (nulls === 4) { const h = await page.evaluate(() => { const m = document.querySelector('.main'); return (m ? m.outerHTML : document.body.innerHTML).slice(0, 900); }); console.log(`NULLCARD [${tag}] ${h}`); } await page.waitForTimeout(400); continue; }
    nulls = 0;
    if (!seen[t]) { seen[t] = 1; await shot(page, `${tag}-${t}`); }
    try {
      if (t === 'langhome') break;
      if (t === 'voice') { const nn = await page.locator('[data-noun]').first().getAttribute('data-noun').catch(() => null); if (nn != null) chunkSeen.push(nn); await voice(page); continue; }
      if (t === 'story') { await nextBtn(page); continue; }
      if (t === 'tpr') { await page.waitForTimeout(3600); await nextBtn(page); continue; }
      if (t === 'mission-check') { await click(page, '[data-testid=mission-yes]'); continue; }
      if (t === 'learn') await nextBtn(page);
      else if (t.startsWith('pick-')) { await click(page, '.main .choice[data-ok="1"]'); await nextBtn(page); }
      else if (t === 'sayit') await sayIt(page);
      else if (t === 'spell') { const a = await page.locator('[data-testid=spell-input]').getAttribute('data-answer'); await page.fill('[data-testid=spell-input]', a); await click(page, '[data-testid=check]'); await nextBtn(page); }
      else if (t === 'speed') { await click(page, '[data-testid=start]'); await page.waitForTimeout(3800); await nextBtn(page); }
      else if (t === 'triplets') { for (let r = 0; r < 4; r++) { await page.locator('.main [data-testid=triplets] .choice[data-ok="1"]').nth(0).click(); await page.locator('.main [data-testid=triplets] .choice[data-ok="1"]').nth(1).click(); await nextBtn(page); await page.waitForTimeout(150); if ((await tid(page)) !== 'triplets') break; } }
      else if (t === 'grammar-explain') await nextBtn(page);
      else if (t === 'grammar-item') { await click(page, '.main .choice[data-ok="1"]'); if (await page.locator('.main .why button').count()) await click(page, '.main .why button'); await click(page, '[data-testid=check]'); await nextBtn(page); }
      else if (t === 'write-copy') { const a = await page.locator('[data-testid=write-copy]').getAttribute('data-answer'); await page.fill('[data-testid=write-input]', a); await click(page, '[data-testid=check]'); await nextBtn(page); }
      else if (t === 'write-fill') { await click(page, '.main .choice[data-ok="1"]'); await click(page, '[data-testid=check]'); await nextBtn(page); }
      else if (t === 'write-build') {
        const a = (await page.locator('[data-testid=write-build]').getAttribute('data-answer')).split('|');
        for (const w of a) { await page.locator(`[data-testid=build-pool] .tile[data-tile="${w.replace(/"/g, '\\"')}"]`).first().click(); }
        await click(page, '[data-testid=check]'); await nextBtn(page);
      }
      else if (t === 'write-one' || t === 'write-three') { const a = await page.locator(`[data-testid=${t}]`).getAttribute('data-answer'); await page.fill('[data-testid=write-input]', a || 'hola'); await click(page, '[data-testid=check]'); await nextBtn(page); }

      else if (t === 'picdescribe') await nextBtn(page);
      else if (t === 'boss-intro') await click(page, '[data-testid=boss-start]');
      else if (t === 'boss-fight') { await click(page, '.main .choice[data-ok="1"]'); await nextBtn(page); }
      else if (t === 'boss-end') await nextBtn(page);
      else if (t === 'reward') { if (await page.locator('[data-testid=open-chest]').count()) { await click(page, '[data-testid=open-chest]'); await page.waitForTimeout(300); await shot(page, `${tag}-reward-open`); } await click(page, '[data-testid=finish]'); }
      else if (t === 'script-lesson') {
        if (await page.locator('[data-testid=trace]').count()) await drawTrace(page);
        else if (await page.locator('[data-testid=type-value]').count()) { const a = await page.locator('[data-testid=type-value]').getAttribute('data-answer'); await typeFa(page, a); await nextBtn(page); }
        else if (await page.locator('.main .choice[data-ok="1"]').count()) { await click(page, '.main .choice[data-ok="1"]'); await nextBtn(page); }
        else await nextBtn(page);
      }
      else if (t === 'script-home') break;
      else { console.log('unknown card', t); unknown++; if (unknown > 3) break; await nextBtn(page); }
    } catch (e) { console.log(`[${tag}] step ${steps} on ${t}: ${e.message.split('\n')[0]}`); await page.waitForTimeout(300); }
  }
  return { steps, seen: Object.keys(seen) };
}

async function walkthrough(vp, srOn) {
  const tag = `${vp}`;
  const ctx = await newCtx(vp, srOn); const page = await ctx.newPage(); watch(page, tag);
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]', { timeout: 15000 });
  await shot(page, `${tag}-01-welcome`);
  await page.fill('[data-testid=nick]', 'Hero'); await click(page, '[data-testid=nick-ok]');
  await page.waitForSelector('[data-testid=door-es]'); await page.waitForTimeout(1200); await shot(page, `${tag}-02-home`);
  // Spanish placement (game-like test)
  await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=placement-intro]'); await shot(page, `${tag}-03-placement-intro`);
  await click(page, '[data-testid=pl-new]');
  await page.waitForSelector('[data-testid=placement-result]'); await shot(page, `${tag}-05-placement-result`);
  await click(page, '[data-testid=pl-accept]');
  await page.waitForSelector('[data-testid=map]'); await page.waitForTimeout(800); await shot(page, `${tag}-06-es-map`);
  ok(`${tag}: Spanish placement`, true);
  await click(page, '[data-testid=start-quest]');
  const q1 = await playCards(page, `${tag}-es`);
  ok(`${tag}: full Spanish quest`, (await tid(page)) === 'langhome', `${q1.steps} steps; cards: ${q1.seen.join(', ')}`);
  // Farsi: placement with listening rounds, then a full quest
  await click(page, '[data-testid=back]'); await click(page, '[data-testid=door-fa]'); await page.waitForSelector('[data-testid=placement-intro]');
  await shot(page, `${tag}-03b-home-one-door`);
  await click(page, '[data-testid=pl-start]');
  for (let k = 0; k < 14; k++) { await page.waitForTimeout(250); if (!(await page.locator('[data-testid=placement-q]').count())) break; if (k === 0) await shot(page, `${tag}-07-fa-placement-q`); const right = k < 4; try { await click(page, right ? '.main .choice[data-ok="1"]' : '.main .choice[data-ok="0"]'); } catch (e) {} await page.waitForTimeout(1300); }
  if (await page.locator('[data-testid=placement-read]').count()) { await shot(page, `${tag}-08-fa-placement-read`); await click(page, '[data-testid=pl-noread]'); }
  await page.waitForSelector('[data-testid=placement-result]'); await shot(page, `${tag}-09-fa-placement-result`);
  ok(`${tag}: Farsi placement celebrates known words`, (await page.locator('[data-testid=known-est]').count()) > 0);
  await click(page, '[data-testid=pl-accept]'); await page.waitForSelector('[data-testid=map]'); await page.waitForTimeout(600); await shot(page, `${tag}-10-fa-map`);
  await click(page, '[data-testid=start-quest]');
  const q2 = await playCards(page, `${tag}-fa`);
  ok(`${tag}: full Farsi quest`, (await tid(page)) === 'langhome', `${q2.steps} steps; cards: ${q2.seen.join(', ')}`);
  // second Farsi quest = script step day
  await click(page, '[data-testid=start-quest]');
  const q3 = await playCards(page, `${tag}-fa2`);
  ok(`${tag}: second Farsi quest (letters step)`, (await tid(page)) === 'langhome' && q3.seen.includes('script-lesson'), q3.seen.join(', '));
  // Script track: lesson 1 from the letters screen
  await click(page, '[data-testid=script-btn]'); await page.waitForSelector('[data-testid=script-home]'); await shot(page, `${tag}-11-script-home`);
  await page.locator('[data-testid=script-home] .prow').first().click();
  const s1 = await playCards(page, `${tag}-script`, 40);
  ok(`${tag}: script lesson 1`, (await tid(page)) === 'script-home', s1.seen.join(', '));
  return { ctx, page };
}

async function bossWin(page, tag) {
  // seed: Spanish unit 1 fully introduced with the boss on its last heart, then play a quest to the boss
  await page.evaluate(() => {
    const s = JSON.parse(localStorage.getItem('langQuest.state'));
    s.es.units['1'] = Object.assign(s.es.units['1'] || {}, { hp: 1, done: false });
    const d = Math.floor((Date.now() - new Date().getTimezoneOffset() * 60000) / 86400000);
    for (let i = 0; i < 60; i++) { s.es.srs['es1w' + i] = s.es.srs['es1w' + i] || { b: 2, d: d + 3, r: 2, w: 0, s: d }; s.es.srs['es1p' + i] = s.es.srs['es1p' + i] || { b: 2, d: d + 3, r: 2, w: 0, s: d }; }
    localStorage.setItem('langQuest.state', JSON.stringify(s));
  });
  await page.goto(URL0); await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=map]');
  await click(page, '[data-testid=start-quest]');
  const r = await playCards(page, `${tag}-boss`);
  const won = await page.evaluate(() => JSON.parse(localStorage.getItem('langQuest.state')).es.units['1'].done === true);
  ok(`${tag}: boss defeated (unit 1, ${'Mad Scrub'})`, won, r.seen.join(', '));
  await click(page, '[data-testid=ican-btn]'); await page.waitForSelector('[data-testid=ican]'); await shot(page, `${tag}-12-ican`);
  await click(page, '[data-testid=back]');
}

async function speedAndTriplets(page, tag) {
  // seed: many known words due today in both languages and a quest count that schedules the speed round + triplets
  await page.evaluate(() => {
    const s = JSON.parse(localStorage.getItem('langQuest.state'));
    const d = Math.floor((Date.now() - new Date().getTimezoneOffset() * 60000) / 86400000);
    for (const l of ['es', 'fa']) for (let u = 1; u <= 8; u++) for (let i = 0; i < 40; i++) s[l].srs[l + u + 'w' + i] = { b: 3, d, r: 3, w: i % 5 === 0 ? 2 : 0, s: d - 5 };
    s.es.quests = 10; s.es.diff = 3; s.es.lastDay = 0;
    s.es.mission = { day: d - 1, en: 'Say good morning in Spanish.', say: '¡Buenos días!', done: false };
    localStorage.setItem('langQuest.state', JSON.stringify(s));
  });
  await page.goto(URL0); await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=map]');
  await click(page, '[data-testid=start-quest]');
  await page.evaluate(() => { window.__LQ_MISS__ = 2; });
  const r = await playCards(page, `${tag}-extra`);
  const nrev = await page.evaluate(() => JSON.parse(localStorage.getItem('langQuest.state')).reports[0].reviewed);
  const okNouns = chunkSeen.length > 0 && chunkSeen.every((n) => WHITELIST.some((w) => w.en === n));
  ok(`${tag}: power phrases use whitelisted nouns`, okNouns, `seen: ${chunkSeen.join(', ') || 'none'}`);
  ok(`${tag}: speed round + triplets + home-mission check + review cap (<=12)`, r.seen.includes('speed') && r.seen.includes('triplets') && r.seen.includes('mission-check') && nrev <= 12, `reviewed ${nrev}; ${r.seen.join(', ')}`);
}

async function extras(page, tag) {
  await page.goto(URL0); await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=map]');
  // rupee shop: he buys by saying the phrase
  await page.evaluate(() => { const s = JSON.parse(localStorage.getItem('langQuest.state')); s.rupees = Math.max(s.rupees, 100); localStorage.setItem('langQuest.state', JSON.stringify(s)); });
  await page.goto(URL0); await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=map]');
  await click(page, '[data-testid=shop-btn]'); await page.waitForSelector('[data-testid=shop]'); await shot(page, `${tag}-22-shop`);
  await click(page, '[data-testid=shop-navi_pink]'); await page.waitForSelector('[data-testid=voice]'); await shot(page, `${tag}-23-shop-say`);
  await voice(page); await page.waitForSelector('[data-testid=shop-bought]', { timeout: 6000 }); await shot(page, `${tag}-24-shop-bought`);
  const owned = await page.evaluate(() => JSON.parse(localStorage.getItem('langQuest.state')).shop.owned);
  ok(`${tag}: rupee shop (buy by saying the phrase)`, owned.includes('navi_pink'), owned.join(','));
  await click(page, '[data-testid=next]'); await click(page, '[data-testid=back]');
  // songbook: play the unit tune on the keys, then say the line to open the door
  await click(page, '[data-testid=songs-btn]'); await page.waitForSelector('[data-testid=songbook]'); await shot(page, `${tag}-25-songbook`);
  await click(page, '[data-testid=song-door]'); await page.waitForSelector('[data-testid=songbook-tune]'); await page.waitForTimeout(400);
  const ic = await page.$$eval('.tune .tn', (els) => els.map((e) => e.textContent));
  const keyOf = { 'A': '1', '▼': '2', '▶': '3', '◀': '4', '▲': '5' };
  for (const c of ic) { await page.keyboard.press(keyOf[c]); await page.waitForTimeout(250); }
  await shot(page, `${tag}-26-songbook-tune-played`);
  await page.waitForSelector('[data-testid=voice]', { timeout: 5000 }).catch(() => {});
  if (await page.locator('[data-testid=voice]').count()) { await shot(page, `${tag}-27-songbook-karaoke`); await voice(page); }
  const door = await page.waitForSelector('[data-testid=door-open]', { timeout: 6000 }).then(() => true).catch(() => false);
  ok(`${tag}: ocarina songbook (tune on keys + say the line opens the door)`, door, `tune ${ic.join(' ')}`);
  await click(page, '[data-testid=next]'); await click(page, '[data-testid=back]');
  // ocarina toy: he plays Saria's song himself; Navi reacts (the app never plays or shows it)
  await page.goto(URL0); await page.waitForSelector('[data-testid=door-es]');
  const hasToy = await page.locator('text=Ocarina').count();
  await page.evaluate(() => { const s = JSON.parse(localStorage.getItem('langQuest.state')); s.toys.ocarina = true; localStorage.setItem('langQuest.state', JSON.stringify(s)); });
  await page.goto(URL0); await click(page, '[data-testid=door-es]'); await page.waitForSelector('[data-testid=map]');
  await page.locator('button', { hasText: 'Ocarina' }).first().click(); await page.waitForSelector('[data-testid=ocarina]'); await page.waitForTimeout(400);
  for (const k of ['2', '3', '4', '2', '3', '4']) { await page.keyboard.press(k); await page.waitForTimeout(220); }
  const secret = await page.waitForSelector('[data-testid=secret-song]', { timeout: 3000 }).then(() => true).catch(() => false);
  await shot(page, `${tag}-28-ocarina-secret`);
  ok(`${tag}: ocarina recognizes a secret song he plays (heart piece)`, secret);
}

async function parentCorner(page, tag, ctx) {
  await page.goto(URL0); await click(page, '[data-testid=parent-btn]'); await page.waitForSelector('[data-testid=pinpad]'); await shot(page, `${tag}-13-pin`);
  for (const d of '0000') await click(page, `[data-testid=pin-${d}]`);
  for (const d of '2468') await click(page, `[data-testid=pin-${d}]`);
  for (const d of '2468') await click(page, `[data-testid=pin-${d}]`);
  await page.waitForSelector('[data-testid=setup]'); await shot(page, `${tag}-13b-setup`);
  await click(page, '[data-testid=allow-mic]'); await page.waitForTimeout(500); await click(page, '[data-testid=setup-done]');
  await page.waitForSelector('[data-testid=parent]'); await page.waitForTimeout(300); await shot(page, `${tag}-14-parent-report`);
  ok(`${tag}: parent PIN must be changed on first visit`, true);
  await page.waitForSelector('[data-testid=week-card]');
  await click(page, '[data-testid=tab-report]'); await page.waitForTimeout(300); await shot(page, `${tag}-14b-full-reports`);
  const reports = await page.locator('[data-testid=session-report]').count();
  ok(`${tag}: session reports saved`, reports >= (process.env.ONLY === 'desktop2' ? 1 : 2), `${reports} reports`);
  await click(page, '[data-testid=tab-settings]'); await shot(page, `${tag}-15-parent-settings`);
  await click(page, '[data-testid=tab-voices]'); await page.waitForTimeout(300); await shot(page, `${tag}-16-parent-voices`);
  await click(page, '[data-testid=open-queue]'); await page.waitForSelector('[data-testid=rec-queue]'); await shot(page, `${tag}-16b-rec-queue`);
  await click(page, '[data-testid=rec-one]'); await page.waitForTimeout(6800); await shot(page, `${tag}-16c-rec-queue-next`);
  const recs = await page.evaluate(() => new Promise((res) => { const r = indexedDB.open('langQuest.voices', 1); r.onsuccess = () => { const t = r.result.transaction('voices', 'readonly').objectStore('voices').count(); t.onsuccess = () => res(t.result); }; r.onerror = () => res(-1); }));
  ok(`${tag}: guided recording queue saves a family voice`, recs >= 1, `${recs} recordings`);
  await click(page, '[data-testid=open-ear]'); await page.waitForSelector('[data-testid=ear-check]'); await click(page, '[data-testid=thumbs-down]'); await shot(page, `${tag}-16d-ear-check`);
  await click(page, '[data-testid=tab-ai]'); await shot(page, `${tag}-17-parent-ai`);
  await click(page, '[data-testid=tab-help]'); await shot(page, `${tag}-18-parent-help`);
  await click(page, '[data-testid=tab-backup]');
  const [dl] = await Promise.all([page.waitForEvent('download'), click(page, '[data-testid=download-backup]')]);
  const bf = path.join(OUT, `${tag}-backup.json`); await dl.saveAs(bf);
  const b = JSON.parse(fs.readFileSync(bf, 'utf8'));
  ok(`${tag}: backup download`, b.app === 'langQuest' && !!b.localStorage['langQuest.state'], `${fs.statSync(bf).size} bytes`);
  // wipe, then import with confirmation
  await page.evaluate(() => { const s = JSON.parse(localStorage.getItem('langQuest.state')); s.nick = 'Changed'; localStorage.setItem('langQuest.state', JSON.stringify(s)); });
  await page.setInputFiles('[data-testid=import-file]', bf);
  await page.waitForSelector('[data-testid=confirm-import]'); await shot(page, `${tag}-19-import-confirm`);
  await click(page, '[data-testid=confirm-import]'); await page.waitForTimeout(1500);
  const nick = await page.evaluate(() => JSON.parse(localStorage.getItem('langQuest.state')).nick);
  ok(`${tag}: restore from backup`, nick === 'Hero', `nick=${nick}`);
}

async function offline(ctx, page, tag) {
  await page.goto(URL0); await page.waitForTimeout(2500);
  const sw = await page.evaluate(async () => { const r = await navigator.serviceWorker.getRegistration(); return !!(r && r.active); });
  await ctx.setOffline(true);
  await page.reload(); await page.waitForTimeout(1500);
  const okHome = await page.locator('[data-testid=door-es]').count();
  await shot(page, `${tag}-20-offline-home`);
  await click(page, '[data-testid=door-fa]'); await page.waitForSelector('[data-testid=map]'); await click(page, '[data-testid=start-quest]'); await page.waitForTimeout(1500);
  await shot(page, `${tag}-21-offline-quest`);
  ok(`${tag}: works offline after first load`, sw && okHome > 0, `sw=${sw}`);
  await ctx.setOffline(false);
}

// ---- image tour: every screen with pictures, opened directly through the test hook (window.__lqTest) ----
async function imageTour(label, url, { frame = false, vp = 'desktop', dist = true, only = 'all' } = {}) {
  const ctx = await newCtx(vp, true);
  await ctx.addInitScript(() => { window.__LQ_TEST__ = { unlock: true }; });
  const page = await ctx.newPage(); const e0 = errors.length; watch(page, label);
  await page.goto(url);
  const F = async () => { if (!frame) return page.mainFrame(); for (let i = 0; i < 80; i++) { const f = page.frames().find((x) => x !== page.mainFrame()); if (f) return f; await page.waitForTimeout(250); } throw new Error('no frame'); };
  const fr = await F();
  await fr.waitForFunction(() => !!window.__lqTest, null, { timeout: 30000 });
  await fr.evaluate(() => { try { localStorage.removeItem('familyApps.rewards.v1'); localStorage.removeItem('familyApps.tickets.v1'); } catch (e) {} }); // tickets on (defaults)
  await fr.evaluate(() => window.__lqTest.set((s) => {
    s.nick = 'Hero'; s.setupDone = true; s.rupees = 60; s.toys.ocarina = true;
    for (const l of ['es', 'fa']) { s[l].placed = true; s[l].level = 'sprout'; s[l].quests = 3; }
    for (let n = 1; n <= 5; n++) s.es.units[n] = { done: true, hp: 0, doneAt: Date.now() };
  }));
  const visit = async (name, screen, params, after) => {
    await fr.evaluate(([sc, pr]) => window.__lqTest.go(sc, pr), [screen, params]);
    await page.waitForTimeout(900);
    if (after) await after();
    await shot(page, `tour-${label}-${name}`);
  };
  if (only === 'new') {
    // v6 screens: token counter + hidden things, House of Skulltula, the ticket flow, Parent corner → Rewards
    await fr.evaluate(() => window.__lqTest.set((s) => { s.treasure = { found: { moon: 1, unit1: 1, unit3: 1, unit5: 1, speak20: 1 }, tokens: 1, toChoose: 0, flags: {}, capped: false }; }));
    await visit('new-home', 'home', {});
    await visit('new-lang-es', 'lang', { lang: 'es' });
    await visit('new-ican-es', 'ican', { lang: 'es' });
    await visit('new-treasure', 'treasure', {});
    await fr.evaluate(() => window.__lqTest.set((s) => { s.treasure.toChoose = 1; }));
    const L = (sel) => (frame ? page.frameLocator('iframe') : page).locator(sel);
    await visit('new-ticket-chest', 'ticket', {});
    await visit('new-ticket-choose', 'ticket', {}, async () => { await L('[data-testid=open-ticket-chest]').click(); await page.waitForTimeout(600); });
    await L('[data-testid=reward-card]').first().click(); await page.waitForTimeout(700); await shot(page, `tour-${label}-new-ticket-card`);
    await visit('new-parent-rewards', 'parent', {}, async () => { await L('[data-testid=tab-rewards]').click(); await page.waitForTimeout(700); });
    const diagN = await fr.evaluate(() => (window.__lqDiag || []).map((d) => d.m));
    const overlayN = await fr.evaluate(() => { const b = document.getElementById('lq-diag'); return !!(b && b.offsetParent !== null); });
    ok(`${label}: v6 screens (token counter, House of Skulltula, ticket chest/choose/card, Parent → Rewards), zero errors${dist ? ', no overlay' : ''}`, errors.length === e0 && diagN.length === 0 && (!dist || !overlayN), errors.slice(e0, e0 + 3).join(' | ') || diagN.slice(0, 3).join(' | '));
    await ctx.close(); return;
  }
  await visit('home', 'home', {});
  await visit('lang-es', 'lang', { lang: 'es' });
  await visit('ican-es', 'ican', { lang: 'es' });
  await visit('ican-fa', 'ican', { lang: 'fa' });
  await visit('cert-es', 'cert', { lang: 'es', level: 'sprout' });
  await visit('songbook', 'songs', { lang: 'es' });
  await visit('shop', 'shop', { lang: 'es' });
  await visit('ocarina', 'ocarina', { lang: 'es' });
  await visit('letters', 'script', { lang: 'fa' });
  await visit('parent', 'parent', {});
  for (const t of ['week', 'report', 'settings', 'voices', 'backup', 'ai', 'help']) {
    await visit('parent-' + t, 'parent', {}, async () => { const b = (frame ? page.frameLocator('iframe') : page).locator(`[data-testid=tab-${t}]`); if (await b.count()) { await b.first().click(); await page.waitForTimeout(700); } });
  }
  const diag = await fr.evaluate(() => (window.__lqDiag || []).map((d) => d.m));
  const overlayShown = await fr.evaluate(() => { const b = document.getElementById('lq-diag'); return !!(b && b.offsetParent !== null); });
  const helpDiag = await fr.evaluate(() => !!document.querySelector('[data-testid=diagnostics]'));
  if (dist) ok(`${label}: no error overlay in the dist (diagnostics list in Parent corner → Help)`, !overlayShown && helpDiag, `recorded problems: ${diag.length}${diag.length ? ' — ' + diag.slice(0, 3).join(' | ') : ''}`);
  ok(`${label}: image tour, zero errors (home, I can maps with stones/medallions, certificate, songbook, shop, ocarina, letters, 8 parent screens)`, errors.length === e0 && diag.length === 0, errors.slice(e0, e0 + 3).join(' | ') || diag.slice(0, 3).join(' | '));
  await ctx.close();
}
async function treasureTest(page, tag) {
  await page.evaluate(async () => {
    localStorage.removeItem('familyApps.rewards.v1'); localStorage.removeItem('familyApps.tickets.v1');
    await window.__lqTest.setPin('1234');
    // achievements already earned in this profile are marked found, so only the hidden things below change the count
    const ach = ['speak20', 'unit1', 'unit3', 'unit5', 'nohint', 'streak3', 'streak7', 'words50', 'words100', 'story', 'chant', 'farsi'];
    window.__lqTest.set((s) => { s.treasure = { found: Object.fromEntries(ach.map((k) => [k, 1])), tokens: 2, toChoose: 0, flags: {}, capped: false, best: 0 }; });
    window.__lqTest.go('home');
  });
  await page.waitForTimeout(900);
  const chip = await page.locator('[data-testid=tokens]').count();
  await page.locator('[data-secret=glint]').click({ force: true });
  const toastTxt = await page.locator('[data-testid=toast]').first().textContent({ timeout: 3000 }).catch(() => '');
  await page.locator('[data-testid=ticket-chest]').waitFor({ timeout: 8000 });
  await shot(page, `${tag}-treasure-chest`);
  // another app writes a ticket and edits the shared list meanwhile
  await page.evaluate(() => {
    const t = JSON.parse(localStorage.getItem('familyApps.tickets.v1') || '[]'); t.push({ id: 'math-x1', app: 'math', rewardId: 'pet', rewardText: 'Play time with our pet', emoji: '🐾', earnedAt: Date.now() - 5000, status: 'earned' }); localStorage.setItem('familyApps.tickets.v1', JSON.stringify(t));
    // nothing was written at load, so the other app (first to write) stores the shared defaults plus its edit
    const c = JSON.parse(localStorage.getItem('familyApps.rewards.v1') || 'null') || { version: 1, enabled: true, tokensPerTicket: 3, weeklyCap: 5, rewards: [{ id: 'youtube', emoji: '📺', text: '15 minutes of YouTube' }, { id: 'switch', emoji: '🎮', text: '20 minutes of Nintendo Switch' }, { id: 'pet', emoji: '🐾', text: 'Play time with our pet' }, { id: 'treat', emoji: '🍦', text: 'Pick a special treat' }, { id: 'game', emoji: '🎲', text: 'Family game pick' }], updatedAt: new Date().toISOString() };
    c.rewards.push({ id: 'zoo', emoji: '🦁', text: 'Zoo trip' }); localStorage.setItem('familyApps.rewards.v1', JSON.stringify(c));
  });
  await click(page, '[data-testid=open-ticket-chest]');
  await page.locator('[data-testid=ticket-choose]').waitFor({ timeout: 5000 });
  const zoo = await page.locator('[data-testid=reward-card]', { hasText: 'Zoo trip' }).count();
  await shot(page, `${tag}-treasure-choose`);
  await page.locator('[data-testid=reward-card]').nth(1).click();
  await page.locator('[data-testid=ticket-card]').waitFor({ timeout: 5000 });
  await shot(page, `${tag}-treasure-ticket`);
  await page.locator('[data-testid=ticket-card] [data-testid=approve]').first().click();
  await page.fill('[data-testid=pin-ask-input]', '9999'); await page.click('[data-testid=pin-ask-ok]'); await page.waitForTimeout(500);
  const wrong = await page.locator('[data-testid=pin-ask-err]').count();
  const mid = JSON.parse(await page.evaluate(() => localStorage.getItem('familyApps.tickets.v1')));
  const stillEarned = (mid.find((t) => t.app === 'language') || {}).status === 'earned';
  await page.fill('[data-testid=pin-ask-input]', '1234'); await page.click('[data-testid=pin-ask-ok]'); await page.waitForTimeout(700);
  await shot(page, `${tag}-treasure-approved`);
  const tk = JSON.parse(await page.evaluate(() => localStorage.getItem('familyApps.tickets.v1')));
  const mine = tk.filter((t) => t.app === 'language');
  ok(`${tag}: secret → toast, ticket chest → choose (re-reads the shared list) → ticket; PIN gate refuses a wrong PIN, the right PIN marks it used; other apps' tickets kept`,
    chip > 0 && /Secret found! 13\/18 · A Reward Ticket is waiting for you!/.test(toastTxt || '') && zoo === 1 && wrong === 1 && stillEarned && mine.length === 1 && mine[0].status === 'used' && mine[0].rewardText === '20 minutes of Nintendo Switch' && /^language-\d{13}-/.test(mine[0].id) && /T/.test(mine[0].earnedAt) && /T/.test(mine[0].usedAt) && tk.some((t) => t.id === 'math-x1' && t.status === 'earned'),
    `toast: ${toastTxt}; tickets: ${tk.map((t) => t.app + ':' + t.status).join(', ')}`);
  // one-time: the glint is gone; the moon needs 3 taps
  await page.evaluate(() => window.__lqTest.go('home')); await page.waitForTimeout(800);
  const glintGone = (await page.locator('[data-secret=glint]').count()) === 0;
  await page.locator('[data-secret=moon]').first().click(); const after1 = await page.evaluate(() => !!window.__lqTest.get().treasure.found.moon);
  await page.locator('[data-secret=moon]').first().click(); await page.locator('[data-secret=moon]').first().click(); await page.waitForTimeout(300);
  const moon = await page.evaluate(() => !!window.__lqTest.get().treasure.found.moon);
  await page.evaluate(() => window.__lqTest.go('home')); await page.waitForTimeout(400);
  await click(page, '[data-testid=tokens]'); await page.locator('[data-testid=treasure]').waitFor({ timeout: 5000 });
  const cnt = await page.locator('[data-testid=found-count]').textContent();
  await shot(page, `${tag}-treasure-page`);
  ok(`${tag}: each secret unlocks once (glint gone; moon only after 3 taps); House of Skulltula shows "${(cnt || '').trim()}"`, glintGone && !after1 && moon && /14 of 18/.test(cnt || ''), cnt);
  // weekly cap: cap 1 is already used this week → new tokens wait with the message
  await page.evaluate(() => { const c = JSON.parse(localStorage.getItem('familyApps.rewards.v1') || '{"version":1,"enabled":true,"rewards":[]}'); c.weeklyCap = 1; c.tokensPerTicket = 1; localStorage.setItem('familyApps.rewards.v1', JSON.stringify(c)); window.__lqTest.go('lang', { lang: 'es' }); });
  await page.waitForTimeout(800);
  await page.locator('[data-secret=cow]').click({ force: true }); await page.waitForTimeout(500);
  await page.evaluate(() => window.__lqTest.go('treasure')); await page.waitForTimeout(700);
  const capped = await page.locator('[data-testid=capped]').count(); const st = await page.evaluate(() => window.__lqTest.get().treasure);
  await shot(page, `${tag}-treasure-capped`);
  ok(`${tag}: weekly cap across apps — over the cap the token waits ("chest is full this week")`, capped === 1 && st.toChoose === 0 && st.tokens >= 1, `tokens waiting: ${st.tokens}`);
}
async function sandboxTest() {
  // exactly the Meta artifact viewer's iframe: sandbox without allow-same-origin (opaque origin: storage/IDB/SW throw)
  const ctx = await newCtx('desktop', true); const page = await ctx.newPage();
  const e0 = errors.length; watch(page, 'sandbox');
  await page.goto(URL0 + 'viewer/x/__viewer.html');
  const fr = page.frameLocator('iframe');
  await fr.locator('[data-testid=welcome]').waitFor({ timeout: 20000 });
  const note = await fr.locator('[data-testid=preview-note]').count();
  await fr.locator('[data-testid=nick]').fill('Hero'); await fr.locator('[data-testid=nick-ok]').click();
  await fr.locator('[data-testid=door-fa]').waitFor({ timeout: 8000 });
  await page.waitForTimeout(2500);
  const kitImgs = await fr.locator('img[src^="blob:"]').count();
  await shot(page, 'sandbox-01-home');
  await fr.locator('[data-testid=door-fa]').click(); await fr.locator('[data-testid=pl-start]').click(); await page.waitForTimeout(2500);
  await shot(page, 'sandbox-02-fa-placement');
  const overlay = await fr.locator('#lq-diag').count();
  const audioOk = await fr.locator('body').evaluate(async () => { const has = () => !!(window.__lqPack && Object.keys(window.__lqPack).some((k) => k.startsWith('fa-'))); for (let i = 0; i < 40 && !has(); i++) await new Promise((r) => setTimeout(r, 250)); return has(); });
  ok('artifact-viewer emulation (opaque srcdoc iframe, static refs only): boots, preview note, kit art, audio packs, no errors', note > 0 && kitImgs > 0 && !overlay && audioOk && errors.length === e0, `kit images: ${kitImgs}, audio pack: ${audioOk}, overlay: ${overlay}`);
  await ctx.close();
}

// ---- run ----
const t0 = Date.now();
if (process.env.ONLY === 'phone') {
  const p = await walkthrough('phone', false); await parentCorner(p.page, 'phone', p.ctx); await treasureTest(p.page, 'phone'); await p.ctx.close();
  await browser.close(); srv.close();
  if (!results.some((r) => /no broken images/.test(r.name))) imgSummary(process.env.ONLY || 'all');
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
await sandboxTest();
if (process.env.ONLY === 'swupdate') {
  // an updated app.js must be picked up on reload (network-first), not served from the old cache. Run on a COPY of the dist.
  const ctx = await newCtx('desktop', true); const page = await ctx.newPage(); watch(page, 'swupdate');
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
  const ctl = await page.evaluate(async () => { const r = await navigator.serviceWorker.ready; for (let i = 0; i < 40 && !navigator.serviceWorker.controller; i++) await new Promise((x) => setTimeout(x, 250)); return !!navigator.serviceWorker.controller; });
  if (!ctl) { await page.reload(); await page.waitForSelector('[data-testid=welcome]'); }
  const cacheName = await page.evaluate(async () => (await caches.keys()).join(','));
  fs.appendFileSync(path.join(DIST, 'app.js'), '\nwindow.__lqMarker=2;\n');
  await page.reload(); await page.waitForSelector('[data-testid=welcome]');
  const marker = await page.evaluate(() => window.__lqMarker || 0);
  await ctx.setOffline(true); await page.reload(); await page.waitForSelector('[data-testid=welcome]', { timeout: 15000 }).catch(() => {});
  const offlineOk = await page.locator('[data-testid=welcome]').count();
  ok('service worker: an updated app.js is used on the next reload (network-first), and the page still opens offline', marker === 2 && offlineOk > 0 && /langQuest-v6-/.test(cacheName), `cache: ${cacheName}; marker: ${marker}; offline: ${offlineOk}`);
  await ctx.close(); await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'offline') {
  const ctx = await newCtx('desktop', true); const page = await ctx.newPage(); watch(page, 'offline');
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
  await page.evaluate(() => localStorage.setItem('langQuest.state', JSON.stringify({ v: 3, nick: 'Hero', es: { level: 'sprout', placed: true }, fa: { level: 'sprout', placed: true }, settings: { mix: 'es' }, setupDone: true })));
  await page.goto(URL0); await page.waitForSelector('[data-testid=door-es]');
  await offline(ctx, page, 'desktop');
  await ctx.close(); await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'treasure') {
  // the Secret Treasures flow at both sizes (fresh profile, rewards on)
  for (const vp of ['desktop', 'phone']) {
    const ctx = await newCtx(vp, true); const page = await ctx.newPage(); watch(page, vp + '-treasure');
    await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
    await page.evaluate(() => localStorage.setItem('langQuest.state', JSON.stringify({ v: 3, nick: 'Hero', es: { level: 'sprout', placed: true }, fa: { level: 'sprout', placed: true }, settings: { mix: 'es' }, setupDone: true })));
    await page.goto(URL0); await page.waitForSelector('[data-testid=door-es]');
    await treasureTest(page, vp);
    await ctx.close();
  }
  imgSummary('treasure');
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'imgnew') {
  const T = { a: [URL0 + 'language-quest/', {}], 'a-phone': [URL0 + 'language-quest/', { vp: 'phone' }], b: ['file://' + path.join(DIST, 'index.html'), {}], 'b-phone': ['file://' + path.join(DIST, 'index.html'), { vp: 'phone' }], c: [URL0 + 'viewer/x/__viewer.html', { frame: true, dist: false }], 'c-phone': [URL0 + 'viewer/x/__viewer.html', { frame: true, dist: false, vp: 'phone' }] };
  for (const k of (process.env.TOURS || 'a,a-phone,b,b-phone,c,c-phone').split(',')) await imageTour('v6-' + k, T[k][0], { ...T[k][1], only: 'new' });
  imgSummary('imgnew ' + (process.env.TOURS || 'all'));
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'imgab') {
  await imageTour('a-subpath', URL0 + 'language-quest/');
  await imageTour('a-subpath-phone', URL0 + 'language-quest/', { vp: 'phone' });
  await imageTour('b-file', 'file://' + path.join(DIST, 'index.html'));
  imgSummary('imgab');
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'imgc') {
  await imageTour('c-viewer', URL0 + 'viewer/x/__viewer.html', { frame: true, dist: false });
  imgSummary('imgc');
  await browser.close(); srv.close();
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'images') {
  await imageTour('a-subpath', URL0 + 'language-quest/');
  await imageTour('a-subpath-phone', URL0 + 'language-quest/', { vp: 'phone' });
  await imageTour('b-file', 'file://' + path.join(DIST, 'index.html'));
  await imageTour('c-viewer', URL0 + 'viewer/x/__viewer.html', { frame: true, dist: false });
  imgSummary('images');
  await browser.close(); srv.close();
  if (!results.some((r) => /no broken images/.test(r.name))) imgSummary(process.env.ONLY || 'all');
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'desktop2') {
  // the parts that changed in the fix round: power phrases (+ whitelist check), shop, songbook, ocarina, parent corner, offline
  const ctx = await newCtx('desktop', true); const page = await ctx.newPage(); watch(page, 'desktop');
  await page.goto(URL0); await page.waitForSelector('[data-testid=welcome]');
  await page.evaluate(() => { const L = (extra) => Object.assign({ level: 'sprout', placed: true, srs: {}, units: {}, quests: 0, mistakes: {}, speak: { tries: 0, good: 0 }, writing: [], weekly: {}, songs: {}, comeback: [], script: { step: 0, done: {} } }, extra);
    localStorage.setItem('langQuest.state', JSON.stringify({ v: 3, nick: 'Hero', rupees: 0, hc: 0, chests: 0, toys: { ocarina: false }, shop: { owned: [] }, secrets: {}, reports: [], settings: { mix: 'es' }, es: L({ units: { 1: { done: true, hp: 0 } } }), fa: L({}) })); });
  await page.goto(URL0); await page.waitForSelector('[data-testid=door-es]');
  await speedAndTriplets(page, 'desktop'); await extras(page, 'desktop'); await parentCorner(page, 'desktop', ctx); await treasureTest(page, 'desktop'); await offline(ctx, page, 'desktop');
  await ctx.close(); await browser.close(); srv.close();
  if (!results.some((r) => /no broken images/.test(r.name))) imgSummary(process.env.ONLY || 'all');
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
  console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e));
  process.exit(results.every((r) => r.pass) && !errors.length ? 0 : 1);
}
if (process.env.ONLY === 'viewer') { await browser.close(); srv.close(); console.log(errors.join('\n')); process.exit(results.every((r) => r.pass) ? 0 : 1); }
const d = await walkthrough('desktop', true);
if (process.env.ONLY === 'quick') { imgSummary('quick'); await d.ctx.close(); await browser.close(); srv.close(); fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors }, null, 1)); console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks; console errors: ${errors.length}`); errors.slice(0, 20).forEach((e) => console.log('  ' + e)); process.exit(0); }
await bossWin(d.page, 'desktop');
await speedAndTriplets(d.page, 'desktop');
await extras(d.page, 'desktop');
await parentCorner(d.page, 'desktop', d.ctx);
await offline(d.ctx, d.page, 'desktop');
await d.ctx.close();
// phone: no speech recognition (record-and-compare + self-check), iPhone size
const p = await walkthrough('phone', false);
await parentCorner(p.page, 'phone', p.ctx);
await p.ctx.close();
imgSummary('all');
await browser.close(); srv.close();
const fails = results.filter((r) => !r.pass);
fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, errors, secs: Math.round((Date.now() - t0) / 1000) }, null, 1));
console.log(`\n${results.length - fails.length}/${results.length} checks passed; console errors: ${errors.length}`);
errors.slice(0, 20).forEach((e) => console.log('  ' + e));
process.exit(fails.length || errors.length ? 1 : 0);
