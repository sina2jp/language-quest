# INTEGRATION-1.1.md: what changes for the 4 app builders

This covers two shared modules: family-sync.js 1.0.x → 1.1.0 and family-wallet.js 1.1 → 1.2.

**What's new:** his son may use several laptops. Each laptop opens the family link once, and after that any of them just works: his progress follows him, and two laptops used offline are merged without losing anything. Everything in `INTEGRATION.md` still applies. This file lists only what is new.

## 1. Swap the files (required)

- Replace `family-sync.js` with 1.1.0 and `family-wallet.js` with 1.2.0, both byte-identical. The sha256 of each is in `SHA256SUMS`.
- Ship the two together: family-sync 1.1 merges the wallet 1.2 fields between laptops.
- Every 1.1 wallet call behaves exactly as before.
- The API is the same. There are no new calls you must make.
- No keys move or change shape, so your `register()` lists stay the same.
- It works against the current backend (Code.gs 1.0) and the new one (Code.gs 1.1). Multi-laptop conflict checks start once the parent updates the script (`UPDATE.md`). It is safe to ship your app before or after that.

## 2. Your own progress key now arrives by `familysync:update` in normal use (required: check this path)

- **1.0.x:** your own progress key changed only after a first connect.
- **1.1:** it changes whenever he played on another laptop. The module takes the newer cloud copy when this laptop did not change the key, then fires `familysync:update` with `source: 'pull'` and your key in `detail.keys`. It also fires on start, on focus, and on the 60 s pull.

What your app must do (one handler covers it):

```js
window.addEventListener('familysync:update', (e) => {
  const mine = e.detail.keys.filter((k) => MY_PROGRESS_KEYS.includes(k));
  if (!mine.length) return;                                // settings: re-read as before (INTEGRATION.md §8)
  if (calmScreen()) location.reload();                     // Home, map, results: reload now
  else { pendingReload = true; dirtyFromCloud = true; }    // mid-lesson: reload at the next calm moment
});
```

- **Never save your in-memory copy over a newer stored copy.** If `dirtyFromCloud` is set, finish the lesson, then reload instead of saving the old state, or re-read storage and merge your one change into it.
- **The safety net:** for 60 s after a download, the module's guard catches a save with less progress than the downloaded copy. It restores the downloaded copy, fires `source: 'guard'`, and keeps the overwrite in the backup (`FS.log()` shows it). After 60 s it can no longer tell, so the reload rule above is what keeps the newer progress.
- **`source` values:** `'pull'`, `'connect'`, `'guard'`, `'repair'`, `'requests'` and `'tab'`. Treat `'pull'`, `'connect'` and `'guard'` the same for your own keys.

## 3. Register a score function for your progress (strongly recommended)

When he used two laptops offline and both changed your app's progress, the copy with **more progress** wins. The other copy is kept for 30 days in `familyApps.backup.<app>.v1`, with a line in `FS.log()`.

- The built-in score counts items in lists, object keys and small counters, and ignores timestamps.
- Your own score function is better. It receives `{key: parsedValue}` for your progress keys and returns a number:

```js
FS.register('math', { /* same lists */, score: (v) => {
  const d = v['mathArena.v3.data.v1'] || {}; const p = d.progress || {};
  return (d.reports || []).length * 10 + Object.keys(p.seen || {}).length + Object.keys(p.relics || {}).length * 5;
} });
```

Suggested scores:

| App | Score from |
|---|---|
| math | reports (quests finished) × 10 + problems seen + relics/mastery pages × 5 |
| language | `es` + `fa`: words learned (`srs` entries) + quests × 5 + units done × 10 |
| code | lessons done × 10 + games built × 20 + quiz answered |
| music | lessons done × 10 + practice minutes + belts × 20 |

**Wallet, tickets, inventory and minutes are merged by the module.** They are unions by id, so no shards, rupees, tickets or minutes are lost or doubled. Your code changes nothing for these.

## 4. Small notes

- **"Replaced" is gone.** A laptop that 1.0.x paused as "replaced" resumes by itself after the swap. `status().paused` is now only ever `''` or `'too-big'`.
- **Startup:** on a slow backend start the dot stays "☁ syncing…" until the 20 s retry finishes, instead of flashing "offline". Startup still never blocks rendering.
- **Re-opening the family link** on a laptop that is already connected just syncs. Nothing merges twice.
- **Check that nothing writes progress at load.** You already don't, but it matters more now: a write at load on an idle laptop would compete with the laptop he is really using.
- **Test checklist:**
  1. Two browser profiles both joined: play in A, then focus B. B's app reloads at a calm moment with A's progress.
  2. Both profiles offline, play in each, back online: the shards from both add up, and your progress shows the copy with more progress.
  3. `FS.log()` shows the merge.


## 5. family-wallet.js 1.2: rewards only for new learning (anti-farming)

**The problem:** a 1-minute easy lesson repeated every minute paid +2 shards each time, about 30 shards in 15 minutes. The parent's rule: he gets rewards only when he has truly learned something and passed it. Easy content he has already passed pays nothing again.

The parent controls this in the Hub under Rewards. Two settings reach every laptop through family-sync:
- **Rewards only for new learning (no repeats):** on by default.
- **Max lesson shards per app per day:** default 6.

### New calls (exact names)

```js
FW.earnOnce(app, onceId, shards, label)   // → { paid, banked, reason: 'repeat' | 'cap' | 'guessing' | null }
FW.rupeesOnce(app, itemId, rupees, label) // → rupees paid (0 for a repeat)
FW.tickActive(app, ms, { repeat: true })  // review minutes: counted, no shards
FW.startTracker(app, { isLearning, isRepeat: () => inReviewOrGraduatedContent })
FW.releaseBanked(app)                     // optional, at start: pays banked shards that are due (writes only then)
FW.policy()   // { noRepeats, onceDailyCap, rupeeDays: 30, … }
FW.daily()    // { 'YYYY-MM-DD': { app: { repeat, repeatRupees, banked, released } } }
FW.bankedNow() // { app: shards waiting }
```

**`earnOnce`:**
- **Once ever:** it pays only the first time `(app, onceId)` is ever earned, on any of his laptops.
  - The ledger event has the fixed id `once:<app>:<onceId>`, and the wallet keeps a compact set of earned onceIds.
  - Two laptops paying the same onceId offline count it once after they sync.
- **Daily cap:** at most `onceDailyCap` such shards per app per day. The rest is **banked** and paid on a later day, oldest first, within that day's cap.
  - True learning is never lost, but it can't be sprinted.
  - The cap holds across laptops: the merge banks any excess.
- **Repeats** return `reason: 'repeat'` and pay 0. They add no ledger line, only a daily counter, which the Hub shows as one summary row.
- **`'guessing'`:** returned during the wallet's 60 s rapid-guessing pause. Nothing is paid and the onceId is not used up.

**`rupeesOnce`:**
- Pays only for the first correct answer on `itemId` in 30 days. Each app remembers at most 5,000 ids, and the oldest are dropped.
- Repeats pay 0 and are only counted.
- Paid rupees go into one growing ledger line per app per day.

**When the parent turns the rule off:** repeats pay again, and repeat minutes earn shards. The daily cap still applies.

### What each app should change

Call `earnOnce` only when he **passed** (good grade, mastered, or beat), and give each passable thing a stable onceId:

| App | Replace | With (examples) |
|---|---|---|
| math | `finishUnit('math', …)` on a quest | `earnOnce('math', 'codex:<pageId>:mastered', 2, title)`, `earnOnce('math', 'quest:<id>:pass', 2, …)`; boss: `earnOnce('math', 'guardian:<id>', 3, …)` |
| language | `finishUnit('language', …)` per lesson | `earnOnce('language', 'lesson:<lang>-<unit>-<lesson>:pass', 2, title)` when the lesson's score passes; boss: `'boss:<id>'` |
| code | `finishUnit('code', …)` per build/lesson | `earnOnce('code', 'lesson:<id>:pass', 2, …)`, `earnOnce('code', 'game:<id>:built', 2, …)` (first build of each game) |
| music | `finishUnit('music', …)` | `earnOnce('music', 'level:<id>:pass', 2, …)`, `earnOnce('music', 'piece:<id>:<tempo>:pass', 2, …)` |
| all | `answer(app, true, lessonId)` | `rupeesOnce(app, '<itemId>', 1, 'New correct answers')`, where itemId is the question or word id. Keep calling `answer(app, false, …)` for wrong answers: it still drives the rapid-guessing check. |
| all | `startTracker(app, { isLearning })` | `startTracker(app, { isLearning, isRepeat: () => inGraduatedOrReview() })` |

- **Ranks and old shards:** rupee ranks still use lifetime earned. Nothing already earned is taken away.
- **Graduation:** "graduated" means he passed that level with good grades. Your app decides the threshold, and then calls `earnOnce` exactly once for it.
- **Old calls:** the 1.1 calls (`finishUnit`, `beatBoss`, `answer`, `earn`, `comeback`, `secret`, `tickActive` without opts) still work and pay as before. Use them only for things that can't repeat, or leave them until you switch.
